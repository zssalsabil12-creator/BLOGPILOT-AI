// Generates prisma/schema.postgres.prisma from prisma/schema.prisma with the
// datasource provider switched to "postgresql".
//
// Prisma does not allow env() in the provider field, so production builds use
// this generated copy while local development keeps using the SQLite original.
// The generated file is deterministic and safe to regenerate at any time.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = path.join(root, 'prisma', 'schema.prisma');
const target = path.join(root, 'prisma', 'schema.postgres.prisma');

let content = fs.readFileSync(source, 'utf8');

const block = /datasource\s+db\s*\{[\s\S]*?\}/;
if (!block.test(content)) {
  console.error('make-postgres-schema: no datasource block found in schema.prisma');
  process.exit(1);
}

content = content.replace(block, (match) =>
  match
    .replace(/provider\s*=\s*"(sqlite|postgresql)"/, 'provider = "postgresql"')
    // Relative SQLite file URLs are meaningless for Postgres; swap to the env var.
    .replace(/url\s*=\s*"[^"]*"/, 'url      = env("DATABASE_URL")'),
);

fs.writeFileSync(target, content, 'utf8');
console.log('Generated prisma/schema.postgres.prisma (provider = postgresql)');
