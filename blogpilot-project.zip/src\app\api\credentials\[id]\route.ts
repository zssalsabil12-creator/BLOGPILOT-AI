﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { encrypt } from '@/lib/encryption';

const updateCredentialSchema = z.object({
  apiKey: z.string().max(500).optional().nullable(),
  apiSecret: z.string().max(500).optional().nullable(),
  trackingId: z.string().max(200).optional().nullable(),
  isActive: z.boolean().optional(),
});

function maskSecret(value?: string | null): string | null {
  if (!value) return null;
  const trimmed = value.trim();
  if (trimmed.length <= 6) return '••••••';
  return `${trimmed.slice(0, 3)}${'•'.repeat(Math.min(trimmed.length - 5, 24))}${trimmed.slice(-2)}`;
}

function publicCredential(cred: {
  id: string;
  platform: string;
  apiKey?: string | null;
  apiSecret?: string | null;
  trackingId?: string | null;
  isActive: boolean;
  status: string;
  createdAt: Date;
}) {
  return {
    id: cred.id,
    platform: cred.platform,
    hasApiKey: !!cred.apiKey,
    hasApiSecret: !!cred.apiSecret,
    apiKeyMasked: maskSecret(cred.apiKey),
    apiSecretMasked: maskSecret(cred.apiSecret),
    trackingId: cred.trackingId,
    isActive: cred.isActive,
    status: cred.status,
    createdAt: cred.createdAt,
  };
}

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const credential = await prisma.affiliateKey.findFirst({ where: { id, userId } });
    if (!credential) return NextResponse.json({ ok: false, error: 'Credential not found' }, { status: 404 });

    return NextResponse.json({
      ok: true,
      data: { credential: publicCredential(credential) },
    });
  } catch (error: any) {
    console.error('Get credential error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load credential' }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = updateCredentialSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const existing = await prisma.affiliateKey.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Credential not found' }, { status: 404 });

    const data: any = { ...parsed.data };
    if (parsed.data.isActive === false) data.status = 'disconnected';
    if (parsed.data.isActive === true) data.status = 'connected';

    if (data.apiKey !== undefined && data.apiKey !== null) {
      data.apiKey = encrypt(data.apiKey);
    }
    if (data.apiSecret !== undefined && data.apiSecret !== null) {
      data.apiSecret = encrypt(data.apiSecret);
    }

    const credential = await prisma.affiliateKey.update({ where: { id }, data });

    return NextResponse.json({
      ok: true,
      data: { credential: publicCredential(credential) },
    });
  } catch (error: any) {
    console.error('Update credential error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to update credential' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const existing = await prisma.affiliateKey.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Credential not found' }, { status: 404 });

    await prisma.affiliateKey.delete({ where: { id } });
    return NextResponse.json({ ok: true, data: { deleted: true, id } });
  } catch (error: any) {
    console.error('Delete credential error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to delete credential' }, { status: 500 });
  }
}