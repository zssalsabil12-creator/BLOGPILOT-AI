import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { buildSerpIntelligence } from '@/lib/serp-intelligence';
import { computeInformationGain } from '@/lib/information-gain';

const bodySchema = z.object({
  keyword: z.string().min(2).max(200),
  articleId: z.string().max(64).optional().nullable(),
  /** Compare against pasted content instead of a saved article. */
  content: z.string().max(120_000).optional(),
});
export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const limit = await checkRateLimit(`serp-gap:${userId}`, { windowMs: 60_000, maxRequests: 4 });
  if (!limit.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Analysis limit reached — try again in a minute.' },
      { status: 429 },
    );
  }

  const { keyword, articleId, content } = parsed.data;

  // Resolve "our" side of the comparison. When neither is provided we return
  // SERP intelligence only (no Information Gain) — nothing fabricated.
  let ourContent = content || '';
  if (articleId) {
    const article = await prisma.article.findFirst({
      where: { id: articleId, userId },
      select: { content: true },
    });
    if (!article) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });
    ourContent = article.content || '';
  }

  try {
    const intel = await buildSerpIntelligence(keyword);

    if (intel.competitors.length === 0) {
      return NextResponse.json(
        { ok: false, error: 'Could not fetch search results for this keyword. Try again shortly.' },
        { status: 502 },
      );
    }

    const hasOurSide = ourContent.trim().length > 0;
    const informationGain = hasOurSide
      ? computeInformationGain(ourContent, intel, { competitorTexts: intel.competitorTexts })
      : null;

    // Our coverage of the entity set the top results share.
    const ourCoveragePct =
      informationGain && intel.commonEntities.length
        ? Math.round((informationGain.coveredEntities.length / intel.commonEntities.length) * 100)
        : null;

    return NextResponse.json({
      ok: true,
      data: {
        keyword,
        serp: {
          intent: intel.intent,
          format: intel.format,
          avgWordCount: intel.avgWordCount,
          maxWordCount: intel.maxWordCount,
          competitors: intel.competitors.map(c => ({
            url: c.url,
            title: c.title,
            position: c.position,
            wordCount: c.wordCount,
            h2Count: c.h2Count,
            hasFaq: c.hasFaq,
          })),
          commonEntities: intel.commonEntities,
          partialEntities: intel.partialEntities,
          questions: intel.questions,
          blindSpots: intel.serpBlindSpots,
          aiPowered: intel.aiPowered,
        },
        gap: {
          ourCoveragePct,
          missingEntities: informationGain?.missingEntities ?? [],
          unansweredQuestions: informationGain?.unansweredQuestions ?? intel.questions.slice(0, 6),
          blindSpotOpportunities: intel.serpBlindSpots,
        },
        informationGain,
      },
    });
  } catch (error: any) {
    console.error('SERP gap error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'SERP analysis failed' },
      { status: 502 },
    );
  }
}
