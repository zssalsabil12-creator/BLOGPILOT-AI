﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { generateText } from '@/lib/gemini';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { apiError } from '@/lib/utils';
import { checkTextLength } from '@/lib/input-limits';

const bodySchema = z.object({
  query: z.string().min(3).max(250),
  targetKeyword: z.string().max(200).optional(),
  language: z.string().max(10).optional().default('en'),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const ip = getClientIp(req);
  const rl = await checkRateLimit(`generate-outline:${userId}:${ip}`, RATE_LIMITS.generate);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON payload' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const inputSizeCheck = checkTextLength(parsed.data.query, 500);
  if (!inputSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: inputSizeCheck.error }, { status: 413 });
  }

  const { query, targetKeyword, language } = parsed.data;

  const prompt = `Create a detailed article outline for the topic: "${query}".
${targetKeyword ? `Target keyword: "${targetKeyword}".` : ''}
Language: ${language}.

Return a JSON object with exactly this structure:
{
  "title": "Suggested article title",
  "metaDescription": "150-char meta description",
  "outline": [
    { "heading": "H2 heading text", "subheadings": ["H3 subheading 1", "H3 subheading 2"] }
  ],
  "keywords": ["keyword1", "keyword2", "keyword3", "keyword4", "keyword5"],
  "faq": ["Question 1?", "Question 2?", "Question 3?"]
}

Include at least 8 outline sections with H2 headings. Make it comprehensive and SEO-optimized. Return ONLY valid JSON, no markdown.`;

  try {
    const result = await generateText(prompt, 2000);
    let parsed;
    try {
      const cleaned = result.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      parsed = JSON.parse(cleaned);
    } catch {
      parsed = {
        title: query,
        metaDescription: result.slice(0, 155),
        outline: [{ heading: 'Overview', subheadings: [] }],
        keywords: targetKeyword ? [targetKeyword] : [],
        faq: [],
        rawText: result,
      };
    }

    return NextResponse.json({ ok: true, data: parsed });
  } catch (err) {
    return apiError('generate-outline', err);
  }
}
