/**
 * Deterministic, dependency-free SEO scoring for generated/saved articles.
 *
 * This is an honest, explainable on-page score — NOT a ranking guarantee.
 * It analyzes what search engines can verify on the page itself:
 * title quality, keyword placement/density, structure, depth, links and
 * readability proxies. Language-neutral (works for Arabic + Latin scripts).
 */

export interface SeoCheck {
  key: string;
  label: string;
  score: number;
  max: number;
  status: 'good' | 'warn' | 'bad';
  detail: string;
}

export interface SeoScoreResult {
  score: number;
  checks: SeoCheck[];
}

export interface SeoScoreInput {
  title?: string | null;
  content?: string | null;
  excerpt?: string | null;
  targetKeyword?: string | null;
}

/** Strip markdown formatting so analysis runs on plain text. */
function markdownToPlainText(md: string): string {
  return md
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`[^`]*`/g, ' ')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/[*_~>|]/g, ' ')
    .replace(/^\s*[-+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function countWords(text: string): number {
  if (!text) return 0;
  return text.split(/\s+/).filter(Boolean).length;
}

function countSentences(text: string): number {
  // Sentence terminators across Arabic (.؟!…) and Latin (.?!)
  const parts = text.split(/[.!?؟…]+/).map(s => s.trim()).filter(Boolean);
  return parts.length;
}

function clamp(n: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, n));
}

export function computeSeoScore(input: SeoScoreInput): SeoScoreResult {
  const title = (input.title || '').trim();
  const content = input.content || '';
  const excerpt = (input.excerpt || '').trim();
  const keyword = (input.targetKeyword || '').trim().toLowerCase();
  const plain = markdownToPlainText(content);
  const words = countWords(plain);
  const lowerPlain = plain.toLowerCase();
  const checks: SeoCheck[] = [];

  // 1. Title length (max 8)
  {
    const len = title.length;
    let score = 0;
    let detail: string;
    if (len >= 30 && len <= 60) { score = 8; detail = `Title length is optimal (${len} characters).`; }
    else if (len > 0 && len < 30) { score = 4; detail = `Title is short (${len} chars) — aim for 30-60.`; }
    else if (len > 60 && len <= 80) { score = 5; detail = `Title is long (${len} chars) — may be truncated in SERP.`; }
    else if (len > 80) { score = 2; detail = `Title is very long (${len} chars) — will be cut off.`; }
    else { detail = 'Missing title.'; }
    checks.push({ key: 'title-length', label: 'Title length', score, max: 8, status: score >= 8 ? 'good' : score >= 4 ? 'warn' : 'bad', detail });
  }

  // 2. Keyword in title (max 12)
  {
    let score = 0;
    let detail = 'No target keyword set — add one to guide optimization.';
    if (keyword) {
      if (title.toLowerCase().includes(keyword)) {
        score = title.toLowerCase().indexOf(keyword) <= 30 ? 12 : 9;
        detail = score === 12 ? 'Target keyword appears early in the title.' : 'Keyword is in the title but appears late.';
      } else {
        detail = 'Target keyword is missing from the title.';
      }
    }
    checks.push({ key: 'keyword-title', label: 'Keyword in title', score, max: 12, status: score >= 9 ? 'good' : score >= 5 ? 'warn' : 'bad', detail });
  }

  // 3. Keyword placement — first ~100 words (max 10)
  {
    const firstWords = lowerPlain.split(/\s+/).slice(0, 100).join(' ');
    let score = 0;
    let detail = 'No target keyword set.';
    if (keyword) {
      if (firstWords.includes(keyword)) { score = 10; detail = 'Keyword appears within the first 100 words.'; }
      else { detail = 'Add the target keyword to the introduction.'; }
    }
    checks.push({ key: 'keyword-placement', label: 'Keyword placement', score, max: 10, status: score >= 10 ? 'good' : score > 0 || !keyword ? 'warn' : 'bad', detail });
  }

  // 4. Meta description / excerpt (max 10)
  {
    const len = excerpt.length;
    let score = 0;
    let detail: string;
    if (len >= 120 && len <= 165) { score = 10; detail = `Meta description length is optimal (${len} chars).`; }
    else if (len > 0 && len < 120) { score = 5; detail = `Meta description is short (${len} chars) — aim for 120-160.`; }
    else if (len > 165) { score = 5; detail = `Meta description is long (${len} chars) — it will be truncated.`; }
    else { detail = 'No meta description/excerpt — add one (120-160 chars).'; }
    checks.push({ key: 'meta-description', label: 'Meta description', score, max: 10, status: score >= 10 ? 'good' : score >= 5 ? 'warn' : 'bad', detail });
  }

  // 5. Heading structure (max 14)
  {
    const h2 = (content.match(/^##\s+/gm) || []).length;
    const h3 = (content.match(/^###\s+/gm) || []).length;
    let score = 0;
    let detail: string;
    if (h2 >= 3 && h3 >= 2) { score = 14; detail = `Strong hierarchy: ${h2} H2 and ${h3} H3 sections.`; }
    else if (h2 >= 2) { score = 11; detail = `${h2} H2 sections found — consider adding more H3 subsections.`; }
    else if (h2 === 1) { score = 6; detail = 'Only one H2 section — break the content into more sections.'; }
    else { detail = 'No H2 headings — add structured sections (## in markdown).'; }
    checks.push({ key: 'headings', label: 'Heading structure', score, max: 14, status: score >= 11 ? 'good' : score >= 6 ? 'warn' : 'bad', detail });
  }

  // 6. Content depth (max 16)
  {
    let score = 0;
    let detail: string;
    if (words >= 1500) { score = 16; detail = `In-depth article (${words} words).`; }
    else if (words >= 800) { score = 13; detail = `Good depth (${words} words).`; }
    else if (words >= 400) { score = 9; detail = `Moderate length (${words} words) — top results usually go deeper.`; }
    else if (words >= 150) { score = 4; detail = `Thin content (${words} words).`; }
    else { detail = `Very thin content (${words} words).`; }
    checks.push({ key: 'content-depth', label: 'Content depth', score, max: 16, status: score >= 13 ? 'good' : score >= 9 ? 'warn' : 'bad', detail });
  }

  // 7. Keyword density (max 10) — healthy range 0.4%-2.5%
  {
    let score = 0;
    let detail = 'No target keyword set.';
    if (keyword && words > 0) {
      const kwWords = keyword.split(/\s+/).filter(Boolean);
      let occurrences = 0;
      if (kwWords.length === 1) {
        occurrences = kwWords[0].length >= 3
          ? (lowerPlain.match(new RegExp(kwWords[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length
          : 0;
      } else {
        const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        occurrences = (lowerPlain.match(new RegExp(escaped, 'g')) || []).length;
      }
      const density = (occurrences * Math.max(kwWords.length, 1)) / Math.max(words, 1) * 100;
      if (density >= 0.4 && density <= 2.5) { score = 10; detail = `Keyword density ${density.toFixed(1)}% is in a natural range.`; }
      else if (density > 2.5 && density <= 4) { score = 4; detail = `Keyword density ${density.toFixed(1)}% is high — risk of over-optimization.`; }
      else if (density > 4) { score = 0; detail = `Keyword density ${density.toFixed(1)}% is excessive — reduce repetition.`; }
      else { score = 4; detail = `Keyword density ${density.toFixed(1)}% is low — mention it naturally a few more times.`; }
    }
    checks.push({ key: 'keyword-density', label: 'Keyword usage', score, max: 10, status: score >= 10 ? 'good' : score >= 4 ? 'warn' : 'bad', detail });
  }

  // 8. Links (max 6)
  {
    const links = (content.match(/\[[^\]]+\]\((https?:\/\/|\/|#)[^)]*\)/g) || []).length;
    let score = 0;
    let detail: string;
    if (links >= 3) { score = 6; detail = `${links} links included.`; }
    else if (links >= 1) { score = 3; detail = `${links} link found — add a few more relevant links.`; }
    else { detail = 'No links — add internal or authoritative external links.'; }
    checks.push({ key: 'links', label: 'Links', score, max: 6, status: score >= 6 ? 'good' : score >= 3 ? 'warn' : 'bad', detail });
  }

  // 9. Structured elements: lists & tables (max 4)
  {
    const lists = (content.match(/^\s*([-+]|\d+\.)\s+/gm) || []).length;
    const tables = (content.match(/^\|.+\|$/gm) || []).length;
    const hasList = lists >= 3;
    const hasTable = tables >= 4;
    const score = hasTable ? 4 : hasList ? 3 : 0;
    const detail = hasTable ? 'Contains list and table elements.'
      : hasList ? 'Contains lists — a comparison table could add value.'
      : 'No lists or tables — scannable formats improve engagement.';
    checks.push({ key: 'structured-elements', label: 'Lists & tables', score, max: 4, status: score >= 4 ? 'good' : score >= 3 ? 'warn' : 'bad', detail });
  }

  // 10. Readability proxy — average sentence length (max 10)
  {
    const sentences = countSentences(plain);
    const avgLen = sentences > 0 ? words / sentences : words;
    let score = 0;
    let detail: string;
    if (sentences < 3) { score = 5; detail = 'Not enough sentences to evaluate readability.'; }
    else if (avgLen <= 20) { score = 10; detail = `Easy to read (avg. ${Math.round(avgLen)} words per sentence).`; }
    else if (avgLen <= 28) { score = 7; detail = `Readable (avg. ${Math.round(avgLen)} words per sentence) — shorter sentences would help.`; }
    else { score = 3; detail = `Dense paragraphs (avg. ${Math.round(avgLen)} words per sentence) — split long sentences.`; }
    checks.push({ key: 'readability', label: 'Readability', score, max: 10, status: score >= 10 ? 'good' : score >= 7 ? 'warn' : 'bad', detail });
  }

  const total = checks.reduce((sum, c) => sum + c.score, 0);
  const maxTotal = checks.reduce((sum, c) => sum + c.max, 0);
  const score = clamp(Math.round((total / maxTotal) * 100), 0, 100);

  return { score, checks };
}
