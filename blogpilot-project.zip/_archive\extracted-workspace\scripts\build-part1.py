#!/usr/bin/env python3
"""
Part 1: Config files + lib/ + API routes + prisma/
"""

import os

BASE = "/home/z/my-project"
OUTPUT = "/home/z/my-project/download/BlogPilot-Code-Part1-Config-Lib-API.txt"

TARGET_PREFIXES = [
    "package.json", "tsconfig.json", "next.config.ts", "tailwind.config.ts",
    "postcss.config.mjs", "eslint.config.mjs", "components.json",
    "vercel.json", "Dockerfile", "Caddyfile", "README.md",
    "prisma/", "src/lib/", "src/app/api/", "src/app/layout.tsx", 
    "src/app/page.tsx", "src/app/globals.css", "src/hooks/"
]

def matches(rel):
    for prefix in TARGET_PREFIXES:
        if rel == prefix or rel.startswith(prefix):
            return True
    return False

def skip_dir(rel):
    skip = {"node_modules", ".next", ".git", "download", "scripts", "tests",
            "examples", "skills", "mini-services", "tool-results"}
    parts = rel.replace(os.sep, "/").split("/")
    return any(p in skip for p in parts)

def main():
    files = []
    for root, dirs, fnames in os.walk(BASE):
        dirs[:] = [d for d in dirs if d not in {"node_modules", ".next", ".git", "download",
            "scripts", "tests", "examples", "skills", "mini-services", "tool-results"}]
        for f in fnames:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, BASE).replace(os.sep, "/")
            if not skip_dir(rel) and matches(rel):
                files.append((rel, full))
    files.sort()
    
    with open(OUTPUT, "w", encoding="utf-8") as out:
        out.write("BlogPilot AI - Source Code Part 1\n")
        out.write("Config + Libraries + API Routes + Database\n")
        out.write("=" * 60 + "\n\n")
        
        cur = None
        for rel, full in files:
            top = rel.split("/")[0] if "/" in rel else "(root)"
            if top != cur:
                cur = top
                out.write(f"\n{'#' * 60}\n# {top}/\n{'#' * 60}\n\n")
            out.write(f"# --- {rel} ---\n")
            try:
                with open(full, "r", encoding="utf-8") as f:
                    c = f.read()
                out.write(c)
                if not c.endswith("\n"): out.write("\n")
            except Exception as e:
                out.write(f"# [ERROR: {e}]\n")
            out.write("\n\n")
    
    sz = os.path.getsize(OUTPUT)
    print(f"Part 1: {len(files)} files, {sz:,} bytes ({sz/1024:.1f} KB)")

if __name__ == "__main__":
    main()
