'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { CheckCircle, XCircle, Wallet, Loader2, AlertTriangle, KeyRound, ShieldCheck, Info } from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'

interface Gateway {
  name: string
  connected: boolean
}

const GATEWAY_NAMES = ['Stripe', 'PayPal', 'Payeer', 'Airtm']

const GATEWAY_HINTS: Record<string, string> = {
  Stripe: 'Restricted API key (sk_live_… or rk_live_…) — used for checkout configuration checks.',
  PayPal: 'Client ID and secret, separated by "|".',
  Payeer: 'Merchant ID and secret, separated by "|".',
  Airtm: 'API token issued for your merchant account.',
}

const gatewayColors: Record<string, string> = {
  Stripe: 'from-indigo-500/15 to-blue-500/15 text-indigo-400 border-indigo-500/20',
  PayPal: 'from-sky-500/15 to-cyan-500/15 text-sky-400 border-sky-500/20',
  Payeer: 'from-emerald-500/15 to-teal-500/15 text-emerald-400 border-emerald-500/20',
  Airtm: 'from-violet-500/15 to-purple-500/15 text-violet-400 border-violet-500/20',
}

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
}

const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
}

export default function AffiliateCredentialsPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [savingGateway, setSavingGateway] = useState<string | null>(null)
  const [message, setMessage] = useState<{ ok: boolean; message: string } | null>(null)
  const [keys, setKeys] = useState<Record<string, string>>({})
  const [gateways, setGateways] = useState<Gateway[]>(GATEWAY_NAMES.map(name => ({ name, connected: false })))

  const loadGateways = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/credentials')
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to load credentials')
      const platforms = json?.data?.platforms || []
      setGateways(GATEWAY_NAMES.map(name => {
        const info = platforms.find((p: any) => p.platform === name)
        return { name, connected: !!info?.connected }
      }))
      setError(null)
    } catch (err: any) {
      console.error('Load credentials error:', err)
      setError(err?.message || 'Failed to load credentials')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadGateways()
  }, [loadGateways])

  const connectedCount = gateways.filter(g => g.connected).length

  const connectGateway = async (name: string) => {
    const apiKey = (keys[name] || '').trim()
    if (!apiKey) return
    setSavingGateway(name)
    setMessage(null)
    try {
      const res = await fetch('/api/credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ platform: name, apiKey, apiSecret: apiKey.split('|')[1] || undefined }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to connect')
      setMessage({ ok: true, message: `${name} connected successfully.` })
      setKeys(prev => ({ ...prev, [name]: '' }))
      await loadGateways()
    } catch (err: any) {
      console.error('Connect gateway error:', err)
      setMessage({ ok: false, message: err?.message || 'Failed to connect' })
    } finally {
      setSavingGateway(null)
    }
  }

  const disconnectGateway = async (name: string) => {
    setSavingGateway(name)
    try {
      const res = await fetch('/api/credentials')
      const json = await res.json()
      const cred = (json?.data?.credentials || []).find((c: any) => c.platform === name)
      if (cred) {
        await fetch(`/api/credentials/${cred.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ isActive: false }),
        })
      }
      setMessage({ ok: true, message: `${name} disconnected.` })
      await loadGateways()
    } catch (err: any) {
      console.error('Disconnect gateway error:', err)
      setMessage({ ok: false, message: err?.message || 'Failed to disconnect' })
    } finally {
      setSavingGateway(null)
    }
  }

  return (
    <div className="min-h-screen p-6 md:p-10">
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <h1 className="text-2xl font-bold text-foreground">Payment Gateway Credentials</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Connect the payment providers your business uses. Keys are stored server-side and never displayed again.
        </p>
      </motion.div>

      {message && (
        <div className={cn(
          'mb-6 flex items-center gap-3 px-4 py-3 rounded-xl border text-sm',
          message.ok
            ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
            : 'bg-red-500/10 border-red-500/20 text-red-400'
        )}>
          {message.ok
            ? <CheckCircle className="w-4 h-4 shrink-0" />
            : <AlertTriangle className="w-4 h-4 shrink-0" />}
          {message.message}
        </div>
      )}

      {error && (
        <div className="mb-6 flex items-center justify-between gap-3 px-4 py-3 rounded-xl border border-red-500/20 bg-red-500/10 text-sm text-red-400">
          <span>{error}</span>
          <Button variant="ghost" size="sm" onClick={loadGateways} className="text-red-400 hover:text-red-300">
            Retry
          </Button>
        </div>
      )}

      <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
        <motion.div variants={item}>
          <Card className="bg-card/50 border border-border backdrop-blur-xl overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center border border-cyan-500/20">
                    <KeyRound className="w-7 h-7 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Connected Providers</p>
                    <p className="text-3xl font-bold text-gradient">{connectedCount}/{gateways.length}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 max-w-md px-4 py-3 rounded-xl border border-border bg-muted/30">
                  <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Connecting a provider here does not move money or create payouts — it stores the credentials
                    your account needs to use that provider&apos;s checkout features. Earnings and payout reporting
                    will appear here once a provider integration reports real data.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Providers</h2>
            <Badge variant="secondary" className="bg-muted/70 text-muted-foreground border-0">
              {connectedCount}/{gateways.length} Connected
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {gateways.map(gateway => (
              <motion.div key={gateway.name} variants={item}>
                <Card className={cn(
                  'bg-card/50 border backdrop-blur-xl hover:border-border transition-all duration-300',
                  gateway.connected ? 'border-border' : 'border-border/50'
                )}>
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className={cn('w-10 h-10 rounded-xl bg-gradient-to-br flex items-center justify-center border', gatewayColors[gateway.name])}>
                          <Wallet className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="text-foreground font-medium">{gateway.name}</h3>
                          <span className="flex items-center gap-1 text-xs">
                            {gateway.connected ? (
                              <span className="text-emerald-400 flex items-center gap-1">
                                <CheckCircle className="w-3 h-3" /> Connected
                              </span>
                            ) : (
                              <span className="text-muted-foreground flex items-center gap-1">
                                <XCircle className="w-3 h-3" /> Not connected
                              </span>
                            )}
                          </span>
                        </div>
                      </div>
                      {gateway.connected ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => disconnectGateway(gateway.name)}
                          disabled={savingGateway === gateway.name}
                          className="text-muted-foreground hover:text-red-400 hover:bg-red-500/10 text-xs"
                        >
                          {savingGateway === gateway.name ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" />
                          ) : null}
                          Disconnect
                        </Button>
                      ) : (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => connectGateway(gateway.name)}
                          disabled={savingGateway === gateway.name || !(keys[gateway.name] || '').trim()}
                          className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 text-xs"
                        >
                          {savingGateway === gateway.name ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin mr-1" />
                          ) : null}
                          Connect
                        </Button>
                      )}
                    </div>
                    {!gateway.connected && (
                      <>
                        <Input
                          type="password"
                          placeholder={`Enter ${gateway.name} credentials`}
                          value={keys[gateway.name] || ''}
                          onChange={e => setKeys(prev => ({ ...prev, [gateway.name]: e.target.value }))}
                          className="mb-2 bg-muted/50 border-border text-foreground placeholder:text-muted-foreground focus-visible:ring-primary h-9 text-sm"
                        />
                        <p className="text-[11px] text-muted-foreground mb-1">{GATEWAY_HINTS[gateway.name]}</p>
                      </>
                    )}
                    <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border/50">
                      <div>
                        <p className="text-xs text-muted-foreground mb-0.5">Status</p>
                        <p className={cn('text-sm font-semibold', gateway.connected ? 'text-emerald-400' : 'text-muted-foreground')}>
                          {gateway.connected ? 'Active' : 'Inactive'}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-0.5">Payout Data</p>
                        <p className="text-sm text-muted-foreground">No data yet</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div variants={item}>
          <Card className="bg-card/50 border border-border backdrop-blur-xl">
            <CardContent className="p-5 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="text-foreground font-medium text-sm mb-1">How your keys are handled</h3>
                <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Keys are validated, stored server-side, and never returned in full after saving.</li>
                  <li>Requests are rate-limited and every access is tied to your authenticated session.</li>
                  <li>To rotate a key: disconnect the provider, then reconnect with the new key.</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  )
}
