/**
 * Lightweight site crawler for the internal-link graph.
 *
 * Strategy: sitemap.xml first (cheap + complete), fallback to BFS from the
 * homepage. Every URL passes SSRF validation before fetch; concurrency is
 * capped and results are cached (public site data, global key by URL digest).
 */

import { validateFetchUrl } from './url-validator';
import { cacheGet, cacheSet, hashKeyParts } from './cache';

export interface CrawledPage {
  url: string;
  path: string;
  title?: string;
  wordCount: number;
  outboundInternal: string[]; // paths
}

export interface CrawlGraph {
  root: string;
  pages: CrawledPage[];
  inboundCount: Map<string, number>;
  orphanPaths: string[];
  source: 'sitemap' | 'crawl' | 'mixed';
  crawledAt: string;
}

const MAX_PAGES = Number(process.env.CRAWL_MAX_PAGES || 30);
const FETCH_TIMEOUT_MS = 10_000;

function normalizeToPath(urlStr: string, baseUrl: URL): string | null {
  try {
    const u = new URL(urlStr, baseUrl);
    if (u.hostname !== baseUrl.hostname) return null;
    const path = u.pathname.replace(/\/$/, '') || '/';
    // Skip obvious non-content URLs.
    if (/\.(jpg|jpeg|png|gif|webp|svg|css|js|pdf|zip|xml|ico)$/i.test(path)) return null;
    if (/^\/(wp-admin|wp-login|wp-json|feed|cart|checkout|my-account)/i.test(path)) return null;
    return path;
  } catch {
    return null;
  }
}

function extractTitle(html: string): string | undefined {
  const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? m[1].replace(/<[^>]+>/g, '').trim().slice(0, 200) : undefined;
}

function extractInternalLinks(html: string, base: URL): Set<string> {
  const links = new Set<string>();
  const re = /href=["']([^"'#]+)["']/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(html))) {
    const path = normalizeToPath(m[1], base);
    if (path) links.add(path);
  }
  return links;
}

async function fetchText(urlStr: string): Promise<string | null> {
  const check = await validateFetchUrl(urlStr);
  if (!check.ok) return null;
  try {
    const res = await fetch(urlStr.startsWith('//') ? `https:${urlStr}` : urlStr, {
      headers: { 'User-Agent': 'BlogPilotBot/1.0 (+https://blogpilot.ai)' },
      redirect: 'follow',
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

async function getSitemapUrls(root: URL): Promise<string[]> {
  const candidates = [`${root.origin}/sitemap.xml`, `${root.origin}/sitemap_index.xml`, `${root.origin}/wp-sitemap.xml`];
  for (const candidate of candidates) {
    const xml = await fetchText(candidate);
    if (!xml || !/<(urlset|sitemapindex)/i.test(xml)) continue;

    const locs = Array.from(xml.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/gi)).map(m => m[1]);
    const urls: string[] = [];

    // Sitemap index → descend one level into child sitemaps.
    if (/sitemapindex/i.test(xml)) {
      for (const child of locs.slice(0, 5)) {
        const childXml = await fetchText(child);
        if (!childXml) continue;
        for (const loc of Array.from(childXml.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/gi)).map(m => m[1])) {
          urls.push(loc);
          if (urls.length >= MAX_PAGES * 2) break;
        }
      }
    } else {
      urls.push(...locs);
    }

    const paths = new Set<string>();
    for (const u of urls) {
      const p = normalizeToPath(u, root);
      if (p && p !== '/') paths.add(p);
      if (paths.size >= MAX_PAGES) break;
    }
    if (paths.size > 0) return Array.from(paths).map(p => `${root.origin}${p}`);
  }
  return [];
}

export async function crawlSite(siteUrl: string, opts?: { maxPages?: number }): Promise<CrawlGraph> {
  const maxPages = Math.min(opts?.maxPages ?? MAX_PAGES, 50);
  const cacheKey = `crawl:v1:${hashKeyParts(siteUrl)}:${maxPages}`;
  const cached = await cacheGet<CrawlGraph>(cacheKey);
  if (cached) {
    return { ...cached, inboundCount: new Map(cached.inboundCount as unknown as Array<[string, number]>) };
  }

  const root = new URL(siteUrl);
  let source: CrawlGraph['source'] = 'crawl';
  const sitemapUrls: string[] = await getSitemapUrls(root);

  let targets: string[];
  if (sitemapUrls.length > 0) {
    source = 'sitemap';
    // Homepage first, then sitemap paths.
    targets = ['/'].concat(sitemapUrls).slice(0, maxPages).map(p =>
      p.startsWith('/') ? `${root.origin}${p}` : p
    );
  } else {
    // BFS from homepage.
    targets = [`${root.origin}/`];
  }

  const pages: CrawledPage[] = [];
  const visited = new Set<string>();
  const queue: Array<{ url: string; depth: number }> = targets.map(url => ({ url, depth: 0 }));

  while (queue.length > 0 && pages.length < maxPages) {
    const batch = queue.splice(0, 5).filter(b => !visited.has(b.url));
    for (const b of batch) visited.add(b.url);

    const results = await Promise.all(
      batch.map(async b => {
        const html = await fetchText(b.url);
        return { ...b, html };
      })
    );

    for (const { url, depth, html } of results) {
      if (!html) continue;
      const path = normalizeToPath(url, root) || '/';
      const internalLinks = extractInternalLinks(html, root);
      const text = html.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<[^>]+>/g, ' ');

      pages.push({
        url,
        path,
        title: extractTitle(html),
        wordCount: text.split(/\s+/).filter(Boolean).length,
        outboundInternal: Array.from(internalLinks),
      });

      if (source === 'crawl' && depth < 1) {
        for (const link of internalLinks) {
          const childUrl = `${root.origin}${link}`;
          if (!visited.has(childUrl)) {
            visited.add(childUrl);
            queue.push({ url: childUrl, depth: depth + 1 });
          }
        }
      }
    }
  }

  const inboundCount = new Map<string, number>();
  for (const page of pages) {
    for (const target of page.outboundInternal) {
      inboundCount.set(target, (inboundCount.get(target) || 0) + 1);
    }
  }
  const orphanPaths = pages.filter(p => (inboundCount.get(p.path) || 0) === 0 && p.path !== '/').map(p => p.path);

  const graph: CrawlGraph = {
    root: root.origin,
    pages,
    inboundCount,
    orphanPaths,
    source,
    crawledAt: new Date().toISOString(),
  };

  await cacheSet(cacheKey, { ...graph, inboundCount: Array.from(inboundCount.entries()) }, 6 * 3600);
  return graph;
}
