﻿import { NextResponse } from 'next/server';
import { isGoogleConfigured } from '@/lib/google-oauth';

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      configured: isGoogleConfigured(),
    },
  });
}
