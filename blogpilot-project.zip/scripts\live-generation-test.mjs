const BASE = process.argv[2] || 'http://localhost:3000';
const email = `gen-live-${Date.now()}@test.com`;
const password = 'Sup3rSecurePass!';

const j = (r) => r.json();

const signup = await fetch(`${BASE}/api/auth/signup`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password, name: 'Live Gen' }),
});
console.log('signup:', signup.status);

const { PrismaClient } = await import('@prisma/client');
const prisma = new PrismaClient();
const user = await prisma.user.findUnique({ where: { email } });
await prisma.user.update({ where: { id: user.id }, data: { credits: 2 } });

const login = await fetch(`${BASE}/api/auth/login`, {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password }),
});
const cookie = (login.headers.get('set-cookie') || '').split(';')[0];

const t0 = Date.now();
const res = await fetch(`${BASE}/api/generate`, {
  method: 'POST',
  headers: { 'Cookie': cookie, 'Content-Type': 'application/json' },
  body: JSON.stringify({
    title: 'Best Running Shoes for Beginners in 2026',
    query: 'best running shoes for beginners',
    instructions: 'Write a helpful beginner guide.',
  }),
});
const data = await j(res);
const secs = ((Date.now() - t0) / 1000).toFixed(1);

if (res.status === 200 && data.article) {
  console.log(`GENERATION OK in ${secs}s — length ${data.article.length} chars, meta:`, JSON.stringify(data.meta));
  console.log('EXCERPT:', data.article.slice(0, 250).replace(/\n/g, ' '));
} else {
  console.log(`GENERATION FAILED (${res.status}) in ${secs}s:`, JSON.stringify(data).slice(0, 300));
}

const after = await prisma.user.findUnique({ where: { id: user.id } });
const usage = await prisma.aiUsage.findMany({ where: { userId: user.id } });
console.log('balance after:', after.credits, '| aiUsage rows:', JSON.stringify(usage.map(u => ({ op: u.operation, ok: u.success, model: u.model, ms: u.durationMs, charged: u.creditsCharged }))));

await prisma.creditTransaction.deleteMany({ where: { userId: user.id } }).catch(() => {});
await prisma.user.delete({ where: { id: user.id } }).catch(() => {});
await prisma.$disconnect();
