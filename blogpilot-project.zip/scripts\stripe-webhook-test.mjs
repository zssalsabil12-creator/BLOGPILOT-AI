/**
 * Stripe subscription flow E2E — runs fully offline against a dev/prod
 * server that has STRIPE_WEBHOOK_SECRET configured (STRIPE_SECRET_KEY may be
 * a placeholder: webhook verification is local HMAC, and the subscription is
 * resolved from our own DB, so no Stripe API calls occur in this flow).
 *
 * Verifies:
 *  1. checkout.session.completed (subscription) activates the plan record but
 *     grants NO credits (invoice.paid is the single granting event).
 *  2. invoice.paid grants the plan credits exactly once.
 *  3. A duplicate invoice.paid delivered under a DIFFERENT event id grants
 *     nothing (invoice-scoped idempotency).
 *  4. customer.subscription.updated syncs status/period.
 *  5. charge.refunded deducts credits without going negative (full refund).
 *  6. Bad signatures are rejected with 400.
 *
 * Run: node scripts/stripe-webhook-test.mjs [baseUrl]
 */
import { PrismaClient } from '@prisma/client';

const BASE = process.argv[2] || 'http://localhost:3000';
const prisma = new PrismaClient();

const { default: Stripe } = await import('stripe');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');

const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;
if (!WEBHOOK_SECRET) {
  console.error('STRIPE_WEBHOOK_SECRET must be set on the server AND in this process.');
  process.exit(1);
}

function signedEvent(event) {
  const payload = JSON.stringify(event);
  const header = stripe.webhooks.generateTestHeaderString({
    payload,
    secret: WEBHOOK_SECRET,
  });
  return { header, payload };
}

async function deliver(event) {
  const { header, payload } = signedEvent(event);
  const res = await fetch(`${BASE}/api/stripe/webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Stripe-Signature': header },
    body: payload,
  });
  let json = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

let failures = 0;
function check(name, cond, detail = '') {
  console.log(`  ${cond ? 'PASS' : 'FAIL'} ${name}${cond ? '' : ` — ${detail}`}`);
  if (!cond) failures++;
}

async function main() {
  console.log(`Stripe webhook flow against ${BASE}\n`);

  // --- setup user -----------------------------------------------------------
  const email = `stripe-e2e-${Date.now()}@test.com`;
  await fetch(`${BASE}/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'Sup3rSecurePass!', name: 'Stripe E2E' }),
  });
  const loginRes = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'Sup3rSecurePass!' }),
  });
  const authCookie = (loginRes.headers.get('set-cookie') || '').split(';')[0];
  const user = await prisma.user.findUnique({ where: { email } });
  const userId = user.id;

  const balance = async () => (await prisma.user.findUnique({ where: { id: userId } })).credits;
  const before = await balance();
  check('initial balance recorded', typeof before === 'number', String(before));

  const subId = `sub_test_${Date.now()}`;
  const custId = `cus_test_${Date.now()}`;
  const now = Math.floor(Date.now() / 1000);

  // --- 1. checkout.session.completed (subscription): bookkeeping only -------
  const r1 = await deliver({
    id: `evt_co_${Date.now()}`,
    object: 'event',
    type: 'checkout.session.completed',
    data: {
      object: {
        id: `cs_test_${Date.now()}`,
        object: 'checkout.session',
        mode: 'subscription',
        customer: custId,
        subscription: subId,
        metadata: { userId, planId: 'starter' },
      },
    },
  });
  check('checkout.session.completed accepted', r1.status === 200, `got ${r1.status}`);
  const afterCheckout = await balance();
  check('subscription checkout granted NO credits', afterCheckout === before, `${before} -> ${afterCheckout}`);
  const subRow = await prisma.subscription.findUnique({ where: { userId } });
  check('subscription row created for correct plan', subRow?.plan === 'starter' && subRow?.stripeSubscriptionId === subId,
    JSON.stringify({ plan: subRow?.plan, sub: subRow?.stripeSubscriptionId }));

  // --- 2. invoice.paid: exactly one grant ------------------------------------
  const invoiceId = `in_test_${Date.now()}`;
  const priceId = process.env.STRIPE_PRICE_ID_STARTER || null;
  const r2 = await deliver({
    id: `evt_inv1_${Date.now()}`,
    object: 'event',
    type: 'invoice.paid',
    data: {
      object: {
        id: invoiceId,
        object: 'invoice',
        subscription: subId,
        customer: custId,
        amount_paid: 2900,
        ...(priceId ? { lines: { data: [{ pricing: { price_details: { price: priceId } } }] } } : {}),
      },
    },
  });
  check('invoice.paid accepted', r2.status === 200, `got ${r2.status}`);
  const afterInvoice = await balance();
  check('invoice.paid granted starter credits once (+50)', afterInvoice === before + 50, `${before} -> ${afterInvoice}`);

  // --- 3. duplicate invoice under a NEW event id: still one grant ------------
  const r3 = await deliver({
    id: `evt_inv1_dup_${Date.now()}`,   // different event id — outer claim passes
    object: 'event',
    type: 'invoice.paid',
    data: {
      object: {
        id: invoiceId,                   // same invoice — inner key must block
        object: 'invoice',
        subscription: subId,
        customer: custId,
        amount_paid: 2900,
        ...(priceId ? { lines: { data: [{ pricing: { price_details: { price: priceId } } }] } } : {}),
      },
    },
  });
  check('duplicate invoice.paid accepted', r3.status === 200, `got ${r3.status}`);
  const afterDup = await balance();
  check('duplicate invoice granted nothing', afterDup === afterInvoice, `${afterInvoice} -> ${afterDup}`);

  // --- 4. customer.subscription.updated syncs status --------------------------
  const r4 = await deliver({
    id: `evt_sub_${Date.now()}`,
    object: 'event',
    type: 'customer.subscription.updated',
    data: {
      object: {
        id: subId,
        object: 'subscription',
        status: 'active',
        cancel_at_period_end: false,
        current_period_end: now + 30 * 24 * 3600,
        customer: custId,
        metadata: { userId, planId: 'starter' },
        items: { data: [{ current_period_end: now + 30 * 24 * 3600 }] },
      },
    },
  });
  check('customer.subscription.updated accepted', r4.status === 200, `got ${r4.status}`);
  const subAfter = await prisma.subscription.findUnique({ where: { userId } });
  check('subscription synced active with period end', subAfter?.status === 'active' && !!subAfter?.currentPeriodEnd,
    JSON.stringify({ status: subAfter?.status }));

  // --- 5. full refund ends entitlements + clamped deduction ------------------
  // NOTE: the handler resolves charge→invoice→subscription via the live
  // Stripe API, so this leg needs a REAL test-mode key. With a placeholder
  // key we verify only that the webhook is accepted and handled safely.
  const hasRealStripeKey = (process.env.STRIPE_SECRET_KEY || '').startsWith('sk_test_') &&
    !process.env.STRIPE_SECRET_KEY.includes('placeholder');
  const r5 = await deliver({
    id: `evt_ref_${Date.now()}`,
    object: 'event',
    type: 'charge.refunded',
    data: {
      object: {
        id: `ch_test_${Date.now()}`,
        object: 'charge',
        invoice: invoiceId,
        customer: custId,
        amount: 2900,
        amount_refunded: 2900,
      },
    },
  });
  check('charge.refunded accepted', r5.status === 200, `got ${r5.status}`);
  if (hasRealStripeKey) {
    const afterRefund = await balance();
    check('refund deducted credits, never negative', afterRefund >= 0 && afterRefund < afterDup, `${afterDup} -> ${afterRefund}`);
    const subRefunded = await prisma.subscription.findUnique({ where: { userId } });
    check('full refund cancelled entitlements', subRefunded?.status === 'cancelled', String(subRefunded?.status));
  } else {
    console.log('  SKIP refund deduction checks (placeholder STRIPE_SECRET_KEY — needs a real test-mode key)');
  }

  // --- 6. bad signature rejected ---------------------------------------------
  const bad = await fetch(`${BASE}/api/stripe/webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Stripe-Signature': 't=1,v1=deadbeef' },
    body: '{}',
  });
  check('bad signature rejected (400)', bad.status === 400, `got ${bad.status}`);

  // --- cleanup -----------------------------------------------------------------
  await prisma.creditTransaction.deleteMany({ where: { userId } }).catch(() => {});
  await prisma.subscription.deleteMany({ where: { userId } }).catch(() => {});
  await prisma.processedEvent.deleteMany({ where: { eventId: { startsWith: 'evt_' } } }).catch(() => {});
  await prisma.user.delete({ where: { id: userId } }).catch(() => {});

  console.log(failures === 0 ? '\nSTRIPE FLOW TEST PASSED' : `\n${failures} CHECK(S) FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
