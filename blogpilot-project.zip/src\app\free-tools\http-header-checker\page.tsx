'use client';

import React, { useCallback, useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Shield,
  ShieldCheck,
  ShieldX,
  Loader2,
  AlertTriangle,
  Check,
  RotateCcw,
  Copy,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ArrowRight,
} from 'lucide-react';

interface SecurityHeaderResult {
  present: boolean;
  value?: string;
}

interface HeaderCheckResult {
  status: number;
  headers: Record<string, string>;
  url: string;
  redirected: boolean;
  finalUrl: string;
  securityHeaders: Record<string, SecurityHeaderResult>;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  }, [text]);
  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1 rounded-lg border border-border bg-muted/50 px-2 py-1 text-xs text-muted-foreground transition hover:bg-muted hover:text-foreground"
      aria-label="Copy"
    >
      {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
    </button>
  );
}

function StatusBadge({ status }: { status: number }) {
  let color = 'bg-slate-500/20 text-slate-300';
  if (status >= 200 && status < 300) color = 'bg-emerald-500/20 text-emerald-300';
  else if (status >= 300 && status < 400) color = 'bg-amber-500/20 text-amber-300';
  else if (status >= 400 && status < 500) color = 'bg-orange-500/20 text-orange-300';
  else if (status >= 500) color = 'bg-rose-500/20 text-rose-300';

  return (
    <span className={`inline-flex items-center rounded-full px-3 py-1 text-sm font-semibold ${color}`}>
      {status}
    </span>
  );
}

const SECURITY_HEADER_LABELS: Record<string, string> = {
  'x-content-type-options': 'X-Content-Type-Options',
  'x-frame-options': 'X-Frame-Options',
  'x-xss-protection': 'X-XSS-Protection',
  'content-security-policy': 'Content-Security-Policy',
  'strict-transport-security': 'Strict-Transport-Security',
  'referrer-policy': 'Referrer-Policy',
  'permissions-policy': 'Permissions-Policy',
};

const SECURITY_HEADER_DESCRIPTIONS: Record<string, string> = {
  'x-content-type-options': 'Prevents MIME-type sniffing',
  'x-frame-options': 'Prevents clickjacking attacks',
  'x-xss-protection': 'XSS filter in older browsers',
  'content-security-policy': 'Controls resource loading policies',
  'strict-transport-security': 'Enforces HTTPS connections',
  'referrer-policy': 'Controls referrer information sent',
  'permissions-policy': 'Controls browser feature access',
};

export default function HttpHeaderCheckerPage() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HeaderCheckResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showAllHeaders, setShowAllHeaders] = useState(false);

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setResult(null);
    setShowAllHeaders(false);

    const trimmed = url.trim();
    if (!trimmed) {
      setError('Please enter a URL to check.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/http-header-checker', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Failed to fetch headers.');
        return;
      }
      setResult(data);
    } catch (err: any) {
      setError(err?.message || 'Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setUrl('');
    setResult(null);
    setError(null);
    setShowAllHeaders(false);
  }

  const securityKeys = result ? Object.keys(SECURITY_HEADER_LABELS) : [];
  const otherHeaders = result
    ? Object.entries(result.headers).filter(
        ([k]) => !securityKeys.includes(k.toLowerCase())
      )
    : [];
  const allHeadersText = result
    ? Object.entries(result.headers)
        .map(([k, v]) => `${k}: ${v}`)
        .join('\n')
    : '';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            HTTP Header <span className="text-gradient">Checker</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Inspect all HTTP response headers for any URL. Check security headers at a glance.
          </p>
        </section>

        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="url-input" className="text-sm font-medium text-foreground">
                URL to Check
              </label>
              <input
                id="url-input"
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                className="mt-2 w-full rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
              />
            </div>
            <div className="flex items-center justify-between">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Shield className="h-4 w-4" />}
                {loading ? 'Checking Headers…' : 'Check Headers'}
              </button>
              {result && (
                <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" />
                  New check
                </button>
              )}
            </div>
          </form>

          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </section>

        {loading && !result && (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="shimmer h-20 rounded-2xl border border-border bg-card/50" />
            ))}
          </div>
        )}

        {result && (
          <div className="space-y-6">
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <StatusBadge status={result.status} />
                  {result.redirected && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-3 py-1 text-xs font-medium text-amber-300">
                      <ArrowRight className="h-3 w-3" />
                      Redirected to {result.finalUrl.length > 50 ? result.finalUrl.slice(0, 50) + '…' : result.finalUrl}
                    </span>
                  )}
                </div>
                <CopyButton text={allHeadersText} />
              </div>
              <p className="mt-2 text-xs text-muted-foreground break-all">
                {result.url}
                {result.redirected && (
                  <>
                    {' '}<ArrowRight className="inline h-3 w-3" />{' '}{result.finalUrl}
                  </>
                )}
              </p>
            </section>

            <section className="rounded-2xl border border-cyan-400/20 bg-cyan-400/5 p-6">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-cyan-300" />
                <h2 className="text-lg font-semibold text-foreground">Security Headers</h2>
              </div>
              <div className="mt-4 space-y-2">
                {securityKeys.map((key) => {
                  const sh = result.securityHeaders[key];
                  const present = sh?.present;
                  return (
                    <div
                      key={key}
                      className={`flex items-center justify-between rounded-xl border px-4 py-3 ${
                        present
                          ? 'border-emerald-500/20 bg-emerald-500/5'
                          : 'border-rose-500/20 bg-rose-500/5'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          {present ? (
                            <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-400" />
                          ) : (
                            <ShieldX className="h-4 w-4 shrink-0 text-rose-400" />
                          )}
                          <span className="text-sm font-medium text-foreground">
                            {SECURITY_HEADER_LABELS[key]}
                          </span>
                        </div>
                        <p className="ml-6 mt-0.5 text-xs text-muted-foreground">
                          {SECURITY_HEADER_DESCRIPTIONS[key]}
                        </p>
                      </div>
                      <span className={`text-xs font-semibold ${present ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {present ? '✓ Present' : '✗ Missing'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </section>

            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-foreground">All Headers</h2>
                <span className="text-xs text-muted-foreground">{Object.keys(result.headers).length} headers</span>
              </div>
              <button
                onClick={() => setShowAllHeaders(!showAllHeaders)}
                className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
              >
                {showAllHeaders ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                {showAllHeaders ? 'Collapse all headers' : 'Show all headers'}
              </button>

              {showAllHeaders && (
                <div className="mt-4 overflow-x-auto rounded-xl border border-border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                          Header Name
                        </th>
                        <th className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider text-muted-foreground">
                          Value
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {otherHeaders.map(([key, value]) => (
                        <tr key={key} className="transition hover:bg-muted/20">
                          <td className="whitespace-nowrap px-4 py-2.5 font-medium text-foreground">{key}</td>
                          <td className="px-4 py-2.5 break-all text-muted-foreground">{value}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
