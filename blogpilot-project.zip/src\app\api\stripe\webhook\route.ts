﻿import { NextResponse } from 'next/server';
import { verifyStripeWebhook, handleStripeEvent, isStripeConfigured } from '@/lib/stripe';

export async function POST(req: Request) {
  if (!isStripeConfigured()) {
    return NextResponse.json({ ok: false, error: 'Stripe is not configured' }, { status: 501 });
  }

  const signature = req.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ ok: false, error: 'Missing Stripe signature' }, { status: 400 });
  }

  const body = await req.text();
  const event = verifyStripeWebhook(body, signature);
  if (!event) {
    return NextResponse.json({ ok: false, error: 'Invalid Stripe signature' }, { status: 400 });
  }

  try {
    await handleStripeEvent(event);
  } catch (error: any) {
    console.error('Stripe webhook handler error:', error);
    return NextResponse.json({ ok: false, error: 'Webhook handling failed' }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}