/**
 * Input Validation Library (Zod schemas)
 *
 * Centralized schema definitions for every user-facing input the API
 * accepts. Each schema:
 *   - Enforces type correctness
 *   - Applies length / format constraints
 *   - Strips dangerous characters that could enable XSS or injection
 *   - Returns human-readable error messages
 *
 * Why centralize:
 *   - Keeps validation rules consistent across routes (a keyword accepted
 *     by /api/generate must satisfy the same rules as one sent to
 *     /api/analyze).
 *   - Easy to audit — one file lists every input the API trusts.
 *
 * Sanitization strategy:
 *   - Reject control characters (\x00-\x1F except \t \n \r)
 *   - Reject null bytes outright (SQL injection / log poisoning vector)
 *   - Trim leading/trailing whitespace
 *   - Cap length to prevent memory-exhaustion attacks
 *   - For URLs: enforce protocol allowlist (http/https only)
 *
 * Zod v4 note:
 *   - `.transform()` returns a ZodEffects which loses the original
 *     string's `.min()` / `.max()` methods. So we apply length constraints
 *     FIRST on a plain `z.string()`, then chain the sanitization transforms.
 *   - `.refine()` works on ZodEffects (returns another ZodEffects), so
 *     format checks go LAST.
 */

import { z } from 'zod'

/* -------------------------------------------------------------------------- */
/*                          Shared sanitizers                                 */
/* -------------------------------------------------------------------------- */

/**
 * Strip control characters and null bytes from a string.
 * Preserves \t, \n, \r since they're legitimate in markdown.
 *
 * Returned as a function so callers can apply it inside `.transform()`
 * AFTER length constraints have been validated.
 */
function stripControlChars(s: string): string {
  return s.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
}

/**
 * Single-line variant — also strips \n to prevent header injection and
 * log-line-splitting attacks.
 */
function stripAllControlChars(s: string): string {
  return s.replace(/[\x00-\x1F\x7F]/g, '')
}

/**
 * Build a sanitized single-line string schema with length constraints.
 *
 * The order matters in Zod v4:
 *   1. z.string()              — base type
 *   2. .min() / .max()         — length check on the raw input
 *   3. .transform(stripAllControlChars)  — strip control chars
 *   4. .transform(trim)        — trim whitespace
 *   5. .refine(xssCheck)       — optional content check
 */
function singleLineString(opts: {
  min?: number
  max: number
  minMessage?: string
  maxMessage?: string
  required?: boolean
}) {
  let schema = z.string()
  if (opts.min !== undefined) {
    schema = schema.min(opts.min, opts.minMessage || `Must be at least ${opts.min} characters`)
  } else if (opts.required) {
    schema = schema.min(1, 'This field is required')
  }
  schema = schema.max(opts.max, opts.maxMessage || `Must be at most ${opts.max} characters`)
  return schema
    .transform(stripAllControlChars)
    .transform((s) => s.trim())
}

/**
 * Multiline string (markdown content) — allows \n but strips other
 * control characters.
 */
function multilineString(opts: { max: number; maxMessage?: string }) {
  return z
    .string()
    .max(opts.max, opts.maxMessage || `Must be at most ${opts.max} characters`)
    .transform(stripControlChars)
    .transform((s) => s.trim())
}

/**
 * XSS / injection pattern check — rejects obvious script injection
 * attempts in user-supplied free text. Defence-in-depth: even if the
 * content is rendered with proper escaping, blocking at the API layer
 * prevents log poisoning and prompt-injection confusion.
 */
const XSS_PATTERN = /<script|javascript:|on\w+=|<iframe|<embed|<object/i

/* -------------------------------------------------------------------------- */
/*                              Auth schemas                                  */
/* -------------------------------------------------------------------------- */

export const loginSchema = z.object({
  email: z.string().email('A valid email is required').max(254),
  password: z
    .string()
    .min(1, 'Password is required')
    .max(1024, 'Password is too long'),
})

export const signupSchema = z.object({
  email: z.string().email('A valid email is required').max(254),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(1024, 'Password is too long'),
  name: singleLineString({
    min: 1,
    max: 100,
    minMessage: 'Name is required',
    maxMessage: 'Name is too long',
  }),
})

/* -------------------------------------------------------------------------- */
/*                            Article schemas                                 */
/* -------------------------------------------------------------------------- */

/**
 * Keyword / topic schema.
 *
 * Keywords are user-supplied free text that goes into an AI prompt, so we
 * must prevent prompt injection AND downstream XSS when the keyword is
 * rendered back to the UI.
 */
export const keywordSchema = singleLineString({
  min: 2,
  max: 200,
  minMessage: 'Keyword must be at least 2 characters',
  maxMessage: 'Keyword is too long (max 200 chars)',
}).refine((s) => !XSS_PATTERN.test(s), {
  message: 'Keyword contains disallowed content',
})

export const topicSchema = singleLineString({
  max: 300,
  maxMessage: 'Topic is too long (max 300 chars)',
}).optional().or(z.literal(''))

export const toneSchema = singleLineString({
  max: 60,
  maxMessage: 'Tone descriptor is too long',
}).optional().or(z.literal(''))

export const languageSchema = z
  .enum([
    'en', 'ar', 'es', 'fr', 'de', 'it', 'pt', 'nl',
    'ru', 'zh', 'ja', 'ko', 'hi', 'tr',
  ])
  .default('en')

export const intentSchema = z.enum(['informational', 'commercial'])
export const lengthSchema = z.enum(['short', 'medium', 'long'])

export const generateArticleSchema = z.object({
  keyword: keywordSchema,
  topic: topicSchema,
  tone: toneSchema,
  length: lengthSchema.default('medium'),
  affiliatePlatform: singleLineString({ max: 50 }).optional().or(z.literal('')),
  language: languageSchema,
  intent: intentSchema.default('informational'),
  products: z
    .array(
      z.object({
        name: singleLineString({ min: 1, max: 200, required: true }),
        brand: singleLineString({ max: 100 }).optional(),
        price: z.number().nonnegative().max(1_000_000).optional(),
        originalPrice: z.number().nonnegative().max(1_000_000).optional(),
        currency: z.string().length(3).optional(),
        rating: z.number().min(0).max(5).optional(),
        reviewCount: z.number().int().min(0).max(10_000_000).optional(),
        specs: z.record(z.string(), z.string()).optional(),
        pros: z.array(singleLineString({ max: 300 })).max(20).optional(),
        cons: z.array(singleLineString({ max: 300 })).max(20).optional(),
        badge: singleLineString({ max: 60 }).optional(),
      }).strict()
    )
    .max(20, 'Too many products (max 20)')
    .default([]),
  deductCredit: z.boolean().default(true),
})

/* -------------------------------------------------------------------------- */
/*                           Outline / analyze                                */
/* -------------------------------------------------------------------------- */

export const analyzeSchema = z.object({
  keyword: keywordSchema,
  topic: topicSchema,
  tone: toneSchema,
})

export const generateOutlineSchema = z.object({
  keyword: keywordSchema,
  topic: topicSchema,
  tone: toneSchema,
  length: lengthSchema.default('medium'),
  enableFactCheck: z.boolean().default(false),
  affiliatePlatform: singleLineString({ max: 50 }).optional().or(z.literal('')),
})

export const factCheckSchema = z
  .object({
    query: singleLineString({ max: 500 }).optional(),
    context: multilineString({ max: 5000 }).optional(),
    statements: z.array(singleLineString({ max: 500 })).max(20).optional(),
  })
  .refine(
    (v) => !!v.query?.trim() || (!!v.statements && v.statements.length > 0),
    { message: 'Either "query" or "statements" is required' }
  )

/* -------------------------------------------------------------------------- */
/*                              Products / images                             */
/* -------------------------------------------------------------------------- */

export const productsSchema = z.object({
  keyword: keywordSchema,
  platform: z.enum(['amazon', 'ebay', 'cj', 'custom']).default('amazon'),
  limit: z.number().int().min(1).max(10).default(5),
})

export const imagesSchema = z.object({
  keyword: keywordSchema,
  products: z
    .array(
      z.object({
        name: singleLineString({ min: 1, max: 200, required: true }),
        brand: singleLineString({ max: 100 }).optional(),
      })
    )
    .max(20)
    .default([]),
  sectionCount: z.number().int().min(1).max(20).default(5),
  includeHero: z.boolean().default(true),
  width: z.number().int().min(100).max(2000).default(800),
  height: z.number().int().min(100).max(2000).default(600),
})

/* -------------------------------------------------------------------------- */
/*                              Article CRUD                                  */
/* -------------------------------------------------------------------------- */

/**
 * URL schema — strict http/https only.
 * Rejects javascript:, data:, file:, etc. (XSS vectors).
 */
export const urlSchema = z
  .string()
  .trim()
  .url('Must be a valid URL')
  .max(2048, 'URL is too long')
  .refine(
    (u) => u.startsWith('http://') || u.startsWith('https://'),
    'URL must start with http:// or https://'
  )

export const createArticleSchema = z.object({
  title: singleLineString({
    min: 1,
    max: 300,
    minMessage: 'Title is required',
    maxMessage: 'Title is too long',
  }),
  content: multilineString({ max: 500_000, maxMessage: 'Content is too long' }),
  targetKeyword: keywordSchema.optional(),
  siteId: z.string().max(100).optional(),
  language: languageSchema,
  intent: intentSchema.default('informational'),
  tone: toneSchema,
  length: lengthSchema.optional(),
})

export const updateArticleSchema = z.object({
  title: singleLineString({ min: 1, max: 300 }).optional(),
  content: multilineString({ max: 500_000 }).optional(),
  excerpt: multilineString({ max: 500 }).optional().or(z.literal('')),
  targetKeyword: keywordSchema.optional().or(z.literal('')),
  tone: toneSchema,
  length: lengthSchema.optional().or(z.literal('')),
  language: languageSchema.optional(),
  intent: intentSchema.optional(),
  seoScore: z.number().int().min(0).max(100).optional(),
  status: z.enum(['draft', 'published', 'scheduled']).optional(),
  siteId: z.string().max(100).optional().or(z.literal('')),
})

/* -------------------------------------------------------------------------- */
/*                              Sites & credentials                           */
/* -------------------------------------------------------------------------- */

export const platformSchema = z.enum([
  'wordpress',
  'shopify',
  'custom',
])

export const createSiteSchema = z.object({
  userId: z.string().min(1).max(100),
  name: singleLineString({
    min: 1,
    max: 120,
    minMessage: 'Site name is required',
  }),
  url: urlSchema,
  platform: platformSchema,
  username: singleLineString({ max: 200 }).optional().or(z.literal('')),
  apiKey: singleLineString({ max: 500 }).optional().or(z.literal('')),
})

export const updateSiteSchema = z.object({
  isActive: z.boolean().optional(),
  username: singleLineString({ max: 200 }).optional().or(z.literal('')),
  apiKey: singleLineString({ max: 500 }).optional().or(z.literal('')),
})

export const affiliatePlatformSchema = z.enum([
  'amazon',
  'ebay',
  'cj',
  'impact',
  'shareasale',
  'awin',
  'clickbank',
  'custom',
])

export const createCredentialSchema = z.object({
  userId: z.string().min(1).max(100),
  platform: affiliatePlatformSchema,
  apiKey: singleLineString({
    min: 1,
    max: 500,
    minMessage: 'API key is required',
  }),
  apiSecret: singleLineString({ max: 500 }).optional().or(z.literal('')),
  trackingId: singleLineString({ max: 200 }).optional().or(z.literal('')),
})

export const updateCredentialSchema = z.object({
  isActive: z.boolean().optional(),
  apiKey: singleLineString({ max: 500 }).optional(),
  apiSecret: singleLineString({ max: 500 }).optional(),
  trackingId: singleLineString({ max: 200 }).optional().or(z.literal('')),
  status: singleLineString({ max: 50 }).optional(),
})

/* -------------------------------------------------------------------------- */
/*                              Credits / Stripe                              */
/* -------------------------------------------------------------------------- */

export const topupCreditsSchema = z.object({
  amount: z.number().int().min(1, 'Amount must be positive').max(10_000),
  reason: singleLineString({ max: 100 }).default('topup'),
  description: multilineString({ max: 500 }).optional(),
})

export const stripeCheckoutSchema = z.object({
  tier: z.enum(['basic', 'pro', 'agency'], {
    error: 'Tier must be one of: basic, pro, agency',
  }),
})

/* -------------------------------------------------------------------------- */
/*                              Helper                                        */
/* -------------------------------------------------------------------------- */

/**
 * Format a ZodError into a single human-readable string for the API
 * response. Picks the first issue for brevity.
 */
export function formatZodError(error: z.ZodError): string {
  const first = error.issues[0]
  if (!first) return 'Invalid request payload'
  const path = first.path.length > 0 ? first.path.join('.') : 'value'
  return `${path}: ${first.message}`
}

/**
 * Safe-parse helper that returns either the parsed value or a NextResponse-
 * friendly error tuple.
 *
 *   const [data, error] = parseBody(generateArticleSchema, body)
 *   if (error) return NextResponse.json({ error }, { status: 400 })
 *   // data is now typed
 */
export function parseBody<T>(
  schema: z.ZodType<T>,
  body: unknown
): [T | null, string | null] {
  const result = schema.safeParse(body)
  if (result.success) {
    return [result.data, null]
  }
  return [null, formatZodError(result.error)]
}
