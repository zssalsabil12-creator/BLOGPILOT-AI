'use client'

import { useAppStore, type DashboardTab } from '@/lib/store'
import { ThemeToggle } from '@/components/theme-toggle'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  Sparkles,
  FileText,
  Globe,
  KeyRound,
  History,
  LogOut,
  Menu,
  ChevronLeft,
  Settings,
  CreditCard,
  BarChart3,
} from 'lucide-react'
import { AnalyticsPage } from './analytics-page'
import { GenerateArticlePage } from './generate-article-page'
import { ConnectedSitesPage } from './connected-sites-page'
import { AffiliateCredentialsPage } from './affiliate-credentials-page'
import { HistoryPage } from './history-page'
import { EditorPage } from './editor-page'
import { BillingPage } from './billing-page'

const sidebarItems: { id: DashboardTab; label: string; icon: React.ElementType }[] = [
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'generate-article', label: 'Generate Article', icon: FileText },
  { id: 'connected-sites', label: 'Connected Sites', icon: Globe },
  { id: 'affiliate-credentials', label: 'Affiliate Credentials', icon: KeyRound },
  { id: 'history', label: 'History', icon: History },
  { id: 'billing', label: 'Billing', icon: CreditCard },
]

function SidebarContent({
  currentTab,
  onTabChange,
  isCollapsed,
  user,
  onLogout,
}: {
  currentTab: DashboardTab
  onTabChange: (tab: DashboardTab) => void
  isCollapsed: boolean
  user: { name: string | null; email: string; subscription: { plan: string; status: string } | null } | null
  onLogout: () => void
}) {
  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex h-16 items-center px-4 border-b border-border/50">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          {!isCollapsed && (
            <span className="font-bold tracking-tight text-sm">BlogPilot AI</span>
          )}
        </div>
      </div>

      {/* Nav Items */}
      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="flex flex-col gap-1">
          {sidebarItems.map((item) => (
            <TooltipProvider key={item.id} delayDuration={0}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant={currentTab === item.id ? 'secondary' : 'ghost'}
                    className={`w-full ${isCollapsed ? 'justify-center px-2' : 'justify-start'} h-10`}
                    onClick={() => onTabChange(item.id)}
                  >
                    <item.icon className={`h-4 w-4 ${isCollapsed ? '' : 'mr-3'}`} />
                    {!isCollapsed && <span className="text-sm">{item.label}</span>}
                  </Button>
                </TooltipTrigger>
                {isCollapsed && (
                  <TooltipContent side="right" className="font-medium">
                    {item.label}
                  </TooltipContent>
                )}
              </Tooltip>
            </TooltipProvider>
          ))}
        </nav>
      </ScrollArea>

      {/* User Section */}
      <div className="border-t border-border/50 p-3">
        {!isCollapsed && user && (
          <div className="mb-3 flex items-center gap-3 px-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs bg-primary/10 text-primary">
                {user.name?.charAt(0)?.toUpperCase() || user.email.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name || 'User'}</p>
              <div className="flex items-center gap-1">
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4">
                  {user.subscription?.plan || 'free'}
                </Badge>
              </div>
            </div>
          </div>
        )}
        <div className="flex flex-col gap-1">
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  className={`w-full ${isCollapsed ? 'justify-center px-2' : 'justify-start'} h-9`}
                  onClick={() => onTabChange('billing')}
                >
                  <CreditCard className={`h-4 w-4 ${isCollapsed ? '' : 'mr-3'}`} />
                  {!isCollapsed && <span className="text-xs">Upgrade Plan</span>}
                </Button>
              </TooltipTrigger>
              {isCollapsed && <TooltipContent side="right">Upgrade Plan</TooltipContent>}
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  className={`w-full ${isCollapsed ? 'justify-center px-2' : 'justify-start'} h-9 text-muted-foreground hover:text-destructive`}
                  onClick={onLogout}
                >
                  <LogOut className={`h-4 w-4 ${isCollapsed ? '' : 'mr-3'}`} />
                  {!isCollapsed && <span className="text-xs">Log out</span>}
                </Button>
              </TooltipTrigger>
              {isCollapsed && <TooltipContent side="right">Log out</TooltipContent>}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  )
}

export function Dashboard() {
  const { currentDashboardTab, setDashboardTab, user, isSidebarOpen, setSidebarOpen, toggleSidebar, logout } = useAppStore()

  const renderContent = () => {
    switch (currentDashboardTab) {
      case 'analytics':
        return <AnalyticsPage />
      case 'generate-article':
        return <GenerateArticlePage />
      case 'connected-sites':
        return <ConnectedSitesPage />
      case 'affiliate-credentials':
        return <AffiliateCredentialsPage />
      case 'history':
        return <HistoryPage />
      case 'billing':
        return <BillingPage />
      case 'editor':
        return <EditorPage />
      default:
        return <AnalyticsPage />
    }
  }

  const sidebar = (
    <SidebarContent
      currentTab={currentDashboardTab}
      onTabChange={setDashboardTab}
      isCollapsed={!isSidebarOpen}
      user={user}
      onLogout={logout}
    />
  )

  return (
    <div className="h-screen flex overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col border-r border-border/50 bg-card transition-all duration-300 ${
          isSidebarOpen ? 'w-64' : 'w-16'
        }`}
      >
        {sidebar}
      </aside>

      {/* Main Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-14 border-b border-border/50 bg-card/50 backdrop-blur-sm flex items-center justify-between px-4 lg:px-6 shrink-0">
          <div className="flex items-center gap-2">
            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden h-9 w-9">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                <SidebarContent
                  currentTab={currentDashboardTab}
                  onTabChange={(tab) => {
                    setDashboardTab(tab)
                  }}
                  isCollapsed={false}
                  user={user}
                  onLogout={logout}
                />
              </SheetContent>
            </Sheet>

            {/* Desktop Collapse Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="hidden lg:flex h-9 w-9"
              onClick={toggleSidebar}
            >
              <ChevronLeft className={`h-4 w-4 transition-transform ${isSidebarOpen ? '' : 'rotate-180'}`} />
            </Button>

            <Separator orientation="vertical" className="h-6 hidden lg:block" />

            <h2 className="text-sm font-medium hidden sm:block">
              {sidebarItems.find((i) => i.id === currentDashboardTab)?.label || 'Dashboard'}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            {user?.subscription?.plan && user.subscription.plan !== 'free' && (
              <Badge variant="secondary" className="text-xs hidden sm:flex">
                {user.subscription.plan.toUpperCase()}
              </Badge>
            )}
            <ThemeToggle />
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs bg-primary/10 text-primary">
                {user?.name?.charAt(0)?.toUpperCase() || user?.email.charAt(0).toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto">
          {currentDashboardTab === 'editor' ? (
            <div className="h-full">
              {renderContent()}
            </div>
          ) : (
            <div className="p-4 lg:p-6 max-w-5xl">
              {renderContent()}
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
