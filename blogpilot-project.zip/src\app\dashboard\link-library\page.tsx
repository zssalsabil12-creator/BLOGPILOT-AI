'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';

type LinkRecord = {
  id: string;
  url: string;
  urlNormalized: string;
  title?: string;
  description?: string;
  category?: string;
  linkType?: string;
  affiliate?: boolean;
  affiliateProvider?: string | null;
  anchorText?: string | null;
  targetKeyword?: string | null;
  preferredPlacement?: string | null;
  active?: boolean;
  safetyStatus?: string;
  safetyReason?: string | null;
  productInfo?: any | null;
  createdAt: string;
  updatedAt: string;
};

type ImportPreview = {
  valid: Array<{ record: any; payload: any; safety: any }>;
  invalid: Array<any>;
  duplicates: Array<any>;
  unsafe: Array<any>;
};

type ApiResponse<T> = { ok: boolean; data?: T; error?: string; details?: any };

const LINK_TYPES = ['GENERAL', 'ARTICLE', 'TOOL', 'SOFTWARE', 'SERVICE', 'PRODUCT', 'AFFILIATE', 'RESOURCE', 'OTHER'];
const SAFETY_STATUS = ['UNKNOWN', 'SAFE', 'UNSAFE', 'REVIEW'];

export default function LinkLibraryPage() {
  const [links, setLinks] = useState<LinkRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [linkTypeFilter, setLinkTypeFilter] = useState('');
  const [activeFilter, setActiveFilter] = useState('');
  const [affiliateFilter, setAffiliateFilter] = useState('');
  const [safetyFilter, setSafetyFilter] = useState('');
  const [addVisible, setAddVisible] = useState(false);
  const [importVisible, setImportVisible] = useState(false);
  const [formState, setFormState] = useState({
    id: '',
    url: '',
    title: '',
    description: '',
    category: '',
    linkType: 'GENERAL',
    affiliate: false,
    affiliateProvider: '',
    anchorText: '',
    targetKeyword: '',
    preferredPlacement: '',
    active: true,
  });
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [importContent, setImportContent] = useState('');
  const [importType, setImportType] = useState<'csv' | 'json'>('csv');
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [importing, setImporting] = useState(false);

  const fetchLinks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (search) params.set('q', search);
      if (categoryFilter) params.set('category', categoryFilter);
      if (linkTypeFilter) params.set('linkType', linkTypeFilter);
      if (affiliateFilter) params.set('affiliate', affiliateFilter);
      if (activeFilter) params.set('active', activeFilter);
      if (safetyFilter) params.set('safetyStatus', safetyFilter);
      const res = await fetch(`/api/dashboard/link-library?${params.toString()}`);
      const json = (await res.json()) as ApiResponse<{ links: LinkRecord[] }>;
      if (!res.ok || !json.ok) {
        setError(json.error || 'Unable to load links.');
        setLinks([]);
      } else {
        setLinks(json.data?.links || []);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to load links.');
    } finally {
      setLoading(false);
    }
  }, [search, categoryFilter, linkTypeFilter, affiliateFilter, activeFilter, safetyFilter]);

  useEffect(() => {
    fetchLinks();
  }, [fetchLinks]);

  const stats = useMemo(() => {
    const total = links.length;
    const active = links.filter((link) => link.active).length;
    const affiliate = links.filter((link) => link.affiliate).length;
    const products = links.filter((link) => link.linkType === 'PRODUCT').length;
    const resources = links.filter((link) => link.linkType === 'RESOURCE' || link.linkType === 'ARTICLE' || link.linkType === 'TOOL').length;
    return { total, active, affiliate, products, resources };
  }, [links]);

  const resetForm = () => {
    setFormState({
      id: '',
      url: '',
      title: '',
      description: '',
      category: '',
      linkType: 'GENERAL',
      affiliate: false,
      affiliateProvider: '',
      anchorText: '',
      targetKeyword: '',
      preferredPlacement: '',
      active: true,
    });
    setEditMode(false);
  };

  const openEdit = (link: LinkRecord) => {
    setEditMode(true);
    setAddVisible(true);
    setFormState({
      id: link.id,
      url: link.url,
      title: link.title || '',
      description: link.description || '',
      category: link.category || '',
      linkType: link.linkType || 'GENERAL',
      affiliate: !!link.affiliate,
      affiliateProvider: link.affiliateProvider || '',
      anchorText: link.anchorText || '',
      targetKeyword: link.targetKeyword || '',
      preferredPlacement: link.preferredPlacement || '',
      active: !!link.active,
    });
  };

  const submitForm = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSaving(true);
    setError(null);
    try {
      const payload = {
        url: formState.url,
        title: formState.title || undefined,
        description: formState.description || undefined,
        category: formState.category || undefined,
        linkType: formState.linkType || undefined,
        affiliate: formState.affiliate,
        affiliateProvider: formState.affiliateProvider || undefined,
        anchorText: formState.anchorText || undefined,
        targetKeyword: formState.targetKeyword || undefined,
        preferredPlacement: formState.preferredPlacement || undefined,
        active: formState.active,
      };
      const res = await fetch(editMode ? `/api/dashboard/link-library/${encodeURIComponent(formState.id)}` : '/api/dashboard/link-library', {
        method: editMode ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json.error || 'Unable to save link.');
      } else {
        resetForm();
        setAddVisible(false);
        fetchLinks();
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to save link.');
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (link: LinkRecord) => {
    setError(null);
    try {
      const res = await fetch(`/api/dashboard/link-library/${encodeURIComponent(link.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: !link.active }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json.error || 'Unable to update link.');
      } else {
        fetchLinks();
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to update link.');
    }
  };

  const deleteLink = async (link: LinkRecord) => {
    if (!window.confirm('Delete this link from your library?')) return;
    setError(null);
    try {
      const res = await fetch(`/api/dashboard/link-library/${encodeURIComponent(link.id)}`, {
        method: 'DELETE',
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setError(json.error || 'Unable to delete link.');
      } else {
        fetchLinks();
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to delete link.');
    }
  };

  const handleImportFile = async (file: File) => {
    const text = await file.text();
    const candidateType = file.name.toLowerCase().endsWith('.json') ? 'json' : 'csv';
    setImportType(candidateType);
    setImportContent(text);
    setPreview(null);
    setPreviewError(null);
  };

  const previewImport = async () => {
    setImporting(true);
    setPreviewError(null);
    try {
      const res = await fetch('/api/dashboard/link-library/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: importType, content: importContent }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setPreviewError(json.error || 'Unable to preview import.');
        setPreview(null);
      } else {
        setPreview(json.data.preview || null);
      }
    } catch (err: any) {
      setPreviewError(err?.message || 'Import preview failed.');
    } finally {
      setImporting(false);
    }
  };

  const confirmImport = async () => {
    if (!preview) return;
    setImporting(true);
    setPreviewError(null);
    try {
      const res = await fetch('/api/dashboard/link-library/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: importType, content: importContent, confirm: true }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) {
        setPreviewError(json.error || 'Unable to import links.');
      } else {
        setImportVisible(false);
        setImportContent('');
        setPreview(null);
        fetchLinks();
      }
    } catch (err: any) {
      setPreviewError(err?.message || 'Import failed.');
    } finally {
      setImporting(false);
    }
  };

  const exportAs = async (format: 'json' | 'csv') => {
    try {
      const res = await fetch(`/api/dashboard/link-library/export?format=${format}`);
      if (!res.ok) {
        const json = await res.json();
        setError(json.error || `Unable to export ${format}.`);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `link-library.${format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      setError(err?.message || 'Export failed.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-10 shadow-xl shadow-black/10">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.35em] text-cyan-400">Link Library</p>
            <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white sm:text-5xl">Manage your Link Library</h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-slate-300">Add affiliate links, product references, tools, resources, and internal content opportunities that BlogPilot AI can use when generating SEO content.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button type="button" onClick={() => { setAddVisible(!addVisible); setImportVisible(false); }} className="rounded-full bg-cyan-500 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400">{addVisible ? 'Close form' : editMode ? 'Edit link' : 'Add link'}</button>
            <button type="button" onClick={() => { setImportVisible(!importVisible); setAddVisible(false); }} className="rounded-full border border-slate-700 bg-transparent px-5 py-3 text-sm font-semibold text-white transition hover:border-slate-500">{importVisible ? 'Close import' : 'Import links'}</button>
            <button type="button" onClick={() => exportAs('json')} className="rounded-full border border-slate-700 bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:border-slate-500">Export JSON</button>
            <button type="button" onClick={() => exportAs('csv')} className="rounded-full border border-slate-700 bg-slate-950 px-5 py-3 text-sm font-semibold text-white transition hover:border-slate-500">Export CSV</button>
          </div>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-4">
        {[
          { label: 'Total links', value: stats.total },
          { label: 'Active links', value: stats.active },
          { label: 'Affiliate links', value: stats.affiliate },
          { label: 'Product links', value: stats.products },
        ].map((stat) => (
          <div key={stat.label} className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
            <p className="text-sm text-slate-400">{stat.label}</p>
            <p className="mt-3 text-3xl font-semibold text-white">{stat.value}</p>
          </div>
        ))}
      </section>

      <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
        <div className="grid gap-4 lg:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-200">Search</label>
            <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search title, URL, description, category, or keyword" className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <label className="block text-sm font-medium text-slate-200">
              <span className="text-slate-400">Category</span>
              <input type="text" value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} placeholder="Category" className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="block text-sm font-medium text-slate-200">
              <span className="text-slate-400">Link type</span>
              <select value={linkTypeFilter} onChange={(event) => setLinkTypeFilter(event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400">
                <option value="">Any</option>
                {LINK_TYPES.map((type) => (<option key={type} value={type}>{type}</option>))}
              </select>
            </label>
            <label className="block text-sm font-medium text-slate-200">
              <span className="text-slate-400">Affiliate</span>
              <select value={affiliateFilter} onChange={(event) => setAffiliateFilter(event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400">
                <option value="">Any</option>
                <option value="true">Affiliate only</option>
                <option value="false">Non-affiliate</option>
              </select>
            </label>
            <label className="block text-sm font-medium text-slate-200">
              <span className="text-slate-400">Safety</span>
              <select value={safetyFilter} onChange={(event) => setSafetyFilter(event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400">
                <option value="">Any</option>
                {SAFETY_STATUS.map((status) => (<option key={status} value={status}>{status}</option>))}
              </select>
            </label>
          </div>
        </div>
      </section>

      {error && <div className="rounded-3xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-100">{error}</div>}

      {addVisible && (
        <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
          <h2 className="text-xl font-semibold text-white">{editMode ? 'Edit Link' : 'Add a new link'}</h2>
          <p className="mt-2 text-sm text-slate-400">Add a link that BlogPilot AI can use for content suggestions and affiliate references.</p>
          <form onSubmit={submitForm} className="mt-6 grid gap-4 lg:grid-cols-2">
            <label className="space-y-2 text-sm text-slate-200">
              <span>URL</span>
              <input required value={formState.url} onChange={(event) => setFormState({ ...formState, url: event.target.value })} placeholder="https://example.com" className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Title</span>
              <input value={formState.title} onChange={(event) => setFormState({ ...formState, title: event.target.value })} placeholder="Link title" className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200 lg:col-span-2">
              <span>Description</span>
              <textarea value={formState.description} onChange={(event) => setFormState({ ...formState, description: event.target.value })} placeholder="Short description" rows={4} className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Category</span>
              <input value={formState.category} onChange={(event) => setFormState({ ...formState, category: event.target.value })} placeholder="e.g. SaaS, Tool, Resource" className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Link type</span>
              <select value={formState.linkType} onChange={(event) => setFormState({ ...formState, linkType: event.target.value })} className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400">
                {LINK_TYPES.map((type) => (<option key={type} value={type}>{type}</option>))}
              </select>
            </label>
            <div className="space-y-2 text-sm text-slate-200">
              <span>Affiliate</span>
              <div className="flex items-center gap-3">
                <label className="inline-flex items-center gap-2 rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3">
                  <input type="checkbox" checked={formState.affiliate} onChange={(event) => setFormState({ ...formState, affiliate: event.target.checked })} className="h-4 w-4 rounded border-slate-600 bg-slate-950 text-cyan-400" />
                  <span>Mark as affiliate</span>
                </label>
              </div>
            </div>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Affiliate provider</span>
              <input value={formState.affiliateProvider} onChange={(event) => setFormState({ ...formState, affiliateProvider: event.target.value })} placeholder="Optional provider name" className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Suggested anchor text</span>
              <input value={formState.anchorText} onChange={(event) => setFormState({ ...formState, anchorText: event.target.value })} placeholder="Anchor text" className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Target keyword</span>
              <input value={formState.targetKeyword} onChange={(event) => setFormState({ ...formState, targetKeyword: event.target.value })} placeholder="Optional target keyword" className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Preferred placement</span>
              <input value={formState.preferredPlacement} onChange={(event) => setFormState({ ...formState, preferredPlacement: event.target.value })} placeholder="Intro, comparison table, CTA, etc." className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Status</span>
              <select value={formState.active ? 'true' : 'false'} onChange={(event) => setFormState({ ...formState, active: event.target.value === 'true' })} className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400">
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </label>
            <div className="lg:col-span-2 flex items-center gap-3 pt-2">
              <button type="submit" disabled={saving} className="inline-flex items-center justify-center rounded-2xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:opacity-60">{saving ? 'Saving…' : editMode ? 'Save changes' : 'Add link'}</button>
              <button type="button" onClick={() => { resetForm(); setAddVisible(false); }} className="inline-flex items-center justify-center rounded-2xl border border-slate-700 bg-slate-950 px-6 py-3 text-sm font-semibold text-white transition hover:border-slate-500">Cancel</button>
            </div>
          </form>
        </section>
      )}

      {importVisible && (
        <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
          <h2 className="text-xl font-semibold text-white">Import links</h2>
          <p className="mt-2 text-sm text-slate-400">Upload a CSV or JSON file with link records and preview the import before confirming.</p>
          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            <label className="space-y-2 text-sm text-slate-200">
              <span>Import format</span>
              <select value={importType} onChange={(event) => setImportType(event.target.value as 'csv' | 'json')} className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400">
                <option value="csv">CSV</option>
                <option value="json">JSON</option>
              </select>
            </label>
            <label className="space-y-2 text-sm text-slate-200">
              <span>Upload file</span>
              <input type="file" accept=".csv,application/json,text/csv" onChange={(event) => { const file = event.target.files?.[0]; if (file) handleImportFile(file); }} className="mt-2 w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none file:rounded-2xl file:border-0 file:bg-slate-700 file:px-3 file:py-2 file:text-sm file:text-white focus:border-cyan-400" />
            </label>
            <label className="space-y-2 text-sm text-slate-200 lg:col-span-2">
              <span>Paste file content</span>
              <textarea value={importContent} onChange={(event) => setImportContent(event.target.value)} placeholder={importType === 'csv' ? 'url,title,description,category,linkType,affiliate,affiliateProvider,anchorText,targetKeyword,preferredPlacement,active' : '[{ "url": "https://...", "title": "..." }]'} rows={8} className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none focus:border-cyan-400" />
            </label>
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <button type="button" onClick={previewImport} disabled={importing} className="rounded-2xl bg-cyan-500 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:opacity-60">Preview import</button>
            <button type="button" onClick={confirmImport} disabled={importing || !preview || preview.valid.length === 0} className="rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-emerald-400 disabled:opacity-60">Import valid links</button>
          </div>
          {previewError && <div className="mt-4 rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-100">{previewError}</div>}
          {preview && (
            <div className="mt-6 space-y-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="rounded-3xl border border-slate-800 bg-slate-950 p-4">
                  <p className="text-sm text-slate-400">Valid records</p>
                  <p className="mt-2 text-3xl font-semibold text-white">{preview.valid.length}</p>
                </div>
                <div className="rounded-3xl border border-slate-800 bg-slate-950 p-4">
                  <p className="text-sm text-slate-400">Duplicates</p>
                  <p className="mt-2 text-3xl font-semibold text-white">{preview.duplicates.length}</p>
                </div>
                <div className="rounded-3xl border border-slate-800 bg-slate-950 p-4">
                  <p className="text-sm text-slate-400">Invalid / unsafe</p>
                  <p className="mt-2 text-3xl font-semibold text-white">{preview.invalid.length + preview.unsafe.length}</p>
                </div>
              </div>
              {preview.duplicates.length > 0 && (
                <div className="rounded-3xl border border-amber-500/30 bg-amber-900/5 p-4 text-sm text-slate-200">
                  <p className="font-semibold text-amber-200">Duplicate records</p>
                  <ul className="mt-2 list-disc pl-5 text-slate-300">
                    {preview.duplicates.slice(0, 5).map((item, index) => (<li key={index}>{item.reason || 'Duplicate entry detected.'}</li>))}
                  </ul>
                </div>
              )}
              {preview.invalid.length > 0 && (
                <div className="rounded-3xl border border-rose-500/30 bg-rose-900/5 p-4 text-sm text-slate-200">
                  <p className="font-semibold text-rose-200">Invalid records</p>
                  <ul className="mt-2 list-disc pl-5 text-slate-300">
                    {preview.invalid.slice(0, 5).map((item, index) => (<li key={index}>{item.error || 'Invalid record.'}</li>))}
                  </ul>
                </div>
              )}
              {preview.unsafe.length > 0 && (
                <div className="rounded-3xl border border-orange-500/30 bg-orange-900/5 p-4 text-sm text-slate-200">
                  <p className="font-semibold text-orange-200">Unsafe records</p>
                  <ul className="mt-2 list-disc pl-5 text-slate-300">
                    {preview.unsafe.slice(0, 5).map((item, index) => (<li key={index}>{item.error || 'Unsafe URL detected.'}</li>))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </section>
      )}

      <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-xl font-semibold text-white">Your links</h2>
            <p className="mt-2 text-sm text-slate-400">Active and inactive links are stored for your personal library only.</p>
          </div>
          <div className="text-sm text-slate-400">{loading ? 'Refreshing…' : `${links.length} links loaded`}</div>
        </div>

        {links.length === 0 && !loading ? (
          <div className="mt-8 rounded-3xl border border-dashed border-slate-700 bg-slate-950/60 p-8 text-center text-slate-300">
            <p className="text-xl font-semibold text-white">Your Link Library is empty</p>
            <p className="mt-2 text-sm text-slate-400">Add useful resources, product/service links, affiliate opportunities, and internal references to make your content strategy smarter.</p>
            <div className="mt-5 flex flex-col items-center justify-center gap-3 sm:flex-row sm:justify-center">
              <button type="button" onClick={() => { setAddVisible(true); setImportVisible(false); }} className="rounded-full bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400">Add your first link</button>
              <button type="button" onClick={() => { setImportVisible(true); setAddVisible(false); }} className="rounded-full border border-slate-700 bg-transparent px-6 py-3 text-sm font-semibold text-white transition hover:border-slate-500">Import links</button>
            </div>
          </div>
        ) : (
          <div className="mt-6 overflow-hidden rounded-3xl border border-slate-800/80 bg-slate-950/80">
            <div className="overflow-x-auto">
              <table className="min-w-full border-separate border-spacing-0 text-left text-sm text-slate-300">
                <thead className="bg-slate-900/80 text-slate-400">
                  <tr>
                    <th className="p-4">Title</th>
                    <th className="p-4">URL</th>
                    <th className="p-4">Type</th>
                    <th className="p-4">Category</th>
                    <th className="p-4">Affiliate</th>
                    <th className="p-4">Safety</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {links.map((link) => (
                    <tr key={link.id} className="border-t border-slate-800/80 hover:bg-slate-900/80">
                      <td className="p-4 align-top text-white">{link.title || 'Untitled'}</td>
                      <td className="p-4 align-top text-slate-300 break-all"><a href={link.url} target="_blank" rel="noreferrer noopener" className="underline">{new URL(link.url).hostname}</a></td>
                      <td className="p-4 align-top">{link.linkType || 'GENERAL'}</td>
                      <td className="p-4 align-top">{link.category || '—'}</td>
                      <td className="p-4 align-top">{link.affiliate ? 'Yes' : 'No'}</td>
                      <td className="p-4 align-top">{link.safetyStatus || 'UNKNOWN'}</td>
                      <td className="p-4 align-top">{link.active ? 'Active' : 'Inactive'}</td>
                      <td className="p-4 align-top space-y-2">
                        <button type="button" onClick={() => openEdit(link)} className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-100 hover:border-cyan-400">Edit</button>
                        <button type="button" onClick={() => toggleActive(link)} className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-100 hover:border-emerald-400">{link.active ? 'Disable' : 'Enable'}</button>
                        <button type="button" onClick={() => deleteLink(link)} className="w-full rounded-2xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-100 hover:border-rose-400">Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
