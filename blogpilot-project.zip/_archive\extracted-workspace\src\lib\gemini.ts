﻿import { GoogleGenerativeAI } from '@google/generative-ai';

const GEMINI_MODELS = ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-1.5-flash', 'gemini-1.5-pro'];
const DEFAULT_MAX_TOKENS = 1024;

function getApiKey(): string | undefined {
  const envKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_GENERATIVE_API_KEY;
  if (envKey && envKey.trim()) return envKey.trim();
  return undefined;
}

let geminiClient: GoogleGenerativeAI | null = null;

function getClient(): GoogleGenerativeAI | null {
  if (geminiClient) return geminiClient;
  const key = getApiKey();
  if (!key) return null;
  geminiClient = new GoogleGenerativeAI(key);
  return geminiClient;
}

export function isGeminiConfigured(): boolean {
  return !!getApiKey();
}

export function resolveGeminiKey(): string {
  return getApiKey() || '';
}

function extractText(result: any): string | null {
  if (!result) return null;
  if (typeof result === 'string') return result.trim();
  if (result?.response?.text) {
    const text = typeof result.response.text === 'function'
      ? result.response.text()
      : result.response.text;
    return typeof text === 'string' ? text.trim() : null;
  }
  if (result?.text) {
    if (typeof result.text === 'function') return result.text().trim();
    if (typeof result.text === 'string') return result.text.trim();
  }
  const candidate = result?.candidates?.[0]?.content?.parts?.[0]?.text ||
    result?.candidates?.[0]?.content?.text ||
    result?.choices?.[0]?.message?.content ||
    result?.choices?.[0]?.text;
  return candidate ? String(candidate).trim() : null;
}

async function tryGemini(prompt: string, maxOutputTokens: number): Promise<string | null> {
  const client = getClient();
  if (!client) return null;

  let lastError: any = null;
  for (const modelName of GEMINI_MODELS) {
    try {
      const model = client.getGenerativeModel({
        model: modelName,
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens,
        },
      });
      const result = await model.generateContent(prompt);
      const text = extractText(result);
      if (text && text.length > 0) return text;
    } catch (error: any) {
      lastError = error;
    }
  }

  if (lastError) {
    console.warn('[gemini] All Gemini models failed:', lastError?.message || lastError);
  }
  return null;
}

async function tryZaiSdk(prompt: string, maxOutputTokens: number): Promise<string | null> {
  try {
    const mod = await import('z-ai-web-dev-sdk');
    const ZAI = mod.default || mod;
    const zai = await ZAI.create();
    const result = await zai.chat.completions.create({
      model: 'kilo/kilo-auto/free',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: maxOutputTokens,
      temperature: 0.2,
    });
    return extractText(result);
  } catch (error: any) {
    const msg = error?.message || String(error);
    if (msg.includes('Configuration file not found')) {
      console.warn('[gemini] z-ai-web-dev-sdk not configured (no .z-ai-config file).');
    } else {
      console.warn('[gemini] z-ai-web-dev-sdk fallback failed:', msg);
    }
    return null;
  }
}

function generateMock(prompt: string, maxOutputTokens: number): string {
  const keywordMatch = prompt.match(/query:\s*"([^"]+)"/i) ||
    prompt.match(/for the query:\s*"([^"]+)"/i) ||
    prompt.match(/"query":\s*"([^"]+)"/i);
  const keyword = keywordMatch ? keywordMatch[1].trim() : 'the requested topic';

  const titleMatch = prompt.match(/title:\s*"([^"]+)"/i) ||
    prompt.match(/Use the title:\s*"([^"]+)"/i) ||
    prompt.match(/"title":\s*"([^"]+)"/i);
  const title = titleMatch ? titleMatch[1].trim() : `Understanding ${keyword}`;

  const headings = [
    `What Is ${keyword}?`,
    `Why ${keyword} Matters`,
    `Key Benefits`,
    `How to Get Started`,
    `Common Challenges`,
    `Best Practices`,
    `Frequently Asked Questions`,
    `Conclusion`,
  ];

  let article = `# ${title}\n\n`;
  article += `${keyword.charAt(0).toUpperCase() + keyword.slice(1)} is an important topic that deserves careful attention. This article provides a comprehensive overview, practical guidance, and actionable insights to help you understand and master ${keyword}.\n\n`;

  for (const h of headings) {
    article += `## ${h}\n\n`;
    article += `When exploring ${keyword}, it's essential to consider multiple aspects. Success with ${keyword} comes from combining knowledge with practical application and staying informed about new developments.\n\n`;
    article += `Key considerations for ${keyword}:\n\n`;
    for (let i = 1; i <= 5; i++) {
      article += `- **Point ${i}**: Understanding this aspect of ${keyword} helps build a more complete picture and enables better decision-making.\n`;
    }
    article += `\n`;
  }

  article += `## Final Thoughts\n\n`;
  article += `Success with ${keyword} comes from combining knowledge with practical application. By following the guidance outlined above, you can develop confidence and expertise in this area.\n\n`;
  article += `Remember that ${keyword} is an evolving field, and staying informed about new developments will help you maintain your edge.\n`;

  if (article.length <= maxOutputTokens * 4) return article;

  const truncated = article.slice(0, maxOutputTokens * 4);
  const lastPara = truncated.lastIndexOf('\n\n');
  return lastPara > 0 ? truncated.slice(0, lastPara) : truncated;
}

export async function generateText(
  prompt: string,
  maxOutputTokens: number = DEFAULT_MAX_TOKENS,
): Promise<string> {
  if (isGeminiConfigured()) {
    const text = await tryGemini(prompt, maxOutputTokens);
    if (text) return text;
  }

  const zaiText = await tryZaiSdk(prompt, maxOutputTokens);
  if (zaiText) return zaiText;

  console.warn('[gemini] Falling back to mock generation (no AI provider available).');
  return generateMock(prompt, maxOutputTokens);
}

export async function generateTextWithFallback(
  prompt: string,
  maxOutputTokens: number = DEFAULT_MAX_TOKENS,
): Promise<{ text: string; provider: string }> {
  if (isGeminiConfigured()) {
    const text = await tryGemini(prompt, maxOutputTokens);
    if (text) return { text, provider: 'gemini' };
  }

  const zaiText = await tryZaiSdk(prompt, maxOutputTokens);
  if (zaiText) return { text: zaiText, provider: 'z-ai' };

  console.warn('[gemini] Falling back to mock generation (no AI provider available).');
  return { text: generateMock(prompt, maxOutputTokens), provider: 'mock' };
}

export async function geminiGenerate(
  prompt: string,
  options: {
    systemInstruction?: string;
    temperature?: number;
    maxOutputTokens?: number;
    jsonMode?: boolean;
    enableSearchGrounding?: boolean;
  } = {}
): Promise<{ text: string; usageMetadata?: any }> {
  const fullPrompt = options.systemInstruction
    ? `${options.systemInstruction}\n\n${prompt}`
    : prompt;
  const maxTokens = options.maxOutputTokens || DEFAULT_MAX_TOKENS;
  const result = await generateTextWithFallback(fullPrompt, maxTokens);
  return {
    text: result.text,
    usageMetadata: {},
  };
}

export async function geminiFactCheck(
  prompt: string,
  context?: string
): Promise<{ text: string; groundingMetadata?: any; usageMetadata?: any }> {
  const fullPrompt = context ? `${context}\n\n${prompt}` : prompt;
  const result = await generateTextWithFallback(fullPrompt, 2048);
  return {
    text: result.text,
    groundingMetadata: undefined,
    usageMetadata: {},
  };
}

export async function generateMarkdown(
  promptOrOptions: string | {
    systemInstruction?: string;
    userPrompt?: string;
    model?: string;
    maxOutputTokens?: number;
    temperature?: number;
  } = {},
  maybeOptions?: {
    systemInstruction?: string;
    userPrompt?: string;
    model?: string;
    maxOutputTokens?: number;
    temperature?: number;
  }
): Promise<{ text: string }> {
  let prompt: string;
  let options: { systemInstruction?: string; userPrompt?: string; maxOutputTokens?: number } = {};

  if (typeof promptOrOptions === 'string') {
    prompt = promptOrOptions;
    options = maybeOptions || {};
  } else {
    options = promptOrOptions;
    prompt = options.userPrompt || '';
  }

  const fullPrompt = options.systemInstruction
    ? `${options.systemInstruction}\n\n${prompt}`
    : prompt;
  const maxTokens = options.maxOutputTokens || DEFAULT_MAX_TOKENS;
  const text = await generateText(fullPrompt, maxTokens);
  return { text };
}
