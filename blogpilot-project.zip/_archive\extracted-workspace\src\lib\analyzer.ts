﻿import { searchDuckDuckGoHtml, searchSerpApi } from './serp';
import { fetchPageSnapshot, PageSnapshot } from './scraper';
import { generateText, isGeminiConfigured } from './gemini';
import { suggestLinksForArticle } from './linkLibrary';

// Simple in-memory cache for analyzer results. TTL configurable via env ANALYZER_CACHE_TTL_SEC (default 600s).
const ANALYZER_CACHE_TTL = Number(process.env.ANALYZER_CACHE_TTL_SEC || 600) * 1000; // ms
const analyzerCache = new Map<string, { expires: number; value: OpportunityReport }>();


export type OpportunityReport = {
  query: string;
  fetchedAt: string;
  topResults: PageSnapshot[];
  searchIntent: 'informational' | 'transactional' | 'navigational' | 'commercial' | 'unknown';
  contentGaps: string[];
  missingSubtopics: string[];
  faqOpportunities: string[];
  featuredSnippetOpportunities: string[];
  internalLinkingOpportunities: string[];
  freshnessIssues: { url: string; ageDays?: number | null }[];
  competitionLevel: 'low' | 'medium' | 'high' | 'very_high';
  opportunityScore: number;
  beatTop10Highlights: string[];
  personalizedComparison?: {
    userUrl: string;
    missingTopics: string[];
    weakSections: string[];
  } | null;
  recommendedLinks?: Array<{
    url: string;
    title?: string;
    reason: string;
    suggestedAnchor: string;
    suggestedPlacement?: string | null;
    linkType?: string | null;
    monetizationPotential?: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
  }>;
  aiRecommendations?: {
    recommended_h1?: string;
    recommended_h2?: string[];
    recommended_h3?: string[];
    suggested_faqs?: string[];
    top_improvements?: string[];
    raw?: string;
    error?: string;
  };
};

function detectSearchIntent(query: string) {
  const q = query.toLowerCase();
  if (q.match(/\b(buy|price|coupon|discount|best price|compare|vs|sale)\b/)) return 'transactional';
  if (q.match(/\b(how to|what is|why|guide|tutorial|how do i|tips|ways to|examples|best practices)\b/)) return 'informational';
  if (q.match(/\b(login|facebook|twitter|reddit|site:)\b/)) return 'navigational';
  if (q.match(/\b(review|best|top|vs|comparison)\b/)) return 'commercial';
  return 'informational';
}

function simpleCompetitionScore(results: PageSnapshot[]) {
  let score = 0;
  for (const r of results) {
    const wc = r.wordCount || 0;
    const headings = (r.h1?.length || 0) + (r.h2?.length || 0) + (r.h3?.length || 0);
    if (wc > 2500) score += 18;
    else if (wc > 1800) score += 14;
    else if (wc > 1200) score += 10;
    else if (wc > 700) score += 6;
    else score += 3;

    if (headings > 12) score += 12;
    else if (headings > 8) score += 8;
    else if (headings > 4) score += 4;

    if ((r.metaDescription || '').toLowerCase().includes('updated') || (r.title || '').toLowerCase().match(/\b(updated|202\d|202[0-9])\b/)) {
      score -= 2;
    }
  }

  const norm = Math.max(0, Math.min(100, Math.round(score / (results.length || 1))));
  if (norm > 70) return { level: 'very_high' as const, score: norm };
  if (norm > 45) return { level: 'high' as const, score: norm };
  if (norm > 20) return { level: 'medium' as const, score: norm };
  return { level: 'low' as const, score: norm };
}

function extractTopicsFromSnapshots(snapshots: PageSnapshot[]) {
  const topics = new Map<string, number>();
  for (const s of snapshots) {
    const text = [s.title, s.metaDescription, s.textSnippet].filter(Boolean).join(' ');
    const words = text
      .toLowerCase()
      .replace(/["'“”.,:;()\[\]{}<>\/\\]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 4 && !w.match(/^(about|which|there|their|these|other|after|before|where|under|while)$/));
    for (const w of words) topics.set(w, (topics.get(w) || 0) + 1);
  }
  return Array.from(topics.entries()).sort((a, b) => b[1] - a[1]).slice(0, 30).map((entry) => entry[0]);
}

export async function analyzeQuery(query: string, opts?: { numResults?: number; userUrl?: string; userId?: string | null }) {
  const num = opts?.numResults || 10;
  const cacheKey = `${query}::${num}`;
  const cached = analyzerCache.get(cacheKey);
  if (cached && cached.expires > Date.now()) {
    return cached.value;
  }
  let serp: any;
  let serpError: string | null = null;
  try {
    serp = await searchSerpApi(query, num);
  } catch (error: any) {
    serpError = error?.message || String(error);
    console.warn('SERP API failed, falling back to DuckDuckGo HTML scraper:', serpError);
    try {
      serp = await searchDuckDuckGoHtml(query, num);
    } catch (ddgError: any) {
      serpError = serpError + ' | DuckDuckGo fallback also failed: ' + (ddgError?.message || String(ddgError));
      console.warn('DuckDuckGo HTML scraper also failed, using mock results:', ddgError?.message || ddgError);
      serp = { results: [], raw: { error: serpError } };
    }
  }
  const links = (serp?.results || []).map((r: any) => r.link).filter(Boolean) as string[];

  const snapshots: PageSnapshot[] = [];
  for (const link of links) {
    try {
      snapshots.push(await fetchPageSnapshot(link));
    } catch (err) {
      snapshots.push({ url: link, status: 0, fetchedAt: new Date().toISOString() } as PageSnapshot);
    }
  }

  let userSnapshot: PageSnapshot | null = null;
  if (opts?.userUrl) {
    try {
      userSnapshot = await fetchPageSnapshot(opts.userUrl);
    } catch (err) {
      userSnapshot = { url: opts.userUrl, status: 0, fetchedAt: new Date().toISOString() } as PageSnapshot;
    }
  }

  const intent = detectSearchIntent(query);
  const comp = simpleCompetitionScore(snapshots);
  const topics = extractTopicsFromSnapshots(snapshots);

  const topicCounts = new Map<string, number>();
  for (const t of topics) topicCounts.set(t, 0);
  for (const s of snapshots) {
    const text = [s.title, s.metaDescription, s.textSnippet].filter(Boolean).join(' ').toLowerCase();
    for (const t of topics) {
      if (text.includes(t)) topicCounts.set(t, (topicCounts.get(t) || 0) + 1);
    }
  }

  const missing: string[] = [];
  for (const [t, c] of topicCounts.entries()) {
    if (c < Math.max(1, Math.round(snapshots.length * 0.3))) missing.push(t);
  }

  const faqs: string[] = [];
  for (const s of snapshots) {
    const headings = [...(s.h2 || []), ...(s.h3 || [])];
    for (const heading of headings) {
      const lower = heading.toLowerCase();
      if (lower.includes('faq') || lower.includes('question') || lower.startsWith('q:')) {
        faqs.push(heading);
      }
    }
  }

  const featured: string[] = [];
  for (const s of snapshots) {
    if ((s.textSnippet || '').length < 800 && (s.h1?.length || 0) > 0) {
      featured.push(s.url);
    }
  }

  const freshness = snapshots.map((s) => ({ url: s.url, ageDays: null }));
  const internal = snapshots.filter((s) => (s.wordCount || 0) > 800).slice(0, 5).map((s) => s.url);
  const highlights: string[] = [];
  const commonSections = new Set<string>();
  for (const s of snapshots) {
    for (const h of [...(s.h2 || []), ...(s.h3 || [])]) {
      commonSections.add(h.toLowerCase());
    }
  }

  if (!Array.from(commonSections).some((x) => x.includes('faq') || x.includes('frequently asked'))) {
    highlights.push('Top results lack a consolidated FAQ section — adding one can increase relevance.');
  }
  if (!Array.from(commonSections).some((x) => x.includes('case study') || x.includes('example') || x.includes('real-world'))) {
    highlights.push('Few top pages include examples or case studies — adding them can set your article apart.');
  }
  if (!Array.from(commonSections).some((x) => x.includes('how to') || x.includes('step') || x.includes('guide'))) {
    highlights.push('Step-by-step guidance is scarce — include actionable "how to" sections.');
  }

  const gapFactor = Math.max(1, Math.min(100, Math.round((missing.length / Math.max(1, topics.length)) * 100)));
  const rawScore = Math.max(0, 100 - comp.score + gapFactor);
  const score = Math.round(rawScore / 2 + (100 - comp.score) / 4);

  const report: OpportunityReport = {
    query,
    fetchedAt: new Date().toISOString(),
    topResults: snapshots,
    searchIntent: intent,
    contentGaps: missing.slice(0, 20),
    missingSubtopics: missing.slice(0, 12),
    faqOpportunities: Array.from(new Set(faqs)).slice(0, 20),
    featuredSnippetOpportunities: featured.slice(0, 10),
    internalLinkingOpportunities: internal,
    freshnessIssues: freshness,
    competitionLevel: comp.level,
    opportunityScore: Math.max(0, Math.min(100, score)),
    beatTop10Highlights: highlights,
    recommendedLinks: [],
  };

  if (serpError) {
    (report as any).serpError = serpError;
  }

  // Attach link suggestions from user's link library (if available)
  try {
    const linkSuggestions = await suggestLinksForArticle({ query, searchIntent: intent, topics, topResultsUrls: links, userId: opts?.userId || null });
    report.recommendedLinks = linkSuggestions.map((s: any) => ({
      url: s.link.url,
      title: s.link.title,
      reason: s.reason,
      suggestedAnchor: s.suggestedAnchor,
      suggestedPlacement: s.suggestedPlacement,
      linkType: s.link.linkType || null,
      monetizationPotential: s.monetizationPotential,
    }));
  } catch (e) {
    console.warn('Link suggestion generation failed', e);
  }

  // Personalized comparison vs user's provided URL (if any)
  if (userSnapshot) {
    try {
      const userText = [userSnapshot.title, userSnapshot.metaDescription, userSnapshot.textSnippet].filter(Boolean).join(' ').toLowerCase();
      const missingTopicsForUser = topics.filter((t) => !userText.includes(t)).slice(0, 20);
      const userHeadings = new Set<string>([...(userSnapshot.h2||[]).map(h=>h.toLowerCase()), ...(userSnapshot.h3||[]).map(h=>h.toLowerCase())]);
      const weakSections: string[] = [];
      for (const cs of Array.from(commonSections)) {
        if (!userHeadings.has(cs)) weakSections.push(cs);
      }
      report.personalizedComparison = { userUrl: userSnapshot.url, missingTopics: missingTopicsForUser, weakSections: weakSections.slice(0, 20) };
    } catch (err) {
      report.personalizedComparison = { userUrl: userSnapshot?.url || '', missingTopics: [], weakSections: [] };
    }
  } else {
    report.personalizedComparison = null;
  }

  const gkey = isGeminiConfigured();
  if (gkey) {
    try {
      const prompt = `You are an SEO analysis assistant. Given the query: "${query}" and the top competitor titles, descriptions, and headings below, provide a JSON object with keys: recommended_h1, recommended_h2 (array), recommended_h3 (array), suggested_faqs (array), and top_improvements (array). Respond with raw JSON only.\n\n${snapshots
        .slice(0, 6)
        .map((s) => `- Title: ${s.title || 'unknown'}\n  Description: ${s.metaDescription || 'none'}\n  H2/H3: ${[...(s.h2 || []), ...(s.h3 || [])].slice(0, 5).join('; ')}`)
        .join('\n\n')}`;

      const gptResponse = await generateText(prompt, 512);
      try {
        const parsed = JSON.parse(gptResponse);
        report.aiRecommendations = parsed;
      } catch (err) {
        report.aiRecommendations = { raw: gptResponse };
      }
    } catch (error: any) {
      report.aiRecommendations = { error: String(error) };
    }
  }

  // cache the report
  try {
    analyzerCache.set(cacheKey, { expires: Date.now() + ANALYZER_CACHE_TTL, value: report });
  } catch (e) {
    console.warn('Failed to cache analyzer result', e);
  }

  return report;
}

