import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';

/**
 * Real affiliate performance: clicks counted by the /api/aff/[linkId] redirect.
 * Conversions/revenue are NOT shown until a network API reports them —
 * this endpoint never fabricates money numbers.
 */
export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    const since = new Date(Date.now() - 30 * 24 * 3600 * 1000);

    const byArticle = await prisma.affiliateClick.groupBy({
      by: ['articleId'],
      where: { userId, createdAt: { gte: since }, articleId: { not: null } },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 10,
    });

    const articleIds = byArticle.map(b => b.articleId!).filter(Boolean);
    const articles = articleIds.length
      ? await prisma.article.findMany({
          where: { id: { in: articleIds } },
          select: { id: true, title: true },
        })
      : [];
    const titleMap = new Map(articles.map(a => [a.id, a.title]));

    const totals = {
      clicks30d: await prisma.affiliateClick.count({ where: { userId, createdAt: { gte: since } } }),
      clicksTotal: await prisma.affiliateClick.count({ where: { userId } }),
      trackedLinks: await prisma.link.count({ where: { userId, affiliate: true, active: true } }),
      unsafeLinks: await prisma.link.count({ where: { userId, affiliate: true, safetyStatus: 'UNSAFE' } }),
    };

    return NextResponse.json({
      ok: true,
      data: {
        totals,
        topArticles: byArticle.map(b => ({
          articleId: b.articleId,
          title: titleMap.get(b.articleId!) || 'Unknown article',
          clicks30d: b._count.id,
        })),
        note: 'Clicks are real redirect hits. Conversion/revenue reporting requires connecting your network API.',
      },
    });
  } catch (error: any) {
    console.error('Affiliate stats error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load affiliate stats' }, { status: 500 });
  }
}
