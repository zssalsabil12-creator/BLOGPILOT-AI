import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { runAgentForSite } from '@/lib/agent-runner';

const bodySchema = z.object({
  siteId: z.string().min(1).max(64),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'siteId is required' }, { status: 400 });
  }

  const limit = await checkRateLimit(`agent-run:${userId}`, { windowMs: 60_000, maxRequests: 4 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Agent runs are limited — wait a minute.' }, { status: 429 });
  }

  try {
    const result = await runAgentForSite(userId, parsed.data.siteId);
    return NextResponse.json({ ok: true, data: result });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 502;
    return NextResponse.json({ ok: false, error: error?.message || 'Agent run failed' }, { status });
  }
}
