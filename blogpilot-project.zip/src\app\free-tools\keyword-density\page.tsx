'use client';

import React, { useState, useCallback, useRef } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Search,
  AlertTriangle,
  BarChart3,
  RotateCcw,
  Copy,
  Check,
  Target,
} from 'lucide-react';

const STOP_WORDS = new Set([
  'a','an','the','and','or','but','in','on','at','to','for','of','with','by',
  'from','up','about','into','through','during','before','after','above','below',
  'between','out','off','over','under','again','further','then','once','here',
  'there','when','where','why','how','all','each','every','both','few','more',
  'most','other','some','such','no','nor','not','only','own','same','so',
  'than','too','very','s','t','can','will','just','don','should','now','d',
  'll','m','o','re','ve','y','ain','aren','couldn','didn','doesn','hadn',
  'hasn','haven','isn','ma','mightn','mustn','needn','shan','shouldn','wasn',
  'weren','won','wouldn','i','me','my','myself','we','our','ours','ourselves',
  'you','your','yours','yourself','yourselves','he','him','his','himself',
  'she','her','hers','herself','it','its','itself','they','them','their',
  'theirs','themselves','what','which','who','whom','this','that','these',
  'those','am','is','are','was','were','be','been','being','have','has',
  'had','having','do','does','did','doing','would','could','shall','might',
  'must','ought','need','dare','used',
]);

interface KeywordEntry {
  word: string;
  count: number;
  percentage: number;
}

function DensityBadge({ percentage }: { percentage: number }) {
  if (percentage > 3) {
    return (
      <span className="inline-block rounded-full bg-rose-500/10 px-2.5 py-0.5 text-xs font-medium text-rose-400">
        Over-optimized
      </span>
    );
  }
  if (percentage > 2) {
    return (
      <span className="inline-block rounded-full bg-amber-500/10 px-2.5 py-0.5 text-xs font-medium text-amber-400">
        Caution
      </span>
    );
  }
  return (
    <span className="inline-block rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-xs font-medium text-emerald-400">
      Good
    </span>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs text-muted-foreground transition hover:bg-card hover:text-foreground"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function analyzeKeywords(text: string, targetKeyword?: string) {
  const trimmedText = text.trim();
  if (!trimmedText) return null;

  const allWords = trimmedText.split(/\s+/).filter(Boolean);
  const totalWords = allWords.length;

  const freqMap = new Map<string, number>();
  for (const word of allWords) {
    const cleaned = word.toLowerCase().replace(/[^a-z0-9'-]/g, '');
    if (cleaned.length < 2) continue;
    if (STOP_WORDS.has(cleaned)) continue;
    freqMap.set(cleaned, (freqMap.get(cleaned) || 0) + 1);
  }

  const allKeywords: KeywordEntry[] = Array.from(freqMap.entries())
    .map(([word, count]) => ({ word, count, percentage: totalWords > 0 ? (count / totalWords) * 100 : 0 }))
    .sort((a, b) => b.count - a.count);

  let targetCount = 0;
  let targetDensity = 0;
  if (targetKeyword && targetKeyword.trim()) {
    const phrase = targetKeyword.trim().toLowerCase();
    const lowerText = trimmedText.toLowerCase();
    const regex = new RegExp(escapeRegex(phrase), 'gi');
    const matches = lowerText.match(regex);
    targetCount = matches ? matches.length : 0;
    targetDensity = totalWords > 0 ? (targetCount / totalWords) * 100 : 0;
  }

  return { totalWords, targetCount, targetDensity, allKeywords };
}

function escapeRegex(str: string) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export default function KeywordDensityPage() {
  const [text, setText] = useState('');
  const [targetKeyword, setTargetKeyword] = useState('');
  const [results, setResults] = useState<ReturnType<typeof analyzeKeywords>>(null);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleAnalyze = useCallback(() => {
    setError(null);
    if (!text.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    const result = analyzeKeywords(text, targetKeyword);
    setResults(result);
  }, [text, targetKeyword]);

  const handleReset = useCallback(() => {
    setText('');
    setTargetKeyword('');
    setResults(null);
    setError(null);
    textareaRef.current?.focus();
  }, []);

  const charCount = text.length;
  const wordCountApprox = text.trim() ? text.trim().split(/\s+/).length : 0;

  const resultsText = results
    ? [
        `Total Words: ${results.totalWords}`,
        results.targetCount > 0
          ? `Target Keyword "${targetKeyword}": ${results.targetCount} occurrences (${results.targetDensity.toFixed(2)}%)`
          : 'No target keyword specified',
        '',
        'All Keywords:',
        ...results.allKeywords.map(k => `  ${k.word}: ${k.count} (${k.percentage.toFixed(2)}%)`),
      ].join('\n')
    : '';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Keyword Density <span className="text-gradient">Checker</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Analyze your text for keyword density and frequency. Detect keyword stuffing and optimize your content for search engines.
          </p>
        </section>

        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-4">
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste or type your text here..."
              rows={10}
              className="w-full rounded-xl border border-border bg-muted/50 p-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30 resize-y"
            />
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative flex-1 sm:max-w-xs">
                <Target className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={targetKeyword}
                  onChange={(e) => setTargetKeyword(e.target.value)}
                  placeholder="Target keyword (optional)"
                  className="w-full rounded-xl border border-border bg-muted/50 py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                />
              </div>
              <div className="flex items-center gap-3">
                <div className="text-xs text-muted-foreground">
                  {charCount.toLocaleString()} chars &middot; {wordCountApprox.toLocaleString()} words
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleAnalyze}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Search className="h-4 w-4" />
                Check Density
              </button>
              {results && (
                <button
                  onClick={handleReset}
                  className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Reset
                </button>
              )}
            </div>
          </div>
          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <span>{error}</span>
            </div>
          )}
        </section>

        {results && (
          <div className="space-y-6">
            {targetKeyword.trim() && (
              <section className="rounded-2xl border border-border bg-card/50 p-6">
                <div className="flex items-center gap-3">
                  <Target className="h-5 w-5 text-cyan-300" />
                  <h2 className="text-lg font-semibold text-foreground">
                    Target Keyword: &ldquo;{targetKeyword.trim()}&rdquo;
                  </h2>
                </div>
                <div className="mt-4 grid gap-4 sm:grid-cols-3">
                  <div className="rounded-xl border border-border bg-muted/50 p-4">
                    <span className="text-xs font-medium text-muted-foreground">Total Words</span>
                    <p className="mt-1 text-2xl font-bold text-foreground">{results.totalWords.toLocaleString()}</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/50 p-4">
                    <span className="text-xs font-medium text-muted-foreground">Keyword Count</span>
                    <p className="mt-1 text-2xl font-bold text-foreground">{results.targetCount.toLocaleString()}</p>
                  </div>
                  <div className="rounded-xl border border-border bg-muted/50 p-4">
                    <span className="text-xs font-medium text-muted-foreground">Density</span>
                    <div className="mt-1 flex items-center gap-2">
                      <p className="text-2xl font-bold text-foreground">{results.targetDensity.toFixed(2)}%</p>
                      <DensityBadge percentage={results.targetDensity} />
                    </div>
                  </div>
                </div>
                {results.targetDensity > 3 && (
                  <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 px-4 py-3 text-sm text-amber-300">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>
                      <strong>Keyword stuffing warning:</strong> Your target keyword density is {results.targetDensity.toFixed(2)}%, which exceeds the recommended 3% maximum. Consider reducing keyword usage to avoid search engine penalties.
                    </span>
                  </div>
                )}
                {results.targetDensity > 0 && results.targetDensity <= 3 && (
                  <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-500/20 bg-emerald-500/5 px-4 py-3 text-sm text-emerald-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0" />
                    <span>Your keyword density is within the recommended range (1-3%).</span>
                  </div>
                )}
              </section>
            )}

            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BarChart3 className="h-5 w-5 text-violet-300" />
                  <h2 className="text-lg font-semibold text-foreground">Full Keyword Frequency</h2>
                </div>
                <CopyButton text={resultsText} />
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {results.allKeywords.length} unique keywords found (stop words excluded).
              </p>
              {results.allKeywords.length > 0 && (
                (() => {
                  const hasStuffing = results.allKeywords.some(k => k.percentage > 3);
                  if (hasStuffing) {
                    return (
                      <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 px-4 py-3 text-sm text-amber-300">
                        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>Some keywords exceed the 3% recommended density threshold.</span>
                      </div>
                    );
                  }
                  return null;
                })()
              )}
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-left text-muted-foreground">
                      <th className="pb-2 pr-4 font-medium">#</th>
                      <th className="pb-2 pr-4 font-medium">Keyword</th>
                      <th className="pb-2 pr-4 font-medium text-right">Count</th>
                      <th className="pb-2 pr-4 font-medium text-right">Density</th>
                      <th className="pb-2 font-medium text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {results.allKeywords.map((kw, i) => (
                      <tr
                        key={kw.word}
                        className={`border-b border-border/50 ${kw.percentage > 3 ? 'bg-rose-500/5' : ''}`}
                      >
                        <td className="py-2.5 pr-4 text-muted-foreground">{i + 1}</td>
                        <td className="py-2.5 pr-4 font-medium text-foreground">{kw.word}</td>
                        <td className="py-2.5 pr-4 text-right text-muted-foreground">{kw.count}</td>
                        <td className="py-2.5 pr-4 text-right text-muted-foreground">{kw.percentage.toFixed(2)}%</td>
                        <td className="py-2.5 text-right">
                          <DensityBadge percentage={kw.percentage} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
