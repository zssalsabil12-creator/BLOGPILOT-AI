'use client';

import { useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Copy, Check, RotateCcw, FileJson } from 'lucide-react';

const ARTICLE_TYPES = ['Article', 'BlogPosting', 'NewsArticle', 'Report', 'TechnicalArticle'] as const;

export default function ArticleSchemaGeneratorPage() {
  const today = new Date().toISOString().split('T')[0];

  const [headline, setHeadline] = useState('');
  const [description, setDescription] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [authorUrl, setAuthorUrl] = useState('');
  const [datePublished, setDatePublished] = useState(today);
  const [dateModified, setDateModified] = useState(today);
  const [imageUrl, setImageUrl] = useState('');
  const [pageUrl, setPageUrl] = useState('');
  const [publisherName, setPublisherName] = useState('');
  const [publisherLogoUrl, setPublisherLogoUrl] = useState('');
  const [articleType, setArticleType] = useState<string>('Article');

  const [output, setOutput] = useState('');
  const [jsonOnly, setJsonOnly] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [error, setError] = useState('');

  const generate = () => {
    setError('');
    if (!headline.trim()) { setError('Headline is required.'); return; }
    if (!description.trim()) { setError('Description is required.'); return; }
    if (!authorName.trim()) { setError('Author Name is required.'); return; }
    if (!datePublished) { setError('Date Published is required.'); return; }
    if (!pageUrl.trim()) { setError('Page URL is required.'); return; }

    const schema: Record<string, unknown> = {
      '@context': 'https://schema.org',
      '@type': articleType,
      headline: headline.trim(),
      description: description.trim(),
      author: {
        '@type': 'Person',
        name: authorName.trim(),
        ...(authorUrl.trim() ? { url: authorUrl.trim() } : {}),
      },
      datePublished: datePublished,
      dateModified: dateModified || datePublished,
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': pageUrl.trim(),
      },
    };

    if (imageUrl.trim()) {
      schema.image = imageUrl.trim();
    }

    if (publisherName.trim()) {
      schema.publisher = {
        '@type': 'Organization',
        name: publisherName.trim(),
        ...(publisherLogoUrl.trim() ? { logo: { '@type': 'ImageObject', url: publisherLogoUrl.trim() } } : {}),
      };
    }

    const jsonStr = JSON.stringify(schema, null, 2);
    const scriptTag = `<script type="application/ld+json">\n${jsonStr}\n</script>`;

    setOutput(scriptTag);
    setJsonOnly(jsonStr);
  };

  const copyToClipboard = async (text: string, type: 'script' | 'json') => {
    await navigator.clipboard.writeText(text);
    if (type === 'script') {
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2000);
    } else {
      setCopiedJson(true);
      setTimeout(() => setCopiedJson(false), 2000);
    }
  };

  const reset = () => {
    setHeadline('');
    setDescription('');
    setAuthorName('');
    setAuthorUrl('');
    setDatePublished(today);
    setDateModified(today);
    setImageUrl('');
    setPageUrl('');
    setPublisherName('');
    setPublisherLogoUrl('');
    setArticleType('Article');
    setOutput('');
    setJsonOnly('');
    setError('');
  };

  const inputClass = 'w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring';
  const labelClass = 'text-sm font-medium text-foreground';

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className={labelClass}>Headline *</label>
              <input type="text" value={headline} onChange={(e) => setHeadline(e.target.value)} placeholder="Article headline" className={inputClass} />
            </div>
            <div className="md:col-span-2">
              <label className={labelClass}>Description *</label>
              <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Brief description of the article" rows={2} className={`${inputClass} resize-none`} />
            </div>
            <div>
              <label className={labelClass}>Author Name *</label>
              <input type="text" value={authorName} onChange={(e) => setAuthorName(e.target.value)} placeholder="John Doe" className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Author URL</label>
              <input type="url" value={authorUrl} onChange={(e) => setAuthorUrl(e.target.value)} placeholder="https://example.com/authors/john" className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Date Published *</label>
              <input type="date" value={datePublished} onChange={(e) => setDatePublished(e.target.value)} className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Date Modified</label>
              <input type="date" value={dateModified} onChange={(e) => setDateModified(e.target.value)} className={inputClass} />
            </div>
            <div className="md:col-span-2">
              <label className={labelClass}>Image URL</label>
              <input type="url" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="https://example.com/image.jpg" className={inputClass} />
            </div>
            <div className="md:col-span-2">
              <label className={labelClass}>Page URL *</label>
              <input type="url" value={pageUrl} onChange={(e) => setPageUrl(e.target.value)} placeholder="https://example.com/article" className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Publisher Name</label>
              <input type="text" value={publisherName} onChange={(e) => setPublisherName(e.target.value)} placeholder="Publisher Inc." className={inputClass} />
            </div>
            <div>
              <label className={labelClass}>Publisher Logo URL</label>
              <input type="url" value={publisherLogoUrl} onChange={(e) => setPublisherLogoUrl(e.target.value)} placeholder="https://example.com/logo.png" className={inputClass} />
            </div>
            <div className="md:col-span-2">
              <label className={labelClass}>Article Type</label>
              <div className="flex flex-wrap gap-2 mt-1">
                {ARTICLE_TYPES.map((type) => (
                  <button
                    key={type}
                    onClick={() => setArticleType(type)}
                    className={`px-3 py-1.5 rounded-lg border text-sm transition-colors ${
                      articleType === type
                        ? 'border-primary bg-primary text-primary-foreground'
                        : 'border-border text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {error && <p className="text-sm text-red-500 mt-3">{error}</p>}

          <div className="flex gap-3 mt-4">
            <button onClick={generate} className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
              Generate Schema
            </button>
            <button onClick={reset} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
          </div>
        </div>

        {output && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                  <FileJson className="w-4 h-4" /> JSON-LD Script Tag
                </h3>
                <button onClick={() => copyToClipboard(output, 'script')} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                  {copiedScript ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedScript ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">{output}</pre>
            </div>

            <div className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                  <FileJson className="w-4 h-4" /> Raw JSON
                </h3>
                <button onClick={() => copyToClipboard(jsonOnly, 'json')} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                  {copiedJson ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedJson ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">{jsonOnly}</pre>
            </div>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
