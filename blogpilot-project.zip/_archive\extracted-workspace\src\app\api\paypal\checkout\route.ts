import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/auth'
import { PLAN_CONFIG, activateSubscription, type PlanTier } from '@/lib/stripe'
import { createPaypalOrder, isPaypalConfigured } from '@/lib/paypal'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { parseBody } from '@/lib/validation'
import { paypalCheckoutSchema } from '../_validation'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/paypal/checkout
 *
 * Creates a PayPal Order for upgrading to a paid plan.
 *
 * Body:
 *   { tier: 'basic' | 'pro' | 'agency' }
 *
 * Response (live mode):
 *   200 { orderId, approvalUrl, demo: false }
 *
 * Response (demo mode — no PAYPAL_CLIENT_ID/SECRET configured):
 *   200 { demo: true, message, url }
 *   The demo path activates the subscription locally so the user can
 *   try the upgrade flow end-to-end without a real PayPal business account.
 *
 * Funds routing:
 *   When PayPal captures the order, the money lands in the merchant
 *   account that owns PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET — i.e., the
 *   admin's PayPal wallet. There is no separate payout config.
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit (10 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(paypalCheckoutSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const tier = body.tier as PlanTier
    if (!tier || !(tier in PLAN_CONFIG) || tier === 'free') {
      return NextResponse.json(
        { error: `Invalid tier. Must be one of: basic, pro, agency`, code: 'validation' },
        { status: 400 }
      )
    }

    // ─── Demo mode ──────────────────────────────────────────────────────
    // No PayPal credentials — activate the subscription locally and return
    // a fake approval URL so the front-end can complete the flow.
    if (!isPaypalConfigured()) {
      const result = await activateSubscription({
        userId: user.id,
        tier,
        gateway: 'demo',
        externalId: `demo-paypal-${Date.now()}`,
      })

      return NextResponse.json({
        demo: true,
        url: `/dashboard?demo_checkout=success&tier=${tier}&gateway=paypal`,
        message: `Demo mode: upgraded to ${PLAN_CONFIG[tier].label} via PayPal (simulated). ${
          result.creditsGranted ? `${result.creditsGranted} credits granted.` : ''
        }`,
        orderId: `demo-order-${Date.now()}`,
        approvalUrl: null,
      })
    }

    // ─── Live mode ──────────────────────────────────────────────────────
    const origin =
      request.headers.get('origin') ||
      process.env.NEXT_PUBLIC_APP_URL ||
      'http://localhost:3000'

    const returnUrl = `${origin}/dashboard?paypal=success&tier=${tier}`
    const cancelUrl = `${origin}/dashboard?paypal=cancelled`

    const order = await createPaypalOrder({
      tier,
      userId: user.id,
      returnUrl,
      cancelUrl,
    })

    if (!order.approvalUrl) {
      return NextResponse.json(
        { error: 'PayPal did not return an approval URL', code: 'paypal_error' },
        { status: 502 }
      )
    }

    // Persist a pending subscription row so we can match the capture later.
    // We don't activate the plan yet — the /api/paypal/capture endpoint
    // will flip status='active' after the buyer completes payment.
    await db.subscription.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        plan: tier,
        status: 'incomplete',
        stripeSubscriptionId: order.id, // borrowed column — stores PayPal order id
      },
      update: {
        plan: tier,
        status: 'incomplete',
        stripeSubscriptionId: order.id,
      },
    })

    return NextResponse.json({
      orderId: order.id,
      approvalUrl: order.approvalUrl,
      demo: false,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'paypal/checkout')
  }
}
