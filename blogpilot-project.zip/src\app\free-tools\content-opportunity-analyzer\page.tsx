﻿'use client';

import React, { useCallback, useMemo, useRef, useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import type { OpportunityReport, RecommendedLink } from '@/lib/free-tools/types';
import {
  Search,
  Loader2,
  AlertTriangle,
  Copy,
  Check,
  RotateCcw,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Link2,
  FileText,
  Target,
  BarChart3,
  TrendingUp,
  Lightbulb,
  Sparkles,
} from 'lucide-react';

const getInputType = (value: string): 'keyword' | 'article' | 'website' => {
  const normalized = value.trim().toLowerCase();
  if (!normalized) return 'keyword';
  if (normalized.startsWith('http://') || normalized.startsWith('https://')) return 'article';
  if (normalized.includes('.') && !normalized.includes(' ')) return 'website';
  return 'keyword';
};

function safeBase64Encode(value: string) {
  try {
    const utf8Bytes = unescape(encodeURIComponent(value));
    const b64 = typeof window !== 'undefined' && window.btoa ? window.btoa(utf8Bytes) : Buffer.from(value).toString('base64');
    return encodeURIComponent(b64);
  } catch {
    try {
      return encodeURIComponent(btoa(unescape(encodeURIComponent(value))));
    } catch {
      return encodeURIComponent(btoa(value));
    }
  }
}

function CopyButton({ text, label }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  }, [text]);
  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground transition hover:bg-muted hover:text-foreground"
      aria-label={label || 'Copy to clipboard'}
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied' : label || 'Copy'}
    </button>
  );
}

function ScoreGauge({ score }: { score: number }) {
  const color = score >= 70 ? 'text-emerald-400' : score >= 40 ? 'text-amber-400' : 'text-rose-400';
  const bg = score >= 70 ? 'from-emerald-400/20' : score >= 40 ? 'from-amber-400/20' : 'from-rose-400/20';
  return (
    <div className="relative flex h-24 w-24 items-center justify-center">
      <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${bg} to-transparent blur-xl`} />
      <span className={`relative text-3xl font-bold ${color}`}>{score}</span>
    </div>
  );
}

function CollapsibleSection({ title, icon: Icon, children, defaultOpen = false }: {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border border-border bg-card/50 transition hover:border-primary/20">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-3 px-5 py-4 text-left"
      >
        <Icon className="h-5 w-5 text-cyan-300 shrink-0" />
        <span className="flex-1 font-semibold text-foreground">{title}</span>
        {open ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
      </button>
      {open && <div className="border-t border-border px-5 py-4">{children}</div>}
    </div>
  );
}

function ResultCard({ result, index }: { result: OpportunityReport['topResults'][0]; index: number }) {
  return (
    <a
      href={result.url}
      target="_blank"
      rel="noreferrer"
      className="block rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/20 hover:bg-card/50"
    >
      <div className="flex items-start gap-3">
        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-300">
          {index + 1}
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-medium text-foreground line-clamp-1">{result.title || new URL(result.url).hostname}</p>
          <p className="mt-1 text-xs text-muted-foreground">
            {result.wordCount ? `${result.wordCount.toLocaleString()} words` : '—'}
            {result.h1?.length ? ` · ${(result.h1?.length || 0) + (result.h2?.length || 0) + (result.h3?.length || 0)} headings` : ''}
          </p>
          {result.metaDescription && (
            <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{result.metaDescription}</p>
          )}
        </div>
        <ExternalLink className="h-4 w-4 shrink-0 text-muted-foreground" />
      </div>
    </a>
  );
}

function LinkCard({ link }: { link: RecommendedLink }) {
  const potColor = link.monetizationPotential === 'HIGH' ? 'text-emerald-400 bg-emerald-400/10' :
    link.monetizationPotential === 'MEDIUM' ? 'text-amber-400 bg-amber-400/10' :
    link.monetizationPotential === 'LOW' ? 'text-muted-foreground bg-muted' : 'text-muted-foreground bg-muted/50';
  return (
    <div className="rounded-xl border border-border bg-card/30 p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <a href={link.url} target="_blank" rel="noreferrer" className="font-medium text-foreground underline-offset-2 hover:underline line-clamp-1">
            {link.title || link.url}
          </a>
          <p className="mt-1 text-sm text-muted-foreground">{link.reason}</p>
        </div>
        {link.monetizationPotential && (
          <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium ${potColor}`}>
            {link.monetizationPotential}
          </span>
        )}
      </div>
      <div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground">
        {link.suggestedAnchor && (
          <span>Anchor: <span className="font-medium text-foreground">{link.suggestedAnchor}</span></span>
        )}
        {link.suggestedPlacement && (
          <span>Placement: <span className="font-medium text-foreground">{link.suggestedPlacement}</span></span>
        )}
      </div>
    </div>
  );
}

function ReportDisplay({ report }: { report: OpportunityReport }) {
  const fullText = useMemo(() => {
    const lines = [
      `Content Opportunity Report: ${report.query}`,
      `Score: ${report.opportunityScore}/100 | Intent: ${report.searchIntent} | Competition: ${report.competitionLevel}`,
      '',
      'Beat the Top 10:',
      ...report.beatTop10Highlights.map((h) => `- ${h}`),
      '',
      'Content Gaps:',
      ...report.contentGaps.map((g) => `- ${g}`),
      '',
      'FAQ Opportunities:',
      ...report.faqOpportunities.map((f) => `- ${f}`),
    ];
    if (report.recommendedLinks?.length) {
      lines.push('', 'Recommended Links:');
      report.recommendedLinks.forEach((l) => {
        lines.push(`- ${l.title || l.url} (${l.suggestedAnchor}) — ${l.reason}`);
      });
    }
    return lines.join('\n');
  }, [report]);

  return (
    <div className="space-y-6">
      {/* Score Header */}
      <section className="rounded-2xl border border-border bg-card/50 p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <ScoreGauge score={report.opportunityScore} />
            <div>
              <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Opportunity Score</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Intent: <span className="font-medium text-foreground capitalize">{report.searchIntent}</span>
                {' · '}
                Competition: <span className="font-medium text-foreground capitalize">{report.competitionLevel.replace('_', ' ')}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <CopyButton text={fullText} label="Copy report" />
            <button
              onClick={() => {
                const payload = safeBase64Encode(JSON.stringify(report));
                window.location.href = `/dashboard/generate?opportunity=${payload}`;
              }}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-5 py-2.5 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40"
            >
              <Sparkles className="h-4 w-4" />
              Build Article
            </button>
          </div>
        </div>
      </section>

      {/* Beat the Top 10 */}
      {report.beatTop10Highlights.length > 0 && (
        <CollapsibleSection title="Beat the Top 10 — What competitors miss" icon={TrendingUp} defaultOpen>
          <ul className="space-y-2">
            {report.beatTop10Highlights.map((h, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-400" />
                {h}
              </li>
            ))}
          </ul>
        </CollapsibleSection>
      )}

      {/* Competitor Snapshot + Gaps Side by Side */}
      <div className="grid gap-6 lg:grid-cols-2">
        <CollapsibleSection title={`Competitor Snapshot (${report.topResults.length} pages)`} icon={BarChart3} defaultOpen>
          <div className="space-y-3">
            {report.topResults.map((result, i) => (
              <ResultCard key={i} result={result} index={i} />
            ))}
          </div>
          {report.personalizedComparison && (
            <div className="mt-4 rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
              <p className="text-sm font-semibold text-amber-300">Your Page vs. Competitors</p>
              <p className="mt-1 text-xs text-muted-foreground break-all">{report.personalizedComparison.userUrl}</p>
              {report.personalizedComparison.missingTopics.length > 0 && (
                <div className="mt-3">
                  <p className="text-xs font-medium text-muted-foreground">Missing Topics</p>
                  <ul className="mt-1 space-y-1">
                    {report.personalizedComparison.missingTopics.slice(0, 6).map((t, i) => (
                      <li key={i} className="text-sm text-muted-foreground">· {t}</li>
                    ))}
                  </ul>
                </div>
              )}
              {report.personalizedComparison.weakSections.length > 0 && (
                <div className="mt-3">
                  <p className="text-xs font-medium text-muted-foreground">Weak Sections</p>
                  <ul className="mt-1 space-y-1">
                    {report.personalizedComparison.weakSections.slice(0, 6).map((s, i) => (
                      <li key={i} className="text-sm text-muted-foreground">· {s}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </CollapsibleSection>

        <div className="space-y-6">
          <CollapsibleSection title="Content Gaps & FAQ Opportunities" icon={Lightbulb} defaultOpen>
            <div className="space-y-4">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Missing Topics</p>
                <ul className="mt-2 space-y-1.5">
                  {report.contentGaps.slice(0, 8).map((gap, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-400" />
                      {gap}
                    </li>
                  ))}
                </ul>
              </div>
              {report.faqOpportunities.length > 0 && (
                <div>
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">FAQ Opportunities</p>
                  <ul className="mt-2 space-y-1.5">
                    {report.faqOpportunities.slice(0, 6).map((faq, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-violet-400" />
                        {faq}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CollapsibleSection>

          {report.aiRecommendations && !report.aiRecommendations.error && (
            <CollapsibleSection title="AI-Recommended Structure" icon={Target}>
              <div className="space-y-3">
                {report.aiRecommendations.recommended_h1 && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Suggested H1</p>
                    <p className="mt-1 text-sm font-medium text-foreground">{report.aiRecommendations.recommended_h1}</p>
                  </div>
                )}
                {report.aiRecommendations.recommended_h2?.length ? (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Suggested H2s</p>
                    <ul className="mt-1 space-y-1">
                      {report.aiRecommendations.recommended_h2.map((h, i) => (
                        <li key={i} className="text-sm text-muted-foreground">· {h}</li>
                      ))}
                    </ul>
                  </div>
                ) : report.missingSubtopics.length > 0 ? (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Suggested H2s</p>
                    <ul className="mt-1 space-y-1">
                      {report.missingSubtopics.slice(0, 6).map((h, i) => (
                        <li key={i} className="text-sm text-muted-foreground">· {h}</li>
                      ))}
                    </ul>
                  </div>
                ) : null}
                {(report.aiRecommendations.recommended_h3?.length || report.faqOpportunities.length) > 0 && (
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Suggested H3s / FAQs</p>
                    <ul className="mt-1 space-y-1">
                      {(report.aiRecommendations.recommended_h3 || report.faqOpportunities).slice(0, 6).map((h, i) => (
                        <li key={i} className="text-sm text-muted-foreground">· {h}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </CollapsibleSection>
          )}
        </div>
      </div>

      {/* Recommended Links */}
      {report.recommendedLinks && report.recommendedLinks.length > 0 && (
        <CollapsibleSection title="Recommended Links from Your Link Library" icon={Link2}>
          <div className="space-y-3">
            {report.recommendedLinks.map((ln, i) => (
              <LinkCard key={i} link={ln} />
            ))}
          </div>
          <p className="mt-4 text-xs text-muted-foreground">
            Add more links to your <a href="/dashboard/link-library" className="underline text-cyan-400 hover:text-cyan-300">Link Library</a> to get better recommendations.
          </p>
        </CollapsibleSection>
      )}
    </div>
  );
}

export default function AnalyzerPage() {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<OpportunityReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const inputType = useMemo(() => getInputType(input), [input]);

  async function submit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setReport(null);
    if (!input || input.trim().length < 2) {
      setError('Enter a keyword, article URL, or website to analyze.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input, type: inputType, numResults: 10 }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 429) {
          setError(`Rate limit exceeded. Please wait ${data.retryAfter || 60}s before trying again.`);
        } else {
          setError(data?.error || 'Analysis failed. Please try again.');
        }
      } else {
        setReport(data.report);
      }
    } catch (err: any) {
      setError(err?.message || 'Network error. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setInput('');
    setReport(null);
    setError(null);
    inputRef.current?.focus();
  }

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Content Opportunity <span className="text-gradient">Analyzer</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Enter a keyword, article URL, or website to discover what top search results are missing
            and where you can publish a more competitive article.
          </p>
        </section>

        {/* Input Form */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <form onSubmit={submit} className="space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  ref={inputRef}
                  aria-label="Keyword or URL"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="e.g. best email subject lines"
                  className="w-full rounded-xl border border-border bg-background py-3 pl-11 pr-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                {loading ? 'Analyzing…' : 'Analyze'}
              </button>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                Detected: <span className="font-medium text-foreground capitalize">{inputType}</span>
              </p>
              {report && (
                <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" />
                  New analysis
                </button>
              )}
            </div>
          </form>

          {report?.serpError && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-amber-500/20 bg-amber-500/5 px-4 py-3 text-sm text-amber-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>Live search was unavailable. Results may be estimated.</span>
            </div>
          )}
          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </section>

        {/* Loading State */}
        {loading && !report && (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="shimmer h-32 rounded-2xl border border-border bg-card/50" />
            ))}
          </div>
        )}

        {/* Results */}
        {report && <ReportDisplay report={report} />}
      </div>
    </FreeToolLayout>
  );
}
