import { NextResponse } from 'next/server';
import { getCurrentUserId } from '../../../../../lib/auth';
import { listLinks } from '../../../../../lib/linkLibrary';
import { escapeCsvCell } from '@/lib/utils';

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const format = (url.searchParams.get('format') || 'json').toLowerCase();
  const links = await listLinks(userId, { limit: 1000 });

  if (format === 'csv') {
    const header = ['url', 'title', 'description', 'category', 'linkType', 'affiliate', 'affiliateProvider', 'anchorText', 'targetKeyword', 'preferredPlacement', 'active', 'safetyStatus', 'safetyReason', 'createdAt', 'updatedAt'];
    const rows = links.map((link) => [
      link.url,
      link.title || '',
      link.description || '',
      link.category || '',
      link.linkType || '',
      link.affiliate ? 'true' : 'false',
      link.affiliateProvider || '',
      link.anchorText || '',
      link.targetKeyword || '',
      link.preferredPlacement || '',
      link.active ? 'true' : 'false',
      link.safetyStatus || '',
      link.safetyReason || '',
      link.createdAt,
      link.updatedAt,
    ]);
    const csv = [header.join(','), ...rows.map((row) => row.map(escapeCsvCell).join(','))].join('\n');

    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="link-library.csv"',
      },
    });
  }

  return NextResponse.json({ ok: true, data: { links } });
}
