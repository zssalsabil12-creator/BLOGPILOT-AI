/**
 * Competitor Scraper Module
 *
 * Fetches top-ranking URLs for a keyword and extracts structural data (H2/H3 headings).
 * Supports:
 * - Serper.dev API for Google search results
 * - Jina Reader API for content extraction
 * - Mock fallback for development/demo
 */

import { isGeminiConfigured } from './gemini'

interface SearchResult {
  position: number
  title: string
  url: string
  snippet: string
}

interface ScrapedContent {
  url: string
  title: string
  headings: HeadingItem[]
  wordCount: number
  topParagraphs: string[]
}

interface HeadingItem {
  level: number // 2 = H2, 3 = H3
  text: string
}

interface CompetitorAnalysis {
  keyword: string
  searchResults: SearchResult[]
  scrapedPages: ScrapedContent[]
  commonTopics: string[]
  uniqueTopics: string[]
  informationGaps: string[]
  averageWordCount: number
  timestamp: string
}

/**
 * Fetch top Google search results using Serper.dev API.
 */
async function fetchSerperResults(keyword: string): Promise<SearchResult[]> {
  const apiKey = process.env.SERPER_API_KEY
  if (!apiKey || apiKey === 'your-serper-api-key-here') {
    console.log('[scraper] Serper API key not configured, using mock data')
    return generateMockSearchResults(keyword)
  }

  try {
    const response = await fetch('https://google.serper.dev/search', {
      method: 'POST',
      headers: {
        'X-API-KEY': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        q: keyword,
        num: 5,
        gl: 'us',
        hl: 'en',
      }),
    })

    if (!response.ok) {
      console.error(`[scraper] Serper API error: ${response.status}`)
      return generateMockSearchResults(keyword)
    }

    const data = await response.json()
    return (data.organic || []).slice(0, 5).map((item: any) => ({
      position: item.position,
      title: item.title,
      url: item.link,
      snippet: item.snippet || '',
    }))
  } catch (error) {
    console.error('[scraper] Serper fetch failed:', error)
    return generateMockSearchResults(keyword)
  }
}

/**
 * Scrape a URL using Jina Reader API to extract headings and content.
 */
async function scrapeWithJina(url: string): Promise<ScrapedContent | null> {
  try {
    const jinaUrl = `https://r.jina.ai/${url}`
    const response = await fetch(jinaUrl, {
      headers: {
        Accept: 'text/plain',
        'X-Return-Format': 'text',
      },
      signal: AbortSignal.timeout(10000),
    })

    if (!response.ok) return null

    const text = await response.text()
    return extractStructureFromText(text, url)
  } catch (error) {
    console.error(`[scraper] Jina scrape failed for ${url}:`, error)
    return null
  }
}

/**
 * Extract H2/H3 headings and key paragraphs from raw text.
 */
function extractStructureFromText(
  text: string,
  url: string
): ScrapedContent {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean)

  const headings: HeadingItem[] = []
  const topParagraphs: string[] = []
  let paraCount = 0
  const title = lines[0] || url

  for (const line of lines) {
    // Detect markdown headings
    const h2Match = line.match(/^##\s+(.+)/)
    const h3Match = line.match(/^###\s+(.+)/)

    if (h2Match) {
      headings.push({ level: 2, text: h2Match[1].trim() })
    } else if (h3Match) {
      headings.push({ level: 3, text: h3Match[1].trim() })
    } else if (
      line.length > 100 &&
      !line.startsWith('#') &&
      !line.startsWith('[') &&
      !line.startsWith('http') &&
      !line.startsWith('!')
    ) {
      if (paraCount < 3) {
        topParagraphs.push(line)
        paraCount++
      }
    }
  }

  return {
    url,
    title,
    headings,
    wordCount: text.split(/\s+/).length,
    topParagraphs,
  }
}

/**
 * Generate mock search results for demo/development.
 */
function generateMockSearchResults(keyword: string): SearchResult[] {
  const capitalized = keyword
    .split(' ')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ')

  return [
    {
      position: 1,
      title: `${capitalized} - Complete Guide 2026 | TechReview`,
      url: 'https://www.techreview.example.com/guide/' + keyword.replace(/\s+/g, '-'),
      snippet: `The ultimate guide to ${keyword}. Expert reviews, comparisons, and buying advice for 2026.`,
    },
    {
      position: 2,
      title: `Best ${capitalized} in 2026: Top 10 Picks | ReviewHub`,
      url: 'https://www.reviewhub.example.com/best-' + keyword.replace(/\s+/g, '-'),
      snippet: `We tested and reviewed 50+ ${keyword} options. Here are the top 10 that stand out in 2026.`,
    },
    {
      position: 3,
      title: `${capitalized} vs Alternatives: Which is Right for You?`,
      url: 'https://www.comparetech.example.com/' + keyword.replace(/\s+/g, '-') + '-vs',
      snippet: `Comparing the leading ${keyword} options side-by-side. Features, pricing, pros, and cons.`,
    },
    {
      position: 4,
      title: `${capitalized} Buying Guide: Everything You Need to Know`,
      url: 'https://www.buyingguides.example.com/' + keyword.replace(/\s+/g, '-'),
      snippet: `Our comprehensive buying guide covers all the essential factors when choosing ${keyword}.`,
    },
    {
      position: 5,
      title: `How to Choose ${capitalized}: Expert Tips for 2026`,
      url: 'https://www.experttips.example.com/choose-' + keyword.replace(/\s+/g, '-'),
      snippet: `Industry experts share their top tips for selecting the perfect ${keyword} for your needs.`,
    },
  ]
}

/**
 * Generate mock scraped content for demo/development.
 */
function generateMockScrapedContent(
  result: SearchResult,
  keyword: string
): ScrapedContent {
  const capitalized = keyword
    .split(' ')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ')

  const headingTemplates: Record<number, string[]> = {
    1: [
      `What is ${capitalized}?`,
      `Why ${capitalized} Matters in 2026`,
      `Top ${capitalized} Recommendations`,
      `Key Features to Look For`,
      `Pros and Cons`,
      `Pricing Comparison`,
      `Our Verdict`,
    ],
    2: [
      `Best ${capitalized} Overall`,
      `Best Budget Option`,
      `Best for Professionals`,
      `Key Features Comparison`,
      `Final Thoughts`,
      `FAQ`,
    ],
    3: [
      `Quick Summary`,
      `Performance Metrics`,
      `Value for Money`,
      `User Experience`,
      `Alternatives to Consider`,
      `Frequently Asked Questions`,
    ],
    4: [
      `Introduction`,
      `Market Overview`,
      `Selection Criteria`,
      `Detailed Reviews`,
      `Buying Tips`,
      `Conclusion`,
    ],
    5: [
      `Expert Analysis`,
      `Price-to-Performance Ratio`,
      `Long-term Reliability`,
      `Customer Satisfaction`,
      `Bottom Line`,
    ],
  }

  const headings = (headingTemplates[result.position] || headingTemplates[1]).map(
    (text) => ({
      level: Math.random() > 0.5 ? 2 : 3,
      text,
    })
  )

  return {
    url: result.url,
    title: result.title,
    headings,
    wordCount: 800 + Math.floor(Math.random() * 2000),
    topParagraphs: [
      `${capitalized} continues to evolve rapidly in 2026, with new advancements making it more accessible and powerful than ever before.`,
      `Our team of experts has spent months evaluating the latest options to bring you the most comprehensive and unbiased analysis available.`,
    ],
  }
}

/**
 * Main competitor analysis function.
 * Orchestrates search → scrape → analyze flow.
 */
export async function analyzeCompetitors(
  keyword: string
): Promise<CompetitorAnalysis> {
  console.log(`[scraper] Starting competitor analysis for: "${keyword}"`)

  // Step 1: Fetch search results
  const searchResults = await fetchSerperResults(keyword)
  console.log(`[scraper] Found ${searchResults.length} search results`)

  // Step 2: Scrape top pages
  const scrapedPages: ScrapedContent[] = []

  for (const result of searchResults.slice(0, 5)) {
    try {
      // Try real scraping via Jina, fallback to mock
      const scraped = await scrapeWithJina(result.url)
      if (scraped && scraped.headings.length > 0) {
        scrapedPages.push(scraped)
      } else {
        scrapedPages.push(generateMockScrapedContent(result, keyword))
      }
    } catch {
      scrapedPages.push(generateMockScrapedContent(result, keyword))
    }
  }

  console.log(`[scraper] Scraped ${scrapedPages.length} pages`)

  // Step 3: Analyze common topics, unique topics, and gaps
  const allHeadings = scrapedPages.flatMap((p) =>
    p.headings.map((h) => h.text.toLowerCase())
  )

  // Count heading frequency
  const headingFreq = new Map<string, number>()
  for (const h of allHeadings) {
    const normalized = h.replace(/[^a-z0-9\s]/g, '').trim()
    headingFreq.set(normalized, (headingFreq.get(normalized) || 0) + 1)
  }

  // Common topics (appear in 2+ competitors)
  const commonTopics = Array.from(headingFreq.entries())
    .filter(([, count]) => count >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([topic]) => topic)

  // Unique topics (appear in only 1 competitor — potential differentiation)
  const uniqueTopics = Array.from(headingFreq.entries())
    .filter(([, count]) => count === 1)
    .slice(0, 10)
    .map(([topic]) => topic)

  // Information gaps (topics none of the competitors cover)
  const gapCandidates = [
    'case studies',
    'real user experiences',
    'long-term durability',
    'environmental impact',
    'accessibility features',
    'setup tutorial',
    'troubleshooting guide',
    'comparison table',
    'expert interviews',
    'industry trends',
    'cost of ownership',
    'maintenance tips',
    'warranty information',
    'return policy analysis',
    'customer support quality',
  ]

  const informationGaps = gapCandidates.filter(
    (gap) =>
      !allHeadings.some(
        (h) =>
          h.includes(gap.split(' ')[0]) ||
          h.includes(gap.replace(/\s/g, ''))
      )
  )

  // Average word count
  const averageWordCount =
    scrapedPages.length > 0
      ? Math.round(
          scrapedPages.reduce((sum, p) => sum + p.wordCount, 0) /
            scrapedPages.length
        )
      : 0

  return {
    keyword,
    searchResults,
    scrapedPages,
    commonTopics,
    uniqueTopics,
    informationGaps: informationGaps.slice(0, 8),
    averageWordCount,
    timestamp: new Date().toISOString(),
  }
}
