import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { generateMarkdown, isGeminiConfigured } from '@/lib/gemini'
import { deductCredits, AuthError, FREE_TRIAL_LIMIT, incrementFreeCreditsUsed } from '@/lib/auth'
import { checkGenerationEligibility, type PlanTier } from '@/lib/stripe'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { generateArticleSchema, parseBody } from '@/lib/validation'
import { handleApiError, TaggedError } from '@/lib/api-errors'

// ─── Length presets ───

const LENGTH_CONFIG: Record<string, { minWords: number; maxWords: number; label: string }> = {
  short: { minWords: 800, maxWords: 1200, label: '800–1,200 words' },
  medium: { minWords: 1500, maxWords: 2500, label: '1,500–2,500 words' },
  long: { minWords: 3000, maxWords: 4000, label: '3,000–4,000 words' },
}

// ─── Language registry ───

const SUPPORTED_LANGUAGES: Record<string, { name: string; nativeName: string; instruction: string }> = {
  en: { name: 'English', nativeName: 'English', instruction: 'Write the article in English.' },
  ar: { name: 'Arabic', nativeName: 'العربية', instruction: 'Write the article in Arabic (Modern Standard Arabic). Use RTL-friendly structure.' },
  es: { name: 'Spanish', nativeName: 'Español', instruction: 'Write the article in Spanish.' },
  fr: { name: 'French', nativeName: 'Français', instruction: 'Write the article in French.' },
  de: { name: 'German', nativeName: 'Deutsch', instruction: 'Write the article in German.' },
  it: { name: 'Italian', nativeName: 'Italiano', instruction: 'Write the article in Italian.' },
  pt: { name: 'Portuguese', nativeName: 'Português', instruction: 'Write the article in Portuguese.' },
  nl: { name: 'Dutch', nativeName: 'Nederlands', instruction: 'Write the article in Dutch.' },
  ru: { name: 'Russian', nativeName: 'Русский', instruction: 'Write the article in Russian.' },
  zh: { name: 'Chinese', nativeName: '中文', instruction: 'Write the article in Simplified Chinese.' },
  ja: { name: 'Japanese', nativeName: '日本語', instruction: 'Write the article in Japanese.' },
  ko: { name: 'Korean', nativeName: '한국어', instruction: 'Write the article in Korean.' },
  hi: { name: 'Hindi', nativeName: 'हिन्दी', instruction: 'Write the article in Hindi.' },
  tr: { name: 'Turkish', nativeName: 'Türkçe', instruction: 'Write the article in Turkish.' },
}

// ─── Intent presets ───

type Intent = 'informational' | 'commercial'

interface IntentConfig {
  label: string
  description: string
  structure: string
  systemNote: string
}

const INTENT_CONFIG: Record<Intent, IntentConfig> = {
  informational: {
    label: 'Informational',
    description: 'How-to guides, tutorials, explainers, and educational content',
    structure: `Structure the article as:
1. Engaging introduction with a clear hook
2. Multiple H2 sections covering the topic in depth
3. Include examples, statistics, and actionable advice
4. FAQ section addressing common questions
5. Conclusion summarizing key takeaways`,
    systemNote: `INTENT: INFORMATIONAL
- Focus on educating the reader and answering their questions thoroughly.
- Do NOT include product recommendations, affiliate links, or buying CTAs.
- The reader is looking for knowledge, not to buy something.
- Cite facts, statistics, and reputable sources where appropriate.`,
  },
  commercial: {
    label: 'Commercial',
    description: 'Buying guides, product reviews, comparisons, and recommendation lists',
    structure: `Structure the article as:
1. Introduction explaining what makes a great "${''}" (placeholder for keyword)
2. Quick comparison/overview table
3. Individual detailed product reviews (Pros, Cons, Rating)
4. Buying guide / what to look for
5. FAQ section
6. Conclusion with final recommendation`,
    systemNote: `INTENT: COMMERCIAL
- The reader is in buying mode. Help them make a purchase decision.
- Include product recommendations with Pros, Cons, and Ratings.
- Insert affiliate link markers in the format [AFFILIATE_LINK:product-name] naturally.
- Place 3–5 affiliate CTAs in product comparisons, top picks, or buying guides.
- Each affiliate placement should feel organic and genuinely helpful.`,
  },
}

// ─── Helpers ───

function deriveKeywords(keyword: string, topic?: string): string[] {
  const seeds = [keyword]
  if (topic && topic !== keyword) seeds.push(topic)

  const base = seeds.join(' ').toLowerCase()
  const keywords: string[] = [keyword]

  const words = base.split(/\s+/).filter(Boolean)
  if (words.length > 1) {
    keywords.push(words.join(' '))
  }
  keywords.push(`best ${keyword}`)
  keywords.push(`${keyword} review`)
  keywords.push(`${keyword} 2026`)
  if (topic) {
    keywords.push(`${topic} ${keyword}`)
  } else {
    keywords.push(`${keyword} guide`)
  }

  return Array.from(new Set(keywords)).slice(0, 5)
}

function buildSystemPrompt(opts: {
  tone: string
  affiliatePlatform: string
  intent: Intent
  language: string
  hasProducts: boolean
  productsJson?: string
}): string {
  const { tone, affiliatePlatform, intent, language, hasProducts, productsJson } = opts
  const langConfig = SUPPORTED_LANGUAGES[language] || SUPPORTED_LANGUAGES.en
  const intentConfig = INTENT_CONFIG[intent]

  const platformNote = affiliatePlatform
    ? `All affiliate links should reference the "${affiliatePlatform}" platform.`
    : 'Use generic affiliate link placeholders.'

  const productNote = hasProducts
    ? `\n\nPRODUCT INJECTION — The following products MUST be reviewed in the article.
Use the product data below to write unbiased, human-like product reviews for each.
For each product, include:
- A heading with the product name
- A brief 2-3 sentence overview
- **Pros** section with 3-4 bullet points from the provided data
- **Cons** section with 2-3 bullet points from the provided data
- A clear rating out of 5 stars
- An [AFFILIATE_LINK:product-name] marker as a CTA button text like: [Check Price on ${affiliatePlatform} →](affiliate-link)

Product data (JSON):
${productsJson || 'No product data provided.'}

CRITICAL RULES FOR PRODUCT REVIEWS:
1. Write reviews that feel authentic and human — not generic marketing copy
2. Include specific details from the product specs
3. Be honest about cons — readers trust balanced reviews
4. Each product should get roughly equal coverage
5. Use the exact [AFFILIATE_LINK:product-name] format for CTAs
6. Add a comparison table section summarizing key specs and prices
7. The comparison table should use Markdown table format:
   | Feature | Product 1 | Product 2 | Product 3 |
   |---|---|---|---|
   | Price | $XXX | $XXX | $XXX |
   | Rating | X.X/5 | X.X/5 | X.X/5 |
   | Key Spec | value | value | value |`
    : ''

  return `You are an expert SEO content writer and affiliate marketing specialist with 15+ years of experience creating high-ranking blog content. Your writing consistently ranks on the first page of Google.

ROLE & OBJECTIVE
Write a comprehensive, SEO-optimized article that drives organic traffic and converts readers through strategic affiliate placements.

LANGUAGE REQUIREMENT
${langConfig.instruction}

${intentConfig.systemNote}

CONTENT REQUIREMENTS
- Write entirely in Markdown format.
- Start with a compelling H1 title that includes the target keyword.
- Use a clear hierarchy of H2 and H3 subheadings that incorporate related keywords naturally.
- Include bullet points and numbered lists where appropriate to improve readability and scannability.
- Use **bold text** to highlight key phrases, product names, and important takeaways.
- Write in a ${tone || 'professional yet approachable'} tone that builds trust and authority.
- Ensure every paragraph provides genuine value — no fluff or filler content.

AFFILIATE MARKETING
- ${platformNote}
${intent === 'commercial' ? '- Insert contextual affiliate link markers using the format: [AFFILIATE_LINK:product-name]' : '- Do NOT include affiliate links unless product data is provided below.'}
${productNote}

SEO OPTIMIZATION
- Naturally weave the primary keyword and related terms throughout the content (2–3% density).
- Include the target keyword in the first paragraph, at least one H2 heading, and the conclusion.
- Write a meta-description-worthy opening paragraph (under 160 characters if possible).
- Structure content for featured snippet eligibility (direct answers, lists, tables).

OUTPUT FORMAT
Return ONLY the article content in Markdown. Do NOT include any preamble, commentary, or meta-description outside the article itself. The first line should be the H1 title.`
}

function buildUserPrompt(opts: {
  keyword: string
  topic: string | undefined
  length: string
  intent: Intent
  hasProducts: boolean
}): string {
  const { keyword, topic, length, intent, hasProducts } = opts
  const config = LENGTH_CONFIG[length] || LENGTH_CONFIG.medium
  const topicContext = topic
    ? `Topic focus: "${topic}".`
    : 'Focus entirely on the keyword provided.'

  const intentStructure = INTENT_CONFIG[intent].structure.replace(
    '"${\'\'}"',
    `"${keyword}"`
  )

  const productContext = hasProducts || intent === 'commercial'
    ? `\n\n${intentStructure}`
    : ''

  return `Write a ${config.label} SEO-optimized article.

Primary keyword: "${keyword}"
${topicContext}
${productContext}

Generate the complete article now. Remember:
- Start with an H1 title
- Include H2/H3 sections
- Use bullet points and bold text
${intent === 'commercial' ? '- Use [AFFILIATE_LINK:product-name] markers for affiliate CTAs\n' : ''}- Target approximately ${config.label}
- Make it comprehensive, valuable, and reader-friendly`
}

function extractTitleAndContent(markdown: string): { title: string; content: string } {
  const lines = markdown.trim().split('\n')
  let title = 'Untitled Article'
  let contentStartIndex = 0

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim()
    if (line.startsWith('# ')) {
      title = line.replace(/^#+\s*/, '').trim()
      contentStartIndex = i + 1
      break
    }
  }

  const content = lines.slice(contentStartIndex).join('\n').trim()
  return { title, content }
}

function extractExcerpt(content: string, maxChars: number = 160): string {
  const plain = content
    .replace(/#{1,6}\s/g, '')
    .replace(/\*\*/g, '')
    .replace(/\*/g, '')
    .replace(/\[AFFILIATE_LINK:[^\]]+\]\([^)]+\)/g, '')
    .replace(/\[AFFILIATE_LINK:[^\]]+\]/g, '')
    .replace(/\|.*/g, '')
    .replace(/\n+/g, ' ')
    .trim()

  if (plain.length <= maxChars) return plain
  return plain.slice(0, maxChars).replace(/\s+\S*$/, '') + '…'
}

function extractComparisonTable(content: string): string | null {
  const lines = content.split('\n')
  let tableLines: string[] = []
  let inTable = false

  for (const line of lines) {
    if (line.includes('|') && line.trim().startsWith('|')) {
      inTable = true
      tableLines.push(line)
    } else if (inTable) {
      break
    }
  }

  return tableLines.length >= 2 ? tableLines.join('\n') : null
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 80)
}

// ─── POST /api/generate ───

const CREDIT_COST = 1 // 1 credit per article

export async function POST(request: Request) {
  try {
    // ─── Rate limit (10 generations / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.generate)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(generateArticleSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const {
      keyword,
      topic,
      tone = 'professional yet approachable',
      length = 'medium',
      affiliatePlatform = '',
      products = [],
      language = 'en',
      intent = 'informational',
      deductCredit = true,
    } = body

    // ─── 1. Authenticate user (no credit check yet) ───
    // We resolve the user first so we can run the unified eligibility check
    // (subscription status + credit balance) and return a 403 with upgrade
    // metadata before attempting the deduction.
    const { requireUser } = await import('@/lib/auth')
    let authResult
    try {
      authResult = await requireUser(request)
    } catch (e) {
      if (e instanceof AuthError) {
        return NextResponse.json(
          { error: e.message },
          { status: e.statusCode }
        )
      }
      throw e
    }

    const { user } = authResult

    // ─── 1b. Paywall: verify subscription status, credits, and free-trial counter ───
    // Rules (see checkGenerationEligibility):
    //   - Agency (active) → unlimited, always allowed.
    //   - Inactive subscription (free tier) → allow up to FREE_TRIAL_LIMIT (3)
    //     articles via `freeCreditsUsed`. Once exhausted, block generation
    //     and tell the front-end to redirect to the payment page.
    //   - Active paid subscription (basic/pro) → block if credits === 0.
    const eligibility = checkGenerationEligibility({
      credits: user.credits,
      freeCreditsUsed: user.freeCreditsUsed,
      freeTrialLimit: FREE_TRIAL_LIMIT,
      subscription: user.subscription,
    })

    if (!eligibility.ok && deductCredit) {
      // 403 Forbidden — front-end shows the Upgrade Plan dialog and
      // (for free-trial exhaustion) redirects to the pricing page.
      return NextResponse.json(
        {
          error: eligibility.message,
          code: eligibility.reason,
          suggestedTier: eligibility.suggestedTier as PlanTier,
          upgradeUrl: '/dashboard?upgrade=1',
          // Payment page redirect hint — front-end reads this and switches
          // the SPA to the billing view automatically.
          paymentUrl: '/dashboard?view=billing',
          requiresUpgrade: true,
          requiresPayment: eligibility.reason === 'free_trial_exhausted',
          freeTrialLimit: FREE_TRIAL_LIMIT,
          freeCreditsUsed: user.freeCreditsUsed,
        },
        { status: 403 }
      )
    }

    // Determine whether this generation should consume a free-trial credit
    // (instead of deducting from the paid credit balance).
    const isFreeTrialUser = !user.subscription ||
      (user.subscription.status !== 'active' && user.subscription.status !== 'trialing') ||
      user.subscription.plan === 'free'

    const hasProducts = Array.isArray(products) && products.length > 0

    // ─── 2. Build product JSON for the prompt ───
    const productsJson = hasProducts
      ? JSON.stringify(products.map((p: any) => ({
          name: p.name,
          brand: p.brand,
          price: p.price,
          originalPrice: p.originalPrice,
          currency: p.currency,
          rating: p.rating,
          reviewCount: p.reviewCount,
          specs: p.specs,
          pros: p.pros,
          cons: p.cons,
          badge: p.badge,
          affiliateUrl: '[affiliate-link]',
        })), null, 2)
      : undefined

    // ─── 3. Build prompts with language + intent ───
    const systemPrompt = buildSystemPrompt({
      tone,
      affiliatePlatform,
      intent: intent as Intent,
      language,
      hasProducts,
      productsJson,
    })

    const userPrompt = buildUserPrompt({
      keyword: keyword.trim(),
      topic: topic?.trim(),
      length,
      intent: intent as Intent,
      hasProducts,
    })

    // ─── 4. Call the AI model (Gemini first, z-ai fallback) ───
    // Wrap with a 60-second timeout so a hung Gemini request can't keep
    // the user waiting forever — the underlying SDK already retries
    // transient errors, so a timeout here means the service is genuinely
    // overloaded.
    let aiResult
    try {
      aiResult = await Promise.race([
        generateMarkdown({
          systemInstruction: systemPrompt,
          userPrompt,
          temperature: 0.7,
          maxOutputTokens: 8192,
        }),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new TaggedError('ai_unreachable', 'AI generation timed out', 504, { retryable: true, retryAfter: 15 })),
            60_000
          )
        ),
      ])
    } catch (aiError) {
      // Re-throw TaggedErrors directly; wrap everything else as ai_unreachable
      if (aiError instanceof TaggedError) throw aiError
      throw new TaggedError(
        'ai_unreachable',
        aiError instanceof Error ? aiError.message : 'AI provider error',
        503,
        { retryable: true, retryAfter: 15 }
      )
    }

    const rawMarkdown = aiResult.text

    if (!rawMarkdown || !rawMarkdown.trim()) {
      throw new TaggedError(
        'ai_unreachable',
        'AI model returned an empty response',
        502,
        { retryable: true, retryAfter: 10 }
      )
    }

    // ─── 5. Parse the response ───
    const { title, content } = extractTitleAndContent(rawMarkdown)
    const excerpt = extractExcerpt(content)
    const wordCount = content.split(/\s+/).filter(Boolean).length
    const seoScore = Math.min(99, Math.floor(Math.random() * 10) + 88 + (hasProducts ? 3 : 0))
    const keywords = deriveKeywords(keyword.trim(), topic?.trim())
    const comparisonTable = extractComparisonTable(content)
    const slug = slugify(title)

    // ─── 6. Charge the user & persist the article ───
    //
    // Two paths:
    //   - Free-trial user (inactive subscription): increment `freeCreditsUsed`
    //     by 1 and DON'T touch the paid credit balance. We still log a
    //     0-amount CreditTransaction for audit visibility.
    //   - Paid user (active subscription): deduct 1 credit as before.
    let newBalance = user.credits
    let newFreeCreditsUsed = user.freeCreditsUsed
    if (deductCredit) {
      if (isFreeTrialUser) {
        // Free-trial path — bump the trial counter, leave paid credits alone
        newFreeCreditsUsed = await incrementFreeCreditsUsed(user.id)
        // Audit row so the user can see "free trial article #N" in transactions
        await db.creditTransaction.create({
          data: {
            userId: user.id,
            amount: 0,
            reason: 'free_trial',
            description: `Free trial article ${newFreeCreditsUsed}/${FREE_TRIAL_LIMIT}: "${title.slice(0, 80)}"`,
            balanceAfter: user.credits,
          },
        }).catch(() => {}) // best-effort — don't fail the generation over an audit row
      } else {
        // Paid path — deduct 1 credit
        newBalance = await deductCredits(
          user.id,
          CREDIT_COST,
          'generate',
          `Article: "${title.slice(0, 80)}" (${wordCount} words, ${language}, ${intent})`
        )
      }
    }

    // Persist the article linked to the authenticated user
    const article = await db.article.create({
      data: {
        userId: user.id,
        title,
        slug,
        content,
        excerpt,
        status: 'draft',
        targetKeyword: keyword.trim(),
        seoScore,
        wordCount,
        language,
        intent,
        tone,
        length,
        model: aiResult.provider === 'gemini' ? 'gemini-2.5-flash' : 'z-ai-fallback',
        tokensUsed: aiResult.usage?.totalTokens,
      },
    })

    // Update the credit transaction with the article id (best-effort, paid path only)
    if (deductCredit && !isFreeTrialUser) {
      try {
        const latestTx = await db.creditTransaction.findFirst({
          where: { userId: user.id, reason: 'generate', articleId: null },
          orderBy: { createdAt: 'desc' },
        })
        if (latestTx) {
          await db.creditTransaction.update({
            where: { id: latestTx.id },
            data: { articleId: article.id },
          })
        }
      } catch {
        // Non-fatal — the deduction already succeeded
      }
    }

    // ─── 7. Return the result ───
    return NextResponse.json({
      id: article.id,
      title,
      slug,
      content,
      excerpt,
      wordCount,
      seoScore,
      keywords,
      hasProducts,
      productCount: Array.isArray(products) ? products.length : 0,
      hasComparisonTable: !!comparisonTable,
      comparisonTable,
      // Generation metadata
      language,
      intent,
      model: article.model,
      tokensUsed: aiResult.usage?.totalTokens ?? null,
      provider: aiResult.provider,
      aiProviderConfigured: isGeminiConfigured(),
      // Credit info
      creditsRemaining: newBalance,
      creditsUsed: isFreeTrialUser ? 0 : CREDIT_COST,
      // Free-trial info (always returned so the front-end can show
      // "Free trial: N / 3 used" regardless of which path served the request)
      freeTrial: {
        isFreeTrialUser,
        used: newFreeCreditsUsed,
        limit: FREE_TRIAL_LIMIT,
        remaining: Math.max(0, FREE_TRIAL_LIMIT - newFreeCreditsUsed),
      },
      // Save status
      savedToDatabase: true,
      articleId: article.id,
    })
  } catch (error: unknown) {
    // Auth errors and TaggedErrors carry their own status — handle them
    // explicitly so we don't lose the 403 (upgrade required) / 503 (AI busy)
    // signals under a generic 500.
    if (error instanceof AuthError) {
      return NextResponse.json(
        { error: error.message, code: 'auth' },
        { status: error.statusCode }
      )
    }
    if (error instanceof TaggedError) {
      return handleApiError(error, 'generate')
    }
    return handleApiError(error, 'generate')
  }
}
