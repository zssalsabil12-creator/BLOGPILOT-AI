/**
 * Content Refresh Agent.
 *
 * Watches real Search Console performance for the user's bound property,
 * finds pages whose traffic/rankings declined, matches them to articles in
 * the workspace, and produces concrete refresh recommendations:
 * what changed in the SERP, what the article is missing, what went stale.
 *
 * Cost-aware: GSC queries only (2), SERP intel reuses cached infrastructure
 * and runs only for pages that actually declined (max 5 per request).
 * Review-level automation: it recommends — it never publishes.
 */

import prisma from '@/lib/prisma';
import {
  getGscAccessToken,
  querySearchAnalytics,
  buildPeriodRange,
} from '@/lib/gsc';
import { buildSerpIntelligence } from './serp-intelligence';

export interface RefreshProblem {
  type: 'ranking-decline' | 'click-decline' | 'missing-entity' | 'outdated-year' | 'thin-vs-serp' | 'low-ctr' | 'no-article-match';
  detail: string;
}

export interface RefreshRecommendation {
  url: string;
  path: string;
  matchedArticleId: string | null;
  matchedArticleTitle: string | null;
  currentClicks: number;
  previousClicks: number;
  clickChangePct: number | null;
  currentPosition: number | null;
  problems: RefreshProblem[];
  newQuestionsInSerp: string[];
  missingEntities: string[];
  outdatedYears: number[];
  recommendedAction: string;
  priority: 'high' | 'medium' | 'low';
}

function extractPath(url: string): string {
  try {
    return new URL(url).pathname.replace(/\/$/, '') || '/';
  } catch {
    return url;
  }
}

function matchArticleBySlug(path: string, articles: Array<{ id: string; title: string; slug: string | null; content: string; targetKeyword: string | null; updatedAt: Date }>) {
  const segments = path.split('/').filter(Boolean);
  if (segments.length === 0) return null;
  const last = segments[segments.length - 1].toLowerCase();

  return (
    articles.find(a => a.slug && a.slug.toLowerCase() === last) ||
    articles.find(a => a.slug && last.includes(a.slug.toLowerCase()) && a.slug.length > 6) ||
    articles.find(a => last.split('-').length >= 3 && a.title && last.includes(a.title.toLowerCase().split(/\s+/).slice(0, 3).join('-')))
  ) || null;
}

function findOutdatedYears(content: string, currentYear = new Date().getFullYear()): number[] {
  const years = content.match(/20[12]\d/g)?.map(Number) ?? [];
  return Array.from(new Set(years.filter(y => y < currentYear))).sort((a, b) => a - b);
}

export async function computeRefreshRecommendations(
  userId: string,
  siteId: string,
  opts?: { maxPages?: number }
): Promise<{ propertyUrl: string; recommendations: RefreshRecommendation[] }> {
  const site = await prisma.connectedSite.findFirst({
    where: { id: siteId, userId },
    select: { id: true, name: true, url: true, gscProperty: true },
  });
  if (!site) throw Object.assign(new Error('Site not found'), { statusCode: 404 });
  if (!site.gscProperty) throw Object.assign(new Error('This site is not linked to a Search Console property.'), { statusCode: 409 });

  const access = await getGscAccessToken(userId);
  if (!access.ok) {
    throw Object.assign(
      new Error(access.reason === 'needs_reconnect'
        ? 'Reconnect your Google account with Search Console access.'
        : 'Connect your Google account first.'),
      { statusCode: 409 },
    );
  }

  const range = buildPeriodRange(28);
  const [curRows, prevRows] = await Promise.all([
    querySearchAnalytics(access.accessToken, site.gscProperty, { ...range.current, dimensions: ['page'], rowLimit: 1000 }),
    querySearchAnalytics(access.accessToken, site.gscProperty, { ...range.previous, dimensions: ['page'], rowLimit: 1000 }),
  ]);

  // Declining pages: clicks dropped ≥25% with ≥15 previous clicks.
  const prevMap = new Map(prevRows.map(r => [r.keys[0], r]));
  const declined = curRows
    .map(cur => {
      const prev = prevMap.get(cur.keys[0]);
      if (!prev || prev.clicks < 15) return null;
      const changePct = prev.clicks > 0 ? (cur.clicks - prev.clicks) / prev.clicks : -1;
      return { cur, prev, changePct };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null && x.changePct <= -0.25)
    .sort((a, b) => a.changePct - b.changePct)
    .slice(0, Math.min(opts?.maxPages ?? 5, 5));

  const recommendations: RefreshRecommendation[] = [];

  for (const item of declined) {
    const url = item.cur.keys[0];
    const path = extractPath(url);

    // Find candidate articles from the same workspace (all sites of user).
    const articles = await prisma.article.findMany({
      where: { userId, siteId: site.id },
      orderBy: { updatedAt: 'desc' },
      take: 200,
      select: { id: true, title: true, slug: true, content: true, targetKeyword: true, updatedAt: true },
    });

    const article = matchArticleBySlug(path, articles);
    const problems: RefreshProblem[] = [];
    let newQuestionsInSerp: string[] = [];
    let missingEntities: string[] = [];

    problems.push({
      type: 'click-decline',
      detail: `Clicks fell ${Math.abs(item.changePct * 100).toFixed(0)}% (${item.prev.clicks.toLocaleString()} → ${item.cur.clicks.toLocaleString()}) over the last two 28-day periods.`,
    });

    if (item.cur.position > 8) {
      problems.push({ type: 'ranking-decline', detail: `Average position slipped to ${item.cur.position.toFixed(1)}.` });
    }
    if (item.cur.impressions > 300 && item.cur.ctr < 0.03) {
      problems.push({ type: 'low-ctr', detail: `CTR is ${(item.cur.ctr * 100).toFixed(1)}% across ${item.cur.impressions.toLocaleString()} impressions — snippet underperforms.` });
    }

    if (!article) {
      problems.push({
        type: 'no-article-match',
        detail: 'No article in this workspace matches this URL — it may have been published elsewhere or imported.',
      });
    }

    // SERP diff only when we know the keyword (cost-aware).
    const keyword = article?.targetKeyword || article?.title || '';
    if (article && keyword) {
      try {
        const intel = await buildSerpIntelligence(keyword, { numResults: 10 });

        // Outdated info signals.
        const staleYears = findOutdatedYears(article.content || '');
        if (staleYears.length > 0) {
          problems.push({
            type: 'outdated-year',
            detail: `Content still references ${staleYears.join(', ')} — consider updating to ${new Date().getFullYear()} facts.`,
          });
        }

        // Missing entities vs current SERP baseline.
        const contentTokens = new Set((article.content || '').toLowerCase().replace(/[^a-z\u0600-\u06FF\s]/g, ' ').split(/\s+/));
        missingEntities = intel.commonEntities.filter(e => e.length > 4 && !contentTokens.has(e)).slice(0, 8);
        if (missingEntities.length > 0) {
          problems.push({
            type: 'missing-entity',
            detail: `Current top results cover ${missingEntities.length} concepts this article doesn't mention (e.g., ${missingEntities.slice(0, 3).join(', ')}).`,
          });
        }

        // Thin coverage vs current SERP depth.
        const words = (article.content || '').trim().split(/\s+/).length;
        if (intel.avgWordCount > 0 && words < intel.avgWordCount * 0.7) {
          problems.push({
            type: 'thin-vs-serp',
            detail: `~${words.toLocaleString()} words vs current top-result average of ~${intel.avgWordCount.toLocaleString()}.`,
          });
        }

        newQuestionsInSerp = intel.questions.slice(0, 5);
      } catch (err: any) {
        console.warn('[refresh-agent] SERP intel unavailable for', keyword, err?.message || err);
      }
    }

    const highPriority =
      item.changePct <= -0.4 ||
      problems.some(p => p.type === 'missing-entity' || p.type === 'thin-vs-serp');

    recommendations.push({
      url,
      path,
      matchedArticleId: article?.id || null,
      matchedArticleTitle: article?.title || null,
      currentClicks: item.cur.clicks,
      previousClicks: item.prev.clicks,
      clickChangePct: item.changePct,
      currentPosition: item.cur.position > 0 ? item.cur.position : null,
      problems,
      newQuestionsInSerp,
      missingEntities,
      outdatedYears: article ? findOutdatedYears(article.content || '') : [],
      recommendedAction: 'refresh-article',
      priority: highPriority ? 'high' : Math.abs(item.changePct) >= 0.3 ? 'medium' : 'low',
    });
  }

  return { propertyUrl: site.gscProperty, recommendations };
}
