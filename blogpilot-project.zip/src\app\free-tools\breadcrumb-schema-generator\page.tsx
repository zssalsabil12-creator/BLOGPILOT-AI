'use client';

import { useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Plus, Trash2, Copy, Check, RotateCcw, FileJson, ChevronRight, ArrowUp, ArrowDown } from 'lucide-react';

interface BreadcrumbItem {
  id: number;
  name: string;
  url: string;
}

let nextId = 3;

export default function BreadcrumbSchemaGeneratorPage() {
  const [items, setItems] = useState<BreadcrumbItem[]>([
    { id: 1, name: 'Home', url: 'https://example.com' },
    { id: 2, name: '', url: '' },
  ]);
  const [output, setOutput] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [error, setError] = useState('');

  const addItem = () => {
    setItems([...items, { id: nextId++, name: '', url: '' }]);
  };

  const removeItem = (id: number) => {
    if (items.length <= 2) return;
    setItems(items.filter((i) => i.id !== id));
  };

  const updateItem = (id: number, field: 'name' | 'url', value: string) => {
    setItems(items.map((i) => (i.id === id ? { ...i, [field]: value } : i)));
  };

  const moveItem = (id: number, direction: 'up' | 'down') => {
    const index = items.findIndex((i) => i.id === id);
    if (direction === 'up' && index > 0) {
      const newItems = [...items];
      [newItems[index - 1], newItems[index]] = [newItems[index], newItems[index - 1]];
      setItems(newItems);
    } else if (direction === 'down' && index < items.length - 1) {
      const newItems = [...items];
      [newItems[index], newItems[index + 1]] = [newItems[index + 1], newItems[index]];
      setItems(newItems);
    }
  };

  const generate = () => {
    setError('');
    const validItems = items.filter((i) => i.name.trim() && i.url.trim());
    if (validItems.length < 2) {
      setError('Please fill in at least 2 breadcrumb items with both Name and URL.');
      return;
    }

    const schema = {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: validItems.map((item, index) => ({
        '@type': 'ListItem',
        position: index + 1,
        name: item.name.trim(),
        item: item.url.trim(),
      })),
    };

    const jsonStr = JSON.stringify(schema, null, 2);
    setOutput(`<script type="application/ld+json">\n${jsonStr}\n</script>`);
  };

  const copyToClipboard = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const reset = () => {
    setItems([
      { id: 1, name: 'Home', url: 'https://example.com' },
      { id: 2, name: '', url: '' },
    ]);
    setOutput('');
    setError('');
  };

  const previewItems = items.filter((i) => i.name.trim());

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="space-y-3">
            {items.map((item, index) => (
              <div key={item.id} className="flex items-start gap-2">
                <div className="flex flex-col gap-1 pt-1">
                  <button onClick={() => moveItem(item.id, 'up')} disabled={index === 0} className="p-1 rounded text-muted-foreground hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                    <ArrowUp className="w-3 h-3" />
                  </button>
                  <button onClick={() => moveItem(item.id, 'down')} disabled={index === items.length - 1} className="p-1 rounded text-muted-foreground hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                    <ArrowDown className="w-3 h-3" />
                  </button>
                </div>
                <div className="flex-1 grid grid-cols-2 gap-2">
                  <input type="text" placeholder="Name" value={item.name} onChange={(e) => updateItem(item.id, 'name', e.target.value)} className="px-3 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
                  <input type="url" placeholder="URL" value={item.url} onChange={(e) => updateItem(item.id, 'url', e.target.value)} className="px-3 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
                <button onClick={() => removeItem(item.id)} disabled={items.length <= 2} className="p-2 mt-1 rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-500/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          <button onClick={addItem} className="flex items-center gap-2 mt-3 px-4 py-2 rounded-lg border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-foreground/50 transition-colors">
            <Plus className="w-4 h-4" /> Add Item
          </button>

          {previewItems.length > 0 && (
            <div className="mt-4 rounded-xl border border-border bg-muted/50 p-4">
              <h3 className="text-sm font-medium text-foreground mb-2">Visual Preview</h3>
              <div className="flex items-center gap-1 text-sm flex-wrap">
                {previewItems.map((item, index) => (
                  <span key={item.id} className="flex items-center gap-1">
                    <span className="text-foreground font-medium">{item.name || '...'}</span>
                    {index < previewItems.length - 1 && <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />}
                  </span>
                ))}
              </div>
            </div>
          )}

          {error && <p className="text-sm text-red-500 mt-3">{error}</p>}

          <div className="flex gap-3 mt-4">
            <button onClick={generate} className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">Generate Schema</button>
            <button onClick={reset} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              <RotateCcw className="w-4 h-4" /> Reset
            </button>
          </div>
        </div>

        {output && (
          <div className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                <FileJson className="w-4 h-4" /> JSON-LD Script Tag
              </h3>
              <button onClick={() => copyToClipboard(output)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                {copiedScript ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedScript ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">{output}</pre>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
