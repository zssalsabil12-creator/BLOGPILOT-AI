﻿import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { NextResponse } from 'next/server';
import { GeminiUnavailableError } from '@/lib/gemini';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Centralized API error mapping. Unknown errors stay generic (no internal
 * detail leaks); AI availability errors get precise, user-safe messages:
 *  - not_configured          → 503 with setup instructions
 *  - invalid                 → 503 configuration error
 *  - temporarily_unavailable → 503 with retry hint
 */
export function apiError(context: string, err: unknown, status = 500): NextResponse {
  if (err instanceof GeminiUnavailableError) {
    if (err.status === 'not_configured') {
      console.error(`[${context}] Gemini is not configured`);
      return NextResponse.json(
        { ok: false, error: 'AI generation is not configured on this server. Set GEMINI_API_KEY to enable it.', code: 'ai_not_configured' },
        { status: 503 },
      );
    }
    console.error(`[${context}] Gemini unavailable (${err.status})`, err.message);
    return NextResponse.json(
      { ok: false, error: err.message, code: `ai_${err.status}` },
      { status: 503 },
    );
  }
  console.error(`[${context}]`, err);
  return NextResponse.json(
    { ok: false, error: 'An internal error occurred. Please try again.' },
    { status },
  );
}

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function formatDateRelative(date: string | Date): string {
  const d = new Date(date);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffHours / 24);

  if (diffHours < 1) return 'Just now';
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(d);
}

export function wordCount(text: string): number {
  if (!text || !text.trim()) return 0;
  return text.trim().split(/\s+/).length;
}

export function truncate(text: string, maxLen: number): string {
  if (!text || text.length <= maxLen) return text;
  return text.slice(0, maxLen) + '…';
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function maskKey(key: string, visibleChars = 4): string {
  if (!key || key.length <= visibleChars * 2) return '*'.repeat(key?.length || 0);
  return (
    key.slice(0, visibleChars) +
    '•'.repeat(Math.max(1, key.length - visibleChars * 2)) +
    key.slice(-visibleChars)
  );
}

/**
 * Escapes a single CSV cell.
 *
 * 1. Formula-injection defense: cells beginning with =, +, -, @ (or a
 *    tab/CR that could hide one) are prefixed with a single quote so Excel,
 *    Google Sheets and LibreOffice treat them as literal text instead of
 *    evaluating them as formulas (CSV injection).
 * 2. RFC-4180 quoting: cells containing commas, quotes or newlines are
 *    wrapped in double quotes with inner quotes doubled — the standard
 *    encoding understood by Excel/Google Sheets round-trips.
 */
export function escapeCsvCell(value: unknown): string {
  let str = String(value ?? '');

  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }

  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}
