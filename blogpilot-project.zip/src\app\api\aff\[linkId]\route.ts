import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { checkRateLimit, getClientIp } from '@/lib/rate-limit';

/**
 * Public affiliate click-tracker: records a real click then 302s to the
 * merchant URL. No auth (visitors from published articles are anonymous),
 * but rate-limited per IP and the target must be an ACTIVE affiliate link.
 */
export async function GET(req: Request, { params }: { params: Promise<{ linkId: string }> }) {
  const { linkId } = await params;

  const ip = getClientIp(req);
  const limit = await checkRateLimit(`aff-click:${ip}`, { windowMs: 60_000, maxRequests: 30 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests' }, { status: 429 });
  }

  try {
    const link = await prisma.link.findUnique({
      where: { id: linkId },
      select: { id: true, userId: true, campaignId: true, url: true, active: true, affiliate: true },
    });

    if (!link || !link.affiliate) {
      return NextResponse.json({ ok: false, error: 'Link not found' }, { status: 404 });
    }

    // Open-redirect guard: only http(s) destinations are ever redirected to.
    if (!/^https?:\/\//i.test(link.url)) {
      return NextResponse.json({ ok: false, error: 'Invalid destination' }, { status: 400 });
    }

    if (!link.active) {
      return NextResponse.redirect(`${new URL(req.url).origin}/dashboard?tab=affiliate-campaigns&aff=inactive`, 302);
    }

    // Record the real click. Fail-open on logging errors — never block the hop.
    let articleId: string | null = null;
    try {
      const ref = req.headers.get('referer') || '';
      if (ref) {
        // Best-effort attribution: match referrer path to a published article.
        const refPath = new URL(ref).pathname.replace(/\/$/, '');
        const candidate = await prisma.article.findFirst({
          where: { userId: link.userId, slug: refPath.split('/').pop() || '' },
          select: { id: true },
        });
        articleId = candidate?.id || null;
      }
    } catch {}

    await prisma.affiliateClick.create({
      data: {
        userId: link.userId,
        linkId: link.id,
        campaignId: link.campaignId,
        articleId,
        referrer: req.headers.get('referer')?.slice(0, 500) || null,
      },
    }).catch(err => console.warn('[aff] click log failed:', err?.message));

    return NextResponse.redirect(link.url, 302);
  } catch (error: any) {
    console.error('Affiliate redirect error:', error);
    return NextResponse.json({ ok: false, error: 'Redirect failed' }, { status: 500 });
  }
}
