import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { encrypt } from '@/lib/crypto'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { updateSiteSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

interface RouteContext {
  params: Promise<{ id: string }>
}

// PATCH /api/sites/[id] — toggle active status or update credentials
export async function PATCH(
  request: Request,
  context: RouteContext
) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { id } = await context.params

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(updateSiteSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { isActive, username, apiKey } = body

    // Build update data
    const updateData: Record<string, unknown> = {}
    if (typeof isActive === 'boolean') updateData.isActive = isActive
    if (username !== undefined) updateData.username = username
    if (apiKey !== undefined) updateData.apiKey = apiKey ? encrypt(apiKey) : null

    const site = await db.connectedSite.update({
      where: { id },
      data: updateData,
    })

    const { apiKey: _, ...safeSite } = site
    return NextResponse.json({ site: safeSite })
  } catch (error) {
    return handleApiError(error, 'sites/update')
  }
}

// DELETE /api/sites/[id] — remove a connected site
export async function DELETE(
  request: Request,
  context: RouteContext
) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { id } = await context.params

    await db.connectedSite.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error, 'sites/delete')
  }
}
