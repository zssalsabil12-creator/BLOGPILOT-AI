'use client';

import { useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Copy, Check, RotateCcw, Link, ChevronDown } from 'lucide-react';

const PRESETS = [
  { label: 'Facebook Ad', source: 'facebook', medium: 'cpc', name: 'facebook_ad' },
  { label: 'Google Ads', source: 'google', medium: 'cpc', name: 'google_ads' },
  { label: 'Twitter Post', source: 'twitter', medium: 'social', name: 'twitter_post' },
  { label: 'LinkedIn Post', source: 'linkedin', medium: 'social', name: 'linkedin_post' },
  { label: 'Instagram Story', source: 'instagram', medium: 'social', name: 'instagram_story' },
  { label: 'Newsletter', source: 'newsletter', medium: 'email', name: 'newsletter_2026' },
  { label: 'Email Campaign', source: 'email', medium: 'email', name: 'email_campaign' },
  { label: 'YouTube Video', source: 'youtube', medium: 'video', name: 'youtube_video' },
  { label: 'Reddit Post', source: 'reddit', medium: 'social', name: 'reddit_post' },
  { label: 'Organic Social', source: 'organic', medium: 'social', name: 'organic_social' },
];

export default function UTMBuilderPage() {
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [source, setSource] = useState('');
  const [medium, setMedium] = useState('');
  const [campaignName, setCampaignName] = useState('');
  const [term, setTerm] = useState('');
  const [content, setContent] = useState('');
  const [output, setOutput] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');
  const [showPresets, setShowPresets] = useState(false);

  const generate = () => {
    setError('');

    if (!websiteUrl.trim()) {
      setError('Website URL is required.');
      return;
    }

    if (!source.trim()) {
      setError('Campaign Source is required.');
      return;
    }

    if (!medium.trim()) {
      setError('Campaign Medium is required.');
      return;
    }

    if (!campaignName.trim()) {
      setError('Campaign Name is required.');
      return;
    }

    let url: URL;
    try {
      url = new URL(websiteUrl.trim());
    } catch {
      setError('Please enter a valid URL (e.g., https://example.com).');
      return;
    }

    url.searchParams.set('utm_source', source.trim());
    url.searchParams.set('utm_medium', medium.trim());
    url.searchParams.set('utm_campaign', campaignName.trim());

    if (term.trim()) {
      url.searchParams.set('utm_term', term.trim());
    }

    if (content.trim()) {
      url.searchParams.set('utm_content', content.trim());
    }

    setOutput(url.toString());
  };

  const applyPreset = (preset: typeof PRESETS[number]) => {
    setSource(preset.source);
    setMedium(preset.medium);
    setCampaignName(preset.name);
    setShowPresets(false);
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const reset = () => {
    setWebsiteUrl('');
    setSource('');
    setMedium('');
    setCampaignName('');
    setTerm('');
    setContent('');
    setOutput('');
    setError('');
  };

  const inputClass = 'w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring';
  const labelClass = 'text-sm font-medium text-foreground';
  const optionalClass = 'text-xs text-muted-foreground ml-1';

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="relative mb-4">
            <button
              onClick={() => setShowPresets(!showPresets)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              Quick Presets
              <ChevronDown className={`w-4 h-4 transition-transform ${showPresets ? 'rotate-180' : ''}`} />
            </button>
            {showPresets && (
              <div className="absolute z-10 mt-2 w-full max-w-sm rounded-xl border border-border bg-card shadow-lg p-2 grid grid-cols-2 gap-1">
                {PRESETS.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => applyPreset(preset)}
                    className="text-left px-3 py-2 rounded-lg text-sm text-foreground hover:bg-muted/50 transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className={labelClass}>Website URL *</label>
              <input type="url" value={websiteUrl} onChange={(e) => setWebsiteUrl(e.target.value)} placeholder="https://example.com/page" className={`${inputClass} mt-1`} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Campaign Source *</label>
                <input type="text" value={source} onChange={(e) => setSource(e.target.value)} placeholder="google, facebook, newsletter" className={`${inputClass} mt-1`} />
              </div>
              <div>
                <label className={labelClass}>Campaign Medium *</label>
                <input type="text" value={medium} onChange={(e) => setMedium(e.target.value)} placeholder="cpc, social, email, organic" className={`${inputClass} mt-1`} />
              </div>
            </div>
            <div>
              <label className={labelClass}>Campaign Name *</label>
              <input type="text" value={campaignName} onChange={(e) => setCampaignName(e.target.value)} placeholder="spring_sale, product_launch" className={`${inputClass} mt-1`} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Campaign Term<span className={optionalClass}>(optional)</span></label>
                <input type="text" value={term} onChange={(e) => setTerm(e.target.value)} placeholder="keyword for paid search" className={`${inputClass} mt-1`} />
              </div>
              <div>
                <label className={labelClass}>Campaign Content<span className={optionalClass}>(optional)</span></label>
                <input type="text" value={content} onChange={(e) => setContent(e.target.value)} placeholder="to differentiate similar links" className={`${inputClass} mt-1`} />
              </div>
            </div>
          </div>

          {error && <p className="text-sm text-red-500 mt-3">{error}</p>}

          <div className="flex gap-3 mt-4">
            <button onClick={generate} className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">Generate UTM URL</button>
            <button onClick={reset} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              <RotateCcw className="w-4 h-4" /> Reset
            </button>
          </div>
        </div>

        {output && (
          <div className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                <Link className="w-4 h-4" /> Generated UTM URL
              </h3>
              <button onClick={copyToClipboard} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <div className="p-4 rounded-xl bg-muted/50 border border-border">
              <p className="text-sm font-mono text-foreground break-all">{output}</p>
            </div>
            <div className="mt-4 rounded-xl border border-border bg-muted/50 p-4">
              <h4 className="text-xs font-medium text-muted-foreground mb-2">Parameters</h4>
              <div className="space-y-1 text-sm">
                <p><span className="text-muted-foreground">Source:</span> <span className="text-foreground">{source}</span></p>
                <p><span className="text-muted-foreground">Medium:</span> <span className="text-foreground">{medium}</span></p>
                <p><span className="text-muted-foreground">Campaign:</span> <span className="text-foreground">{campaignName}</span></p>
                {term && <p><span className="text-muted-foreground">Term:</span> <span className="text-foreground">{term}</span></p>}
                {content && <p><span className="text-muted-foreground">Content:</span> <span className="text-foreground">{content}</span></p>}
              </div>
            </div>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
