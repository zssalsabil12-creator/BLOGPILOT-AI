import { validateFetchUrl } from '@/lib/url-validator';
import { decrypt } from '@/lib/encryption';

export interface WordPressSiteInput {
  url: string;
  username?: string | null;
  apiKey?: string | null;
}

export interface WordPressPostInput {
  title: string;
  content: string;
  status?: 'draft' | 'publish' | 'pending' | 'private';
  excerpt?: string | null;
  slug?: string | null;
  featuredMediaId?: number;
  /** WP-native term IDs (passthrough — resolved by the caller/site). */
  categories?: number[];
  tags?: number[];
}

export interface WordPressPostResult {
  id: number;
  link: string;
  status: string;
  slug: string;
  title: string;
}

export interface PublishResult {
  id: string;
  link: string;
  status: string;
  platform: string;
}

function normalizeUrl(url: string): string {
  return url.trim().replace(/\/+$/, '');
}

function basicAuth(site: WordPressSiteInput): string | null {
  const username = site.username?.trim();
  if (!username || !site.apiKey) return null;
  let apiKey: string;
  try {
    apiKey = decrypt(site.apiKey);
  } catch {
    apiKey = site.apiKey;
  }
  return `Basic ${Buffer.from(`${username}:${apiKey}`).toString('base64')}`;
}

async function wpRequest(
  site: WordPressSiteInput,
  path: string,
  init: RequestInit = {},
  timeoutMs = 15000,
): Promise<any> {
  const urlCheck = await validateFetchUrl(site.url);
  if (!urlCheck.ok) {
    throw new Error(`URL validation failed: ${urlCheck.error}`);
  }
  const base = `${normalizeUrl(site.url)}/wp-json/wp/v2`;
  const auth = basicAuth(site);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(`${base}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(auth ? { Authorization: auth } : {}),
        ...(init.headers || {}),
      },
      signal: controller.signal,
    });

    const text = await res.text();
    let json: any = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }

    if (!res.ok) {
      const message =
        json?.message ||
        (typeof json?.code === 'string' ? `WordPress error: ${json.code}` : `WordPress responded with ${res.status}`);
      const error: any = new Error(message);
      error.status = res.status;
      error.code = json?.code;
      error.data = json;
      throw error;
    }

    return json;
  } finally {
    clearTimeout(timer);
  }
}

export async function testWordPressConnection(site: WordPressSiteInput): Promise<{ ok: boolean; message: string }> {
  const base = `${normalizeUrl(site.url)}/wp-json`;
  const urlCheck = await validateFetchUrl(site.url);
  if (!urlCheck.ok) {
    return { ok: false, message: `URL validation failed: ${urlCheck.error}` };
  }
  const auth = basicAuth(site);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(base, {
      headers: {
        Accept: 'application/json',
        ...(auth ? { Authorization: auth } : {}),
      },
      signal: controller.signal,
    });

    if (res.status === 401 || res.status === 403) {
      return { ok: false, message: 'Authentication failed. Check the username and application password.' };
    }
    if (res.status === 404) {
      return { ok: false, message: 'WordPress REST API not found. The site may not be a WordPress site.' };
    }
    if (!res.ok) {
      return { ok: false, message: `WordPress responded with status ${res.status}.` };
    }

    if (auth) {
      try {
        const me = await fetch(`${base}/wp/v2/users/me`, {
          headers: { Accept: 'application/json', Authorization: auth },
          signal: controller.signal,
        });
        if (!me.ok) {
          return { ok: false, message: 'Authentication failed. Check the username and application password.' };
        }
      } catch {
        return { ok: false, message: 'Could not verify authentication with this WordPress site.' };
      }
    }

    return { ok: true, message: 'Connected successfully.' };
  } catch (error: any) {
    if (error?.name === 'AbortError') {
      return { ok: false, message: 'Connection timed out. Check the site URL.' };
    }
    return { ok: false, message: error?.message || 'Could not reach this WordPress site.' };
  } finally {
    clearTimeout(timer);
  }
}

export async function createWordPressPost(
  site: WordPressSiteInput,
  input: WordPressPostInput,
): Promise<WordPressPostResult> {
  const body: Record<string, any> = {
    title: input.title,
    content: input.content,
    status: input.status || 'publish',
  };
  if (input.excerpt) body.excerpt = input.excerpt;
  if (input.slug) body.slug = input.slug;
  if (input.featuredMediaId) body.featured_media = input.featuredMediaId;
  if (input.categories?.length) body.categories = input.categories;
  if (input.tags?.length) body.tags = input.tags;

  const result = await wpRequest(site, '/posts', {
    method: 'POST',
    body: JSON.stringify(body),
  });

  return {
    id: result?.id,
    link: result?.link,
    status: result?.status,
    slug: result?.slug,
    title: result?.title?.rendered || result?.title || input.title,
  };
}

export async function publishToWebhook(
  site: WordPressSiteInput,
  input: { title: string; content: string; excerpt?: string | null; slug?: string | null },
): Promise<{ id: string; link: string; status: string }> {
  const url = normalizeUrl(site.url);
  if (!/^https?:\/\//i.test(url)) {
    throw new Error('Invalid webhook URL');
  }

  const urlCheck = await validateFetchUrl(url);
  if (!urlCheck.ok) {
    throw new Error(`URL validation failed: ${urlCheck.error}`);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);

  let bearerToken: string | undefined;
  if (site.apiKey) {
    try {
      bearerToken = decrypt(site.apiKey);
    } catch {
      bearerToken = site.apiKey;
    }
  }

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        ...(bearerToken ? { Authorization: `Bearer ${bearerToken}` } : {}),
      },
      body: JSON.stringify({
        event: 'article.published',
        title: input.title,
        content: input.content,
        excerpt: input.excerpt || null,
        slug: input.slug || undefined,
        publishedAt: new Date().toISOString(),
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Webhook responded with status ${res.status}${text ? `: ${text.slice(0, 200)}` : ''}`);
    }

    return { id: String(Date.now()), link: url, status: 'publish' };
  } finally {
    clearTimeout(timer);
  }
}

export async function publishArticle(
  site: WordPressSiteInput & { platform: string },
  input: { title: string; content: string; excerpt?: string | null; slug?: string | null; status?: string; categories?: number[]; tags?: number[] },
): Promise<PublishResult> {
  const platform = (site.platform || '').toLowerCase();

  if (platform === 'webhook' || platform === 'custom') {
    const result = await publishToWebhook(site, input);
    return { ...result, platform: site.platform };
  }

  if (platform === 'blogger') {
    const { getValidAccessToken, publishToBlogger } = await import('@/lib/google-oauth');
    const accessToken = await getValidAccessToken(site.username || '');
    if (!accessToken) throw new Error('Google account not connected. Reconnect via Google OAuth.');
    let blogId = site.apiKey || '';
    try {
      blogId = decrypt(blogId);
    } catch {
      // blogId may be plaintext for older records
    }
    const result = await publishToBlogger(accessToken, blogId, input);
    return { id: result.id, link: result.url, status: result.status, platform: 'Blogger' };
  }

  const result = await createWordPressPost(site, {
    title: input.title,
    content: input.content,
    excerpt: input.excerpt,
    slug: input.slug,
    status: input.status === 'SCHEDULED' ? 'pending' : 'publish',
    categories: input.categories,
    tags: input.tags,
  });

  return {
    id: String(result.id),
    link: result.link,
    status: result.status,
    platform: 'WordPress',
  };
}