﻿import { NextResponse } from 'next/server';
import { capturePayPalOrder } from '@/lib/paypal';
import { APP_URL } from '@/lib/env';
import { apiError } from '@/lib/utils';
import { getCurrentUserId } from '@/lib/auth';
import { z } from 'zod';

const captureSchema = z.object({
  orderId: z.string().min(1).max(255),
});

export async function GET(req: Request) {
  // The browser redirect from PayPal carries the user's session cookie.
  // Require it so a captured order can never be bound to a plan without an
  // authenticated caller.
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.redirect(`${APP_URL}/login?next=${encodeURIComponent('/dashboard?tab=billing')}`);
  }

  const url = new URL(req.url);
  const token = url.searchParams.get('token') || url.searchParams.get('orderId');
  if (!token) {
    return NextResponse.redirect(`${APP_URL}/dashboard?tab=billing&payment=failed`);
  }

  try {
    await capturePayPalOrder(token);
    return NextResponse.redirect(`${APP_URL}/dashboard?tab=billing&payment=success`);
  } catch (error: any) {
    console.error('PayPal capture error:', error);
    return NextResponse.redirect(`${APP_URL}/dashboard?tab=billing&payment=failed`);
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = captureSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const result = await capturePayPalOrder(parsed.data.orderId);
    return NextResponse.json({ ok: true, data: { status: result?.status, id: parsed.data.orderId } });
  } catch (error) {
    return apiError('paypal/capture', error, 502);
  }
}
