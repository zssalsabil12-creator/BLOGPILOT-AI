/**
 * Authentication & Session Management Library
 *
 * Provides lightweight session-based authentication for the BlogPilot AI API.
 * Sessions are passed via the `x-session-token` HTTP header (or Authorization Bearer).
 *
 * In production, you would replace `verifySession` with JWT verification
 * backed by a secret key. For this demo, we accept either:
 *   1. A signed session token issued by /api/auth/login
 *   2. The literal "demo-user" id passed in the `x-user-id` header (dev mode only)
 *
 * All API routes that require authentication should call `requireUser(request)`
 * to obtain the authenticated user. Credit checks use `requireCredits`.
 */

import { db } from '@/lib/db'

const DEMO_USER_ID = 'demo-user'
const DEMO_USER_EMAIL = 'demo@blogpilot.ai'

export interface AuthUser {
  id: string
  email: string | null
  name: string | null
  credits: number
  freeCreditsUsed: number
  preferredLanguage: string
  subscription: {
    plan: string
    status: string
  } | null
}

export interface SimpleAuthUser {
  id: string
  email?: string | null
  name?: string | null
}

export function getCurrentUserId(req?: Request): string | null {
  if (process.env.NODE_ENV !== 'production') {
    const devUserId = process.env.DEVELOPMENT_USER_ID || 'dev_user';
    if (req) {
      const header = req.headers.get('x-user-id');
      if (header && header.trim()) return header.trim();
      const auth = req.headers.get('authorization');
      if (auth?.startsWith('Bearer ')) {
        const token = auth.slice(7).trim();
        if (token) return token;
      }
    }
    return devUserId;
  }

  if (req) {
    const auth = req.headers.get('authorization');
    if (auth?.startsWith('Bearer ')) {
      const token = auth.slice(7).trim();
      if (token) return token;
    }
    const header = req.headers.get('x-user-id');
    if (header && header.trim()) return header.trim();
  }

  return process.env.DEVELOPMENT_USER_ID || 'demo_user';
}

export function getCurrentUser(req?: Request): SimpleAuthUser | null {
  const id = getCurrentUserId(req);
  if (!id) return null;
  return { id, email: null, name: null };
}


export interface AuthResult {
  user: AuthUser
  /** The method used to authenticate (for logging) */
  method: 'session' | 'header' | 'demo'
}

/**
 * Ensure a demo user exists in the database. Called lazily by requireUser
 * if no real user can be resolved. This keeps the demo workflow frictionless
 * — the user can immediately try the product without signing up.
 */
async function ensureDemoUser(): Promise<AuthUser> {
  let user = await db.user.findUnique({
    where: { id: DEMO_USER_ID },
    include: { subscription: true },
  })

  if (!user) {
    user = await db.user.create({
      data: {
        id: DEMO_USER_ID,
        email: DEMO_USER_EMAIL,
        name: 'Demo User',
        credits: 50, // generous demo balance
        preferredLanguage: 'en',
        subscription: {
          create: { plan: 'pro', status: 'active' },
        },
      },
      include: { subscription: true },
    })
  }

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    credits: user.credits,
    freeCreditsUsed: user.freeCreditsUsed,
    preferredLanguage: user.preferredLanguage,
    subscription: user.subscription
      ? { plan: user.subscription.plan, status: user.subscription.status }
      : null,
  }
}

/**
 * Look up a user by id. Returns null if the user does not exist.
 */
async function findUserById(userId: string): Promise<AuthUser | null> {
  const user = await db.user.findUnique({
    where: { id: userId },
    include: { subscription: true },
  })

  if (!user) return null

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    credits: user.credits,
    freeCreditsUsed: user.freeCreditsUsed,
    preferredLanguage: user.preferredLanguage,
    subscription: user.subscription
      ? { plan: user.subscription.plan, status: user.subscription.status }
      : null,
  }
}

/**
 * Resolve the authenticated user from an incoming request.
 *
 * Resolution order:
 * 1. `x-session-token` header → look up user by session token
 * 2. `authorization: Bearer <userId>` header → direct user lookup (dev only)
 * 3. `x-user-id` header → direct user lookup (dev only)
 * 4. Fallback: return the demo user
 *
 * Throws an `AuthError` with status=401 if the supplied credentials
 * are present but invalid.
 */
export async function requireUser(request: Request): Promise<AuthResult> {
  const headers = request.headers

  // 1. Session token
  const sessionToken = headers.get('x-session-token')
  if (sessionToken) {
    // In production: verify JWT and look up the user.
    // For this demo, we accept any non-empty token as a user id.
    const user = await findUserById(sessionToken)
    if (user) return { user, method: 'session' }
    throw new AuthError('Invalid or expired session token', 401)
  }

  // 2. Authorization Bearer
  const authHeader = headers.get('authorization')
  if (authHeader?.startsWith('Bearer ')) {
    const token = authHeader.slice('Bearer '.length).trim()
    const user = await findUserById(token)
    if (user) return { user, method: 'session' }
    throw new AuthError('Invalid bearer token', 401)
  }

  // 3. x-user-id header (dev convenience)
  const headerUserId = headers.get('x-user-id')
  if (headerUserId) {
    const user = await findUserById(headerUserId)
    if (user) return { user, method: 'header' }
    // Fall through to demo if the header was the literal "demo-user"
    if (headerUserId === DEMO_USER_ID) {
      const demo = await ensureDemoUser()
      return { user: demo, method: 'demo' }
    }
    throw new AuthError('User not found', 401)
  }

  // 4. Fallback to demo user
  const demo = await ensureDemoUser()
  return { user: demo, method: 'demo' }
}

/**
 * Require the user to have at least `cost` credits. Returns the user if OK,
 * otherwise throws an `AuthError` with status=402 (Payment Required).
 */
export async function requireCredits(
  request: Request,
  cost: number = 1
): Promise<{ user: AuthUser; method: 'session' | 'header' | 'demo' }> {
  const { user, method } = await requireUser(request)

  if (user.credits < cost) {
    throw new AuthError(
      `Insufficient credits. You need ${cost} but have ${user.credits}. Please upgrade your plan to continue.`,
      402
    )
  }

  return { user, method }
}

/**
 * Deduct credits from a user and log the transaction.
 * Returns the new balance.
 *
 * This is wrapped in a Prisma transaction to ensure atomicity.
 */
export async function deductCredits(
  userId: string,
  amount: number,
  reason: string,
  description?: string,
  articleId?: string
): Promise<number> {
  if (amount <= 0) throw new Error('Credit deduction amount must be positive')

  return await db.$transaction(async (tx) => {
    // Lock the user row by reading first
    const user = await tx.user.findUnique({ where: { id: userId } })
    if (!user) throw new Error(`User ${userId} not found`)
    if (user.credits < amount) {
      throw new AuthError(
        `Insufficient credits. Required: ${amount}, available: ${user.credits}`,
        402
      )
    }

    const newBalance = user.credits - amount

    const [updatedUser] = await Promise.all([
      tx.user.update({
        where: { id: userId },
        data: {
          credits: newBalance,
          totalCreditsUsed: { increment: amount },
        },
      }),
      tx.creditTransaction.create({
        data: {
          userId,
          amount: -amount,
          reason,
          description,
          articleId,
          balanceAfter: newBalance,
        },
      }),
    ])

    return updatedUser.credits
  })
}

/**
 * Add credits to a user (e.g., after a top-up or bonus).
 */
export async function addCredits(
  userId: string,
  amount: number,
  reason: string,
  description?: string
): Promise<number> {
  if (amount <= 0) throw new Error('Credit amount must be positive')

  return await db.$transaction(async (tx) => {
    const user = await tx.user.findUnique({ where: { id: userId } })
    if (!user) throw new Error(`User ${userId} not found`)

    const newBalance = user.credits + amount

    await Promise.all([
      tx.user.update({
        where: { id: userId },
        data: { credits: newBalance },
      }),
      tx.creditTransaction.create({
        data: {
          userId,
          amount,
          reason,
          description,
          balanceAfter: newBalance,
        },
      }),
    ])

    return newBalance
  })
}

/**
 * Custom auth error with HTTP status code.
 */
export class AuthError extends Error {
  statusCode: number

  constructor(message: string, statusCode: number = 401) {
    super(message)
    this.name = 'AuthError'
    this.statusCode = statusCode
  }
}

/**
 * Plan-based credit limits.
 */
export const PLAN_CREDIT_LIMITS: Record<string, number> = {
  free: 10,
  basic: 100,
  pro: 1000,
  agency: 10000,
}

/**
 * Get the credit cap for a user's plan.
 */
export function getPlanCreditCap(plan: string | undefined | null): number {
  if (!plan) return PLAN_CREDIT_LIMITS.free
  return PLAN_CREDIT_LIMITS[plan] ?? PLAN_CREDIT_LIMITS.free
}

/**
 * Free-trial article limit — number of articles a user with an inactive
 * subscription can generate before being blocked by the paywall.
 */
export const FREE_TRIAL_LIMIT = 3

/**
 * Increment the user's free-trial counter by 1.
 *
 * This counter only matters when the user's subscription status is
 * "inactive" — active paid users bypass the free-trial paywall entirely.
 *
 * Returns the new value of `freeCreditsUsed`.
 */
export async function incrementFreeCreditsUsed(userId: string): Promise<number> {
  const updated = await db.user.update({
    where: { id: userId },
    data: { freeCreditsUsed: { increment: 1 } },
    select: { freeCreditsUsed: true },
  })
  return updated.freeCreditsUsed
}
