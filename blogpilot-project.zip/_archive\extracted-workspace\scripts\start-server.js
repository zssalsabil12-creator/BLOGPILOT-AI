// Persistent standalone server launcher.
// Uses spawn({detached: true}) + child.unref() to create a truly detached
// process that survives the parent shell exiting. This is the only method
// that has been verified to work in this sandbox environment.
const { spawn } = require('child_process')
const fs = require('fs')

const logFile = '/tmp/next-server.log'
// Truncate the log file so we always start fresh
fs.writeFileSync(logFile, '')

const logStream = fs.createWriteStream(logFile, { flags: 'a' })

const child = spawn(
  'node',
  ['.next/standalone/server.js'],
  {
    cwd: '/home/z/my-project',
    detached: true,  // critical: detaches the child into its own process group
    stdio: ['ignore', 'pipe', 'pipe'],
    env: {
      ...process.env,
      DATABASE_URL: 'file:/home/z/my-project/db/custom.db',
      PORT: '3000',
      HOSTNAME: '0.0.0.0',
      FORCE_COLOR: '0',
      NODE_ENV: 'production',
    },
  }
)

child.stdout.pipe(logStream)
child.stderr.pipe(logStream)

// Critical: unref the child so the parent shell can exit without keeping
// the child alive in the foreground. Combined with detached:true, this
// creates a truly orphaned background process.
child.unref()

console.log(`Server PID: ${child.pid}`)
console.log(`Logs: ${logFile}`)
process.exit(0)
