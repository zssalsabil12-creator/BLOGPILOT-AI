'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Megaphone,
  Plus,
  Loader2,
  AlertTriangle,
  CheckCircle,
  MousePointerClick,
  ShieldAlert,
  Sparkles,
  PenTool,
  Trash2,
  Link2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore, type DashboardTab } from '@/lib/store'

interface CampaignStats {
  campaignId: string
  name: string
  productName: string
  isActive: boolean
  linkCount: number
  clicks30d: number
  clicksTotal: number
  lastClickAt: string | null
}

interface Idea {
  title: string
  type: string
  intent: string
  keyword: string
  angle: string
  affiliateFit: 'primary' | 'secondary' | 'support'
}

interface StatsResponse {
  totals: { clicks30d: number; clicksTotal: number; trackedLinks: number; unsafeLinks: number }
  topArticles: Array<{ articleId: string; title: string; clicks30d: number }>
}

const FIT_STYLES: Record<string, string> = {
  primary: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  secondary: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
  support: 'bg-muted text-muted-foreground border-transparent',
}

export default function AffiliateCampaignsPage() {
  const setDashboardTab = useAppStore(s => s.setDashboardTab)
  const [campaigns, setCampaigns] = useState<CampaignStats[]>([])
  const [stats, setStats] = useState<StatsResponse | null>(null)
  const [loading, setLoading] = useState(true)
  const [createOpen, setCreateOpen] = useState(false)
  const [creating, setCreating] = useState(false)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)
  const [scanning, setScanning] = useState(false)
  const [ideasFor, setIdeasFor] = useState<string | null>(null)
  const [ideas, setIdeas] = useState<Idea[] | null>(null)
  const [ideasLoading, setIdeasLoading] = useState(false)
  const [articles, setArticles] = useState<Array<{ id: string; title: string }>>([])

  // Create form state
  const [form, setForm] = useState({ name: '', productName: '', affiliateUrl: '', network: '', commission: '', targetAudience: '' })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [cRes, sRes] = await Promise.all([
        fetch('/api/affiliate/campaigns'),
        fetch('/api/affiliate/stats'),
      ])
      const cJson = await cRes.json()
      const sJson = sRes.ok ? await sRes.json() : null
      if (cRes.ok) setCampaigns(cJson?.data?.campaigns || [])
      if (sRes.ok && sJson) setStats(sJson?.data || null)
    } catch {
      // surfaced via empty state
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    fetch('/api/articles?limit=100')
      .then(r => r.json())
      .then(j => setArticles((j?.data?.articles || []).map((a: any) => ({ id: a.id, title: a.title }))))
      .catch(() => {})
  }, [])

  const handleCreate = async () => {
    if (!form.name.trim() || !form.productName.trim() || !form.affiliateUrl.trim()) return
    setCreating(true)
    setMessage(null)
    try {
      const res = await fetch('/api/affiliate/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(),
          productName: form.productName.trim(),
          affiliateUrl: form.affiliateUrl.trim(),
          network: form.network.trim() || undefined,
          commission: form.commission.trim() || undefined,
          targetAudience: form.targetAudience.trim() || undefined,
        }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to create campaign')
      setCreateOpen(false)
      setForm({ name: '', productName: '', affiliateUrl: '', network: '', commission: '', targetAudience: '' })
      setMessage({ ok: true, text: `Campaign created — tracked link ready: ${json.data.trackedUrl}` })
      await load()
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Failed to create campaign' })
    } finally {
      setCreating(false)
    }
  }

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/affiliate/campaigns/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Delete failed')
      setMessage({ ok: true, text: 'Campaign deleted (links kept but unlinked).' })
      await load()
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Delete failed' })
    }
  }

  const loadIdeas = async (campaignId: string) => {
    setIdeasFor(campaignId)
    setIdeasLoading(true)
    setIdeas(null)
    try {
      const res = await fetch(`/api/affiliate/campaigns/${campaignId}/ideas`, { method: 'POST' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to generate ideas')
      setIdeas(json.data.ideas)
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Failed to generate ideas' })
    } finally {
      setIdeasLoading(false)
    }
  }

  const insertIntoArticle = async (campaignId: string, articleId: string) => {
    try {
      const res = await fetch('/api/affiliate/insert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaignId, articleId }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Insertion failed')
      setMessage({
        ok: json.data.applied,
        text: json.data.applied
          ? `Tracked link inserted at paragraph ${json.data.placementParagraph + 1}.`
          : 'This tracked link is already in the article.',
      })
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Insertion failed' })
    }
  }

  const scanBroken = async () => {
    setScanning(true)
    try {
      const res = await fetch('/api/affiliate/broken-links', { method: 'POST' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Scan failed')
      setMessage({
        ok: true,
        text: `${json.data.scanned} link(s) scanned — ${json.data.broken} broken. Broken links are deactivated automatically in Autopilot.`,
      })
      await load()
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Scan failed' })
    } finally {
      setScanning(false)
    }
  }

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Affiliate Campaigns</h1>
            <p className="text-muted-foreground">Commercial content clusters with real click tracking</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={scanBroken} disabled={scanning} className="rounded-xl">
              {scanning ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ShieldAlert className="w-4 h-4 mr-2" />}
              Scan for broken links
            </Button>
            <Dialog open={createOpen} onOpenChange={setCreateOpen}>
              <DialogTrigger asChild>
                <Button className="rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  New Campaign
                </Button>
              </DialogTrigger>
              <DialogContent className="glass bg-background/95 max-w-lg">
                <DialogHeader>
                  <DialogTitle>New Affiliate Campaign</DialogTitle>
                </DialogHeader>
                <div className="space-y-3 mt-2">
                  {[
                    { k: 'name', label: 'Campaign name', ph: 'Q4 espresso machines', req: true },
                    { k: 'productName', label: 'Product name', ph: 'Alpha Espresso Pro', req: true },
                    { k: 'affiliateUrl', label: 'Affiliate URL', ph: 'https://amzn.to/…', req: true },
                    { k: 'network', label: 'Network (optional)', ph: 'Amazon / CJ / Impact' },
                    { k: 'commission', label: 'Commission (optional)', ph: '4%' },
                    { k: 'targetAudience', label: 'Target audience (optional)', ph: 'home baristas, beginners' },
                  ].map(f => (
                    <div key={f.k}>
                      <label className="text-xs font-medium text-muted-foreground mb-1 block">{f.label}</label>
                      <Input
                        value={(form as any)[f.k]}
                        onChange={e => setForm(prev => ({ ...prev, [f.k]: e.target.value }))}
                        placeholder={f.ph}
                        className="bg-muted/40 border-border"
                      />
                    </div>
                  ))}
                  <Button
                    onClick={handleCreate}
                    disabled={creating || !form.name.trim() || !form.productName.trim() || !form.affiliateUrl.trim()}
                    className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
                  >
                    {creating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                    Create Campaign
                  </Button>
                  <p className="text-[11px] text-muted-foreground/70">
                    Links inserted into articles route through your tracking redirect so clicks are counted for real.
                  </p>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {message && (
          <div className={cn(
            'mb-6 flex items-start gap-3 px-4 py-3 rounded-xl border text-sm break-all',
            message.ok ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
          )}>
            {message.ok ? <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />}
            {message.text}
          </div>
        )}

        {/* Real totals */}
        {!loading && stats && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Clicks (30d)', value: String(stats.totals.clicks30d), icon: MousePointerClick },
              { label: 'Clicks total', value: String(stats.totals.clicksTotal), icon: Megaphone },
              { label: 'Tracked links', value: String(stats.totals.trackedLinks), icon: Link2 },
              { label: 'Broken links', value: String(stats.totals.unsafeLinks), icon: ShieldAlert },
            ].map(s => (
              <Card key={s.label} className="bg-card/50 border border-border backdrop-blur-xl">
                <CardContent className="p-5">
                  <s.icon className="w-4 h-4 text-cyan-400 mb-2" />
                  <p className="text-2xl font-bold text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Top articles */}
        {stats && stats.topArticles.length > 0 && (
          <Card className="bg-card/50 border border-border backdrop-blur-xl mb-8">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Top articles by affiliate clicks (30d)</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-1.5">
                {stats.topArticles.map(a => (
                  <li key={a.articleId} className="flex items-center justify-between text-xs">
                    <span className="truncate text-muted-foreground">{a.title}</span>
                    <span className="font-semibold text-foreground shrink-0 ml-3">{a.clicks30d} clicks</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Campaign list */}
        {loading ? (
          <div className="h-24 rounded-2xl bg-card/40 border border-border animate-pulse" />
        ) : campaigns.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Megaphone className="w-10 h-10 text-cyan-400 mb-4" />
            <h3 className="text-base font-semibold text-foreground mb-1">No campaigns yet</h3>
            <p className="text-sm text-muted-foreground max-w-md mb-5">
              Create a campaign around one product, then let the agent design its commercial content cluster and insert
              tracked links into matching articles.
            </p>
            <Button onClick={() => setCreateOpen(true)} className="rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white">
              <Plus className="w-4 h-4 mr-2" /> Create first campaign
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {campaigns.map(c => (
              <Card key={c.campaignId} className="bg-card/50 border border-border backdrop-blur-xl">
                <CardContent className="p-5">
                  <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h3 className="text-sm font-semibold text-foreground">{c.name}</h3>
                        <Badge variant="secondary" className={cn(
                          'text-[10px] border',
                          c.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-muted text-muted-foreground border-transparent'
                        )}>
                          {c.isActive ? 'Active' : 'Paused'}
                        </Badge>
                        <span className="text-xs text-muted-foreground">· {c.productName}</span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-xs text-muted-foreground">
                        <span>{c.linkCount} link(s)</span>
                        <span><b className="text-foreground">{c.clicks30d}</b> clicks / 30d</span>
                        <span><b className="text-foreground">{c.clicksTotal}</b> total</span>
                        {c.lastClickAt && (
                          <span>last click {new Date(c.lastClickAt).toLocaleDateString()}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 shrink-0">
                      <Button size="sm" variant="outline" className="rounded-xl" onClick={() => loadIdeas(c.campaignId)}>
                        <Sparkles className="w-3.5 h-3.5 mr-1.5" />
                        Content cluster
                      </Button>
                      <Select onValueChange={(articleId) => insertIntoArticle(c.campaignId, articleId)}>
                        <SelectTrigger className="h-9 w-[150px] rounded-xl bg-muted/40 border-border text-xs">
                          <SelectValue placeholder="Insert into…" />
                        </SelectTrigger>
                        <SelectContent>
                          {articles.map(a => (
                            <SelectItem key={a.id} value={a.id}>{a.title.slice(0, 50)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button size="sm" variant="ghost" onClick={() => handleDelete(c.campaignId)} className="rounded-xl text-red-400 hover:bg-red-500/10">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>

                  {ideasFor === c.campaignId && (
                    <div className="mt-4 pt-4 border-t border-border">
                      {ideasLoading ? (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground py-3">
                          <Loader2 className="w-4 h-4 animate-spin" /> Designing the commercial cluster…
                        </div>
                      ) : ideas && ideas.length > 0 ? (
                        <>
                          <p className="text-xs font-medium text-muted-foreground mb-3">
                            Commercial content cluster ({ideas.length} articles):
                          </p>
                          <div className="space-y-2">
                            {ideas.map((idea, i) => (
                              <div key={i} className="flex flex-col sm:flex-row sm:items-center gap-2 p-3 rounded-xl border border-border/60 bg-muted/20">
                                <div className="min-w-0 flex-1">
                                  <div className="flex flex-wrap items-center gap-2 mb-0.5">
                                    <span className="text-xs font-medium text-foreground">{idea.title}</span>
                                    <Badge variant="secondary" className={cn('text-[9px] border capitalize', FIT_STYLES[idea.affiliateFit])}>
                                      {idea.affiliateFit}
                                    </Badge>
                                  </div>
                                  <p className="text-[11px] text-muted-foreground truncate">{idea.keyword} — {idea.angle}</p>
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="shrink-0 rounded-xl text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
                                  onClick={() => {
                                    try { sessionStorage.setItem('pendingOpportunity', idea.title) } catch {}
                                    setDashboardTab('generate-article' as DashboardTab)
                                  }}
                                >
                                  <PenTool className="w-3.5 h-3.5 mr-1" />
                                  Write
                                </Button>
                              </div>
                            ))}
                          </div>
                        </>
                      ) : null}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
