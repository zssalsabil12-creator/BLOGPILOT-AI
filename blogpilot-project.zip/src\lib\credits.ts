import prisma from '@/lib/prisma';

export class InsufficientCreditsError extends Error {
  constructor(message = 'Insufficient credits') {
    super(message);
    this.name = 'InsufficientCreditsError';
  }
}

export interface ConsumeOptions {
  /** Track usage against the free tier allowance (plan === 'free'). */
  freeUse?: boolean;
  description?: string | null;
}

/**
 * Atomically deduct credits from a user.
 *
 * The decrement only applies when the user still holds at least `amount`
 * credits (`credits >= amount` is part of the UPDATE's WHERE clause), so
 * concurrent requests can never drive a balance negative or spend the same
 * credits twice — the database serializes the conditional writes and exactly
 * one loser observes count === 0.
 *
 * Throws InsufficientCreditsError when the balance is too low. Nothing is
 * deducted in that case.
 */
export async function consumeCredits(
  userId: string,
  amount: number,
  reason: string,
  opts?: ConsumeOptions,
): Promise<number> {
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error('Invalid credit amount');
  }

  return prisma.$transaction(async (tx) => {
    const result = await tx.user.updateMany({
      where: { id: userId, credits: { gte: amount } },
      data: {
        credits: { decrement: amount },
        totalCreditsUsed: { increment: amount },
        ...(opts?.freeUse ? { freeCreditsUsed: { increment: amount } } : {}),
      },
    });

    if (result.count === 0) {
      throw new InsufficientCreditsError();
    }

    const user = await tx.user.findUnique({
      where: { id: userId },
      select: { credits: true },
    });

    await tx.creditTransaction.create({
      data: {
        userId,
        amount: -amount,
        reason,
        description: opts?.description ?? null,
        balanceAfter: user!.credits,
      },
    });

    return user!.credits;
  });
}

/**
 * Atomically add credits to a user (refunds, bonuses). Never rejects for
 * balance reasons.
 */
export async function grantCreditsAtomic(
  userId: string,
  amount: number,
  reason: string,
  description?: string | null,
): Promise<number> {
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error('Invalid credit amount');
  }

  return prisma.$transaction(async (tx) => {
    const updated = await tx.user.update({
      where: { id: userId },
      data: { credits: { increment: amount } },
    });
    await tx.creditTransaction.create({
      data: {
        userId,
        amount,
        reason,
        description: description ?? null,
        balanceAfter: updated.credits,
      },
    });
    return updated.credits;
  });
}

/**
 * Atomically deduct up to `maxAmount` credits without ever going negative.
 * Used for refunds/clawbacks where the balance may already be partially spent.
 * Returns the amount actually deducted.
 */
export async function deductCreditsCapped(
  userId: string,
  maxAmount: number,
  reason: string,
  description?: string | null,
): Promise<number> {
  if (!Number.isInteger(maxAmount) || maxAmount <= 0) {
    throw new Error('Invalid credit amount');
  }

  for (let attempt = 0; attempt < 5; attempt++) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { credits: true },
    });
    if (!user) throw new Error('User not found');

    const deduct = Math.min(user.credits, maxAmount);
    if (deduct <= 0) return 0;

    const result = await prisma.user.updateMany({
      where: { id: userId, credits: { gte: deduct } },
      data: { credits: { decrement: deduct } },
    });

    if (result.count > 0) {
      const fresh = await prisma.user.findUnique({
        where: { id: userId },
        select: { credits: true },
      });
      await prisma.creditTransaction.create({
        data: {
          userId,
          amount: -deduct,
          reason,
          description: description ?? null,
          balanceAfter: fresh!.credits,
        },
      });
      return deduct;
    }
    // Concurrent spend raced us — re-read and retry with the smaller balance.
  }

  console.error(`[credits] deductCreditsCapped gave up after retries for user ${userId}`);
  return 0;
}

/**
 * Claim an event id for exactly-once processing. Returns false when the id was
 * already claimed (duplicate webhook delivery / replay).
 *
 * The claim INSERT is unique-constrained (ProcessedEvent.eventId), so two
 * concurrent deliveries cannot both succeed — the database arbitrates.
 */
export async function claimEvent(eventId: string, eventType: string): Promise<boolean> {
  try {
    await prisma.processedEvent.create({
      data: { eventId, eventType },
    });
    return true;
  } catch (err: any) {
    if (err?.code === 'P2002') return false;
    throw err;
  }
}

/**
 * Release a previously claimed event so a payment provider retry can be
 * processed again after an internal failure.
 */
export async function releaseEvent(eventId: string): Promise<void> {
  await prisma.processedEvent.deleteMany({ where: { eventId } }).catch(() => {});
}

export interface AllocationResult {
  applied: boolean;
  credits: number | null;
}

/**
 * Grant plan credits exactly once per idempotency key.
 *
 * The ProcessedEvent claim and the credit increment commit in the SAME
 * transaction, so a duplicate webhook either sees the claim (applied=false)
 * or races on the unique constraint (applied=false). Credits can never be
 * allocated twice for the same key.
 */
export async function allocatePlanCreditsOnce(params: {
  idempotencyKey: string;
  eventType: string;
  userId: string;
  amount: number;
  reason: string;
  description?: string | null;
}): Promise<AllocationResult> {
  if (!Number.isInteger(params.amount) || params.amount <= 0) {
    throw new Error('Invalid credit amount');
  }

  return prisma.$transaction(async (tx) => {
    try {
      await tx.processedEvent.create({
        data: { eventId: params.idempotencyKey, eventType: params.eventType },
      });
    } catch (err: any) {
      if (err?.code === 'P2002') {
        return { applied: false, credits: null };
      }
      throw err;
    }

    const updated = await tx.user.update({
      where: { id: params.userId },
      data: { credits: { increment: params.amount } },
    });

    await tx.creditTransaction.create({
      data: {
        userId: params.userId,
        amount: params.amount,
        reason: params.reason,
        description: params.description ?? null,
        balanceAfter: updated.credits,
      },
    });

    return { applied: true, credits: updated.credits };
  });
}
