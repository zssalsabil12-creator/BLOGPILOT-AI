'use client';

import React, { useMemo, useState } from 'react';

type Report = any;

const getInputType = (value: string) => {
  const normalized = value.trim().toLowerCase();
  if (!normalized) return 'keyword';
  if (normalized.startsWith('http://') || normalized.startsWith('https://')) return 'article';
  if (normalized.includes('.') && !normalized.includes(' ')) return 'website';
  return 'keyword';
};

function safeBase64Encode(value: string) {
  try {
    const utf8Bytes = unescape(encodeURIComponent(value));
    const b64 = typeof window !== 'undefined' && window.btoa ? window.btoa(utf8Bytes) : Buffer.from(value).toString('base64');
    return encodeURIComponent(b64);
  } catch (error) {
    try {
      return encodeURIComponent(btoa(unescape(encodeURIComponent(value))));
    } catch (e) {
      return encodeURIComponent(btoa(value));
    }
  }
}

export default function AnalyzerPage() {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<Report | null>(null);
  const [error, setError] = useState<string | null>(null);

  const inputType = useMemo(() => getInputType(input), [input]);

  async function submit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setReport(null);
    if (!input || input.trim().length < 2) {
      return setError('Please enter a keyword, article URL, or website.');
    }

    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input, type: inputType, numResults: 10 }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Analyze failed.');
      } else {
        setReport(data.report);
      }
    } catch (err: any) {
      setError(err?.message || 'Network error while analyzing.');
    } finally {
      setLoading(false);
    }
  }

  function buildArticle() {
    if (!report) return;

    const payload = safeBase64Encode(JSON.stringify(report));
    window.location.href = `/dashboard/generate?opportunity=${payload}`;
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-10 shadow-xl shadow-black/10">
        <p className="text-sm uppercase tracking-[0.35em] text-cyan-400">Free tool</p>
        <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white sm:text-5xl">BlogPilot AI Content Opportunity Analyzer</h1>
        <p className="mt-5 max-w-3xl text-lg leading-8 text-slate-300">Enter a keyword, article URL, or website to discover what the top search results are missing and where you can publish a more competitive, SEO-focused article.</p>
      </section>

      <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
            <input
              aria-label="Keyword or URL"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="e.g. best email subject lines, https://example.com/article"
              className="w-full rounded-2xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none transition focus:border-cyan-400"
            />
            <button type="submit" disabled={loading} className="rounded-2xl bg-cyan-500 px-6 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-60">
              {loading ? 'Analyzing…' : 'Analyze now'}
            </button>
          </div>
          <p className="text-sm text-slate-400">Detected input type: <span className="font-semibold text-white">{inputType}</span></p>
          <p className="text-sm text-slate-500">The analyzer uses real SERP data for the top 10 ranking pages and extracts content gaps, headings, FAQs, and feature opportunities.</p>
        </form>

          {report?.serpError && (
            <div className="mt-4 rounded-2xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
              <strong>Note:</strong> Live search results were unavailable. Showing estimated analysis based on cached/keyword data.
            </div>
          )}
          {error && <div className="mt-4 rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 text-sm text-rose-100">{error}</div>}
      </section>

      {report && (
        <div className="space-y-6">
          <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
              <div>
                <p className="text-sm uppercase tracking-[0.35em] text-cyan-400">Opportunity grade</p>
                <h2 className="mt-2 text-5xl font-bold text-emerald-400">{report.opportunityScore}</h2>
                <p className="mt-2 text-sm text-slate-300">Search intent: <span className="font-semibold text-white">{report.searchIntent}</span> • Competition: <span className="font-semibold text-white">{report.competitionLevel}</span></p>
              </div>
              <button onClick={buildArticle} className="rounded-2xl bg-indigo-600 px-6 py-3 text-sm font-semibold text-white transition hover:bg-indigo-500">Build a Better Article with BlogPilot AI</button>
            </div>

            {report.beatTop10Highlights?.length ? (
              <div className="mt-6 space-y-3 rounded-3xl border border-slate-800/80 bg-slate-950/80 p-5">
                <h3 className="text-base font-semibold text-white">Beat the Top 10 — What the top results miss</h3>
                <ul className="list-disc space-y-2 pl-5 text-slate-300">
                  {report.beatTop10Highlights.map((highlight: string, index: number) => (
                    <li key={index}>{highlight}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </section>

          <section className="grid gap-6 lg:grid-cols-[1fr_0.85fr]">
            <div className="space-y-6 rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
              <div>
                <h3 className="text-xl font-semibold text-white">Competitor snapshot</h3>
                <p className="mt-2 text-slate-400">This sample shows the top pages that determine ranking. Focus on sections they all miss.</p>
              </div>
              <div className="space-y-4">
                {report.topResults.map((result: any, index: number) => (
                  <a key={index} href={result.url} target="_blank" rel="noreferrer" className="block rounded-2xl border border-slate-800 bg-slate-950 px-4 py-4 transition hover:border-cyan-400">
                    <p className="font-semibold text-white">{result.title || result.url}</p>
                    <p className="mt-1 text-sm text-slate-400">Word count: {result.wordCount || '–'} • H1: {(result.h1 || []).slice(0, 1).join(', ') || '–'}</p>
                    <p className="mt-2 text-sm text-slate-300">{result.metaDescription || result.textSnippet || 'No description available.'}</p>
                  </a>
                ))}

                {report.personalizedComparison ? (
                  <div className="mt-4 rounded-2xl border border-amber-700 bg-amber-900/5 p-4">
                    <h4 className="font-semibold text-amber-300">Personalized analysis for your page</h4>
                    <p className="mt-2 text-sm text-slate-300">URL analyzed: <a href={report.personalizedComparison.userUrl} target="_blank" rel="noreferrer" className="underline">{report.personalizedComparison.userUrl}</a></p>
                    <div className="mt-3 grid gap-3 md:grid-cols-2">
                      <div>
                        <strong className="text-sm text-slate-200">Missing topics</strong>
                        <ul className="mt-2 list-disc pl-5 text-slate-300">
                          {report.personalizedComparison.missingTopics.slice(0,8).map((t: string, i: number) => <li key={i}>{t}</li>)}
                        </ul>
                      </div>
                      <div>
                        <strong className="text-sm text-slate-200">Weak or missing sections</strong>
                        <ul className="mt-2 list-disc pl-5 text-slate-300">
                          {report.personalizedComparison.weakSections.slice(0,8).map((s: string, i: number) => <li key={i}>{s}</li>)}
                        </ul>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>

            <div className="space-y-6 rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
              <div>
                <h3 className="text-xl font-semibold text-white">Missing topics & FAQ openings</h3>
                <p className="mt-2 text-slate-400">Add these to outrank current results by covering what competitors skip.</p>
              </div>
              <div className="grid gap-4">
                <div>
                  <h4 className="text-sm font-semibold uppercase text-slate-300">High-value gaps</h4>
                  <ul className="mt-3 list-disc space-y-2 pl-5 text-slate-300">
                    {(report.contentGaps || []).slice(0, 8).map((gap: string, index: number) => (
                      <li key={index}>{gap}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-sm font-semibold uppercase text-slate-300">FAQ opportunities</h4>
                  <ul className="mt-3 list-disc space-y-2 pl-5 text-slate-300">
                    {(report.faqOpportunities || []).slice(0, 8).map((faq: string, index: number) => (
                      <li key={index}>{faq}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
            <h3 className="text-xl font-semibold text-white">Recommended structure</h3>
            <p className="mt-2 text-slate-400">Use these section ideas as the framework for your next article.</p>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              <div className="rounded-3xl border border-slate-800 bg-slate-950 p-4 text-slate-300">
                <strong>Suggested H2s</strong>
                <ul className="mt-3 list-disc space-y-2 pl-5">
                  {report.aiRecommendations?.recommended_h2?.length ? report.aiRecommendations.recommended_h2.map((heading: string, index: number) => (
                    <li key={index}>{heading}</li>
                  )) : (report.missingSubtopics || []).slice(0, 8).map((heading: string, index: number) => (
                    <li key={index}>{heading}</li>
                  ))}
                </ul>
              </div>
              <div className="rounded-3xl border border-slate-800 bg-slate-950 p-4 text-slate-300">
                <strong>Suggested H3s / FAQs</strong>
                <ul className="mt-3 list-disc space-y-2 pl-5">
                  {(report.aiRecommendations?.recommended_h3 || report.faqOpportunities || []).slice(0, 8).map((heading: string, index: number) => (
                    <li key={index}>{heading}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          {report.recommendedLinks?.length ? (
            <section className="rounded-3xl border border-slate-800/80 bg-slate-900/80 p-6">
              <h3 className="text-xl font-semibold text-white">Recommended links & monetization opportunities</h3>
              <p className="mt-2 text-slate-400">These link suggestions come from your Link Library. Add links in your library to enable more recommendations. Links are suggested based on relevance and monetization potential.</p>
              <div className="mt-4 space-y-3">
                {report.recommendedLinks.map((ln: any, idx: number) => (
                  <div key={idx} className="rounded-2xl border border-slate-800 bg-slate-950 p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <a href={ln.url} target="_blank" rel="noreferrer" className="font-semibold text-white underline">{ln.title || ln.url}</a>
                        <div className="mt-1 text-sm text-slate-300">{ln.reason}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-slate-400">Type: <span className="font-medium text-white">{ln.linkType || 'External'}</span></div>
                        <div className="mt-1 text-sm text-slate-400">Potential: <span className="font-medium text-white">{ln.monetizationPotential || 'NONE'}</span></div>
                      </div>
                    </div>
                    <div className="mt-3 text-sm text-slate-300">Suggested anchor: <span className="font-medium text-white">{ln.suggestedAnchor}</span> • Placement: <span className="font-medium text-white">{ln.suggestedPlacement || 'in-body'}</span></div>
                  </div>
                ))}
              </div>
            </section>
          ) : null}
        </div>
      )}
    </div>
  );
}
