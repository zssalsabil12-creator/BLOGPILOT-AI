import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { encrypt } from '@/lib/crypto'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { createCredentialSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

// GET /api/credentials — list all affiliate credentials (masked)
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    const credentials = await db.affiliateKey.findMany({
      where: userId ? { userId } : undefined,
      orderBy: { createdAt: 'desc' },
    })

    // Return credentials with masked keys (never expose raw keys)
    const safeCredentials = credentials.map((cred) => {
      const { apiKey, apiSecret, ...rest } = cred
      return {
        ...rest,
        hasApiKey: !!apiKey,
        hasApiSecret: !!apiSecret,
        // Mask: show first 8 chars of the encrypted blob as identifier
        maskedKey: apiKey
          ? apiKey.slice(0, 8) + '••••••••••••••••'
          : null,
      }
    })

    return NextResponse.json({ credentials: safeCredentials })
  } catch (error) {
    return handleApiError(error, 'credentials/list')
  }
}

// POST /api/credentials — create a new affiliate credential with encryption
export async function POST(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(createCredentialSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { userId, platform, apiKey, apiSecret, trackingId } = body

    // Check for duplicate platform for the same user
    const existing = await db.affiliateKey.findFirst({
      where: { userId, platform },
    })

    if (existing) {
      // Update the existing credential instead of creating a duplicate
      const updated = await db.affiliateKey.update({
        where: { id: existing.id },
        data: {
          apiKey: encrypt(apiKey),
          apiSecret: apiSecret ? encrypt(apiSecret) : existing.apiSecret,
          trackingId: trackingId || existing.trackingId,
          isActive: true,
          status: 'connected',
        },
      })

      const { apiKey: _, apiSecret: __, ...safe } = updated
      return NextResponse.json(
        { credential: safe, updated: true },
        { status: 200 }
      )
    }

    // Encrypt sensitive fields before storage
    const credential = await db.affiliateKey.create({
      data: {
        userId,
        platform,
        apiKey: encrypt(apiKey),
        apiSecret: apiSecret ? encrypt(apiSecret) : null,
        trackingId: trackingId || null,
        isActive: true,
        status: 'connected',
      },
    })

    const { apiKey: _, apiSecret: __, ...safeCred } = credential
    return NextResponse.json(
      { credential: safeCred },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error, 'credentials/create')
  }
}
