/**
 * Concurrency regression test for atomic credit operations.
 *
 * Simulates N concurrent spenders racing on the same balance using the exact
 * conditional-decrement primitive used by src/lib/credits.ts, plus the
 * ProcessedEvent unique-claim used for webhook idempotency.
 *
 * Run: node tests/concurrent-credits.mjs
 */
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const email = `concurrency-test-${Date.now()}@example.com`;
  const user = await prisma.user.create({
    data: {
      email,
      name: 'Concurrency Test',
      credits: 5,
      subscription: { create: { plan: 'free', status: 'active' } },
    },
  });

  console.log(`Created user ${user.id} with ${user.credits} credits`);

  // ---- Test 1: 8 concurrent spends against a balance of 5 -----------------
  const SPENDERS = 8;
  const results = await Promise.all(
    Array.from({ length: SPENDERS }, () =>
      prisma.user.updateMany({
        where: { id: user.id, credits: { gte: 1 } },
        data: { credits: { decrement: 1 }, totalCreditsUsed: { increment: 1 } },
      }),
    ),
  );

  const successes = results.filter((r) => r.count === 1).length;
  const failures = results.filter((r) => r.count === 0).length;
  const after = await prisma.user.findUnique({ where: { id: user.id } });

  console.log(`Test 1 — concurrent spends: succeeded=${successes} rejected=${failures} finalBalance=${after.credits}`);

  if (successes !== 5 || failures !== 3 || after.credits !== 0) {
    throw new Error(`FAIL: expected exactly 5 successes, 3 rejections, balance 0`);
  }
  if (after.totalCreditsUsed !== 5) throw new Error('FAIL: totalCreditsUsed mismatch');

  // ---- Test 2: concurrent webhook claims (exactly-once) -------------------
  const eventId = `test-event-${Date.now()}`;
  const claims = await Promise.allSettled(
    Array.from({ length: 6 }, () =>
      prisma.processedEvent.create({
        data: { eventId, eventType: 'test.duplicate' },
      }),
    ),
  );
  const fulfilled = claims.filter((c) => c.status === 'fulfilled').length;
  const rejected = claims.filter((c) => c.status === 'rejected').length;

  console.log(`Test 2 — concurrent event claims: won=${fulfilled} rejected=${rejected}`);
  if (fulfilled !== 1 || rejected !== 5) {
    throw new Error('FAIL: event claim did not enforce exactly-once');
  }

  // ---- Test 3: capped deduction never goes negative -----------------------
  await prisma.user.update({ where: { id: user.id }, data: { credits: 3 } });
  let deducted = 0;
  for (let i = 0; i < 2; i++) {
    const u = await prisma.user.findUnique({ where: { id: user.id } });
    const d = Math.min(u.credits, 10);
    if (d <= 0) break;
    const r = await prisma.user.updateMany({
      where: { id: user.id, credits: { gte: d } },
      data: { credits: { decrement: d } },
    });
    if (r.count > 0) deducted += d;
  }
  const finalUser = await prisma.user.findUnique({ where: { id: user.id } });
  console.log(`Test 3 — capped deduction: deducted=${deducted} finalBalance=${finalUser.credits}`);
  if (deducted !== 3 || finalUser.credits !== 0) throw new Error('FAIL: capped deduction incorrect');

  // ---- Cleanup -------------------------------------------------------------
  await prisma.user.delete({ where: { id: user.id } }).catch(() => {});
  await prisma.processedEvent.deleteMany({ where: { eventId } });

  console.log('\nALL CONCURRENCY TESTS PASSED');
}

main()
  .catch((err) => {
    console.error(err.message || err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
