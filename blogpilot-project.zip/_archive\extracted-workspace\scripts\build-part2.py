#!/usr/bin/env python3
"""
Part 2: Custom components (landing, auth, dashboard) + hooks + theme
"""

import os

BASE = "/home/z/my-project"
OUTPUT = "/home/z/my-project/download/BlogPilot-Code-Part2-Components.txt"

TARGET_PREFIXES = [
    "src/components/dashboard/", "src/components/landing/",
    "src/components/auth/", "src/components/theme-",
    "src/hooks/", "public/"
]

def matches(rel):
    for prefix in TARGET_PREFIXES:
        if rel == prefix or rel.startswith(prefix):
            return True
    return False

def skip_dir(rel):
    skip = {"node_modules", ".next", ".git", "download", "scripts", "tests",
            "examples", "skills", "mini-services", "tool-results", "ui"}
    parts = rel.replace(os.sep, "/").split("/")
    return any(p in skip for p in parts)

def main():
    files = []
    for root, dirs, fnames in os.walk(BASE):
        dirs[:] = [d for d in dirs if d not in {"node_modules", ".next", ".git", "download",
            "scripts", "tests", "examples", "skills", "mini-services", "tool-results"}]
        for f in fnames:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, BASE).replace(os.sep, "/")
            if not skip_dir(rel) and matches(rel):
                files.append((rel, full))
    files.sort()
    
    with open(OUTPUT, "w", encoding="utf-8") as out:
        out.write("BlogPilot AI - Source Code Part 2\n")
        out.write("Components (Dashboard, Landing, Auth) + Hooks + Theme\n")
        out.write("=" * 60 + "\n")
        out.write("NOTE: shadcn/ui components are NOT included.\n")
        out.write("Install them with: npx shadcn@latest add button card input dialog...\n")
        out.write("=" * 60 + "\n\n")
        
        cur = None
        for rel, full in files:
            top = rel.split("/")[0] if "/" in rel else "(root)"
            if top != cur:
                cur = top
                out.write(f"\n{'#' * 60}\n# {top}/\n{'#' * 60}\n\n")
            out.write(f"# --- {rel} ---\n")
            try:
                with open(full, "r", encoding="utf-8") as f:
                    c = f.read()
                out.write(c)
                if not c.endswith("\n"): out.write("\n")
            except Exception as e:
                out.write(f"# [ERROR: {e}]\n")
            out.write("\n\n")
    
    sz = os.path.getsize(OUTPUT)
    print(f"Part 2: {len(files)} files, {sz:,} bytes ({sz/1024:.1f} KB)")

if __name__ == "__main__":
    main()
