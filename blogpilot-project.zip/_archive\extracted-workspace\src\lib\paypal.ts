/**
 * PayPal REST API client for BlogPilot AI.
 *
 * Responsibilities:
 *   - Lazy-fetch and cache PayPal access tokens (client-credentials grant).
 *   - Create orders for subscription tiers (basic / pro / agency).
 *   - Capture an order after the buyer approves it on PayPal's side.
 *   - Verify webhook signatures so /api/paypal/webhook can trust inbound events.
 *
 * Routing of funds:
 *   PayPal ALWAYS pays out to the merchant account that owns
 *   PAYPAL_CLIENT_ID / PAYPAL_CLIENT_SECRET. The "admin's merchant wallet" is
 *   the PayPal business account that those credentials belong to — there is
 *   no separate payout config needed.
 *
 * Environment variables (validated by /src/lib/env.ts):
 *   PAYPAL_CLIENT_ID      — public client id (EBA... or A... depending on app type)
 *   PAYPAL_CLIENT_SECRET  — server-side secret
 *   PAYPAL_WEBHOOK_ID     — webhook id (used for signature verification)
 *   PAYPAL_MODE           — 'sandbox' (default) | 'live'
 *
 * Demo mode: when PAYPAL_CLIENT_ID or PAYPAL_CLIENT_SECRET is missing, every
 * function returns null and the route handlers fall back to a simulated
 * checkout flow that grants the plan locally (mirroring Stripe demo mode).
 */

import { PLAN_CONFIG, type PlanTier } from '@/lib/stripe'

/* -------------------------------------------------------------------------- */
/*                              Configuration                                 */
/* -------------------------------------------------------------------------- */

/** Base URL for PayPal REST API — switches on PAYPAL_MODE. */
function paypalApiBase(): string {
  const mode = (process.env.PAYPAL_MODE || 'sandbox').toLowerCase()
  return mode === 'live'
    ? 'https://api-m.paypal.com'
    : 'https://api-m.sandbox.paypal.com'
}

/** PayPal Checkout URL — where the buyer lands to approve an order. */
export function paypalCheckoutBaseUrl(): string {
  const mode = (process.env.PAYPAL_MODE || 'sandbox').toLowerCase()
  return mode === 'live'
    ? 'https://www.paypal.com/checkoutnow'
    : 'https://www.sandbox.paypal.com/checkoutnow'
}

/** Whether PayPal is fully configured for live mode. */
export function isPaypalConfigured(): boolean {
  return !!(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET)
}

/* -------------------------------------------------------------------------- */
/*                          Access token management                           */
/* -------------------------------------------------------------------------- */

interface CachedToken {
  accessToken: string
  /** Epoch-ms when the token expires. */
  expiresAt: number
  /** Token type — usually "Bearer". */
  tokenType: string
}

let tokenCache: CachedToken | null = null

/**
 * Fetch a fresh PayPal access token using the OAuth2 client-credentials grant.
 * Tokens are cached for their advertised lifetime (PayPal returns ~9 hours).
 *
 * Returns null in demo mode (no credentials configured) — callers MUST
 * null-check and fall back to a simulated flow.
 */
export async function getPaypalAccessToken(): Promise<string | null> {
  if (!isPaypalConfigured()) return null

  // Return cached token if it has >60s of life remaining
  if (tokenCache && tokenCache.expiresAt - Date.now() > 60_000) {
    return tokenCache.accessToken
  }

  const clientId = process.env.PAYPAL_CLIENT_ID!
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET!
  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64')

  const res = await fetch(`${paypalApiBase()}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
    cache: 'no-store',
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`PayPal token request failed (${res.status}): ${text}`)
  }

  const data = await res.json() as {
    access_token: string
    expires_in: number
    token_type: string
  }

  tokenCache = {
    accessToken: data.access_token,
    expiresAt: Date.now() + (data.expires_in - 60) * 1000,
    tokenType: data.token_type,
  }

  return tokenCache.accessToken
}

/* -------------------------------------------------------------------------- */
/*                              Order creation                                */
/* -------------------------------------------------------------------------- */

export interface PaypalOrderResponse {
  id: string
  status: string
  /** Links keyed by rel (self, approve, capture, etc.). */
  links: Array<{ href: string; rel: string; method: string }>
  /** The PayPal approval URL — where the front-end redirects the buyer. */
  approvalUrl: string | null
}

/**
 * Create a PayPal Order for a subscription tier.
 *
 * Funds are routed to the merchant account that owns the PayPal credentials
 * (the "admin's wallet"). We pass metadata.userId + metadata.tier so the
 * webhook can find the user and activate the right plan when capture succeeds.
 */
export async function createPaypalOrder(opts: {
  tier: PlanTier
  userId: string
  returnUrl: string
  cancelUrl: string
}): Promise<PaypalOrderResponse> {
  const accessToken = await getPaypalAccessToken()
  if (!accessToken) {
    throw new Error('PayPal not configured (missing PAYPAL_CLIENT_ID or PAYPAL_CLIENT_SECRET)')
  }

  const { tier, userId, returnUrl, cancelUrl } = opts
  const cfg = PLAN_CONFIG[tier]
  const amount = (cfg.priceUsdCents / 100).toFixed(2)

  const body = {
    intent: 'CAPTURE',
    purchase_units: [
      {
        amount: {
          currency_code: 'USD',
          value: amount,
        },
        description: `BlogPilot AI — ${cfg.label} plan (monthly subscription)`,
        custom_id: `${userId}:${tier}`,
        metadata: {
          userId,
          tier,
        },
      },
    ],
    application_context: {
      brand_name: 'BlogPilot AI',
      user_action: 'PAY_NOW',
      shipping_preference: 'NO_SHIPPING',
      return_url: returnUrl,
      cancel_url: cancelUrl,
    },
  }

  const res = await fetch(`${paypalApiBase()}/v2/checkout/orders`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
    },
    body: JSON.stringify(body),
    cache: 'no-store',
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`PayPal order creation failed (${res.status}): ${text}`)
  }

  const data = await res.json() as {
    id: string
    status: string
    links: Array<{ href: string; rel: string; method: string }>
  }

  const approveLink = data.links.find((l) => l.rel === 'approve' || l.rel === 'payer-action')

  return {
    id: data.id,
    status: data.status,
    links: data.links,
    approvalUrl: approveLink?.href || null,
  }
}

/* -------------------------------------------------------------------------- */
/*                              Order capture                                 */
/* -------------------------------------------------------------------------- */

export interface PaypalCaptureResult {
  ok: boolean
  tier: PlanTier | null
  userId: string | null
  captureId: string | null
  amount: string | null
  currency: string | null
  raw: unknown
}

/**
 * Capture a previously-approved PayPal order.
 *
 * Called by /api/paypal/capture after the buyer returns from the PayPal
 * approval page. On success, funds are debited from the buyer and deposited
 * to the merchant's PayPal wallet.
 */
export async function capturePaypalOrder(orderId: string): Promise<PaypalCaptureResult> {
  const accessToken = await getPaypalAccessToken()
  if (!accessToken) {
    throw new Error('PayPal not configured (missing PAYPAL_CLIENT_ID or PAYPAL_CLIENT_SECRET)')
  }

  const res = await fetch(`${paypalApiBase()}/v2/checkout/orders/${orderId}/capture`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
    },
    cache: 'no-store',
  })

  const data = await res.json().catch(() => ({})) as any

  if (!res.ok) {
    return {
      ok: false,
      tier: null,
      userId: null,
      captureId: null,
      amount: null,
      currency: null,
      raw: data,
    }
  }

  // Extract metadata we set when creating the order
  const purchaseUnit = data.purchase_units?.[0]
  const customId: string | undefined = purchaseUnit?.payments?.captures?.[0]?.custom_id
    || purchaseUnit?.custom_id
  const [userId, tier] = customId ? customId.split(':') : [null, null]
  const capture = purchaseUnit?.payments?.captures?.[0]

  return {
    ok: data.status === 'COMPLETED',
    tier: (tier as PlanTier) || null,
    userId: userId || null,
    captureId: capture?.id || null,
    amount: capture?.amount?.value || null,
    currency: capture?.amount?.currency_code || null,
    raw: data,
  }
}

/* -------------------------------------------------------------------------- */
/*                          Webhook verification                              */
/* -------------------------------------------------------------------------- */

/**
 * Verify a PayPal webhook event signature.
 *
 * PayPal sends three headers we need:
 *   PAYPAL-TRANSMISSION-ID
 *   PAYPAL-TRANSMISSION-TIME
 *   PAYPAL-TRANSMISSION-SIG
 *   PAYPAL-CERT-URL
 *   PAYPAL-AUTH-ALGO
 *
 * We POST those + the raw body to PayPal's /v1/verify/verify-webhook-signature
 * endpoint and PayPal tells us whether the event is genuine.
 */
export async function verifyPaypalWebhook(opts: {
  headers: Record<string, string>
  rawBody: string
}): Promise<{ valid: boolean; reason?: string }> {
  if (!isPaypalConfigured() || !process.env.PAYPAL_WEBHOOK_ID) {
    return { valid: false, reason: 'PAYPAL_WEBHOOK_ID not configured' }
  }

  const accessToken = await getPaypalAccessToken()
  if (!accessToken) {
    return { valid: false, reason: 'Could not obtain PayPal access token' }
  }

  const {
    'paypal-transmission-id': transmissionId,
    'paypal-transmission-time': transmissionTime,
    'paypal-transmission-sig': transmissionSig,
    'paypal-cert-url': certUrl,
    'paypal-auth-algo': authAlgo,
  } = opts.headers

  if (!transmissionId || !transmissionSig || !certUrl || !authAlgo) {
    return { valid: false, reason: 'Missing PayPal webhook headers' }
  }

  const body = {
    auth_algo: authAlgo,
    cert_url: certUrl,
    transmission_id: transmissionId,
    transmission_sig: transmissionSig,
    transmission_time: transmissionTime,
    webhook_id: process.env.PAYPAL_WEBHOOK_ID,
    webhook_event: JSON.parse(opts.rawBody),
  }

  const res = await fetch(`${paypalApiBase()}/v1/verify/verify-webhook-signature`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
    cache: 'no-store',
  })

  if (!res.ok) {
    return { valid: false, reason: `Verification HTTP ${res.status}` }
  }

  const data = await res.json() as { verification_status: string }

  return {
    valid: data.verification_status === 'SUCCESS',
    reason: data.verification_status !== 'SUCCESS' ? data.verification_status : undefined,
  }
}
