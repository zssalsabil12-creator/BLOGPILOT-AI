/**
 * Lightweight Markdown <-> HTML converter for the article editor.
 *
 * Articles are stored as Markdown in the database (the AI generator returns
 * markdown), but TipTap (the rich text editor) works with HTML internally.
 * This module bridges the two formats.
 *
 * Supports:
 *   - Headings (H1–H4)
 *   - Bold, italic, inline code
 *   - Links and images
 *   - Unordered and ordered lists
 *   - Blockquotes
 *   - Code blocks (```fenced```)
 *   - Horizontal rules
 *   - Pipe tables (basic)
 *
 * NOTE: This is intentionally a small, dependency-free converter. For full
 * markdown fidelity you could swap in `marked` or `remark`, but this avoids
 * adding 100KB+ to the editor bundle.
 */

/* -------------------------------------------------------------------------- */
/*                              Markdown -> HTML                              */
/* -------------------------------------------------------------------------- */

export function markdownToHtml(md: string): string {
  if (!md) return ''

  const lines = md.split('\n')
  const html: string[] = []
  let inUl = false
  let inOl = false
  let inCode = false
  let inTable = false
  let codeLang = ''

  const closeLists = () => {
    if (inUl) {
      html.push('</ul>')
      inUl = false
    }
    if (inOl) {
      html.push('</ol>')
      inOl = false
    }
  }

  for (const raw of lines) {
    const line = raw.replace(/\s+$/, '')

    // Code fence
    const fence = line.trim().match(/^```(\w*)$/)
    if (fence) {
      if (inCode) {
        html.push('</code></pre>')
        inCode = false
        codeLang = ''
      } else {
        closeLists()
        codeLang = fence[1] || ''
        html.push('<pre><code>')
        inCode = true
      }
      continue
    }
    if (inCode) {
      html.push(escapeHtml(line))
      continue
    }

    // Table
    if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
      if (!inTable) {
        closeLists()
        html.push('<table><tbody>')
        inTable = true
      }
      const cells = line.trim().slice(1, -1).split('|').map((c) => c.trim())
      if (!cells.every((c) => /^:?-+:?$/.test(c))) {
        const tds = cells.map((c) => `<td>${inlineMd(c)}</td>`).join('')
        html.push(`<tr>${tds}</tr>`)
      }
      continue
    } else if (inTable) {
      html.push('</tbody></table>')
      inTable = false
    }

    if (!line.trim()) {
      closeLists()
      continue
    }

    // Headings
    const h = line.match(/^(#{1,6})\s+(.*)$/)
    if (h) {
      closeLists()
      const level = h[1].length
      html.push(`<h${level}>${inlineMd(h[2])}</h${level}>`)
      continue
    }

    // Blockquote
    if (line.startsWith('>')) {
      closeLists()
      html.push(`<blockquote>${inlineMd(line.slice(1).trim())}</blockquote>`)
      continue
    }

    // HR
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(line.trim())) {
      closeLists()
      html.push('<hr />')
      continue
    }

    // Ordered list
    if (/^\d+\.\s+/.test(line)) {
      if (!inOl) {
        closeLists()
        html.push('<ol>')
        inOl = true
      }
      const item = line.replace(/^\d+\.\s+/, '')
      html.push(`<li>${inlineMd(item)}</li>`)
      continue
    }

    // Unordered list
    if (/^[-*+]\s+/.test(line)) {
      if (!inUl) {
        closeLists()
        html.push('<ul>')
        inUl = true
      }
      const item = line.replace(/^[-*+]\s+/, '')
      html.push(`<li>${inlineMd(item)}</li>`)
      continue
    }

    // Paragraph
    closeLists()
    html.push(`<p>${inlineMd(line)}</p>`)
  }

  if (inCode) html.push('</code></pre>')
  closeLists()
  if (inTable) html.push('</tbody></table>')

  return html.join('\n')
}

/** Inline markdown: images, links, bold, italic, code. */
function inlineMd(text: string): string {
  let out = escapeHtml(text)
  // images: ![alt](url)
  out = out.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, (_, alt, url) => {
    return `<img src="${url}" alt="${alt}" />`
  })
  // links: [text](url)
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_, label, url) => {
    return `<a href="${url}">${label}</a>`
  })
  // bold
  out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
  // italic
  out = out.replace(/\*([^*]+)\*/g, '<em>$1</em>')
  // inline code
  out = out.replace(/`([^`]+)`/g, '<code>$1</code>')
  return out
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

/* -------------------------------------------------------------------------- */
/*                              HTML -> Markdown                              */
/* -------------------------------------------------------------------------- */

/**
 * Convert TipTap's HTML output back to Markdown.
 *
 * Walks the DOM tree manually so we don't depend on a parser lib.
 */
export function htmlToMarkdown(htmlInput: string): string {
  if (!htmlInput || typeof window === 'undefined') {
    // Fallback: simple regex-based strip if DOM is unavailable
    return htmlInput
      .replace(/<h([1-6])[^>]*>(.*?)<\/h\1>/gi, (_, lvl, t) => `\n${'#'.repeat(+lvl)} ${stripTags(t)}\n`)
      .replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**')
      .replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*')
      .replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`')
      .replace(/<a[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)')
      .replace(/<img[^>]*src="([^"]+)"[^>]*alt="([^"]*)"[^>]*\/?>/gi, '![$2]($1)')
      .replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n')
      .replace(/<p[^>]*>(.*?)<\/p>/gi, '$1\n\n')
      .replace(/<[^>]+>/g, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim()
  }

  const container = document.createElement('div')
  container.innerHTML = htmlInput
  const md = nodeToMarkdown(container, '')
  return md.replace(/\n{3,}/g, '\n\n').trim()
}

function nodeToMarkdown(node: Node, indent: string): string {
  let out = ''

  node.childNodes.forEach((child) => {
    if (child.nodeType === Node.TEXT_NODE) {
      out += child.textContent || ''
      return
    }
    if (child.nodeType !== Node.ELEMENT_NODE) return

    const el = child as HTMLElement
    const tag = el.tagName.toLowerCase()
    const inner = () => nodeToMarkdown(el, indent)

    switch (tag) {
      case 'h1': out += `\n# ${inner()}\n\n`; break
      case 'h2': out += `\n## ${inner()}\n\n`; break
      case 'h3': out += `\n### ${inner()}\n\n`; break
      case 'h4': out += `\n#### ${inner()}\n\n`; break
      case 'h5': out += `\n##### ${inner()}\n\n`; break
      case 'h6': out += `\n###### ${inner()}\n\n`; break
      case 'p': out += `${inner()}\n\n`; break
      case 'br': out += '\n'; break
      case 'hr': out += `\n---\n\n`; break
      case 'strong':
      case 'b': out += `**${inner()}**`; break
      case 'em':
      case 'i': out += `*${inner()}*`; break
      case 'code': out += `\`${inner()}\``; break
      case 'pre': {
        const codeText = el.textContent || ''
        out += `\n\`\`\`\n${codeText}\n\`\`\`\n\n`
        break
      }
      case 'a': {
        const href = el.getAttribute('href') || ''
        out += `[${inner()}](${href})`
        break
      }
      case 'img': {
        const src = el.getAttribute('src') || ''
        const alt = el.getAttribute('alt') || ''
        out += `![${alt}](${src})`
        break
      }
      case 'ul': {
        out += '\n'
        el.childNodes.forEach((li) => {
          if (li.nodeType === Node.ELEMENT_NODE && (li as HTMLElement).tagName.toLowerCase() === 'li') {
            out += `- ${nodeToMarkdown(li, indent).trim()}\n`
          }
        })
        out += '\n'
        break
      }
      case 'ol': {
        out += '\n'
        let i = 1
        el.childNodes.forEach((li) => {
          if (li.nodeType === Node.ELEMENT_NODE && (li as HTMLElement).tagName.toLowerCase() === 'li') {
            out += `${i}. ${nodeToMarkdown(li, indent).trim()}\n`
            i++
          }
        })
        out += '\n'
        break
      }
      case 'li': out += inner(); break
      case 'blockquote': out += `\n> ${inner().trim().replace(/\n/g, '\n> ')}\n\n`; break
      case 'table': out += `\n${tableToMarkdown(el)}\n\n`; break
      default: out += inner()
    }
  })

  return out
}

function tableToMarkdown(table: HTMLElement): string {
  const rows = Array.from(table.querySelectorAll('tr'))
  if (rows.length === 0) return ''
  const lines: string[] = []
  rows.forEach((row, idx) => {
    const cells = Array.from(row.querySelectorAll('td,th'))
      .map((c) => (c.textContent || '').trim().replace(/\|/g, '\\|'))
    lines.push(`| ${cells.join(' | ')} |`)
    if (idx === 0) {
      lines.push(`| ${cells.map(() => '---').join(' | ')} |`)
    }
  })
  return lines.join('\n')
}

function stripTags(html: string): string {
  return html.replace(/<[^>]+>/g, '')
}
