/**
 * Shared caching layer for expensive public operations (SERP results, page
 * snapshots, analyzer artifacts).
 *
 * Drivers (selected automatically by environment, overridable):
 *   - memory : bounded in-process TTL map. Local development / single instance.
 *   - redis  : any Upstash-REST-compatible endpoint. Correct across multiple
 *              serverless instances because the data lives in Redis.
 *
 * Configuration:
 *   CACHE_DRIVER             "memory" | "redis"   (optional override)
 *   UPSTASH_REDIS_REST_URL   REST base URL        (or REDIS_REST_URL)
 *   UPSTASH_REDIS_REST_TOKEN REST bearer token    (or REDIS_REST_TOKEN)
 *
 * Safety rules enforced by convention in this codebase:
 *   - ONLY public, non-personalized data may be stored under a global key.
 *     User-specific values (link-library suggestions, personalized comparisons)
 *     are computed per request and never passed to these helpers.
 *   - Fail-open: cache errors are logged and treated as misses; they can never
 *     break a request path.
 */

const MEMORY_MAX_ENTRIES = 500;

const memoryCache = new Map<string, { expires: number; value: string }>();

function memoryGetParsed<T>(key: string): T | null {
  const entry = memoryCache.get(key);
  if (!entry) return null;
  if (entry.expires <= Date.now()) {
    memoryCache.delete(key);
    return null;
  }
  try {
    return JSON.parse(entry.value) as T;
  } catch {
    memoryCache.delete(key);
    return null;
  }
}

function memorySet(key: string, value: unknown, ttlSec: number): void {
  // Simple bound: drop expired then oldest-inserted entries when full.
  if (memoryCache.size >= MEMORY_MAX_ENTRIES) {
    const now = Date.now();
    for (const [k, v] of memoryCache) {
      if (v.expires <= now) memoryCache.delete(k);
      if (memoryCache.size < MEMORY_MAX_ENTRIES) break;
    }
    while (memoryCache.size >= MEMORY_MAX_ENTRIES) {
      const firstKey = memoryCache.keys().next().value;
      if (firstKey === undefined) break;
      memoryCache.delete(firstKey);
    }
  }
  memoryCache.set(key, { expires: Date.now() + ttlSec * 1000, value: JSON.stringify(value) });
}

// ---------------------------------------------------------------------------
// Redis driver (Upstash REST-compatible)
// ---------------------------------------------------------------------------

function getRedisRestConfig(): { url: string; token: string } | null {
  const url = process.env.UPSTASH_REDIS_REST_URL || process.env.REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.REDIS_REST_TOKEN;
  if (url?.trim() && token?.trim()) return { url: url.trim().replace(/\/+$/, ''), token: token.trim() };
  return null;
}

async function redisCommand<T>(command: (string | number)[]): Promise<T | null> {
  const cfg = getRedisRestConfig()!;
  const res = await fetch(`${cfg.url}/${command.map(encodeURIComponent).join('/')}`, {
    headers: { Authorization: `Bearer ${cfg.token}` },
    signal: AbortSignal.timeout(3000),
  });
  if (!res.ok) throw new Error(`Redis cache command failed (${res.status})`);
  const data = await res.json();
  if (data?.error) throw new Error(String(data.error));
  return (data?.result ?? null) as T | null;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

function resolveDriver(): 'memory' | 'redis' {
  const explicit = (process.env.CACHE_DRIVER || '').trim().toLowerCase();
  if (explicit === 'redis') return getRedisRestConfig() ? 'redis' : 'memory';
  if (explicit === 'memory') return 'memory';
  return process.env.NODE_ENV === 'production' && getRedisRestConfig() ? 'redis' : 'memory';
}

export async function cacheGet<T>(key: string): Promise<T | null> {
  const prefixed = `bp:cache:${key}`;
  try {
    if (resolveDriver() === 'redis') {
      const raw = await redisCommand<string>(['GET', prefixed]);
      if (!raw) return null;
      return JSON.parse(raw) as T;
    }
    return memoryGetParsed<T>(prefixed);
  } catch (err: any) {
    console.error('[cache] get failed:', err?.message || err);
    return null;
  }
}

export async function cacheSet(key: string, value: unknown, ttlSec: number): Promise<void> {
  const prefixed = `bp:cache:${key}`;
  try {
    if (resolveDriver() === 'redis') {
      await redisCommand(['SET', prefixed, JSON.stringify(value), 'EX', Math.max(1, Math.floor(ttlSec))]);
      return;
    }
    memorySet(prefixed, value, ttlSec);
  } catch (err: any) {
    console.error('[cache] set failed:', err?.message || err);
  }
}

/** Stable short hash for cache-key material (FNV-1a, hex). */
export function hashKeyParts(...parts: (string | number | undefined | null)[]): string {
  const input = parts.map((p) => (p === undefined || p === null ? '' : String(p))).join('\u0000');
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}
