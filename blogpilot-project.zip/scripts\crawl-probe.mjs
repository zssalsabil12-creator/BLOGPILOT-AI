const BASE = 'http://localhost:3000';
(async () => {
  const s = await fetch(BASE + '/api/auth/signup', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Crawler Probe', email: 'cc' + Math.random().toString(36).slice(2) + '@x.com', password: 'TestPass123!' }),
  });
  console.log('signup:', s.status);
  if (s.status !== 201) { console.log(JSON.stringify(await s.json())); process.exit(1); }
  const H = { 'Content-Type': 'application/json', Cookie: s.headers.getSetCookie().map(c => c.split(';')[0]).join('; ') };

  const site = await fetch(BASE + '/api/sites', {
    method: 'POST', headers: H,
    body: JSON.stringify({ name: 'WP Local', url: 'http://localhost:4310', platform: 'WordPress', username: 'blogpilot-tester', apiKey: 'abcd efgh ijkl mnop' }),
  }).then(r => r.json());

  const art = await fetch(BASE + '/api/articles', {
    method: 'POST', headers: H,
    body: JSON.stringify({
      title: 'Crawl Probe Article', targetKeyword: 'probe crawl',
      content: Array(15).fill('## H\n\nBody text about the probe topic with enough length here.').join('\n\n'),
      siteId: site.data.site.id,
    }),
  }).then(r => r.json());

  const t0 = Date.now();
  const sug = await fetch(BASE + '/api/internal-links/suggestions?articleId=' + art.data.article.id, { headers: H }).then(r => r.json());
  console.log(`crawl (${Date.now() - t0}ms):`, JSON.stringify(sug?.data?.graphSummary), '| suggestions:', sug?.data?.suggestions?.length, '| err:', sug?.error || '-');
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
