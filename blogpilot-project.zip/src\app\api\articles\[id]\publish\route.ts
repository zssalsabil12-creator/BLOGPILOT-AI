﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { publishArticle } from '@/lib/wordpress';
import { runQualityGate, type QualityGateResult } from '@/lib/quality-gate';

const publishSchema = z.object({
  siteId: z.string().min(1).optional(),
  status: z.enum(['PUBLISHED', 'SCHEDULED']).optional(),
  /** Explicit user override when the quality gate reports blockers. */
  force: z.boolean().optional(),
  /**
   * Idempotency key: retrying the same logical publish returns the original
   * result instead of creating a duplicate post on the CMS.
   */
  executionId: z.string().max(64).optional(),
  /** WP-native term IDs, passed through to the REST payload. */
  categories: z.array(z.number().int()).max(20).optional(),
  tags: z.array(z.number().int()).max(30).optional(),
});

function slugify(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 200);
}

/**
 * Builds Article + Person JSON-LD for E-E-A-T signals. Injected at the top of
 * post content because generic CMS APIs don't expose <head>. Rendered as a
 * visible "Attribution" line too, so trust signals survive script stripping
 * by sanitizers.
 */
function buildEeatBlock(article: {
  title: string;
  excerpt?: string | null;
  slug?: string | null;
  authorName?: string | null;
  reviewerName?: string | null;
  reviewedAt?: Date | null;
  publishedAt?: Date | null;
  updatedAt: Date;
  language?: string | null;
}, siteUrl: string): string {
  const canonical = `${siteUrl.replace(/\/+$/, '')}/${article.slug || ''}`;
  const schema: any = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: article.title,
    ...(article.excerpt ? { description: article.excerpt.slice(0, 300) } : {}),
    inLanguage: article.language || 'en',
    datePublished: (article.publishedAt || article.updatedAt).toISOString(),
    dateModified: article.updatedAt.toISOString(),
    mainEntityOfPage: { '@type': 'WebPage', '@id': canonical },
  };
  if (article.authorName) {
    schema.author = { '@type': 'Person', name: article.authorName };
  }
  if (article.reviewerName) {
    schema.reviewedBy = { '@type': 'Person', name: article.reviewerName };
    if (!schema.author) schema.author = { '@type': 'Organization', name: 'BlogPilot AI' };
  }
  if (!schema.author) {
    // Google requires an author for Article rich results — fall back to org.
    schema.author = { '@type': 'Organization', name: 'BlogPilot AI' };
  }

  const lines: string[] = [];
  const attributionBits: string[] = [];
  if (article.authorName) attributionBits.push(`Written by ${article.authorName}`);
  if (article.reviewerName) attributionBits.push(`Reviewed by ${article.reviewerName}`);
  attributionBits.push(`Last updated ${article.updatedAt.toISOString().slice(0, 10)}`);

  let html = '';
  if (attributionBits.length > 0) {
    html += `<p><em>${attributionBits.join(' · ')}</em></p>\n`;
  }
  html += `<script type="application/ld+json">${JSON.stringify(schema)}</script>\n`;
  void lines;
  return html;
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  let body: unknown = {};
  try {
    body = await req.json();
  } catch {
    // empty body is allowed
  }

  const parsed = publishSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const article = await prisma.article.findFirst({ where: { id, userId } });
    if (!article) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });

    if (!article.content || article.content.trim().length === 0) {
      return NextResponse.json({ ok: false, error: 'Article has no content to publish' }, { status: 422 });
    }

    // ── Idempotent replay: same executionId + already published → return
    // the original result without touching the CMS again. ──
    const executionId = parsed.data.executionId;
    if (
      executionId &&
      (article as any).lastPublishExecutionId === executionId &&
      article.status === 'PUBLISHED'
    ) {
      const existingSite = article.siteId
        ? await prisma.connectedSite.findUnique({ where: { id: article.siteId }, select: { platform: true } })
        : null;
      return NextResponse.json({
        ok: true,
        data: {
          article,
          idempotentReplay: true,
          publish: {
            id: article.id,
            link: (article as any).publishedUrl || null,
            status: 'PUBLISHED',
            platform: existingSite?.platform || 'unknown',
          },
        },
      });
    }

    const site = parsed.data.siteId
      ? await prisma.connectedSite.findFirst({ where: { id: parsed.data.siteId, userId } })
      : await prisma.connectedSite.findFirst({ where: { userId, isActive: true }, orderBy: { createdAt: 'desc' } });

    if (!site) {
      return NextResponse.json({
        ok: false,
        error: 'No connected site found. Connect a WordPress or webhook site first.',
        code: 'no_site',
      }, { status: 422 });
    }

    if (!site.apiKey && site.platform !== 'Webhook' && site.platform !== 'Custom') {
      return NextResponse.json({ ok: false, error: 'This site is missing credentials. Reconnect it.' }, { status: 422 });
    }

    if (site.platform === 'WordPress' && !site.username) {
      return NextResponse.json({
        ok: false,
        error: 'WordPress site is missing a username. Edit the site to add credentials.',
      }, { status: 422 });
    }

    // ── Pre-Publish Quality Gate ──
    let gate: QualityGateResult | null = null;
    if (!parsed.data.force) {
      gate = await runQualityGate(
        {
          title: article.title,
          content: article.content || '',
          excerpt: article.excerpt,
          slug: article.slug,
          targetKeyword: article.targetKeyword,
          authorName: article.authorName,
          reviewerName: article.reviewerName,
          siteId: site.id,
        },
        { userId, currentArticleId: article.id },
      );

      if (!gate.passed) {
        return NextResponse.json({
          ok: false,
          code: 'quality_gate',
          error: 'Do not publish yet — quality issues must be resolved or explicitly overridden.',
          report: gate,
        }, { status: 422 });
      }
    }

    const slug = article.slug || slugify(article.title);
    const eeatBlock = buildEeatBlock(article, site.url);
    const finalContent = eeatBlock + article.content;

    let publish;
    try {
      publish = await publishArticle(
        {
          url: site.url,
          username: site.username,
          apiKey: site.apiKey,
          platform: site.platform,
        },
        {
          title: article.title,
          content: finalContent,
          excerpt: article.excerpt,
          slug,
          status: parsed.data.status || 'PUBLISHED',
          categories: parsed.data.categories,
          tags: parsed.data.tags,
        },
      );
    } catch (error: any) {
      console.error('Publish to site failed:', error?.message || error);
      return NextResponse.json({
        ok: false,
        error: 'Publishing failed. Check the site connection and try again.',
        code: 'publish_failed',
      }, { status: 502 });
    }

    const updated = await prisma.article.update({
      where: { id },
      data: {
        status: parsed.data.status || 'PUBLISHED',
        publishedAt: new Date(),
        publishedUrl: publish.link || `${site.url.replace(/\/+$/, '')}/${slug}`,
        siteId: site.id,
        slug: slug || undefined,
        ...(executionId ? { lastPublishExecutionId: executionId } : {}),
      } as any,
    });

    await import('@/lib/agent-governance').then(g =>
      g.logActivity({
        userId,
        siteId: site.id,
        executionId: executionId || undefined,
        agent: 'content',
        action: 'publish-article',
        targetType: 'article',
        targetId: article.id,
        targetLabel: article.title,
        reason: parsed.data.force ? 'Human override of quality gate' : 'Passed quality gate',
        afterState: { status: 'PUBLISHED', url: (updated as any).publishedUrl },
      }),
    );

    await prisma.connectedSite.update({
      where: { id: site.id },
      data: { lastSyncAt: new Date() },
    });

    return NextResponse.json({
      ok: true,
      data: {
        article: updated,
        gate: gate ? { passed: true, warnings: gate.warnings, checks: gate.checks } : null,
        publish: {
          id: publish.id,
          link: publish.link,
          status: publish.status,
          platform: site.platform,
        },
      },
    });
  } catch (error: any) {
    console.error('Publish article error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to publish article' }, { status: 500 });
  }
}

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const article = await prisma.article.findFirst({
      where: { id, userId },
      include: { site: { select: { id: true, name: true, url: true, platform: true, isActive: true } } },
    });
    if (!article) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });

    return NextResponse.json({
      ok: true,
      data: {
        article,
        sites: await prisma.connectedSite.findMany({
          where: { userId, isActive: true },
          select: { id: true, name: true, url: true, platform: true, isActive: true },
          orderBy: { createdAt: 'desc' },
        }),
      },
    });
  } catch (error: any) {
    console.error('Get publish info error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load publish info' }, { status: 500 });
  }
}