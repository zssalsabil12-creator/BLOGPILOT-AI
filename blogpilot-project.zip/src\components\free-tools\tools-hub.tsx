'use client';

import React, { useMemo, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Target,
  Type,
  Code,
  Search,
  Link2,
  Share2,
  Bot,
  ArrowRightLeft,
  FileJson,
  Heading1,
  FileText,
  BarChart3,
  BookOpen,
  CaseSensitive,
  Link as LinkIcon,
  HelpCircle,
  FileCode,
  GitBranch,
  Braces,
  Percent,
  KeyRound,
  Gauge,
  Zap,
  ArrowRight,
  ArrowUpRight,
  Check,
  Sparkles,
  Layers,
  Star,
  Lightbulb,
} from 'lucide-react';
import { ALL_TOOLS, TOOL_CATEGORIES } from '@/lib/free-tools/tool-registry';
import type { ToolCategory, ToolDefinition } from '@/lib/free-tools/types';

const iconMap: Record<string, React.ElementType> = {
  Target,
  Type,
  Code,
  Search,
  Link2,
  Share2,
  Bot,
  ArrowRightLeft,
  FileJson,
  Heading1,
  FileText,
  BarChart3,
  BookOpen,
  CaseSensitive,
  LinkIcon,
  HelpCircle,
  FileCode,
  GitBranch,
  Braces,
  Percent,
  KeyRound,
  Gauge,
};

const categoryStyles: Record<string, { dot: string; badge: string; glow: string }> = {
  seo: { dot: 'bg-cyan-400', badge: 'text-cyan-600 dark:text-cyan-300 bg-cyan-400/10', glow: 'from-cyan-400/20 to-cyan-400/0' },
  content: { dot: 'bg-violet-400', badge: 'text-violet-600 dark:text-violet-300 bg-violet-400/10', glow: 'from-violet-400/20 to-violet-400/0' },
  keywords: { dot: 'bg-emerald-400', badge: 'text-emerald-600 dark:text-emerald-300 bg-emerald-400/10', glow: 'from-emerald-400/20 to-emerald-400/0' },
  'internal-linking': { dot: 'bg-amber-400', badge: 'text-amber-600 dark:text-amber-300 bg-amber-400/10', glow: 'from-amber-400/20 to-amber-400/0' },
  analysis: { dot: 'bg-rose-400', badge: 'text-rose-600 dark:text-rose-300 bg-rose-400/10', glow: 'from-rose-400/20 to-rose-400/0' },
  'technical-seo': { dot: 'bg-blue-400', badge: 'text-blue-600 dark:text-blue-300 bg-blue-400/10', glow: 'from-blue-400/20 to-blue-400/0' },
  'structured-data': { dot: 'bg-orange-400', badge: 'text-orange-600 dark:text-orange-300 bg-orange-400/10', glow: 'from-orange-400/20 to-orange-400/0' },
  developer: { dot: 'bg-green-400', badge: 'text-green-600 dark:text-green-300 bg-green-400/10', glow: 'from-green-400/20 to-green-400/0' },
  text: { dot: 'bg-pink-400', badge: 'text-pink-600 dark:text-pink-300 bg-pink-400/10', glow: 'from-pink-400/20 to-pink-400/0' },
};

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-60px' } as const,
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as const },
};

function ToolCard({ tool, index }: { tool: ToolDefinition; index: number }) {
  const style = categoryStyles[tool.category] ?? categoryStyles.seo;
  const Icon = iconMap[tool.icon] || Search;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: index * 0.05 }}
      viewport={{ once: true }}
      className="group relative"
    >
      <Link href={tool.href} className="block h-full">
        <div className="relative h-full overflow-hidden rounded-2xl border border-border bg-card/50 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/5">
          {/* Glow effect on hover */}
          <div className={`absolute -right-16 -top-16 h-40 w-40 rounded-full bg-gradient-to-br ${style.glow} opacity-0 blur-3xl transition-all duration-500 group-hover:opacity-100`} />

          <div className="relative">
            {/* Header */}
            <div className="mb-4 flex items-start justify-between">
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${style.glow} ring-1 ring-border`}>
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <div className="flex items-center gap-2">
                {tool.isNew && (
                  <span className="rounded-full bg-emerald-500/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    New
                  </span>
                )}
                {tool.benefit && (
                  <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${style.badge}`}>
                    {tool.benefit}
                  </span>
                )}
              </div>
            </div>

            {/* Content */}
            <h3 className="text-lg font-semibold text-foreground">{tool.title}</h3>
            <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">{tool.description}</p>

            {/* CTA */}
            <div className="mt-5 flex items-center gap-2 text-sm font-medium text-primary transition group-hover:gap-3">
              {tool.cta}
              <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

function ToolsGridWithFilter() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [query, setQuery] = useState('');

  const filteredTools = useMemo(() => {
    let result = ALL_TOOLS;
    if (activeCategory !== 'all') {
      result = result.filter((t) => t.category === activeCategory);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      result = result.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.category.includes(q)
      );
    }
    return result;
  }, [activeCategory, query]);

  return (
    <div>
      {/* Search + Filters */}
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-full max-w-lg">
          <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search tools by name, category, or keyword..."
            className="w-full rounded-2xl border border-border bg-card py-3 pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-2 focus:ring-primary/20"
          />
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2">
          {TOOL_CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setActiveCategory(cat.key)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                activeCategory === cat.key
                  ? 'bg-primary/15 text-primary ring-1 ring-primary/30'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {filteredTools.map((tool, i) => (
          <ToolCard key={tool.slug} tool={tool} index={i} />
        ))}
      </div>

      {filteredTools.length === 0 && (
        <div className="mt-16 text-center">
          <Search className="mx-auto h-10 w-10 text-muted-foreground/30" />
          <p className="mt-3 text-muted-foreground">No tools match your search.</p>
          <button onClick={() => { setQuery(''); setActiveCategory('all'); }} className="mt-2 text-sm text-primary hover:underline">
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
}

export function ToolsHub() {
  const featuredTool = ALL_TOOLS.find((t) => t.featured);

  return (
    <div className="-mx-4 px-4 md:-mx-8 md:px-8">
      {/* ── Hero ── */}
      <section className="relative mx-auto max-w-3xl pb-8 pt-6 text-center md:pt-10">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Badge
            variant="secondary"
            className="glass mb-6 inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-primary"
          >
            <Zap className="h-3 w-3" />
            Free SEO Toolkit
          </Badge>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.05 }}
          className="text-4xl font-extrabold leading-[1.08] tracking-tight text-balance sm:text-5xl md:text-6xl"
        >
          Free tools to research,{' '}
          <span className="text-gradient">analyze &amp; outrank.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.12 }}
          className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg"
        >
          Data-driven SEO tools powered by real SERP analysis. No signup required for basic use.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"
        >
          <Button
            size="lg"
            asChild
            className="w-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-8 text-base font-semibold text-slate-950 shadow-xl shadow-cyan-500/30 transition hover:shadow-cyan-400/50 sm:w-auto"
          >
            <Link href="/free-tools/content-opportunity-analyzer">
              Try the Analyzer
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button
            variant="outline"
            size="lg"
            asChild
            className="glass w-full rounded-full px-8 text-base sm:w-auto"
          >
            <Link href="/dashboard/generate">Start Article Builder</Link>
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.35 }}
          className="mt-5 flex items-center justify-center gap-4 text-xs text-muted-foreground"
        >
          <span className="flex items-center gap-1"><Check className="h-3 w-3 text-emerald-500" /> No credit card</span>
          <span className="flex items-center gap-1"><Check className="h-3 w-3 text-emerald-500" /> Free forever</span>
          <span className="flex items-center gap-1"><Check className="h-3 w-3 text-emerald-500" /> No signup needed</span>
        </motion.p>
      </section>

      {/* ── Featured Tool ── */}
      {featuredTool && (
        <motion.section {...fadeInUp} className="mx-auto mt-12 max-w-5xl md:mt-16">
          <div className="relative overflow-hidden rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/[0.08] via-card to-accent/[0.06] p-8 md:p-12">
            <div className="absolute -left-24 -top-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
            <div className="absolute -bottom-24 -right-24 h-64 w-64 rounded-full bg-accent/10 blur-3xl" />
            <div className="relative flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
              <div className="max-w-xl">
                <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-primary">
                  <Sparkles className="h-3 w-3" />
                  Flagship Tool
                </div>
                <h2 className="text-2xl font-bold text-foreground md:text-3xl">{featuredTool.title}</h2>
                <p className="mt-4 text-muted-foreground md:text-lg">
                  {featuredTool.description} Powered by real SERP data.
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  {['Real SERP Data', 'Content Gaps', 'AI Structure', 'Link Suggestions'].map((f) => (
                    <span key={f} className="flex items-center gap-1.5 rounded-full border border-border bg-card/50 px-3 py-1 text-xs font-medium text-muted-foreground">
                      <Check className="h-3 w-3 text-emerald-500" />
                      {f}
                    </span>
                  ))}
                </div>
              </div>
              <Button
                size="lg"
                asChild
                className="shrink-0 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-8 text-base font-semibold text-slate-950 shadow-xl shadow-cyan-500/30"
              >
                <Link href={featuredTool.href}>
                  Analyze Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </motion.section>
      )}

      {/* ── All Tools ── */}
      <section className="mx-auto mt-16 max-w-6xl md:mt-24">
        <motion.div className="mx-auto max-w-2xl text-center" {...fadeInUp}>
          <Badge
            variant="secondary"
            className="glass mb-4 inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-primary"
          >
            <Layers className="h-3 w-3" />
            All Tools
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Everything you need to <span className="text-gradient">research content.</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            From keyword research to internal linking, each tool is built for real SEO workflows.
          </p>
        </motion.div>

        <div className="mt-10">
          <ToolsGridWithFilter />
        </div>
      </section>

      {/* ── How It Works ── */}
      <section className="mx-auto mt-20 max-w-5xl md:mt-28">
        <motion.div className="mx-auto max-w-2xl text-center" {...fadeInUp}>
          <Badge
            variant="secondary"
            className="glass mb-4 inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-primary"
          >
            How It Works
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Three simple <span className="text-gradient">steps.</span>
          </h2>
        </motion.div>

        <motion.div
          className="mt-14 grid gap-8 md:grid-cols-3 md:gap-10"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
        >
          {[
            { step: '01', icon: Search, title: 'Enter a keyword or URL', description: 'Paste a target keyword, article URL, or website to start the analysis.' },
            { step: '02', icon: BarChart3, title: 'Analyze top results', description: 'We fetch real ranking pages and extract headings, word counts, FAQs, and content gaps.' },
            { step: '03', icon: FileText, title: 'Build a better article', description: 'Use the insights to craft a more comprehensive article with BlogPilot AI.' },
          ].map((item) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="relative mx-auto mb-6 flex h-20 w-20 items-center justify-center">
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/25 to-accent/25 blur-xl" />
                <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl border border-border bg-card">
                  <item.icon className="h-8 w-8 text-primary" />
                  <span className="absolute -right-2.5 -top-2.5 flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-violet-500 text-xs font-bold text-slate-950">
                    {item.step}
                  </span>
                </div>
              </div>
              <h3 className="text-lg font-semibold text-foreground">{item.title}</h3>
              <p className="mx-auto mt-2.5 max-w-xs text-sm leading-relaxed text-muted-foreground">
                {item.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* ── Why These Tools ── */}
      <section className="mx-auto mt-20 max-w-5xl md:mt-28">
        <motion.div className="mx-auto max-w-2xl text-center" {...fadeInUp}>
          <Badge
            variant="secondary"
            className="glass mb-4 inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-primary"
          >
            Why BlogPilot
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
            Not just another <span className="text-gradient">free tool page.</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            Every tool is built on the same engine that powers our AI article generator — real data, real analysis, real results.
          </p>
        </motion.div>

        <motion.div
          className="mt-12 grid gap-4 sm:grid-cols-2 md:grid-cols-3"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-40px' }}
        >
          {[
            { icon: Search, title: 'Real SERP Data', desc: 'Results from actual search rankings, not random data.' },
            { icon: Target, title: 'Actionable Output', desc: 'Scores that explain why and what to improve.' },
            { icon: Link2, title: 'Link Library Integration', desc: 'Your links matched to content opportunities.' },
            { icon: Sparkles, title: 'AI-Powered Structure', desc: 'Recommended headings and FAQs from real analysis.' },
            { icon: Check, title: 'No Signup Required', desc: 'Use every tool without creating an account.' },
            { icon: ArrowRight, title: 'One-Click Generation', desc: 'Turn analysis into a published article instantly.' },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              viewport={{ once: true }}
              className="flex gap-4 rounded-2xl border border-border bg-card/50 p-5"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                <item.icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{item.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* ── CTA ── */}
      <motion.section {...fadeInUp} className="mx-auto mt-20 max-w-4xl md:mt-28">
        <div className="relative overflow-hidden rounded-[32px] border border-border bg-card/50 px-6 py-16 text-center md:py-20">
          <div className="absolute -left-24 -top-24 h-64 w-64 rounded-full bg-primary/15 blur-3xl" />
          <div className="absolute -bottom-24 -right-24 h-64 w-64 rounded-full bg-accent/15 blur-3xl" />
          <div className="relative mx-auto max-w-xl">
            <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-4 py-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
              <Check className="h-3.5 w-3.5" />
              Free forever — no account required
            </div>
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
              Ready to build better content?
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-muted-foreground md:text-lg">
              Start with the free analyzer, then use BlogPilot AI to generate the article that outranks the competition.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                asChild
                className="w-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-8 text-base font-semibold text-slate-950 shadow-xl shadow-cyan-500/30 sm:w-auto"
              >
                <Link href="/free-tools/content-opportunity-analyzer">
                  Open the Analyzer
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="lg"
                asChild
                className="w-full rounded-full text-muted-foreground hover:text-foreground sm:w-auto"
              >
                <Link href="/signup">Create a free account</Link>
              </Button>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Bottom spacer */}
      <div className="h-12" />
    </div>
  );
}
