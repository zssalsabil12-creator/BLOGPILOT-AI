﻿export const placeholder = true;
