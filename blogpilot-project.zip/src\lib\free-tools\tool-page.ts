import { freeToolMetadata, toolJsonLd, breadcrumbJsonLd } from '@/lib/free-tools/seo';
import { absoluteUrl } from '@/lib/site';
import { ALL_TOOLS } from '@/lib/free-tools/tool-registry';

export function getToolBySlug(slug: string) {
  return ALL_TOOLS.find((t) => t.slug === slug);
}

export function toolPageMetadata(slug: string) {
  const tool = getToolBySlug(slug);
  if (!tool) throw new Error(`Unknown tool slug: ${slug}`);
  return freeToolMetadata({
    title: tool.title,
    description: tool.description,
    path: tool.href,
    openGraphTitle: `${tool.title} — Free ${tool.category.replace('-', ' ')} tool`,
  });
}

export function toolStructuredData(slug: string) {
  const tool = getToolBySlug(slug);
  if (!tool) throw new Error(`Unknown tool slug: ${slug}`);
  const url = absoluteUrl(tool.href);
  return [
    toolJsonLd({ name: tool.title, description: tool.description, url }),
    breadcrumbJsonLd([
      { name: 'BlogPilot AI', url: absoluteUrl('/') },
      { name: 'Free SEO Tools', url: absoluteUrl('/free-tools') },
      { name: tool.title, url },
    ]),
  ];
}
