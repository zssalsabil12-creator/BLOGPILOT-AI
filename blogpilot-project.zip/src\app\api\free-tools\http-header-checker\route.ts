import { NextResponse } from 'next/server';
import { z } from 'zod';
import { validateFetchUrl } from '@/lib/url-validator';
import { apiError } from '@/lib/utils';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { checkUrlLength } from '@/lib/input-limits';

const bodySchema = z.object({
  url: z.string().url().max(2048),
});

const SECURITY_HEADERS = [
  'x-content-type-options',
  'x-frame-options',
  'x-xss-protection',
  'content-security-policy',
  'strict-transport-security',
  'referrer-policy',
  'permissions-policy',
];

async function tryFetch(url: string): Promise<{ status: number; headers: Record<string, string>; redirected: boolean; finalUrl: string }> {
  let res: Response;
  try {
    res = await fetch(url, {
      method: 'HEAD',
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; HeaderChecker/1.0)',
        Accept: '*/*',
      },
      signal: AbortSignal.timeout(10000),
    });
  } catch {
    res = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (compatible; HeaderChecker/1.0)',
        Accept: 'text/html,application/xhtml+xml,*/*',
      },
      signal: AbortSignal.timeout(15000),
    });
  }

  const headers: Record<string, string> = {};
  res.headers.forEach((value, key) => {
    headers[key] = value;
  });

  return {
    status: res.status,
    headers,
    redirected: res.redirected,
    finalUrl: res.url,
  };
}

export async function POST(req: Request) {
  // Public endpoint — throttle per IP before any outbound work.
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`free-tool:${ip}`, RATE_LIMITS.publicApi);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait a moment and try again.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const parse = bodySchema.safeParse(body);
  if (!parse.success) {
    return NextResponse.json(
      { error: 'Invalid input', details: parse.error.flatten() },
      { status: 400 }
    );
  }

  const urlSizeCheck = checkUrlLength(parse.data.url);
  if (!urlSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: urlSizeCheck.error }, { status: 413 });
  }

  try {
    const urlCheck = await validateFetchUrl(parse.data.url);
    if (!urlCheck.ok) {
      return NextResponse.json({ error: urlCheck.error }, { status: 400 });
    }
    const result = await tryFetch(parse.data.url);

    const securityHeaders: Record<string, { present: boolean; value?: string }> = {};
    for (const h of SECURITY_HEADERS) {
      const val = result.headers[h] || result.headers[h.toLowerCase()];
      securityHeaders[h] = { present: !!val, value: val };
    }

    return NextResponse.json({
      ok: true,
      status: result.status,
      headers: result.headers,
      url: parse.data.url,
      redirected: result.redirected,
      finalUrl: result.finalUrl,
      securityHeaders,
    });
  } catch (err) {
    return apiError('free-tools/http-header-checker', err);
  }
}
