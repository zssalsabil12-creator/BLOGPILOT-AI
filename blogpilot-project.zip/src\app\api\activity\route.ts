import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';

const querySchema = z.object({
  status: z.enum(['pending_approval', 'success', 'failed', 'rejected', 'all']).optional().default('all'),
  limit: z.coerce.number().int().min(1).max(100).optional().default(30),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters' }, { status: 400 });
  }

  try {
    const where = parsed.data.status === 'all' ? { userId } : { userId, status: parsed.data.status };
    const [activities, pendingCount] = await Promise.all([
      prisma.agentActivity.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: parsed.data.limit,
        select: {
          id: true, executionId: true, agent: true, action: true,
          targetType: true, targetId: true, targetLabel: true,
          reason: true, status: true, error: true,
          beforeState: true, afterState: true, payload: true,
          createdAt: true,
        },
      }),
      prisma.agentActivity.count({ where: { userId, status: 'pending_approval' } }),
    ]);

    return NextResponse.json({ ok: true, data: { activities, pendingCount } });
  } catch (error: any) {
    console.error('Activity list error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load activity' }, { status: 500 });
  }
}
