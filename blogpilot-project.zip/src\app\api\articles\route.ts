﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { checkBodySize } from '@/lib/input-limits';
import { computeSeoScore } from '@/lib/seo-score';

const createArticleSchema = z.object({
  title: z.string().min(1, 'Title is required').max(300),
  content: z.string().optional(),
  slug: z.string().optional(),
  excerpt: z.string().max(500).optional(),
  targetKeyword: z.string().max(200).optional(),
  seoScore: z.number().int().min(0).max(100).optional(),
  wordCount: z.number().int().min(0).optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'SCHEDULED']).optional(),
  language: z.string().max(10).optional(),
  intent: z.string().max(50).optional(),
  tone: z.string().max(50).optional(),
  length: z.string().max(20).optional(),
  model: z.string().max(100).optional(),
  tokensUsed: z.number().int().min(0).optional(),
  authorName: z.string().max(120).optional().nullable(),
  reviewerName: z.string().max(120).optional().nullable(),
  siteId: z.string().max(64).optional().nullable(),
});

const querySchema = z.object({
  status: z.enum(['DRAFT', 'PUBLISHED', 'SCHEDULED']).optional(),
  limit: z.coerce.number().int().positive().optional(),
  offset: z.coerce.number().int().min(0).optional(),
  q: z.string().optional(),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters', details: parsed.error.flatten() }, { status: 400 });
  }

  const { status, limit, offset, q } = parsed.data;

  const where: any = { userId };
  if (status) where.status = status;
  if (q) {
    where.OR = [
      { title: { contains: q } },
      { content: { contains: q } },
      { targetKeyword: { contains: q } },
    ];
  }

  try {
    const articles = await prisma.article.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      take: limit || 50,
      skip: offset || 0,
    });

    const total = await prisma.article.count({ where });

    return NextResponse.json({
      ok: true,
      data: { articles, total },
    });
  } catch (error: any) {
    console.error('List articles error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load articles' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const bodySizeCheck = await checkBodySize(req);
  if (!bodySizeCheck.ok) {
    return NextResponse.json({ ok: false, error: bodySizeCheck.error }, { status: 413 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = createArticleSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const data = parsed.data;
  const slug = data.slug || data.title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]+/g, '');

  try {
    // Ownership validation for optional site binding.
    let validSiteId: string | null = null;
    if (data.siteId) {
      const site = await prisma.connectedSite.findFirst({
        where: { id: data.siteId, userId },
        select: { id: true },
      });
      if (!site) {
        return NextResponse.json({ ok: false, error: 'Linked site not found' }, { status: 404 });
      }
      validSiteId = site.id;
    }

    const existing = await prisma.article.findFirst({ where: { userId, slug } });
    if (existing) {
      return NextResponse.json({ ok: false, error: 'An article with this slug already exists' }, { status: 409 });
    }

    const content = data.content || '';
    const wordCount = data.wordCount || (content ? content.trim().split(/\s+/).length : 0);

    // Server-side SEO score is the single source of truth (client-passed
    // values are ignored) so scores are consistent and honest.
    const seo = computeSeoScore({
      title: data.title,
      content,
      excerpt: data.excerpt,
      targetKeyword: data.targetKeyword,
    });

    const article = await prisma.article.create({
      data: {
        userId,
        title: data.title,
        slug,
        content,
        excerpt: data.excerpt || (content ? content.slice(0, 200) : null),
        targetKeyword: data.targetKeyword,
        seoScore: seo.score,
        wordCount,
        status: data.status || 'DRAFT',
        language: data.language || 'en',
        intent: data.intent,
        tone: data.tone,
        length: data.length,
        model: data.model,
        tokensUsed: data.tokensUsed,
        authorName: data.authorName ?? null,
        reviewerName: data.reviewerName ?? null,
        siteId: validSiteId,
      },
    });

    return NextResponse.json({ ok: true, data: { article } }, { status: 201 });
  } catch (error: any) {
    console.error('Create article error:', error);
    if (error?.code === 'P2002') {
      return NextResponse.json({ ok: false, error: 'An article with this slug already exists' }, { status: 409 });
    }
    return NextResponse.json({ ok: false, error: 'Unable to create article' }, { status: 500 });
  }
}
