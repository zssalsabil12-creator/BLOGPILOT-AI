import { NextResponse } from 'next/server';
import { z } from 'zod';
import { fetchPageSnapshot } from '../../../../lib/scraper';
import { validateFetchUrl } from '@/lib/url-validator';
import { apiError } from '@/lib/utils';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { checkUrlLength } from '@/lib/input-limits';

const bodySchema = z.object({
  url: z.string().url().max(2048),
});

export async function POST(req: Request) {
  // Public endpoint — throttle per IP before any outbound work.
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`free-tool:${ip}`, RATE_LIMITS.publicApi);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait a moment and try again.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const parse = bodySchema.safeParse(body);
  if (!parse.success) {
    return NextResponse.json(
      { error: 'Invalid input', details: parse.error.flatten() },
      { status: 400 }
    );
  }

  const urlSizeCheck = checkUrlLength(parse.data.url);
  if (!urlSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: urlSizeCheck.error }, { status: 413 });
  }

  try {
    const urlCheck = await validateFetchUrl(parse.data.url);
    if (!urlCheck.ok) {
      return NextResponse.json({ error: urlCheck.error }, { status: 400 });
    }
    const snapshot = await fetchPageSnapshot(parse.data.url);
    if (!snapshot || snapshot.status === 0) {
      return NextResponse.json(
        { error: 'Could not fetch the page. The URL may be invalid, blocked, or timed out.' },
        { status: 422 }
      );
    }
    return NextResponse.json({ ok: true, snapshot });
  } catch (err) {
    return apiError('free-tools/page-analyzer', err);
  }
}
