'use client';

import { useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Copy, Check, RotateCcw, Link, ArrowLeftRight } from 'lucide-react';

export default function URLEncoderPage() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [encodeType, setEncodeType] = useState<'component' | 'full'>('component');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const process = () => {
    setError('');
    if (!input.trim()) {
      setError('Please enter some text.');
      return;
    }

    try {
      if (mode === 'encode') {
        const encoded = encodeType === 'component'
          ? encodeURIComponent(input)
          : encodeURI(input);
        setOutput(encoded);
      } else {
        try {
          const decoded = decodeURIComponent(input);
          setOutput(decoded);
        } catch {
          const decoded = decodeURI(input);
          setOutput(decoded);
        }
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Failed to process';
      setError(`Error: ${msg}`);
    }
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const swap = () => {
    setOutput('');
    setInput(output);
    setMode(mode === 'encode' ? 'decode' : 'encode');
  };

  const clear = () => {
    setInput('');
    setOutput('');
    setError('');
  };

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="flex rounded-lg border border-border overflow-hidden">
              <button
                onClick={() => setMode('encode')}
                className={`px-4 py-2 text-sm font-medium transition-colors ${mode === 'encode' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                Encode
              </button>
              <button
                onClick={() => setMode('decode')}
                className={`px-4 py-2 text-sm font-medium transition-colors ${mode === 'decode' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                Decode
              </button>
            </div>

            {mode === 'encode' && (
              <div className="flex rounded-lg border border-border overflow-hidden">
                <button
                  onClick={() => setEncodeType('component')}
                  className={`px-4 py-2 text-sm transition-colors ${encodeType === 'component' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  Component
                </button>
                <button
                  onClick={() => setEncodeType('full')}
                  className={`px-4 py-2 text-sm transition-colors ${encodeType === 'full' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  Full URI
                </button>
              </div>
            )}
          </div>

          <label className="text-sm font-medium text-foreground">{mode === 'encode' ? 'Input Text' : 'Encoded URL'}</label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={mode === 'encode' ? 'Enter text or URL to encode...' : 'Enter encoded URL to decode...'}
            rows={6}
            className="mt-2 w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-y"
          />

          <div className="flex flex-wrap gap-3 mt-4">
            <button onClick={process} className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
              {mode === 'encode' ? 'Encode' : 'Decode'}
            </button>
            <button onClick={swap} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeftRight className="w-4 h-4" /> Swap
            </button>
            <button onClick={clear} className="px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              Clear
            </button>
          </div>

          {error && <p className="text-sm text-red-500 mt-3">{error}</p>}
        </div>

        {output && (
          <div className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                <Link className="w-4 h-4" /> Output
              </h3>
              <button onClick={copyToClipboard} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">{output}</pre>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
