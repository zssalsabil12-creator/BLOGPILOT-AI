﻿import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { createStripePortalSession, isStripeConfigured } from '@/lib/stripe';
import { cancelSubscription } from '@/lib/billing';
import { apiError } from '@/lib/utils';

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    if (isStripeConfigured()) {
      const sub = await prisma.subscription.findUnique({ where: { userId } });
      if (sub?.stripeCustomerId) {
        const url = await createStripePortalSession(sub.stripeCustomerId);
        if (url) {
          return NextResponse.json({ ok: true, data: { url, demo: false } });
        }
      }
    }

    const result = await cancelSubscription(userId);
    return NextResponse.json({ ok: true, data: { url: null, demo: true, ...result } });
  } catch (error: any) {
    console.error('Stripe portal error:', error);
    return apiError('stripe/portal', error);
  }
}