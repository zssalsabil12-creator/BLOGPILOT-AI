'use client';

import { useState, useCallback } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Copy, Check, RotateCcw, Braces, ArrowDownToLine, ArrowUpFromLine, ShieldCheck, Trash2 } from 'lucide-react';

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function syntaxHighlight(json: string): string {
  return json.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)/g,
    (match) => {
      let cls = 'text-blue-500';
      if (/^"/.test(match)) {
        if (/:$/.test(match)) {
          cls = 'text-purple-500';
        } else {
          cls = 'text-green-500';
        }
      } else if (/true|false/.test(match)) {
        cls = 'text-orange-500';
      } else if (/null/.test(match)) {
        cls = 'text-red-500';
      }
      return `<span class="${cls}">${escapeHtml(match)}</span>`;
    }
  );
}

function getStats(obj: unknown): { keys: number; depth: number; strings: number; numbers: number; booleans: number; nulls: number } {
  const stats = { keys: 0, depth: 0, strings: 0, numbers: 0, booleans: 0, nulls: 0 };
  function walk(val: unknown, depth: number) {
    if (depth > stats.depth) stats.depth = depth;
    if (val === null) { stats.nulls++; return; }
    if (typeof val === 'boolean') { stats.booleans++; return; }
    if (typeof val === 'number') { stats.numbers++; return; }
    if (typeof val === 'string') { stats.strings++; return; }
    if (Array.isArray(val)) {
      val.forEach((item) => walk(item, depth + 1));
    } else if (typeof val === 'object') {
      const entries = Object.entries(val as Record<string, unknown>);
      stats.keys += entries.length;
      entries.forEach(([, v]) => walk(v, depth + 1));
    }
  }
  walk(obj, 0);
  return stats;
}

export default function JSONFormatterPage() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [highlighted, setHighlighted] = useState('');
  const [error, setError] = useState('');
  const [indent, setIndent] = useState(2);
  const [copied, setCopied] = useState(false);
  const [stats, setStats] = useState<{ keys: number; depth: number; strings: number; numbers: number; booleans: number; nulls: number } | null>(null);

  const parseInput = useCallback(() => {
    if (!input.trim()) {
      setError('Please enter some JSON.');
      return null;
    }
    try {
      const parsed = JSON.parse(input);
      setError('');
      return parsed;
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Invalid JSON';
      const match = msg.match(/position\s+(\d+)/i);
      if (match) {
        const pos = parseInt(match[1]);
        const before = input.substring(0, pos);
        const line = (before.match(/\n/g) || []).length + 1;
        const lastNewline = before.lastIndexOf('\n');
        const col = pos - lastNewline;
        setError(`Invalid JSON at line ${line}, column ${col}: ${msg}`);
      } else {
        setError(`Invalid JSON: ${msg}`);
      }
      return null;
    }
  }, [input]);

  const format = () => {
    const parsed = parseInput();
    if (parsed === null) return;
    const formatted = JSON.stringify(parsed, null, indent);
    setOutput(formatted);
    setHighlighted(syntaxHighlight(formatted));
    setStats(getStats(parsed));
  };

  const minify = () => {
    const parsed = parseInput();
    if (parsed === null) return;
    const minified = JSON.stringify(parsed);
    setOutput(minified);
    setHighlighted(syntaxHighlight(minified));
    setStats(getStats(parsed));
  };

  const validate = () => {
    parseInput();
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clear = () => {
    setInput('');
    setOutput('');
    setHighlighted('');
    setError('');
    setStats(null);
  };

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <label className="text-sm font-medium text-foreground">Input JSON</label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder='{"key": "value", "numbers": [1, 2, 3]}'
            rows={12}
            className="mt-2 w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-y"
          />

          <div className="flex flex-wrap items-center gap-3 mt-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">Indent:</span>
              <div className="flex rounded-lg border border-border overflow-hidden">
                <button onClick={() => setIndent(2)} className={`px-3 py-1 text-xs transition-colors ${indent === 2 ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>2</button>
                <button onClick={() => setIndent(4)} className={`px-3 py-1 text-xs transition-colors ${indent === 4 ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>4</button>
              </div>
            </div>
            <button onClick={format} className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
              <ArrowDownToLine className="w-3.5 h-3.5" /> Format
            </button>
            <button onClick={minify} className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
              <ArrowUpFromLine className="w-3.5 h-3.5" /> Minify
            </button>
            <button onClick={validate} className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
              <ShieldCheck className="w-3.5 h-3.5" /> Validate
            </button>
            <button onClick={clear} className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-muted-foreground text-sm hover:text-foreground transition-colors">
              <Trash2 className="w-3.5 h-3.5" /> Clear
            </button>
            <button onClick={() => { setInput(JSON.stringify({ example: true, array: [1, 2, 3], nested: { a: "hello", b: null } }, null, 2)); }} className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-muted-foreground text-sm hover:text-foreground transition-colors">
              <Braces className="w-3.5 h-3.5" /> Load Example
            </button>
          </div>

          {error && (
            <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30">
              <p className="text-sm text-red-500 font-mono">{error}</p>
            </div>
          )}
        </div>

        {output && (
          <div className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                <Braces className="w-4 h-4" /> Output
              </h3>
              <button onClick={copyToClipboard} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre
              className="p-4 rounded-xl bg-muted/50 text-sm font-mono overflow-x-auto whitespace-pre-wrap break-all"
              dangerouslySetInnerHTML={{ __html: highlighted }}
            />
          </div>
        )}

        {stats && (
          <div className="rounded-2xl border border-border bg-card/50 p-6">
            <h3 className="text-sm font-medium text-foreground mb-3">Statistics</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
              {[
                { label: 'Keys', value: stats.keys },
                { label: 'Depth', value: stats.depth },
                { label: 'Strings', value: stats.strings },
                { label: 'Numbers', value: stats.numbers },
                { label: 'Booleans', value: stats.booleans },
                { label: 'Nulls', value: stats.nulls },
              ].map((s) => (
                <div key={s.label} className="rounded-xl border border-border bg-muted/50 p-3 text-center">
                  <p className="text-lg font-bold text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
