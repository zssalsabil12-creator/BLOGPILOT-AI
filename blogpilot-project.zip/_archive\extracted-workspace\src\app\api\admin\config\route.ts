import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'zenkhriselsabil@gmail.com'

/**
 * GET /api/admin/config
 *
 * Returns admin-only configuration data.
 * Only accessible to the admin user (matched by email).
 *
 * Response:
 *   200 {
 *     isAdmin: true,
 *     geminiConfigured: true,
 *     geminiKeySource: 'embedded' | 'env',
 *   }
 *   403 if not admin
 */
export async function GET(request: Request) {
  try {
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    // Check if this user is the admin
    const isAdmin = user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase()

    if (!isAdmin) {
      return NextResponse.json(
        { error: 'Access denied', code: 'forbidden' },
        { status: 403 }
      )
    }

    // Determine key source
    const envKey = process.env.GEMINI_API_KEY
    const keySource = (envKey && envKey !== 'your-gemini-api-key-here')
      ? 'env'
      : 'embedded'

    return NextResponse.json({
      isAdmin: true,
      geminiConfigured: true,
      geminiKeySource: keySource,
      // Admin can see the masked key (first 8 chars) for verification
      geminiKeyPreview: keySource === 'env'
        ? envKey!.slice(0, 12) + '••••••••'
        : 'embedded-key-••••••••',
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json(
        { error: e.message, code: 'auth' },
        { status: e.statusCode }
      )
    }
    return handleApiError(e, 'admin/config')
  }
}
