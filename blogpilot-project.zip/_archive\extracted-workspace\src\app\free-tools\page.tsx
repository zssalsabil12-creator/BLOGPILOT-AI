import { Metadata } from 'next';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Search,
  Zap,
  Globe,
  BarChart3,
  ArrowRight,
  Check,
  FileText,
  Link2,
  Shield,
  Clock,
  TrendingUp,
  Target,
} from 'lucide-react';

export const metadata: Metadata = {
  title: 'Free SEO Tools — BlogPilot AI',
  description: 'Free SEO content research tools: keyword analysis, competitor insights, content gap analysis, and more.',
};

const tools = [
  {
    icon: Search,
    title: 'Content Opportunity Analyzer',
    description: 'Enter a keyword, article URL, or website to discover what top search results are missing and where you can publish a more competitive article.',
    href: '/free-tools/content-opportunity-analyzer',
    cta: 'Try the Analyzer',
  },
  {
    icon: Target,
    title: 'Keyword Research',
    description: 'Understand what users search for, why they search, and what content is required to rank — then act on those insights instantly.',
    href: '/free-tools/content-opportunity-analyzer/keyword-research',
    cta: 'Explore Keyword Research',
  },
  {
    icon: BarChart3,
    title: 'Competitor Analysis',
    description: 'Dissect top-ranking pages to learn what they do well and, more importantly, what they miss. Automate the process and build superior content.',
    href: '/free-tools/content-opportunity-analyzer/competitor-analysis',
    cta: 'Analyze Competitors',
  },
  {
    icon: TrendingUp,
    title: 'Beat the Top 10',
    description: 'Compare content depth, structure, and unanswered questions across leading results to get a prioritized list of improvements.',
    href: '/free-tools/content-opportunity-analyzer/beat-top-10',
    cta: 'See How It Works',
  },
];

const stats = [
  { label: 'Analyses Run', value: '2.4M+' },
  { label: 'Active Users', value: '12K+' },
  { label: 'Avg. SEO Score', value: '92/100' },
  { label: 'Content Gaps Found', value: '890K+' },
];

const steps = [
  {
    step: '01',
    icon: Search,
    title: 'Enter a keyword or URL',
    description: 'Paste a target keyword, article URL, or website to start the analysis.',
  },
  {
    step: '02',
    icon: BarChart3,
    title: 'Analyze top results',
    description: 'We fetch the top 10 ranking pages and extract headings, word counts, FAQs, and content gaps.',
  },
  {
    step: '03',
    icon: FileText,
    title: 'Build a better article',
    description: 'Use the insights to craft a more comprehensive article with BlogPilot AI.',
  },
];

export default function FreeToolsPage() {
  return (
    <div className="min-h-screen">
      <main className="mx-auto max-w-7xl px-4 py-12">
        {/* Hero */}
        <section className="mx-auto max-w-3xl text-center">
          <Badge variant="secondary" className="mb-4 px-3 py-1 text-xs font-medium">
            <Zap className="mr-1 h-3 w-3" />
            Free SEO Growth Toolkit
          </Badge>
          <h1 className="text-4xl font-semibold tracking-tight text-white sm:text-5xl">
            Free tools to research, analyze, and outrank.
          </h1>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Launch keyword research, content gap analysis, and competitor insights instantly — then use BlogPilot AI to write the article that outranks them.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Button size="lg" asChild className="w-full sm:w-auto px-8">
              <Link href="/free-tools/content-opportunity-analyzer">
                Try the Analyzer
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild className="w-full sm:w-auto px-8">
              <Link href="/dashboard/generate">Start Article Builder</Link>
            </Button>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">
            No credit card required · Free to use · No signup needed for basic analysis
          </p>
        </section>

        {/* Stats */}
        <section className="mt-20 border-y border-border/40 bg-muted/50">
          <div className="mx-auto max-w-5xl px-4 py-10">
            <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="text-2xl font-bold md:text-3xl">{stat.value}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Tools Grid */}
        <section className="mt-20">
          <div className="mx-auto max-w-2xl text-center">
            <Badge variant="secondary" className="mb-3 px-3 py-1 text-xs font-medium">
              Tools
            </Badge>
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
              Everything you need to research content.
            </h2>
            <p className="mt-4 text-muted-foreground">
              From keyword research to competitor analysis, BlogPilot AI handles every step of the content research lifecycle.
            </p>
          </div>
          <div className="mt-16 grid gap-6 md:grid-cols-2">
            {tools.map((tool) => (
              <Card key={tool.title} className="h-full border-border/50 transition-colors hover:border-border">
                <CardHeader>
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <tool.icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg mt-3">{tool.title}</CardTitle>
                  <CardDescription>{tool.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" asChild className="w-full">
                    <Link href={tool.href}>
                      {tool.cta}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* How It Works */}
        <section className="mt-20 bg-muted/50 border-y border-border/40">
          <div className="mx-auto max-w-5xl px-4 py-20">
            <div className="mx-auto max-w-2xl text-center">
              <Badge variant="secondary" className="mb-3 px-3 py-1 text-xs font-medium">
                How It Works
              </Badge>
              <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
                Three Simple Steps
              </h2>
            </div>
            <div className="mt-16 grid gap-8 md:grid-cols-3">
              {steps.map((item) => (
                <div key={item.step} className="text-center">
                  <div className="relative mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 border-2 border-primary/20">
                    <item.icon className="h-7 w-7 text-primary" />
                    <span className="absolute -top-2 -right-2 flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold">{item.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="mt-20">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">
              Ready to build better content?
            </h2>
            <p className="mt-4 text-muted-foreground text-lg">
              Start with the free analyzer, then use BlogPilot AI to generate the article that outranks the competition.
            </p>
            <div className="mt-8">
              <Button size="lg" asChild className="px-8">
                <Link href="/free-tools/content-opportunity-analyzer">
                  Open the Analyzer
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
