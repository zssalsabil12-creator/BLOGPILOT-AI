'use client';

import React, { useCallback, useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Link2,
  Loader2,
  AlertTriangle,
  Check,
  RotateCcw,
  ExternalLink,
  Copy,
  Plus,
  Search,
  Target,
} from 'lucide-react';

interface LinkSuggestion {
  link: {
    id: string;
    url: string;
    title?: string;
    description?: string;
    category?: string;
    linkType?: string;
    affiliate?: boolean;
    targetKeyword?: string;
  };
  reason: string;
  suggestedAnchor: string;
  suggestedPlacement: string | null;
  monetizationPotential: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
}

interface FinderResult {
  suggestions: LinkSuggestion[];
  detectedTopics: string[];
  searchIntent: string;
  totalLinksInLibrary: number;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  }, [text]);
  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1 rounded-lg border border-border bg-muted/50 px-2 py-1 text-xs text-muted-foreground transition hover:bg-muted hover:text-foreground"
      aria-label="Copy anchor text"
    >
      {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
    </button>
  );
}

function SuggestionCard({ suggestion, index }: { suggestion: LinkSuggestion; index: number }) {
  const potColor =
    suggestion.monetizationPotential === 'HIGH' ? 'text-emerald-400 bg-emerald-400/10' :
    suggestion.monetizationPotential === 'MEDIUM' ? 'text-amber-400 bg-amber-400/10' :
    suggestion.monetizationPotential === 'LOW' ? 'text-slate-400 bg-slate-400/10' : '';

  return (
    <div className="rounded-2xl border border-border bg-card/30 p-5 transition hover:border-primary/20">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-300">
              {index + 1}
            </span>
            <a
              href={suggestion.link.url}
              target="_blank"
              rel="noreferrer"
              className="font-medium text-foreground underline-offset-2 hover:underline line-clamp-1"
            >
              {suggestion.link.title || suggestion.link.url}
            </a>
          </div>
          <p className="mt-1 ml-8 text-sm text-muted-foreground">{suggestion.reason}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {suggestion.monetizationPotential !== 'NONE' && (
            <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${potColor}`}>
              {suggestion.monetizationPotential}
            </span>
          )}
          {suggestion.link.linkType && (
            <span className="rounded-full bg-muted/50 px-2.5 py-0.5 text-xs text-muted-foreground">
              {suggestion.link.linkType}
            </span>
          )}
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-border bg-card/30 p-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground">Suggested Anchor Text</p>
            <CopyButton text={suggestion.suggestedAnchor} />
          </div>
          <p className="mt-1.5 text-sm font-medium text-foreground">&ldquo;{suggestion.suggestedAnchor}&rdquo;</p>
        </div>
        <div className="rounded-xl border border-border bg-card/30 p-3">
          <p className="text-xs font-medium text-muted-foreground">Suggested Placement</p>
          <p className="mt-1.5 text-sm font-medium text-foreground capitalize">
            {suggestion.suggestedPlacement?.replace(/-/g, ' ') || 'In-body'}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function InternalLinkFinderPage() {
  const [text, setText] = useState('');
  const [keywords, setKeywords] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<FinderResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setResult(null);

    if (!text.trim() || text.trim().length < 10) {
      setError('Enter at least 10 characters of article text to analyze.');
      return;
    }

    const keywordArray = keywords
      .split(',')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/internal-link-finder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text.trim(), keywords: keywordArray.length > 0 ? keywordArray : undefined }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Failed to find link opportunities.');
        return;
      }
      setResult(data.results);
    } catch (err: any) {
      setError(err?.message || 'Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setText('');
    setKeywords('');
    setResult(null);
    setError(null);
  }

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Internal Link <span className="text-gradient">Opportunity Finder</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Paste your article content and target keywords. Get internal linking suggestions from your Link Library
            with anchor text, placement, and relevance scores.
          </p>
        </section>

        {/* Info Card */}
        <section className="rounded-2xl border border-cyan-400/20 bg-cyan-400/5 p-5">
          <div className="flex items-start gap-3">
            <Link2 className="mt-0.5 h-5 w-5 shrink-0 text-cyan-300" />
            <div>
              <p className="text-sm font-medium text-foreground">How it works</p>
              <p className="mt-1 text-sm text-muted-foreground">
                This tool matches your article content against links in your{' '}
                <a href="/dashboard/link-library" className="underline text-cyan-400 hover:text-cyan-300">Link Library</a>.
                Add links with target keywords and descriptions for better recommendations.
                {` `}The more links you have, the more opportunities we can find.
              </p>
            </div>
          </div>
        </section>

        {/* Input Form */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="article-text" className="text-sm font-medium text-foreground">
                Article Content
              </label>
              <textarea
                id="article-text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste your article text, draft, or outline here. The tool will analyze it and find relevant links from your Link Library..."
                rows={8}
                className="mt-2 w-full rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30 resize-y"
              />
              <p className="mt-1 text-xs text-muted-foreground">{text.length.toLocaleString()} characters</p>
            </div>
            <div>
              <label htmlFor="target-keywords" className="text-sm font-medium text-foreground">
                Target Keywords <span className="text-muted-foreground">(optional)</span>
              </label>
              <input
                id="target-keywords"
                type="text"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                placeholder="e.g. best laptops, laptop buying guide, student laptops"
                className="mt-2 w-full rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
              />
              <p className="mt-1 text-xs text-muted-foreground">Comma-separated. Helps find more relevant link matches.</p>
            </div>
            <div className="flex items-center justify-between">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                {loading ? 'Finding Opportunities…' : 'Find Link Opportunities'}
              </button>
              {result && (
                <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" />
                  New search
                </button>
              )}
            </div>
          </form>

          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </section>

        {/* Loading */}
        {loading && !result && (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="shimmer h-32 rounded-2xl border border-border bg-card/50" />
            ))}
          </div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* Summary */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="rounded-xl border border-border bg-card/30 p-4 text-center">
                  <p className="text-2xl font-bold text-cyan-300">{result.suggestions.length}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Link Opportunities</p>
                </div>
                <div className="rounded-xl border border-border bg-card/30 p-4 text-center">
                  <p className="text-2xl font-bold text-violet-300">{result.detectedTopics.length}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Topics Detected</p>
                </div>
                <div className="rounded-xl border border-border bg-card/30 p-4 text-center">
                  <p className="text-2xl font-bold text-emerald-300 capitalize">{result.searchIntent}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Search Intent</p>
                </div>
              </div>
            </section>

            {/* Detected Topics */}
            {result.detectedTopics.length > 0 && (
              <section className="rounded-2xl border border-border bg-card/50 p-5">
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Detected Topics</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {result.detectedTopics.map((topic, i) => (
                    <span key={i} className="rounded-full bg-muted/50 px-3 py-1 text-sm text-muted-foreground">
                      {topic}
                    </span>
                  ))}
                </div>
              </section>
            )}

            {/* Suggestions */}
            {result.suggestions.length > 0 ? (
              <section>
                <h2 className="text-lg font-semibold text-foreground">Recommended Internal Links</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Links matched from your Link Library, ranked by relevance and monetization potential.
                </p>
                <div className="mt-4 space-y-4">
                  {result.suggestions.map((suggestion, i) => (
                    <SuggestionCard key={suggestion.link.id} suggestion={suggestion} index={i} />
                  ))}
                </div>
              </section>
            ) : (
              <section className="rounded-2xl border border-border bg-card/50 p-8 text-center">
                <Link2 className="mx-auto h-10 w-10 text-muted-foreground/50" />
                <h3 className="mt-4 text-lg font-semibold text-foreground">No link opportunities found</h3>
                <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
                  This could mean your Link Library doesn't have enough links matching this content,
                  or the links don't have target keywords set. Try adding more links to your library.
                </p>
                <a
                  href="/dashboard/link-library"
                  className="mt-4 inline-flex items-center gap-2 rounded-xl bg-muted/50 px-5 py-2.5 text-sm font-medium text-foreground transition hover:bg-muted"
                >
                  <Plus className="h-4 w-4" />
                  Open Link Library
                </a>
              </section>
            )}

            {/* Next Steps */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <p className="text-xs font-medium uppercase tracking-wider text-cyan-400">Next Steps</p>
              <div className="mt-3 space-y-2">
                <a href="/free-tools/content-opportunity-analyzer" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Run a full Content Opportunity Analysis for this topic
                </a>
                <a href="/free-tools/seo-title-analyzer" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Analyze the SEO title & meta description
                </a>
                <a href="/free-tools/heading-structure-analyzer" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Check the heading structure
                </a>
                <a href="/dashboard/generate" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Generate the full article with BlogPilot AI
                </a>
              </div>
            </section>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
