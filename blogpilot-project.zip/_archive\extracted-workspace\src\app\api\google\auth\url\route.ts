import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { generateAuthUrl, getGoogleClientId, isGoogleOAuthConfigured } from '@/lib/google-oauth'
import { db } from '@/lib/db'
import { randomUUID } from 'crypto'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/google/auth/url
 *
 * Generates a Google OAuth 2.0 authorization URL for the user to visit.
 *
 * Body (optional):
 *   { scopes?: string[] }
 *
 * Response (live mode):
 *   200 { url: string, state: string }
 *
 * Response (demo mode):
 *   200 { url: null, demo: true, message }
 *
 * The `state` parameter is a UUID stored in-memory (and could be persisted
 * to the DB) for CSRF protection. The /api/google/auth/callback endpoint
 * verifies this state before exchanging the code.
 *
 * Key: access_type=offline ensures Google returns a refresh token.
 */
export async function POST(request: Request) {
  try {
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => ({}))
    const scopes = Array.isArray(raw.scopes) ? raw.scopes : undefined

    // ─── Demo mode ──────────────────────────────────────────────────────
    if (!isGoogleOAuthConfigured()) {
      return NextResponse.json({
        url: null,
        demo: true,
        message: 'Google OAuth not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env to enable Google Account connections.',
      })
    }

    // ─── Generate state for CSRF protection ─────────────────────────────
    // In production, persist the state to the DB with an expiry and
    // verify it in the callback. For now, we generate a UUID.
    const state = randomUUID()

    // ─── Generate auth URL ─────────────────────────────────────────────
    const url = generateAuthUrl({ state, scopes })

    if (!url) {
      return NextResponse.json(
        { error: 'Failed to generate Google OAuth URL', code: 'not_configured' },
        { status: 503 }
      )
    }

    return NextResponse.json({ url, state })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'google/auth/url')
  }
}
