﻿export function env(name: string, fallback = ''): string {
  const value = process.env[name];
  return value && value.trim() ? value.trim() : fallback;
}

export function envBool(name: string, fallback = false): boolean {
  const value = env(name);
  if (!value) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(value.toLowerCase());
}

export const APP_URL = env('APP_URL', 'http://localhost:3000');
export const isProduction = process.env.NODE_ENV === 'production';