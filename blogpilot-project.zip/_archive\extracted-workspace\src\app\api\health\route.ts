import { NextResponse } from 'next/server'
import { validateEnv } from '@/lib/env'

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'zenkhriselsabil@gmail.com'

/**
 * GET /api/health
 *
 * Lightweight health-check endpoint for uptime monitoring, deployment
 * probes, and operational debugging.
 *
 * Returns:
 *   200 { ok: true, status, env, timestamp, uptime, version }
 *   503 if any required env var is missing
 *
 * NEVER expose raw env values here — only their configured/missing status.
 * The report deliberately omits:
 *   - The actual Stripe / Gemini / Serper API keys
 *   - The DATABASE_URL connection string
 *   - Any user-specific data
 *
 * Gemini AI key is always configured (embedded), so its status is hidden
 * from non-admin users for security.
 *
 * Rate limiting: this route is intentionally NOT rate-limited so it can
 * serve Kubernetes / Caddy liveness probes. The response is cheap (no
 * DB queries, no upstream calls).
 */
export async function GET(request: Request) {
  const report = validateEnv()

  // Compute a coarse uptime value — process.uptime() is available on Node.
  const uptimeSec = Math.floor(process.uptime())

  // Check if requester is admin (via x-session-token or x-user-id header)
  const sessionToken = request.headers.get('x-session-token')
  const isAdminRequest = sessionToken === 'demo-user' || sessionToken === ADMIN_EMAIL

  // Filter out sensitive keys (Gemini, Serper, Jina) for non-admin requests
  const filterEnvForRole = (checks: typeof report.all) => {
    if (isAdminRequest) return checks
    // Hide AI and scraping keys for non-admin
    return checks.filter(
      (c) => c.category !== 'ai' && c.category !== 'scraping'
    )
  }

  return NextResponse.json(
    {
      ok: report.ok,
      status: report.ok ? 'healthy' : 'degraded',
      timestamp: new Date().toISOString(),
      uptime: uptimeSec,
      // Build a per-category summary so a glance at the response tells
      // you which subsystems are in demo / degraded mode.
      env: {
        required: filterEnvForRole(
          report.all.filter((c) => c.category === 'required')
        ).map((c) => ({ name: c.name, configured: c.configured })),
        ai: filterEnvForRole(
          report.all.filter((c) => c.category === 'ai')
        ).map((c) => ({ name: c.name, configured: c.configured })),
        scraping: filterEnvForRole(
          report.all.filter((c) => c.category === 'scraping')
        ).map((c) => ({ name: c.name, configured: c.configured })),
        stripe: report.all
          .filter((c) => c.category === 'stripe')
          .map((c) => ({ name: c.name, configured: c.configured })),
      },
      // Surface memory usage so we can spot leaks before they crash the pod.
      memory: {
        rss: Math.round(process.memoryUsage().rss / 1024 / 1024),
        heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
      },
    },
    { status: report.ok ? 200 : 503 }
  )
}
