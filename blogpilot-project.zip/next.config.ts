import type { NextConfig } from "next";

/**
 * Production-optimized Next.js 16 configuration for BlogPilot AI.
 *
 * - `output: "standalone"` produces a self-contained `.next/standalone/`
 *   bundle that can be deployed to any Node host (Vercel, Docker, fly.io,
 *   Railway, a plain VPS) without reinstalling node_modules.
 * - TypeScript build errors are NOT ignored in production. The previous
 *   `ignoreBuildErrors: true` was a development shortcut; removing it
 *   forces type-safety at build time so broken code cannot ship.
 * - ESLint runs during build (`eslint duringBuild`) but does not block
 *   builds (`ignoreDuringBuilds: false`); a failing lint step fails the
 *   Vercel deploy, which is what we want.
 * - Image optimization uses Sharp (already a dependency) and allows
 *   remote images from common CMS / CDN origins used by the app.
 * - `poweredByHeader: false` removes the `X-Powered-By: Next.js` header
 *   for minor fingerprinting reduction.
 * - `reactStrictMode: true` catches unsafe lifecycles / side-effects in
 *   development. (Was `false` previously; flipping back for prod quality.)
 * - `compress: true` enables gzip on the Node server (Vercel already
 *   handles this at the edge, but it's a no-op there and helps when
 *   self-hosting).
 * - `experimental.optimizePackageImports` enables barrel-file tree
 *   shaking for the heaviest UI libs we use, trimming client bundle size.
 * - `experimental.serverMinification` and `serverExternalPackages`
 *   keep large server-only libs (Prisma, Sharp) out of the server bundle.
 */
const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,

  // Type-safety must hold at build time. Never silently ship broken types.
  typescript: {
    ignoreBuildErrors: false,
    tsconfigPath: "./tsconfig.json",
  },

  // NOTE: ESLint is run via `bun run lint` separately — Next.js 16 dropped
  // the `eslint.ignoreDuringBuilds` config option. Run `bun run lint` in
  // your CI step before `bun run build` to keep the codebase honest.

  // Image optimization (Sharp is installed as a dependency).
  images: {
    formats: ["image/avif", "image/webp"],
    minimumCacheTTL: 60 * 60 * 24, // 24h
    remotePatterns: [
      { protocol: "https", hostname: "**.wordpress.com" },
      { protocol: "https", hostname: "**.shopify.com" },
      { protocol: "https", hostname: "**.cdn.wordpress.net" },
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "avatars.githubusercontent.com" },
      { protocol: "https", hostname: "lh3.googleusercontent.com" },
    ],
    dangerouslyAllowSVG: false,
  },

  // Headers: security hardening + caching best practices.
  async headers() {
    // -------------------------------------------------------------------
    // CSP is split across TWO headers:
    //
    // 1. `Content-Security-Policy` (ENFORCED) — every directive that is safe
    //    to block on today. Tailwind ships class-based CSS (compiled sheets
    //    served from /_next/static, no inline styles needed beyond what
    //    Framer Motion / Next.js inject), and fonts, images, frames and
    //    XHR/fetch targets come from a fixed allowlist, so these directives
    //    can be enforced without breaking the app.
    //
    // 2. `Content-Security-Policy-Report-Only` — `script-src` ONLY.
    //    Why script-src CANNOT be safely enforced yet:
    //     - Next.js 16 (App Router + Turbopack) delivers hydration/bootstrap
    //       as INLINE <script> payloads (self.__next_f.push(...)), so any
    //       enforced script-src must contain 'unsafe-inline'.
    //     - 'unsafe-eval' is required by Turbopack/webpack HMR in dev.
    //     - Third-party code (Stripe.js, Google Identity/OAuth, GTM) loads
    //       from non-'self' origins.
    //    An enforced script-src containing 'unsafe-inline' would rubber-stamp
    //    XSS payloads, so it stays in observe-only mode until a nonce- or
    //    hash-based script-src (with 'strict-dynamic') is proven in reports.
    //
    //    FALLBACK WARNING (why `default-src` is NOT in the enforced header):
    //    a directive missing from a policy falls back to `default-src`. If
    //    `default-src 'self'` were enforced while script-src remained
    //    report-only, the enforced default-src would become the EFFECTIVE
    //    script-src and BLOCK every inline hydration script (pages render
    //    but nothing is interactive). The enforced header therefore
    //    enumerates each directive explicitly instead of relying on a
    //    catch-all, and `default-src` lives only in the Report-Only header.
    // -------------------------------------------------------------------
    const enforcedCsp = [
      // Deliberately NO `default-src` here — see FALLBACK WARNING above.
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: blob: https: http:",
      "connect-src 'self' https://api.stripe.com https://m.stripe.network https://www.google-analytics.com https://www.googleapis.com https://oauth2.googleapis.com https://accounts.google.com",
      "frame-src 'self' https://js.stripe.com https://hooks.stripe.com https://accounts.google.com https://www.google.com https://checkout.paypal.com",
      "worker-src 'self' blob:",
      "media-src 'self' blob: data:",
      "manifest-src 'self'",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self' https://accounts.google.com https://www.paypal.com https://www.sandbox.paypal.com",
      "frame-ancestors 'none'",
    ].join("; ");

    // Observe-only: script-src (plus default-src so its fallback coverage of
    // scripts/workers/media keeps being reported). Graduate these into the
    // enforced header once a nonce-based script-src passes reporting.
    const reportOnlyCsp = [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://accounts.google.com https://www.googletagmanager.com https://www.google-analytics.com",
    ].join("; ");

    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
          {
            key: "Strict-Transport-Security",
            value: "max-age=63072000; includeSubDomains; preload",
          },
          { key: "Content-Security-Policy", value: enforcedCsp },
          { key: "Content-Security-Policy-Report-Only", value: reportOnlyCsp },
        ],
      },
      {
        // Static assets get a long, immutable cache.
        source: "/_next/static/(.*)",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
        ],
      },
    ];
  },

  // Keep large server-only libs out of the bundled server.js
  serverExternalPackages: ["@prisma/client", "sharp", "@google/generative-ai"],

  experimental: {
    // Tree-shake barrel files from heavy UI libs.
    optimizePackageImports: [
      "lucide-react",
      "@radix-ui/react-icons",
      "framer-motion",
      "date-fns",
      "recharts",
    ],
    // Minify the standalone server bundle.
    serverMinification: true,
  },

  // Vercel-friendly: tell Next where to find the standalone output.
  // (Vercel auto-detects this, but it's explicit for self-hosting.)
  outputFileTracingRoot: __dirname,
};

export default nextConfig;
