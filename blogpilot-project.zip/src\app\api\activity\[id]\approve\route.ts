import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { logActivity } from '@/lib/agent-governance';
import { applyLinks } from '@/lib/internal-links';
import { computeSeoScore } from '@/lib/seo-score';

/**
 * Executes a previously approved queued action.
 * Only whitelisted action kinds are executable — everything else is rejected
 * so a tampered payload can never escalate into an unsafe operation.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const activity = await prisma.agentActivity.findFirst({
      where: { id, userId, status: 'pending_approval' },
    });
    if (!activity) {
      return NextResponse.json({ ok: false, error: 'Pending action not found' }, { status: 404 });
    }

    const payload = (activity.payload || {}) as any;
    let resultDetail = '';

    if (payload.kind === 'internal-links' && activity.action === 'apply-internal-links') {
      // Snapshot before mutating.
      await import('@/lib/content-versions').then(v =>
        v.snapshotVersion(userId, payload.articleId, `before-approved-links-${activity.executionId.slice(0, 8)}`)
      );
      const applied = await applyLinks(userId, payload.articleId, payload.targets || []);
      resultDetail = `${applied.applied} internal link(s) applied.`;

      const article = await prisma.article.findFirst({
        where: { id: payload.articleId, userId },
        select: { title: true, content: true, excerpt: true, targetKeyword: true },
      });
      if (article) {
        const seo = computeSeoScore(article);
        await prisma.article.update({ where: { id: payload.articleId }, data: { seoScore: seo.score } });
      }
    } else if (payload.kind === 'disable-links' && activity.action === 'disable-broken-affiliate') {
      const ids: string[] = Array.isArray(payload.linkIds) ? payload.linkIds.slice(0, 50) : [];
      // Ownership guard: only links belonging to this user.
      const res = await prisma.link.updateMany({
        where: { id: { in: ids }, userId },
        data: { active: false, safetyStatus: 'UNSAFE', safetyReason: 'Deactivated via approval queue' },
      });
      resultDetail = `${res.count} affiliate link(s) deactivated.`;
    } else {
      await logActivity({
        userId, siteId: activity.siteId, executionId: activity.executionId,
        agent: 'system', action: activity.action,
        status: 'failed', error: 'Unsupported action kind for approval execution',
      });
      return NextResponse.json({ ok: false, error: 'This queued action is no longer executable.' }, { status: 422 });
    }

    await prisma.agentActivity.update({
      where: { id: activity.id },
      data: { status: 'success', afterState: { executedAt: new Date().toISOString(), detail: resultDetail }, decidedAt: new Date() },
    });

    return NextResponse.json({ ok: true, data: { detail: resultDetail } });
  } catch (error: any) {
    console.error('Approve action error:', error);
    try {
      await prisma.agentActivity.updateMany({
        where: { id, userId, status: 'pending_approval' },
        data: { status: 'failed', error: error?.message?.slice(0, 300), decidedAt: new Date() },
      });
    } catch {}
    return NextResponse.json({ ok: false, error: 'Execution failed — nothing was changed.' }, { status: 500 });
  }
}
