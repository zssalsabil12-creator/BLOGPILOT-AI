import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const res = await prisma.agentActivity.updateMany({
      where: { id, userId, status: 'pending_approval' },
      data: { status: 'rejected', decidedAt: new Date() },
    });

    if (res.count === 0) {
      return NextResponse.json({ ok: false, error: 'Pending action not found' }, { status: 404 });
    }

    return NextResponse.json({ ok: true, data: { rejected: true } });
  } catch (error: any) {
    console.error('Reject action error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to reject action' }, { status: 500 });
  }
}
