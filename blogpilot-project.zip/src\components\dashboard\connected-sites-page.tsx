'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Globe, Plus, Wifi, WifiOff, CheckCircle, XCircle, ExternalLink, Settings, Trash2, Loader2, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion, AnimatePresence } from 'framer-motion'

interface Site {
  id: string
  name: string
  url: string
  platform: string
  isActive: boolean
  lastSyncAt: string | null
  hasApiKey: boolean
  username: string | null
  gscProperty?: string | null
  automationLevel?: 'assist' | 'review' | 'autopilot'
}

const platformIcons: Record<string, string> = {
  WordPress: 'W',
  Webhook: '⚡',
  Custom: '⚙',
}

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
}

const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
}

export default function ConnectedSitesPage() {
  const [sites, setSites] = useState<Site[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [testingId, setTestingId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [connectionMessage, setConnectionMessage] = useState<{ ok: boolean; message: string } | null>(null)
  const [newSite, setNewSite] = useState({
    name: '',
    url: '',
    platform: 'WordPress',
    apiKey: '',
    username: '',
  })

  const loadSites = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/sites')
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to load sites')
      setSites(json?.data?.sites || [])
      setError(null)
    } catch (err: any) {
      console.error('Load sites error:', err)
      setError(err?.message || 'Failed to load sites')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadSites()
  }, [loadSites])

  const testConnection = async (id: string) => {
    setTestingId(id)
    setConnectionMessage(null)
    try {
      const res = await fetch(`/api/sites/${id}`, { method: 'POST' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to test connection')
      setConnectionMessage({ ok: json?.data?.ok, message: json?.data?.message || 'Connection tested.' })
      await loadSites()
    } catch (err: any) {
      console.error('Test connection error:', err)
      setConnectionMessage({ ok: false, message: err?.message || 'Failed to test connection' })
    } finally {
      setTestingId(null)
    }
  }

  const deleteSite = async (id: string) => {
    setDeletingId(id)
    try {
      const res = await fetch(`/api/sites/${id}`, { method: 'DELETE' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to delete site')
      setSites(prev => prev.filter(s => s.id !== id))
    } catch (err: any) {
      console.error('Delete site error:', err)
      alert(err?.message || 'Failed to delete site')
    } finally {
      setDeletingId(null)
    }
  }

  const addSite = async () => {
    if (!newSite.name || !newSite.url) return
    setSaving(true)
    setConnectionMessage(null)
    try {
      const res = await fetch('/api/sites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newSite.name,
          url: newSite.url,
          platform: newSite.platform,
          apiKey: newSite.apiKey || undefined,
          username: newSite.username || undefined,
        }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to save site')
      if (json?.data?.connection) {
        setConnectionMessage(json.data.connection)
      }
      setNewSite({ name: '', url: '', platform: 'WordPress', apiKey: '', username: '' })
      setShowForm(false)
      await loadSites()
    } catch (err: any) {
      console.error('Add site error:', err)
      alert(err?.message || 'Failed to save site')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="min-h-screen p-6 md:p-10">
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex items-center justify-between mb-8"
      >
        <div>
          <h1 className="text-2xl font-bold text-foreground">Connected Sites</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your connected websites and publishing settings</p>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="bg-gradient-to-r from-cyan-500 to-violet-500 hover:from-cyan-400 hover:to-violet-400 text-white font-medium px-5 py-2.5 rounded-xl transition-all duration-200"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Site
        </Button>
      </motion.div>

      {connectionMessage && (
        <div className={cn(
          'mb-6 flex items-center gap-3 px-4 py-3 rounded-xl border text-sm',
          connectionMessage.ok
            ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
            : 'bg-red-500/10 border-red-500/20 text-red-400'
        )}>
          {connectionMessage.ok
            ? <CheckCircle className="w-4 h-4 shrink-0" />
            : <AlertTriangle className="w-4 h-4 shrink-0" />}
          {connectionMessage.message}
        </div>
      )}

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden mb-8"
          >
            <Card className="bg-card/50 border border-border backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-foreground text-lg">Add New Site</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">Site Name</label>
                    <Input
                      placeholder="My Website"
                      value={newSite.name}
                      onChange={e => setNewSite(prev => ({ ...prev, name: e.target.value }))}
                      className="bg-muted/50 border-border text-foreground placeholder:text-muted-foreground focus-visible:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">Site URL</label>
                    <Input
                      placeholder="https://example.com"
                      value={newSite.url}
                      onChange={e => setNewSite(prev => ({ ...prev, url: e.target.value }))}
                      className="bg-muted/50 border-border text-foreground placeholder:text-muted-foreground focus-visible:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">Platform</label>
                    <select
                      value={newSite.platform}
                      onChange={e => setNewSite(prev => ({ ...prev, platform: e.target.value }))}
                      className="w-full h-10 rounded-md border border-border bg-muted/50 px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary appearance-none"
                    >
                      <option value="WordPress" className="bg-background">WordPress</option>
                      <option value="Webhook" className="bg-background">Webhook</option>
                      <option value="Custom" className="bg-background">Custom CMS</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm text-muted-foreground mb-1.5 block">API Key / Application Password</label>
                    <Input
                      type="password"
                      placeholder="Enter API key"
                      value={newSite.apiKey}
                      onChange={e => setNewSite(prev => ({ ...prev, apiKey: e.target.value }))}
                      className="bg-muted/50 border-border text-foreground placeholder:text-muted-foreground focus-visible:ring-primary"
                    />
                  </div>
                  {newSite.platform === 'WordPress' && (
                    <div>
                      <label className="text-sm text-muted-foreground mb-1.5 block">WordPress Username</label>
                      <Input
                        placeholder="admin"
                        value={newSite.username}
                        onChange={e => setNewSite(prev => ({ ...prev, username: e.target.value }))}
                        className="bg-muted/50 border-border text-foreground placeholder:text-muted-foreground focus-visible:ring-primary"
                      />
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-3 pt-2">
                  <Button
                    onClick={addSite}
                    disabled={!newSite.name || !newSite.url || saving}
                    className="bg-gradient-to-r from-cyan-500 to-violet-500 hover:from-cyan-400 hover:to-violet-400 text-white disabled:opacity-40"
                  >
                    {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle className="w-4 h-4 mr-2" />}
                    {saving ? 'Saving...' : 'Save Site'}
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => setShowForm(false)}
                    className="text-muted-foreground hover:text-foreground hover:bg-accent"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
        </div>
      ) : error ? (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-20"
        >
          <Globe className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground mb-4">{error}</p>
          <Button
            onClick={loadSites}
            className="bg-gradient-to-r from-cyan-500 to-violet-500 text-white rounded-xl"
          >
            Retry
          </Button>
        </motion.div>
      ) : (
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid gap-4"
        >
          {sites.map(site => (
            <motion.div key={site.id} variants={item} layout>
              <Card className="bg-card/50 border border-border backdrop-blur-xl hover:border-border transition-all duration-300 group">
                <CardContent className="p-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <div className={cn(
                        'w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold shrink-0',
                        site.platform === 'WordPress' && 'bg-blue-500/15 text-blue-400',
                        site.platform === 'Webhook' && 'bg-amber-500/15 text-amber-400',
                        site.platform === 'Custom' && 'bg-violet-500/15 text-violet-400',
                      )}>
                        {platformIcons[site.platform] || '🌐'}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 mb-0.5">
                          <h3 className="text-foreground font-semibold truncate">{site.name}</h3>
                          <a
                            href={site.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{site.url}</p>
                        <div className="flex items-center gap-3 mt-1.5">
                          <Badge variant="secondary" className="bg-muted/70 text-muted-foreground text-xs border-0">
                            {site.platform}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {site.lastSyncAt
                              ? `Last sync: ${new Date(site.lastSyncAt).toLocaleDateString()}`
                              : site.hasApiKey ? 'Configured' : site.username ? 'Configured' : 'No credentials yet'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 sm:gap-6 shrink-0">
                      {/* Automation level */}
                      <select
                        value={site.automationLevel || 'review'}
                        onChange={async (e) => {
                          const level = e.target.value
                          setSites(prev => prev.map(s => s.id === site.id ? { ...s, automationLevel: level as Site['automationLevel'] } : s))
                          try {
                            await fetch(`/api/sites/${site.id}`, {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ automationLevel: level }),
                            })
                          } catch {
                            setConnectionMessage({ ok: false, message: 'Failed to update automation level' })
                          }
                        }}
                        className="h-8 rounded-lg border border-border bg-muted/40 text-xs text-foreground px-2"
                        title="SEO agent automation level"
                      >
                        <option value="assist">Assist</option>
                        <option value="review">Review</option>
                        <option value="autopilot">Autopilot</option>
                      </select>

                      <div className="flex items-center gap-2">
                        {site.isActive ? (
                          <span className="flex items-center gap-1.5 text-xs text-emerald-400">
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                            Connected
                          </span>
                        ) : (
                          <span className="flex items-center gap-1.5 text-xs text-red-400">
                            <span className="w-2 h-2 rounded-full bg-red-400" />
                            Disconnected
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => testConnection(site.id)}
                          disabled={testingId === site.id}
                           className="w-8 h-8 text-muted-foreground hover:text-cyan-400 hover:bg-cyan-500/10"
                          title="Test connection"
                        >
                          {testingId === site.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : site.isActive ? (
                            <Wifi className="w-4 h-4" />
                          ) : (
                            <WifiOff className="w-4 h-4" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setShowForm(true)}
                           className="w-8 h-8 text-muted-foreground hover:text-foreground hover:bg-accent"
                           title="Edit site"
                         >
                           <Settings className="w-4 h-4" />
                         </Button>
                         <Button
                           variant="ghost"
                           size="icon"
                           onClick={() => deleteSite(site.id)}
                           disabled={deletingId === site.id}
                           className="w-8 h-8 text-muted-foreground hover:text-red-400 hover:bg-red-500/10"
                          title="Delete site"
                        >
                          {deletingId === site.id ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Trash2 className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}

      {!loading && !error && sites.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-20"
        >
          <Globe className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No connected sites yet. Add your first site to get started.</p>
        </motion.div>
      )}
    </div>
  )
}
