/**
 * Airtm payment integration for BlogPilot AI.
 *
 * Airtm is a digital dollar wallet and payment platform popular in
 * Latin America. It supports email-based checkout: the merchant's
 * email address is used as the payment recipient.
 *
 * Architecture:
 *   1. The admin sets ADMIN_AIRTM_EMAIL in the environment — this is the
 *      Airtm account that receives all payments. No email is ever hardcoded
 *      in the application code.
 *   2. When a user selects a plan and picks "Pay with Airtm", the backend
 *      reads ADMIN_AIRTM_EMAIL at runtime and generates a payment URL /
 *      invoice that directs the payment to that account.
 *   3. Airtm confirms payment via a webhook callback to /api/airtm/webhook.
 *
 * Routing of funds:
 *   All payments go directly to the Airtm account specified by
 *   ADMIN_AIRTM_EMAIL. The system reads this variable at runtime —
 *   there is no hardcoded email anywhere in the repository.
 *
 * Environment variables (validated by /src/lib/env.ts):
 *   ADMIN_AIRTM_EMAIL — the admin's Airtm account email address (required for live mode)
 *   AIRTM_API_TOKEN    — optional API token for webhook signature verification
 *
 * Demo mode: when ADMIN_AIRTM_EMAIL is missing or empty, every function
 * returns null / demo-safe values and the route handlers fall back to a
 * simulated checkout flow (mirroring Stripe / PayPal / Payeer demo mode).
 */

import { createHmac, timingSafeEqual as cryptoTimingSafeEqual } from 'crypto'
import { PLAN_CONFIG, type PlanTier } from '@/lib/stripe'

/* -------------------------------------------------------------------------- */
/*                              Configuration                                 */
/* -------------------------------------------------------------------------- */

/** Airtm API base URL. */
const AIRTM_API_BASE = 'https://www.airtm.com/api'

/**
 * Whether Airtm is fully configured for live mode.
 *
 * The primary check is ADMIN_AIRTM_EMAIL — if the admin's email is not set,
 * we cannot generate payment invoices and fall back to demo mode.
 */
export function isAirtmConfigured(): boolean {
  const email = process.env.ADMIN_AIRTM_EMAIL
  return !!email && email.includes('@')
}

/**
 * Get the admin's Airtm email address at runtime.
 *
 * This is the ONLY place the email value is read from the environment.
 * The returned email is used as the payment recipient in all Airtm
 * checkout URLs and invoices.
 *
 * Returns null in demo mode (email not configured).
 */
export function getAirtmEmail(): string | null {
  if (!isAirtmConfigured()) return null
  return process.env.ADMIN_AIRTM_EMAIL!
}

/* -------------------------------------------------------------------------- */
/*                          Payment URL builder                               */
/* -------------------------------------------------------------------------- */

export interface AirtmPaymentUrlParams {
  /** Payment reference / invoice ID (unique per checkout). */
  reference: string
  /** Amount in USD (formatted string, e.g. "19.00"). */
  amount: string
  /** Currency code. */
  currency: string
  /** Human-readable description. */
  description: string
  /** Recipient email — the admin's Airtm account (from ADMIN_AIRTM_EMAIL). */
  recipientEmail: string
  /** URL to redirect to after successful payment. */
  successUrl: string
  /** URL to redirect to after cancelled payment. */
  cancelUrl: string
  /** URL Airtm calls server-to-server after payment confirmation. */
  statusUrl: string
  /** HMAC-SHA256 signature for integrity verification. */
  signature: string
}

/**
 * Build the signed payment parameters for an Airtm checkout.
 *
 * The signature is computed from the reference, amount, and recipient
 * email to prevent tampering with the payment details.
 *
 * Returns null in demo mode (no ADMIN_AIRTM_EMAIL configured).
 */
export function buildAirtmPaymentParams(opts: {
  tier: PlanTier
  userId: string
  reference: string
  successUrl: string
  cancelUrl: string
  statusUrl: string
}): AirtmPaymentUrlParams | null {
  const email = getAirtmEmail()
  if (!email) return null

  const { tier, userId, reference, successUrl, cancelUrl, statusUrl } = opts
  const cfg = PLAN_CONFIG[tier]
  const amount = (cfg.priceUsdCents / 100).toFixed(2)
  const currency = 'USD'
  const description = `BlogPilot AI — ${cfg.label} plan (monthly subscription) — user ${userId}`

  // HMAC-SHA256 signature: prevents tampering with payment details
  const apiToken = process.env.AIRTM_API_TOKEN || 'blogpilot-airtm-fallback-signing-key'
  const signPayload = `${reference}:${amount}:${currency}:${email}:${userId}`
  const signature = createHmac('sha256', apiToken)
    .update(signPayload)
    .digest('hex')

  return {
    reference,
    amount,
    currency,
    description,
    recipientEmail: email,
    successUrl,
    cancelUrl,
    statusUrl,
    signature,
  }
}

/**
 * Build the full Airtm checkout URL.
 *
 * The front-end redirects the user to this URL to complete payment.
 * After the user pays, Airtm redirects back to successUrl / cancelUrl.
 * Airtm also POSTs to statusUrl server-to-server for confirmation.
 *
 * Returns null in demo mode.
 */
export function buildAirtmCheckoutUrl(opts: {
  tier: PlanTier
  userId: string
  reference: string
  successUrl: string
  cancelUrl: string
  statusUrl: string
}): string | null {
  const params = buildAirtmPaymentParams(opts)
  if (!params) return null

  const {
    reference, amount, currency, description,
    recipientEmail, successUrl, cancelUrl, statusUrl, signature,
  } = params

  const query = new URLSearchParams({
    reference,
    amount,
    currency,
    description,
    email: recipientEmail,
    success_url: successUrl,
    cancel_url: cancelUrl,
    status_url: statusUrl,
    signature,
  })

  return `${AIRTM_API_BASE}/checkout?${query.toString()}`
}

/* -------------------------------------------------------------------------- */
/*                          Order ID helpers                                  */
/* -------------------------------------------------------------------------- */

/**
 * Build a unique Airtm reference ID encoding the user id and tier.
 *
 * Format: `<userId>__<tier>__<timestamp>__<random>`
 */
export function buildAirtmReference(userId: string, tier: PlanTier): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `airtm_${userId}__${tier}__${ts}__${rand}`
}

/**
 * Parse an Airtm reference back into { userId, tier }.
 */
export function parseAirtmReference(reference: string): {
  userId: string | null
  tier: PlanTier | null
} {
  // Strip the "airtm_" prefix if present
  const raw = reference.startsWith('airtm_') ? reference.slice(6) : reference
  const parts = raw.split('__')
  if (parts.length < 2) return { userId: null, tier: null }
  return {
    userId: parts[0] || null,
    tier: (parts[1] as PlanTier) || null,
  }
}

/* -------------------------------------------------------------------------- */
/*                       Webhook signature verification                        */
/* -------------------------------------------------------------------------- */

/**
 * Verify the signature on an inbound Airtm webhook callback.
 *
 * Airtm sends the `signature` parameter that we recompute to validate
 * the integrity of the callback payload.
 */
export function verifyAirtmCallback(payload: {
  reference?: string
  amount?: string
  currency?: string
  status?: string
  signature?: string
}): { valid: boolean; reason?: string } {
  const { reference, amount, currency, status, signature } = payload

  if (!reference || !amount || !currency || !status || !signature) {
    return { valid: false, reason: 'Missing required Airtm callback fields' }
  }

  const email = getAirtmEmail()
  if (!email) {
    return { valid: false, reason: 'ADMIN_AIRTM_EMAIL not configured' }
  }

  const apiToken = process.env.AIRTM_API_TOKEN || 'blogpilot-airtm-fallback-signing-key'
  const expectedPayload = `${reference}:${amount}:${currency}:${email}`
  const expectedSignature = createHmac('sha256', apiToken)
    .update(expectedPayload)
    .digest('hex')

  if (!timingSafeEqual(expectedSignature, signature)) {
    return { valid: false, reason: 'Signature mismatch' }
  }

  return { valid: true }
}

/**
 * Constant-time string comparison to prevent timing attacks.
 */
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false
  const bufA = Buffer.from(a, 'utf8')
  const bufB = Buffer.from(b, 'utf8')
  if (bufA.length !== bufB.length) return false
  try {
    return cryptoTimingSafeEqual(bufA, bufB)
  } catch {
    // Fallback: XOR comparison (not fully timing-safe but acceptable)
    let result = 0
    for (let i = 0; i < bufA.length; i++) {
      result |= bufA[i] ^ bufB[i]
    }
    return result === 0
  }
}
