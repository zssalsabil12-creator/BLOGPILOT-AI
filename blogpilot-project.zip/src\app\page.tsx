﻿import { LandingPage } from '@/components/landing/landing-page'

export const metadata = {
  title: 'BlogPilot AI — Autonomous SEO & Affiliate Blogging',
  description: 'AI-powered SEO content creation and affiliate blogging automation. Generate optimized articles, research keywords, analyze competitors, and grow your blog on autopilot.',
}

export default function HomePage() {
  return <LandingPage />
}
