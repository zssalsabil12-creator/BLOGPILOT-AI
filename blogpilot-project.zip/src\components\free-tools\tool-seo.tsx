import { toolStructuredData } from '@/lib/free-tools/tool-page';

/**
 * Server component that injects per-tool structured data (WebApplication +
 * BreadcrumbList JSON-LD). Client tool pages stay untouched.
 */
export function ToolSeo({ slug, children }: { slug: string; children: React.ReactNode }) {
  const graphs = toolStructuredData(slug);
  return (
    <>
      {graphs.map((graph, i) => (
        <script
          key={i}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(graph) }}
        />
      ))}
      {children}
    </>
  );
}
