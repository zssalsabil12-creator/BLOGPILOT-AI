﻿import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { getValidAccessToken, listBloggerBlogs, isGoogleConfigured } from '@/lib/google-oauth';
import prisma from '@/lib/prisma';

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  if (!isGoogleConfigured()) {
    return NextResponse.json({ ok: false, error: 'Google OAuth not configured' }, { status: 501 });
  }

  const token = await prisma.googleToken.findFirst({
    where: { userId, isActive: true },
    orderBy: { createdAt: 'desc' },
  });

  if (!token) {
    return NextResponse.json({
      ok: true,
      data: { connected: false, blogs: [] },
    });
  }

  try {
    const accessToken = await getValidAccessToken(userId);
    if (!accessToken) {
      return NextResponse.json({
        ok: true,
        data: { connected: false, blogs: [] },
      });
    }

    const blogs = await listBloggerBlogs(accessToken);
    return NextResponse.json({
      ok: true,
      data: {
        connected: true,
        email: token.googleEmail,
        blogs,
      },
    });
  } catch (err: any) {
    console.error('Google tokens error:', err);
    return NextResponse.json({
      ok: true,
      data: { connected: true, email: token.googleEmail, blogs: [] },
    });
  }
}

export async function DELETE(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  await prisma.googleToken.updateMany({
    where: { userId },
    data: { isActive: false, status: 'disconnected' },
  });

  return NextResponse.json({ ok: true });
}
