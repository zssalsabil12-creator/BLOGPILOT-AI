/**
 * Google Search Console API client (raw fetch — no SDK).
 *
 * Docs: https://developers.google.com/webmaster-tools/search-console-api-original
 * All data comes from the real Search Analytics API. No caching of metrics
 * beyond short-lived token handling; results are always live queries.
 */

import prisma from '@/lib/prisma';
import { getValidAccessToken } from '@/lib/google-oauth';

const GSC_API = 'https://www.googleapis.com/webmasters/v3';

export interface GscSite {
  siteUrl: string;
  permissionLevel: string;
}

export interface GscAnalyticsRow {
  keys: string[];
  clicks: number;
  impressions: number;
  ctr: number;
  position: number;
}

export interface SearchAnalyticsQuery {
  startDate: string; // YYYY-MM-DD
  endDate: string;
  dimensions: Array<'query' | 'page' | 'country' | 'device'>;
  dimensionFilterGroups?: any;
  rowLimit?: number;
  startRow?: number;
  dataState?: 'all' | 'final';
}

export type GscAccess =
  | { ok: true; accessToken: string; googleEmail: string | null }
  | { ok: false; reason: 'not_connected' | 'needs_reconnect' };

/**
 * Resolve a usable Search Console access token for the user.
 * `not_connected` = no Google account linked at all.
 * `needs_reconnect` = linked, but the stored grant predates the Search
 * Console scope (or refresh failed) — user must reconnect.
 */
export async function getGscAccessToken(userId: string): Promise<GscAccess> {
  const token = await prisma.googleToken.findFirst({
    where: { userId, isActive: true },
    orderBy: { createdAt: 'desc' },
  });

  if (!token) return { ok: false, reason: 'not_connected' };

  const hasScope = (token.services || '').includes('searchconsole') ||
    (token.scope || '').includes('webmasters');
  if (!hasScope) return { ok: false, reason: 'needs_reconnect' };

  const accessToken = await getValidAccessToken(userId);
  if (!accessToken) return { ok: false, reason: 'needs_reconnect' };

  return { ok: true, accessToken, googleEmail: token.googleEmail };
}

export async function listGscSites(accessToken: string): Promise<GscSite[]> {
  const res = await fetch(`${GSC_API}/sites`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (res.status === 403) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'Search Console access denied — reconnect with Search Console permission.');
  }
  if (!res.ok) {
    throw new Error(`Search Console API error (${res.status})`);
  }

  const data = await res.json();
  return (data.siteEntry || [])
    .filter((s: any) => s.permissionLevel && s.permissionLevel !== 'siteUnverifiedUser')
    .map((s: any) => ({ siteUrl: s.siteUrl, permissionLevel: s.permissionLevel }));
}

export async function querySearchAnalytics(
  accessToken: string,
  siteUrl: string,
  query: SearchAnalyticsQuery,
): Promise<GscAnalyticsRow[]> {
  const encodedSite = encodeURIComponent(siteUrl);
  const rows: GscAnalyticsRow[] = [];
  const rowLimit = Math.min(query.rowLimit ?? 1000, 5000);
  let startRow = query.startRow ?? 0;

  // Paginate up to 3 pages (15k rows max) to stay cost-aware.
  for (let page = 0; page < 3; page++) {
    const res = await fetch(`${GSC_API}/sites/${encodedSite}/searchAnalytics/query`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        startDate: query.startDate,
        endDate: query.endDate,
        dimensions: query.dimensions,
        dimensionFilterGroups: query.dimensionFilterGroups,
        dataState: query.dataState || 'final',
        rowLimit,
        startRow,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || `Search Analytics query failed (${res.status})`);
    }

    const data = await res.json();
    const pageRows: GscAnalyticsRow[] = data.rows || [];
    rows.push(...pageRows);

    if (pageRows.length < rowLimit) break;
    startRow += rowLimit;
  }

  return rows;
}

/** Date helpers for period comparison (UTC). */
export function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export interface PeriodRange {
  current: { startDate: string; endDate: string };
  previous: { startDate: string; endDate: string };
}

export function buildPeriodRange(days: number): PeriodRange {
  const end = new Date();
  // GSC data has a ~2-3 day freshness lag; end yesterday.
  end.setUTCDate(end.getUTCDate() - 1);
  const currentStart = new Date(end);
  currentStart.setUTCDate(currentStart.getUTCDate() - (days - 1));
  const prevEnd = new Date(currentStart);
  prevEnd.setUTCDate(prevEnd.getUTCDate() - 1);
  const prevStart = new Date(prevEnd);
  prevStart.setUTCDate(prevStart.getUTCDate() - (days - 1));

  return {
    current: { startDate: isoDate(currentStart), endDate: isoDate(end) },
    previous: { startDate: isoDate(prevStart), endDate: isoDate(prevEnd) },
  };
}

export function aggregateRows(rows: GscAnalyticsRow[]): {
  clicks: number;
  impressions: number;
  ctr: number;
  position: number;
} {
  let clicks = 0;
  let impressions = 0;
  let weightedPosition = 0;

  for (const r of rows) {
    clicks += r.clicks;
    impressions += r.impressions;
    weightedPosition += r.position * r.impressions;
  }

  return {
    clicks,
    impressions,
    ctr: impressions > 0 ? clicks / impressions : 0,
    position: impressions > 0 ? weightedPosition / impressions : 0,
  };
}
