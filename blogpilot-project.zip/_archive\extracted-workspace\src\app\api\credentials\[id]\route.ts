import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { encrypt, decrypt } from '@/lib/crypto'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { updateCredentialSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

interface RouteContext {
  params: Promise<{ id: string }>
}

// PATCH /api/credentials/[id] — toggle active status or update fields
export async function PATCH(
  request: Request,
  context: RouteContext
) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { id } = await context.params

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(updateCredentialSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { isActive, apiKey, apiSecret, trackingId, status } = body

    const updateData: Record<string, unknown> = {}
    if (typeof isActive === 'boolean') updateData.isActive = isActive
    if (apiKey !== undefined) updateData.apiKey = encrypt(apiKey)
    if (apiSecret !== undefined) updateData.apiSecret = encrypt(apiSecret)
    if (trackingId !== undefined) updateData.trackingId = trackingId
    if (status !== undefined) updateData.status = status

    const credential = await db.affiliateKey.update({
      where: { id },
      data: updateData,
    })

    const { apiKey: _, apiSecret: __, ...safe } = credential
    return NextResponse.json({ credential: safe })
  } catch (error) {
    return handleApiError(error, 'credentials/update')
  }
}

// DELETE /api/credentials/[id] — remove a credential
export async function DELETE(
  request: Request,
  context: RouteContext
) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { id } = await context.params

    await db.affiliateKey.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error) {
    return handleApiError(error, 'credentials/delete')
  }
}
