# Production Deployment Guide

This guide covers deploying BlogPilot AI to production with a PostgreSQL database (Supabase used as the example, any Postgres works).

---

## 1. Database (PostgreSQL)

The app ships with a committed Prisma migration history that works on any Postgres 14+ instance.

### Option A — Supabase

1. Create a project at https://supabase.com/dashboard
2. Open **SQL Editor** and paste the full contents of
   [`prisma/migrations/20240101000000_init/migration.sql`](../prisma/migrations/20240101000000_init/migration.sql)
   (or apply it with `psql -f`). This creates every table, index, and foreign key.
3. Copy the connection string from **Project Settings → Database → Connection string (URI)**.
   Use the **pooled** connection (port `6543`) for serverless/Vercel deployments.

### Option B — Any other Postgres

Apply the same migration file with your tool of choice:

```bash
psql "$DATABASE_URL" -f prisma/migrations/20240101000000_init/migration.sql
```

Or let Prisma manage it directly:

```bash
DATABASE_URL="postgresql://..." npm run db:migrate:deploy
```

### Optional: Row-Level Security

If you use Supabase and want to block direct access from the public anon key,
enable RLS after applying the migration:

```sql
ALTER TABLE "User" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Article" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Subscription" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "CreditTransaction" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "StoredCredential" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "RevokedSession" ENABLE ROW LEVEL SECURITY;
-- repeat for remaining tables; no policies are added, so only the
-- direct connection string used by Prisma (service role) can read/write.
```

> The Next.js app talks to Postgres via Prisma using the privileged connection
> string, which bypasses RLS by design.

### How the schema is maintained

- **Development** uses SQLite via `prisma/schema.prisma` + `npm run db:push`.
- **Production** uses PostgreSQL. The Postgres variant is generated from the
  SQLite schema by `node scripts/make-postgres-schema.mjs` (writes
  `prisma/schema.postgres.prisma`), then diffed into SQL with:

  ```bash
  DATABASE_URL="postgresql://user:pass@localhost:5432/blogpilot" \
    npx prisma migrate diff --from-empty \
      --to-schema-datamodel prisma/schema.postgres.prisma --script
  ```

- The Prisma client itself auto-detects the provider from `DATABASE_URL`
  (`scripts/prisma-generate.mjs`), so no code changes are needed between dev
  and prod.

If you change `prisma/schema.prisma`, regenerate both artifacts:

```bash
node scripts/make-postgres-schema.mjs
# regenerate the migration SQL as shown above and commit it
```

---

## 2. Environment Variables

Copy `.env.example` and fill in the values in your hosting provider's dashboard.

| Variable | Required | Notes |
|---|---|---|
| `DATABASE_URL` | **Yes** | Postgres connection string |
| `AUTH_SECRET` | **Yes** | HMAC secret for session cookies. Generate: `node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"` |
| `ENCRYPTION_KEY` | Yes* | AES-256-GCM key for stored credentials (*required once users save WordPress/Shopify/affiliate credentials) |
| `NEXT_PUBLIC_APP_URL` | Recommended | Public URL, used for redirects/OG |
| `GEMINI_API_KEY` | For AI features | Primary provider. Falls back to OpenRouter when set, then to a clear error response |
| `OPENROUTER_API_KEY` | AI failover | Used automatically when every Gemini model is quota-blocked (needs credits at openrouter.ai/credits) |
| `SERPAPI_API_KEY` | Optional | Falls back to DuckDuckGo scraping |
| `PADDLE_API_KEY` / `PADDLE_WEBHOOK_SECRET` / `PADDLE_PRICE_ID_*` | For card billing | Visa/Mastercard via Paddle-hosted checkout; webhook verifies HMAC `Paddle-Signature`. Checkout returns 503 when unconfigured (no bypass) |
| `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` / price IDs | Alternative card billing | Fully implemented but the UI defaults to Paddle; checkout returns 503 when unconfigured (no bypass) |
| `PAYPAL_*`, `AIRTM_*`, `PAYEER_*` | For those gateways | All webhooks are signature-verified and idempotent |
| `UPSTASH_REDIS_REST_URL` / `_TOKEN` | Recommended | Shared rate-limit + cache store for multi-instance deploys |

### Rate limiting & caching in production

Both subsystems support two drivers selected automatically:

- **memory** (default) — per-process; correct for single-instance deploys.
- **redis** — any Upstash-REST-compatible endpoint; required when running more
  than one server instance so limits and caches are shared.

Redis is chosen automatically in production when `UPSTASH_REDIS_REST_URL` +
`UPSTASH_REDIS_REST_TOKEN` are set (aliases `REDIS_REST_URL`/`REDIS_REST_TOKEN`
also work). Force a driver explicitly with `RATE_LIMIT_DRIVER=memory|redis` and
`CACHE_DRIVER=memory|redis`. If Redis is unreachable the limiter fails open and
the cache misses gracefully — requests are never dropped because of cache
infrastructure.

Cache TTLs are tunable: `SERP_CACHE_TTL_SEC` (default 900),
`SNAPSHOT_CACHE_TTL_SEC` (1800), `AI_REC_CACHE_TTL_SEC` (86400).

---

## 3. Deploy

### Vercel (recommended)

1. Push the repo to GitHub and import it into Vercel.
2. Set all environment variables from the table above.
3. Deploy — `vercel.json` already configures the build command
   (`next build && node scripts/copy-build-output.js`) and security headers.
4. Register webhook endpoints:
   - Paddle: `https://your-app.vercel.app/api/paddle/webhook` (copy the `pdl_ntfset_*` secret into `PADDLE_WEBHOOK_SECRET`)
   - Stripe: `https://your-app.vercel.app/api/stripe/webhook`
   - PayPal: `https://your-app.vercel.app/api/paypal/webhook`
   - Airtm/Payeer: their respective callback URLs

### Self-hosted (standalone)

```bash
npm run build
DATABASE_URL="postgresql://..." AUTH_SECRET="..." PORT=3000 \
  node .next/standalone/server.js
```

Serve behind a TLS-terminating reverse proxy (nginx/Caddy). Session cookies are
issued with `Secure` in production, so HTTPS is effectively mandatory for login.

---

## 4. Post-deploy checklist

1. `GET /api/health` returns `200` and reports every env var as configured.
2. `GET /api/health/ai` (logged in) reports `{"ai":"configured"}`.
3. Register an account at `/signup` and confirm the session cookie works.
4. Log out, then revisit `/dashboard` — you must be redirected to `/login`
   (server-side session revocation).
5. Trigger one card payment (Visa/Mastercard) in your gateway's TEST MODE:
   Paddle sandbox (`PADDLE_ENV=sandbox` + sandbox keys) or Stripe test mode
   (`4242 4242 4242 4242`): checkout → webhook → plan activated on the correct
   tier → credits granted exactly once (redeliver the webhook to confirm
   idempotency).
6. Run the E2E suites against the deployed URL:
   ```bash
   node scripts/e2e-test.mjs https://your-app.vercel.app
   node scripts/paddle-webhook-test.mjs https://your-app.vercel.app
   node scripts/stripe-webhook-test.mjs https://your-app.vercel.app
   node scripts/free-tools-smoke.mjs https://your-app.vercel.app
   node scripts/concurrent-generate-test.mjs https://your-app.vercel.app
   ```
