import { generateTextChecked } from '@/lib/gemini';

/**
 * Section-based (chunked) article generation.
 *
 * Long articles are produced one H2 section at a time instead of relying on a
 * single huge completion. This keeps every individual model call well inside
 * reliable output limits, so finished articles are never silently truncated:
 * each section call reports truncation independently and the caller receives
 * an explicit `truncated` flag if any section could not be completed even
 * after budget escalation.
 *
 * Credit accounting: the API route reserves 1 credit BEFORE the first model
 * call and refunds it only if generation throws, so multi-pass generation
 * still costs exactly one credit per article.
 */

const MAX_SECTIONS = 12;
const OUTLINE_TOKENS = 1200;
const SECTION_TOKENS = 1600;

export interface GeneratedArticle {
  title: string;
  markdown: string;
  sections: string[];
  truncated: boolean;
  model?: string;
}

export interface GenerateArticleParams {
  query: string;
  title: string;
  instructions?: string;
  analysis?: {
    searchIntent?: string;
    competitionLevel?: string;
    opportunityScore?: number | string;
    missingSubtopics?: string[];
    faqOpportunities?: string[];
    aiRecommendations?: { recommended_h2?: string[] };
  } | null;
}

interface OutlineSection {
  heading: string;
  brief: string;
}

function buildAnalysisContext(analysis: GenerateArticleParams['analysis']): string[] {
  const lines: string[] = [];
  if (!analysis) return lines;

  lines.push(`- Search intent: ${analysis.searchIntent || 'informational'}`);
  lines.push(`- Competition strength: ${analysis.competitionLevel || 'medium'}`);
  lines.push(`- Opportunity score: ${analysis.opportunityScore ?? 'unknown'}/100`);

  if (Array.isArray(analysis.missingSubtopics) && analysis.missingSubtopics.length > 0) {
    lines.push(`- Missing subtopics to cover: ${analysis.missingSubtopics.slice(0, 6).join(', ')}`);
  }
  if (Array.isArray(analysis.faqOpportunities) && analysis.faqOpportunities.length > 0) {
    lines.push(`- FAQ ideas: ${analysis.faqOpportunities.slice(0, 5).join(' | ')}`);
  }
  if (analysis.aiRecommendations?.recommended_h2?.length) {
    lines.push(`- Recommended sections: ${analysis.aiRecommendations.recommended_h2.join(' | ')}`);
  }
  return lines;
}

function fallbackOutline(params: GenerateArticleParams): OutlineSection[] {
  const sections: OutlineSection[] = [
    { heading: 'Introduction', brief: 'Hook the reader, establish why this topic matters, preview what the article covers.' },
  ];
  const recommended = params.analysis?.aiRecommendations?.recommended_h2 || [];
  const missing = params.analysis?.missingSubtopics || [];
  const pool = [...recommended, ...missing].slice(0, MAX_SECTIONS - 3);
  for (const h of pool) sections.push({ heading: h, brief: 'Cover this subtopic thoroughly with actionable detail.' });
  if (sections.length < 4) {
    sections.push({ heading: `How ${params.query} Works`, brief: 'Explain the mechanics step by step.' });
    sections.push({ heading: 'Best Practices and Tips', brief: 'Concrete, practical recommendations.' });
  }
  sections.push({ heading: 'Frequently Asked Questions', brief: 'Answer 4-6 common questions in Q&A form.' });
  sections.push({ heading: 'Conclusion', brief: 'Summarize key takeaways and give a clear next step.' });
  return sections.slice(0, MAX_SECTIONS);
}

async function generateOutline(params: GenerateArticleParams): Promise<OutlineSection[]> {
  const analysisLines = buildAnalysisContext(params.analysis);
  const prompt = [
    `You are an SEO content strategist. Topic/query: "${params.query}".`,
    `Article title: "${params.title}".`,
    analysisLines.length ? 'Analysis insights:\n' + analysisLines.join('\n') : '',
    params.instructions ? `Writer instructions: ${params.instructions}` : '',
    'Design an outline of 8 to 10 H2 sections for a comprehensive article.',
    'Return ONLY valid JSON, no markdown fences, matching exactly:',
    '{"sections":[{"heading":"H2 heading text","brief":"1-2 sentence content brief for this section"}]}',
  ].filter(Boolean).join('\n\n');

  try {
    const { text } = await generateTextChecked(prompt, OUTLINE_TOKENS);
    const cleaned = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const parsed = JSON.parse(cleaned);
    const list = Array.isArray(parsed?.sections) ? parsed.sections : null;
    if (!list || list.length === 0) return fallbackOutline(params);
    return list
      .filter((s: any) => s && typeof s.heading === 'string' && s.heading.trim())
      .slice(0, MAX_SECTIONS)
      .map((s: any) => ({ heading: String(s.heading).trim(), brief: String(s.brief || '').trim() }));
  } catch {
    return fallbackOutline(params);
  }
}

function buildSectionPrompt(
  params: GenerateArticleParams,
  outline: OutlineSection[],
  index: number,
  previousTail: string,
): string {
  const sectionList = outline.map((s, i) => `${i + 1}. ${s.heading}`).join('\n');
  const current = outline[index];
  const lines = [
    `You are an SEO content expert writing ONE section of a larger article.`,
    `Article title: "${params.title}". Overall query/topic: "${params.query}".`,
    '',
    `Full outline (for context — do NOT write other sections):`,
    sectionList,
    '',
    `Write ONLY section ${index + 1}: "${current.heading}".`,
    `Section brief: ${current.brief || 'Cover the subtopic thoroughly.'}`,
    'Requirements:',
    `- Start with the H2 heading "## ${current.heading}".`,
    '- Write 250-400 words of high-quality prose. Use paragraphs; bullet lists where genuinely helpful.',
    '- Do not include the article title (H1). Do not write any other section.',
    '- No meta commentary about the writing process.',
  ];
  if (params.instructions) lines.push(`Writer instructions: ${params.instructions}`);
  if (previousTail) {
    lines.push('', `The previous section ended with: "...${previousTail}"`, 'Begin this section naturally, without repeating that content.');
  }
  return lines.join('\n');
}

export async function generateArticleChunked(params: GenerateArticleParams): Promise<GeneratedArticle> {
  const outline = await generateOutline(params);

  const sections: string[] = [];
  let truncated = false;
  let previousTail = '';
  let lastModel: string | undefined;

  for (let i = 0; i < outline.length; i++) {
    const prompt = buildSectionPrompt(params, outline, i, previousTail);
    const out = await generateTextChecked(prompt, SECTION_TOKENS);
    lastModel = out.model;
    let body = out.text.trim();

    if (out.truncated) {
      // Escalation already ran inside gemini.ts; if we are STILL truncated the
      // safest move is to close the section cleanly rather than ship a cut
      // mid-sentence. Mark the article so the UI can surface it.
      truncated = true;
      const lastParagraphBreak = Math.max(body.lastIndexOf('\n\n'), body.lastIndexOf('. '));
      if (lastParagraphBreak > 200) {
        body = body.slice(0, lastParagraphBreak + 1).trim();
      }
    }

    sections.push(body);
    const tailWords = body.split(/\s+/).slice(-40).join(' ');
    previousTail = tailWords.slice(-300);
  }

  const markdown = [`# ${params.title}`, '', sections.join('\n\n')].join('\n').trim();
  return { title: params.title, markdown, sections, truncated, model: lastModel };
}
