﻿import prisma from '@/lib/prisma';
import { APP_URL } from '@/lib/env';
import { encrypt, decrypt } from '@/lib/encryption';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

const SCOPES = [
  'https://www.googleapis.com/auth/blogger',
  'https://www.googleapis.com/auth/webmasters.readonly',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
].join(' ');

/** Scope required for Search Console read access. */
export const SEARCHCONSOLE_SCOPE = 'https://www.googleapis.com/auth/webmasters.readonly';

export function isGoogleConfigured(): boolean {
  return !!(GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET);
}

export function getGoogleAuthUrl(state: string): string {
  const params = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID!,
    redirect_uri: `${APP_URL}/api/google/auth/callback`,
    response_type: 'code',
    scope: SCOPES,
    access_type: 'offline',
    prompt: 'consent',
    state,
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

export async function exchangeCode(code: string): Promise<{
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  email?: string;
  name?: string;
}> {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: GOOGLE_CLIENT_ID!,
      client_secret: GOOGLE_CLIENT_SECRET!,
      redirect_uri: `${APP_URL}/api/google/auth/callback`,
      grant_type: 'authorization_code',
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error_description || 'Failed to exchange authorization code');
  }

  const tokens = await res.json();

  let email: string | undefined;
  let name: string | undefined;
  try {
    const userInfo = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    if (userInfo.ok) {
      const info = await userInfo.json();
      email = info.email;
      name = info.name;
    }
  } catch {}

  return {
    accessToken: tokens.access_token,
    refreshToken: tokens.refresh_token,
    expiresIn: tokens.expires_in || 3600,
    email,
    name,
  };
}

export async function refreshAccessToken(refreshToken: string): Promise<{
  accessToken: string;
  expiresIn: number;
}> {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: GOOGLE_CLIENT_ID!,
      client_secret: GOOGLE_CLIENT_SECRET!,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });

  if (!res.ok) {
    throw new Error('Failed to refresh Google access token');
  }

  const data = await res.json();
  return {
    accessToken: data.access_token,
    expiresIn: data.expires_in || 3600,
  };
}

export async function getValidAccessToken(userId: string): Promise<string | null> {
  const token = await prisma.googleToken.findFirst({
    where: { userId, isActive: true },
    orderBy: { createdAt: 'desc' },
  });

  if (!token) return null;

  let accessToken: string;
  try {
    accessToken = decrypt(token.accessToken || '');
  } catch {
    accessToken = token.accessToken || '';
  }

  let refreshToken: string;
  try {
    refreshToken = decrypt(token.refreshToken);
  } catch {
    refreshToken = token.refreshToken;
  }

  if (token.expiresAt && token.expiresAt > new Date(Date.now() + 60_000)) {
    return accessToken;
  }

  if (!refreshToken) return null;

  try {
    const refreshed = await refreshAccessToken(refreshToken);
    await prisma.googleToken.update({
      where: { id: token.id },
      data: {
        accessToken: encrypt(refreshed.accessToken),
        expiresAt: new Date(Date.now() + refreshed.expiresIn * 1000),
        lastRefreshedAt: new Date(),
      },
    });
    return refreshed.accessToken;
  } catch {
    await prisma.googleToken.update({
      where: { id: token.id },
      data: { isActive: false, status: 'expired' },
    }).catch(() => {});
    return null;
  }
}

export async function listBloggerBlogs(accessToken: string): Promise<Array<{ id: string; name: string; url: string }>> {
  const res = await fetch('https://www.googleapis.com/blogger/v3/users/self/blogs', {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (!res.ok) throw new Error('Failed to list Blogger blogs');
  const data = await res.json();
  return (data.items || []).map((blog: any) => ({
    id: blog.id,
    name: blog.name,
    url: blog.url,
  }));
}

export async function publishToBlogger(
  accessToken: string,
  blogId: string,
  input: { title: string; content: string; slug?: string | null },
): Promise<{ id: string; url: string; status: string }> {
  const res = await fetch(
    `https://www.googleapis.com/blogger/v3/blogs/${blogId}/posts`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        kind: 'blogger#post',
        title: input.title,
        content: input.content,
      }),
    },
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Blogger publish failed (${res.status})`);
  }

  const post = await res.json();
  return {
    id: String(post.id),
    url: post.url,
    status: post.status || 'LIVE',
  };
}

export { GOOGLE_CLIENT_ID };
