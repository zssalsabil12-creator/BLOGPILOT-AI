import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import {
  getGscAccessToken,
  querySearchAnalytics,
  buildPeriodRange,
  aggregateRows,
} from '@/lib/gsc';

const querySchema = z.object({
  siteId: z.string().min(1).max(64),
  days: z.coerce.number().int().min(7).max(90).optional().default(28),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters', details: parsed.error.flatten() }, { status: 400 });
  }

  const limit = await checkRateLimit(`gsc-perf:${userId}`, { windowMs: 60_000, maxRequests: 15 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  const { siteId, days } = parsed.data;

  const site = await prisma.connectedSite.findFirst({
    where: { id: siteId, userId },
    select: { id: true, name: true, url: true, gscProperty: true },
  });

  if (!site) {
    return NextResponse.json({ ok: false, error: 'Site not found' }, { status: 404 });
  }
  if (!site.gscProperty) {
    return NextResponse.json(
      { ok: false, error: 'This site is not linked to a Search Console property yet.' },
      { status: 409 },
    );
  }

  const access = await getGscAccessToken(userId);
  if (!access.ok) {
    return NextResponse.json(
      {
        ok: false,
        error:
          access.reason === 'needs_reconnect'
            ? 'Reconnect your Google account with Search Console access.'
            : 'Connect your Google account first.',
        code: access.reason,
      },
      { status: 409 },
    );
  }

  try {
    const range = buildPeriodRange(days);
    const propertyUrl = site.gscProperty;

    const [byPageCur, byQueryCur, byPagePrev] = await Promise.all([
      querySearchAnalytics(access.accessToken, propertyUrl, {
        ...range.current,
        dimensions: ['page'],
        rowLimit: 1000,
      }),
      querySearchAnalytics(access.accessToken, propertyUrl, {
        ...range.current,
        dimensions: ['query'],
        rowLimit: 1000,
      }),
      querySearchAnalytics(access.accessToken, propertyUrl, {
        ...range.previous,
        dimensions: ['page'],
        rowLimit: 1000,
      }),
    ]);

    const totals = aggregateRows(byPageCur);
    // Aggregate of previous period pages is an approximation of totals
    // (pages without clicks don't appear) — label it honestly in UI.
    const totalsPrevPages = aggregateRows(byPagePrev);

    return NextResponse.json({
      ok: true,
      data: {
        site: { id: site.id, name: site.name, url: site.url, gscProperty: site.gscProperty },
        period: { ...range.current, days },
        comparisonPeriod: range.previous,
        totals: {
          current: totals,
          // Clicks/impressions for the previous period are complete enough
          // through page rows; note: queries w/o page data are excluded.
          previousFromPages: totalsPrevPages,
        },
        topPages: byPageCur.sort((a, b) => b.clicks - a.clicks).slice(0, 20),
        topQueries: byQueryCur.sort((a, b) => b.impressions - a.impressions).slice(0, 30),
      },
    });
  } catch (error: any) {
    console.error('GSC performance error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'Search Console request failed' },
      { status: 502 },
    );
  }
}
