'use client';

import React, { useState, useCallback, useRef } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Type,
  FileText,
  Clock,
  Mic,
  Hash,
  BarChart3,
  RotateCcw,
  Copy,
  Check,
} from 'lucide-react';

const STOP_WORDS = new Set([
  'a','an','the','and','or','but','in','on','at','to','for','of','with','by',
  'from','up','about','into','through','during','before','after','above','below',
  'between','out','off','over','under','again','further','then','once','here',
  'there','when','where','why','how','all','each','every','both','few','more',
  'most','other','some','such','no','nor','not','only','own','same','so',
  'than','too','very','s','t','can','will','just','don','should','now','d',
  'll','m','o','re','ve','y','ain','aren','couldn','didn','doesn','hadn',
  'hasn','haven','isn','ma','mightn','mustn','needn','shan','shouldn','wasn',
  'weren','won','wouldn','i','me','my','myself','we','our','ours','ourselves',
  'you','your','yours','yourself','yourselves','he','him','his','himself',
  'she','her','hers','herself','it','its','itself','they','them','their',
  'theirs','themselves','what','which','who','whom','this','that','these',
  'those','am','is','are','was','were','be','been','being','have','has',
  'had','having','do','does','did','doing','would','could','shall','might',
  'must','ought','need','dare','used',
]);

interface Stats {
  words: number;
  charactersWithSpaces: number;
  charactersWithoutSpaces: number;
  sentences: number;
  paragraphs: number;
  readingTime: string;
  speakingTime: string;
}

interface Keyword {
  word: string;
  count: number;
  percentage: number;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs text-muted-foreground transition hover:bg-card hover:text-foreground"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function analyzeText(text: string): { stats: Stats; keywords: Keyword[] } {
  const trimmedText = text.trim();
  const words = trimmedText ? trimmedText.split(/\s+/).filter(Boolean) : [];
  const wordCount = words.length;

  const sentences = trimmedText ? trimmedText.split(/[.!?]+/).filter(s => s.trim().length > 0) : [];
  const sentenceCount = sentences.length;

  const paragraphs = trimmedText ? trimmedText.split(/\n\s*\n/).filter(p => p.trim().length > 0).length : 0;
  const effectiveParagraphs = paragraphs || (trimmedText ? 1 : 0);

  const charactersWithSpaces = trimmedText.length;
  const charactersWithoutSpaces = trimmedText.replace(/\s/g, '').length;

  const readingMinutes = wordCount / 225;
  const readingTime = readingMinutes < 1
    ? `${Math.max(1, Math.ceil(readingMinutes * 60))} sec`
    : `${Math.floor(readingMinutes)} min ${Math.ceil((readingMinutes % 1) * 60)} sec`;

  const speakingMinutes = wordCount / 130;
  const speakingTime = speakingMinutes < 1
    ? `${Math.max(1, Math.ceil(speakingMinutes * 60))} sec`
    : `${Math.floor(speakingMinutes)} min ${Math.ceil((speakingMinutes % 1) * 60)} sec`;

  const stats: Stats = {
    words: wordCount,
    charactersWithSpaces,
    charactersWithoutSpaces,
    sentences: sentenceCount,
    paragraphs: effectiveParagraphs,
    readingTime,
    speakingTime,
  };

  const freqMap = new Map<string, number>();
  for (const word of words) {
    const cleaned = word.toLowerCase().replace(/[^a-z0-9'-]/g, '');
    if (cleaned.length < 2) continue;
    if (STOP_WORDS.has(cleaned)) continue;
    freqMap.set(cleaned, (freqMap.get(cleaned) || 0) + 1);
  }

  const keywords: Keyword[] = Array.from(freqMap.entries())
    .map(([word, count]) => ({ word, count, percentage: wordCount > 0 ? (count / wordCount) * 100 : 0 }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 20);

  return { stats, keywords };
}

export default function WordCounterPage() {
  const [text, setText] = useState('');
  const [stats, setStats] = useState<Stats | null>(null);
  const [keywords, setKeywords] = useState<Keyword[]>([]);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleAnalyze = useCallback(() => {
    setError(null);
    if (!text.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    const result = analyzeText(text);
    setStats(result.stats);
    setKeywords(result.keywords);
  }, [text]);

  const handleReset = useCallback(() => {
    setText('');
    setStats(null);
    setKeywords([]);
    setError(null);
    textareaRef.current?.focus();
  }, []);

  const charCount = text.length;
  const wordCountApprox = text.trim() ? text.trim().split(/\s+/).length : 0;

  const statsText = stats
    ? [
        `Words: ${stats.words}`,
        `Characters (with spaces): ${stats.charactersWithSpaces}`,
        `Characters (without spaces): ${stats.charactersWithoutSpaces}`,
        `Sentences: ${stats.sentences}`,
        `Paragraphs: ${stats.paragraphs}`,
        `Reading time: ${stats.readingTime}`,
        `Speaking time: ${stats.speakingTime}`,
        '',
        'Keyword Frequency:',
        ...keywords.map(k => `  ${k.word}: ${k.count} (${k.percentage.toFixed(1)}%)`),
      ].join('\n')
    : '';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Word Counter & <span className="text-gradient">Text Analyzer</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Get detailed statistics about your text including word count, character count, reading time, and keyword frequency analysis.
          </p>
        </section>

        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-4">
            <div>
              <textarea
                ref={textareaRef}
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste or type your text here..."
                rows={10}
                className="w-full rounded-xl border border-border bg-muted/50 p-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30 resize-y"
              />
              <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                <span>{charCount.toLocaleString()} characters</span>
                <span>{wordCountApprox.toLocaleString()} words</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleAnalyze}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <BarChart3 className="h-4 w-4" />
                Analyze Text
              </button>
              {stats && (
                <button
                  onClick={handleReset}
                  className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Reset
                </button>
              )}
            </div>
          </div>
          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <span>{error}</span>
            </div>
          )}
        </section>

        {stats && (
          <div className="space-y-6">
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-cyan-300" />
                  <h2 className="text-lg font-semibold text-foreground">Text Statistics</h2>
                </div>
                <CopyButton text={statsText} />
              </div>
              <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="rounded-xl border border-border bg-muted/50 p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Type className="h-4 w-4" />
                    <span className="text-xs font-medium">Words</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.words.toLocaleString()}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Hash className="h-4 w-4" />
                    <span className="text-xs font-medium">Characters (with spaces)</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.charactersWithSpaces.toLocaleString()}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Hash className="h-4 w-4" />
                    <span className="text-xs font-medium">Characters (no spaces)</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.charactersWithoutSpaces.toLocaleString()}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    <span className="text-xs font-medium">Sentences</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.sentences.toLocaleString()}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    <span className="text-xs font-medium">Paragraphs</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.paragraphs.toLocaleString()}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4 sm:col-span-2">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span className="text-xs font-medium">Reading Time (225 WPM)</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.readingTime}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4 sm:col-span-2">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mic className="h-4 w-4" />
                    <span className="text-xs font-medium">Speaking Time (130 WPM)</span>
                  </div>
                  <p className="mt-2 text-2xl font-bold text-foreground">{stats.speakingTime}</p>
                </div>
              </div>
            </section>

            {keywords.length > 0 && (
              <section className="rounded-2xl border border-border bg-card/50 p-6">
                <div className="flex items-center gap-3">
                  <BarChart3 className="h-5 w-5 text-violet-300" />
                  <h2 className="text-lg font-semibold text-foreground">Keyword Frequency (Top 20)</h2>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  Most frequent non-stop-words found in your text.
                </p>
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border text-left text-muted-foreground">
                        <th className="pb-2 pr-4 font-medium">#</th>
                        <th className="pb-2 pr-4 font-medium">Keyword</th>
                        <th className="pb-2 pr-4 font-medium text-right">Count</th>
                        <th className="pb-2 font-medium text-right">Density</th>
                      </tr>
                    </thead>
                    <tbody>
                      {keywords.map((kw, i) => (
                        <tr key={kw.word} className="border-b border-border/50">
                          <td className="py-2.5 pr-4 text-muted-foreground">{i + 1}</td>
                          <td className="py-2.5 pr-4 font-medium text-foreground">{kw.word}</td>
                          <td className="py-2.5 pr-4 text-right text-muted-foreground">{kw.count}</td>
                          <td className="py-2.5 text-right">
                            <span className="inline-block rounded-full bg-muted/50 px-2.5 py-0.5 text-xs text-muted-foreground">
                              {kw.percentage.toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
