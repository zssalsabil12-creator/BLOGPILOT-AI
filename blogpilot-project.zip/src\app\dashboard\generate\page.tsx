﻿import React, { Suspense } from 'react';
import GenerateArticle from '../../../components/dashboard/generate-article-page';

interface DashboardGeneratePageProps {
  searchParams?: Promise<{ [key: string]: string | string[] | undefined }>;
}

async function GenerateArticleWrapper({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }> | undefined;
}) {
  const params = searchParams ? await searchParams : {};
  let opportunity = null as string | null;
  try {
    const raw = params?.opportunity;
    if (typeof raw === 'string' && raw.length > 0) opportunity = raw;
  } catch {
    opportunity = null;
  }

  return <GenerateArticle opportunityParam={opportunity} />;
}

export default function DashboardGeneratePage({ searchParams }: DashboardGeneratePageProps) {
  return (
    <div className="p-6">
      <Suspense fallback={<div className="text-slate-400">Loading article builder…</div>}>
        <GenerateArticleWrapper searchParams={searchParams} />
      </Suspense>
    </div>
  );
}
