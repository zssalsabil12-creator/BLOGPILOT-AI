import React from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';

export const metadata = {
  title: 'Competitor Analysis Guide — Content Opportunity Analyzer | BlogPilot AI',
  description: 'Learn how to analyze competitor pages, identify gaps, and craft content that outranks existing results with BlogPilot AI\'s free analyzer.',
};

export default function CompetitorAnalysisPage() {
  return (
    <FreeToolLayout backHref="/free-tools" backLabel="All Free Tools">
      <article className="max-w-3xl mx-auto">
        <header className="mb-10">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Guide</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">Competitor analysis for content that wins</h1>
          <p className="mt-4 text-lg text-muted-foreground">Dissect top-ranking pages to learn what they do well and, more importantly, what they miss. The Content Opportunity Analyzer automates that process so you can focus on building superior content.</p>
        </header>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Key things to check</h2>
          <ul className="list-disc ml-6 mt-3 text-muted-foreground space-y-2">
            <li>Search intent alignment (does the page satisfy the user?)</li>
            <li>Headings and structure coverage</li>
            <li>FAQ and schema presence</li>
            <li>Examples, visuals, and practical takeaways</li>
            <li>Freshness and update cadence</li>
          </ul>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">How the Analyzer helps</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">The analyzer fetches top results, extracts headings, counts words, and summarizes strengths and weaknesses. It highlights missing sections, unanswered questions, and structural opportunities to create a page that&apos;s more comprehensive and user-focused.</p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Try it now</h2>
          <p className="mt-3 text-muted-foreground">Enter a keyword, page URL, or site URL to see an actionable competitor breakdown and suggested improvements.</p>
          <div className="mt-4">
            <a href="/free-tools/content-opportunity-analyzer" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-5 py-3 text-sm font-semibold text-slate-950">Open the Analyzer →</a>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Related tools</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <a href="/free-tools/content-opportunity-analyzer" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">Content Opportunity Analyzer →</span>
            </a>
            <a href="/free-tools/content-opportunity-analyzer/keyword-research" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">Keyword Research Guide →</span>
            </a>
            <a href="/free-tools/seo-title-analyzer" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">SEO Title & Meta Analyzer →</span>
            </a>
            <a href="/free-tools/heading-structure-analyzer" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">Heading Structure Analyzer →</span>
            </a>
          </div>
        </section>

        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://blogpilot.ai/" },
            { "@type": "ListItem", "position": 2, "name": "Free Tools", "item": "https://blogpilot.ai/free-tools" },
            { "@type": "ListItem", "position": 3, "name": "Competitor Analysis", "item": "https://blogpilot.ai/free-tools/content-opportunity-analyzer/competitor-analysis" }
          ]
        }) }} />
      </article>
    </FreeToolLayout>
  );
}
