import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { loginSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

// POST /api/auth/login
export async function POST(request: Request) {
  try {
    // ─── Rate limit (10 / minute / IP) — strict to slow credential stuffing ───
    const blocked = rateLimit(request, RATE_LIMITS.auth)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(loginSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { email, password } = body

    const user = await db.user.findUnique({
      where: { email },
      include: { subscription: true },
    })

    if (!user || user.passwordHash !== password) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    const { passwordHash: _, ...safeUser } = user

    return NextResponse.json({
      user: safeUser,
      // In production: issue a signed JWT with expiry
      // For this demo, the session token is simply the user id.
      sessionToken: user.id,
    })
  } catch (error: unknown) {
    return handleApiError(error, 'auth/login')
  }
}
