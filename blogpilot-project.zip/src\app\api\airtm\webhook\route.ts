﻿import { NextResponse } from 'next/server';
import { verifyAirtmCallback } from '@/lib/airtm';
import { activatePlan, getPlanConfig, isValidPlanId } from '@/lib/billing';

export async function POST(req: Request) {
  let params: Record<string, string> = {};
  const contentType = req.headers.get('content-type') || '';

  if (contentType.includes('application/json')) {
    params = await req.json().catch(() => ({}));
  } else {
    const formData = await req.formData().catch(() => null);
    if (formData) {
      for (const [key, value] of formData.entries()) {
        params[key] = String(value);
      }
    }
  }

  if (!verifyAirtmCallback(params)) {
    return NextResponse.json({ status: 'invalid_sign' }, { status: 400 });
  }

  try {
    const orderId = params.order_id || '';
    const [userId, planId] = orderId.split(':');
    if (userId && planId && isValidPlanId(planId)) {
      const planConfig = getPlanConfig(planId);
      const expectedAmount = planConfig.priceMonthly.toFixed(2);
      if (params.amount && params.amount !== expectedAmount) {
        return NextResponse.json({ status: 'amount_mismatch' }, { status: 400 });
      }
      await activatePlan(userId, planId, {
        source: 'airtm',
        description: `Airtm payment for the ${planId} plan`,
        idempotencyKey: `airtm:${orderId}`,
      });
    }
    return NextResponse.json({ status: 'success' });
  } catch (error: any) {
    console.error('Airtm webhook error:', error);
    return NextResponse.json({ status: 'error' }, { status: 500 });
  }
}