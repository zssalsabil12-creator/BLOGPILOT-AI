﻿/**
 * Production-ready rate limiting.
 *
 * Drivers (selected automatically by environment, overridable):
 *   - memory : fixed-window in-memory store. Correct for a single instance /
 *              local development only.
 *   - redis  : fixed-window counter in any Redis-compatible REST endpoint
 *              (Upstash REST API compatible; works across serverless
 *              instances because the counter lives in Redis, not in the
 *              function process).
 *
 * Configuration:
 *   RATE_LIMIT_DRIVER        "memory" | "redis"   (optional override)
 *   UPSTASH_REDIS_REST_URL   REST base URL        (or REDIS_REST_URL)
 *   UPSTASH_REDIS_REST_TOKEN REST bearer token    (or REDIS_REST_TOKEN)
 *
 * In production the redis driver is selected automatically when REST URL +
 * token are present. If Redis is unreachable the limiter fails OPEN (request
 * allowed) and logs loudly — authentication and credit checks remain
 * enforced independently of this layer.
 */

export interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

const CLEANUP_INTERVAL = 60_000;
let lastCleanup = Date.now();

// ---------------------------------------------------------------------------
// Memory driver (development / single-instance)
// ---------------------------------------------------------------------------

const memoryStore = new Map<string, { count: number; resetAt: number }>();

function memoryHit(key: string, windowMs: number): { count: number; resetAt: number } {
  const now = Date.now();
  if (now - lastCleanup >= CLEANUP_INTERVAL) {
    lastCleanup = now;
    for (const [k, entry] of memoryStore) {
      if (entry.resetAt <= now) memoryStore.delete(k);
    }
  }

  const entry = memoryStore.get(key);
  if (!entry || entry.resetAt <= now) {
    const fresh = { count: 1, resetAt: now + windowMs };
    memoryStore.set(key, fresh);
    return fresh;
  }
  entry.count += 1;
  return entry;
}

// ---------------------------------------------------------------------------
// Redis driver (Upstash REST-compatible)
// ---------------------------------------------------------------------------

function getRedisRestConfig(): { url: string; token: string } | null {
  const url = process.env.UPSTASH_REDIS_REST_URL || process.env.REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.REDIS_REST_TOKEN;
  if (url?.trim() && token?.trim()) return { url: url.trim().replace(/\/+$/, ''), token: token.trim() };
  return null;
}

async function redisHit(key: string, windowMs: number): Promise<{ count: number; resetAt: number }> {
  const cfg = getRedisRestConfig()!;
  const now = Date.now();
  const bucket = Math.floor(now / windowMs);
  const redisKey = `rl:${key}:${bucket}`;
  const resetAt = (bucket + 1) * windowMs;

  // Single round-trip: INCR then conditional PEXPIRE (only when count === 1).
  const res = await fetch(`${cfg.url}/pipeline`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cfg.token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify([
      ['INCR', redisKey],
      ['EXPIRE', redisKey, Math.ceil(windowMs / 1000) + 1, 'NX'],
    ]),
    signal: AbortSignal.timeout(3000),
  });

  if (!res.ok) throw new Error(`Redis rate-limit request failed (${res.status})`);
  const data = await res.json();
  const count = Number(data?.[0]?.result ?? 1);
  return { count, resetAt };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

function resolveDriver(): 'memory' | 'redis' {
  const explicit = (process.env.RATE_LIMIT_DRIVER || '').trim().toLowerCase();
  if (explicit === 'redis') return getRedisRestConfig() ? 'redis' : 'memory';
  if (explicit === 'memory') return 'memory';
  // Automatic: production + configured Redis -> shared counter.
  return process.env.NODE_ENV === 'production' && getRedisRestConfig() ? 'redis' : 'memory';
}

export async function checkRateLimit(
  identifier: string,
  config: RateLimitConfig,
): Promise<RateLimitResult> {
  const driver = resolveDriver();

  try {
    const { count, resetAt } = driver === 'redis'
      ? await redisHit(identifier, config.windowMs)
      : memoryHit(identifier, config.windowMs);

    if (count > config.maxRequests) {
      return { allowed: false, remaining: 0, resetAt };
    }
    return { allowed: true, remaining: Math.max(0, config.maxRequests - count), resetAt };
  } catch (err: any) {
    console.error(`[rate-limit] ${driver} driver failed, failing open:`, err?.message || err);
    return { allowed: true, remaining: config.maxRequests, resetAt: Date.now() + config.windowMs };
  }
}

export const RATE_LIMITS = {
  login: { windowMs: 15 * 60 * 1000, maxRequests: 10 },
  signup: { windowMs: 60 * 60 * 1000, maxRequests: 5 },
  generate: { windowMs: 60 * 1000, maxRequests: 3 },
  publicApi: { windowMs: 60 * 1000, maxRequests: 30 },
  publicAnalyzer: { windowMs: 60 * 1000, maxRequests: 6 },
  auth: { windowMs: 60 * 1000, maxRequests: 10 },
} as const;

export function getClientIp(req: Request): string {
  return req.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
    || req.headers.get('x-real-ip')
    || 'unknown';
}
