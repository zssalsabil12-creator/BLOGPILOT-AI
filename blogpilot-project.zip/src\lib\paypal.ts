﻿import prisma from '@/lib/prisma';
import { APP_URL } from '@/lib/env';
import { getPlanConfig, activatePlan, isValidPlanId } from '@/lib/billing';

const API_BASE = process.env.PAYPAL_ENV === 'live'
  ? 'https://api-m.paypal.com'
  : 'https://api-m.sandbox.paypal.com';

export function isPayPalConfigured(): boolean {
  return !!(process.env.PAYPAL_CLIENT_ID && process.env.PAYPAL_CLIENT_SECRET);
}

let cachedToken: { token: string; expiresAt: number } | null = null;

export async function getPayPalAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 60000) return cachedToken.token;
  const clientId = process.env.PAYPAL_CLIENT_ID;
  const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
  if (!clientId || !clientSecret) throw new Error('PayPal is not configured');

  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const res = await fetch(`${API_BASE}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) throw new Error(`PayPal authentication failed (${res.status})`);
  const json = await res.json();
  cachedToken = {
    token: json.access_token,
    expiresAt: Date.now() + (json.expires_in || 3600) * 1000,
  };
  return json.access_token;
}

async function paypalFetch(path: string, init: RequestInit = {}): Promise<any> {
  const token = await getPayPalAccessToken();
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(init.headers || {}),
    },
  });
  const text = await res.text();
  let json: any = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = null;
  }
  if (!res.ok) {
    const error = new Error(json?.message || `PayPal request failed (${res.status})`);
    (error as any).status = res.status;
    (error as any).data = json;
    throw error;
  }
  return json;
}

export async function createPayPalOrder(params: { userId: string; planId: string }): Promise<{ id: string; approveUrl: string | null }> {
  const plan = getPlanConfig(params.planId);
  const json = await paypalFetch('/v2/checkout/orders', {
    method: 'POST',
    body: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: 'blogpilot-plan',
        description: `BlogPilot ${plan.name} Plan — ${plan.creditsPerMonth} credits/mo`,
        amount: { currency_code: 'USD', value: plan.priceMonthly.toFixed(2) },
        custom_id: `${params.userId}:${plan.id}`,
      }],
      application_context: {
        brand_name: 'BlogPilot AI',
        user_action: 'PAY_NOW',
        return_url: `${APP_URL}/api/paypal/capture`,
        cancel_url: `${APP_URL}/dashboard?tab=billing&payment=cancelled`,
      },
    }),
  });
  const approve = json?.links?.find((l: any) => l.rel === 'approve');
  return { id: json.id, approveUrl: approve?.href || null };
}

export async function capturePayPalOrder(orderId: string): Promise<any> {
  const json = await paypalFetch(`/v2/checkout/orders/${orderId}/capture`, { method: 'POST' });
  const captureStatus = json?.purchase_units?.[0]?.payments?.captures?.[0]?.status;
  if (captureStatus && captureStatus !== 'COMPLETED') {
    throw new Error(`PayPal capture not completed (status: ${captureStatus})`);
  }
  const customId = json?.purchase_units?.[0]?.payments?.captures?.[0]?.custom_id
    || json?.purchase_units?.[0]?.custom_id;
  if (customId) {
    const [userId, planId] = customId.split(':');
    if (userId && planId && isValidPlanId(planId)) {
      // Idempotent per order — a replayed capture cannot double-allocate.
      await activatePlan(userId, planId, {
        source: 'paypal',
        description: `PayPal purchase: ${getPlanConfig(planId).name} plan`,
        idempotencyKey: `paypal:capture:${orderId}`,
      });
    }
  }
  return json;
}

export async function verifyPayPalWebhook(headers: Headers, body: string): Promise<boolean> {
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId) {
    // Fail closed in ALL environments — an unverified webhook must never be
    // able to grant paid plans, including on internet-exposed dev/staging.
    console.error('[paypal] PAYPAL_WEBHOOK_ID not set — rejecting webhook (verification is mandatory).');
    return false;
  }

  const transmissionId = headers.get('paypal-transmission-id');
  const transmissionTime = headers.get('paypal-transmission-time');
  const certUrl = headers.get('paypal-cert-url');
  const authAlgo = headers.get('paypal-auth-algo');
  const transmissionSig = headers.get('paypal-transmission-sig');

  if (!transmissionId || !transmissionTime || !certUrl || !authAlgo || !transmissionSig) return false;

  try {
    const json = await paypalFetch('/v1/notifications/verify-webhook-signature', {
      method: 'POST',
      body: JSON.stringify({
        auth_algo: authAlgo,
        cert_url: certUrl,
        transmission_id: transmissionId,
        transmission_sig: transmissionSig,
        transmission_time: transmissionTime,
        webhook_id: webhookId,
        webhook_event: JSON.parse(body),
      }),
    });
    return json?.verification_status === 'SUCCESS';
  } catch {
    return false;
  }
}

export async function handlePayPalWebhook(event: any): Promise<void> {
  const eventType = event?.event_type;
  const eventId = event?.id;
  if (eventId) {
    const { claimEvent, releaseEvent } = await import('@/lib/credits');
    const claimed = await claimEvent(`paypal:webhook:${eventId}`, eventType || 'unknown');
    if (!claimed) return;
    try {
      await processPayPalEvent(event, eventType);
    } catch (err) {
      await releaseEvent(`paypal:webhook:${eventId}`);
      throw err;
    }
  } else {
    await processPayPalEvent(event, eventType);
  }
}

async function processPayPalEvent(event: any, eventType: string): Promise<void> {
  if (eventType === 'PAYMENT.CAPTURE.COMPLETED') {
    const customId = event?.resource?.custom_id;
    if (customId) {
      const [userId, planId] = customId.split(':');
      if (userId && planId && isValidPlanId(planId)) {
        await activatePlan(userId, planId, {
          source: 'paypal',
          description: `PayPal purchase: ${getPlanConfig(planId).name} plan`,
          idempotencyKey: `paypal:webhook:${event.id}`,
        });
      }
    }
  } else if (eventType === 'BILLING.SUBSCRIPTION.CANCELLED') {
    const subId = event?.resource?.id;
    if (subId) {
      await prisma.subscription.updateMany({
        where: { paypalSubscriptionId: subId },
        data: { status: 'cancelled' },
      }).catch(() => {});
    }
  }
}