import { NextResponse } from 'next/server'
import { analyzeCompetitors } from '@/lib/competitor-scraper'
import { geminiGenerate, isGeminiConfigured } from '@/lib/gemini'
import ZAI from 'z-ai-web-dev-sdk'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { generateOutlineSchema, parseBody } from '@/lib/validation'
import { handleApiError, TaggedError } from '@/lib/api-errors'

let _zai: any = null
async function getZAI() {
  if (!_zai) _zai = await ZAI.create()
  return _zai as any
}

/**
 * POST /api/generate-outline
 *
 * Full 3-step orchestration:
 * 1. Competitor Scraper → fetch top 5 URLs, extract H2/H3 headings
 * 2. Context Prompting → feed scraped data to Gemini, identify gaps
 * 3. Live Fact-Check (optional) → validate claims with Google Search grounding
 *
 * Returns a comprehensive structured article outline to the dashboard.
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit (8 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.generateOutline)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(generateOutlineSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const {
      keyword,
      topic,
      tone = 'professional',
      length = 'medium',
      enableFactCheck = false,
      affiliatePlatform = 'none',
    } = body

    const trimmedKeyword = keyword.trim()
    const startTime = Date.now()

    // ══════════════════════════════════════════
    // STEP 1: Competitor Scraper
    // ══════════════════════════════════════════
    console.log(`[generate-outline] Step 1/3: Scraping competitors for "${trimmedKeyword}"`)
    let competitorData
    try {
      competitorData = await Promise.race([
        analyzeCompetitors(trimmedKeyword),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new TaggedError('scrape_unreachable', 'Competitor scraping timed out', 504, { retryable: true, retryAfter: 10 })),
            25_000
          )
        ),
      ])
    } catch (scrapeError) {
      if (scrapeError instanceof TaggedError) throw scrapeError
      throw new TaggedError(
        'scrape_unreachable',
        scrapeError instanceof Error ? scrapeError.message : 'Scraper error',
        502,
        { retryable: true, retryAfter: 10 }
      )
    }

    const step1Time = Date.now() - startTime
    console.log(`[generate-outline] Step 1 complete in ${step1Time}ms`)

    // ══════════════════════════════════════════
    // STEP 2: Context Prompting → Gemini Outline
    // ══════════════════════════════════════════
    console.log('[generate-outline] Step 2/3: Generating AI outline with context')

    const lengthConfig: Record<string, string> = {
      short: '800-1,200',
      medium: '1,500-2,500',
      long: '3,000-4,000',
    }

    const competitorContext = buildCompetitorContext(competitorData)

    const systemPrompt = buildOutlineSystemPrompt(tone, affiliatePlatform, enableFactCheck)
    const userPrompt = buildOutlineUserPrompt(
      trimmedKeyword,
      topic?.trim(),
      lengthConfig[length] || lengthConfig.medium,
      competitorContext,
      enableFactCheck
    )

    let outlineResult: any

    try {
      if (isGeminiConfigured()) {
        outlineResult = await geminiGenerate(userPrompt, {
          systemInstruction: systemPrompt,
          temperature: 0.7,
          maxOutputTokens: 8192,
          jsonMode: true,
          enableSearchGrounding: enableFactCheck,
        })
      } else {
        const zai = await getZAI()
        const aiResponse = await zai.chat.completions.create({
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
        })
        outlineResult = { text: aiResponse.content || aiResponse.choices?.[0]?.message?.content || '' }
      }
    } catch (aiError) {
      throw new TaggedError(
        'ai_unreachable',
        aiError instanceof Error ? aiError.message : 'AI provider error',
        503,
        { retryable: true, retryAfter: 15 }
      )
    }

    const step2Time = Date.now() - startTime - step1Time
    console.log(`[generate-outline] Step 2 complete in ${step2Time}ms`)

    // Parse outline JSON
    let outline
    try {
      const cleaned = outlineResult.text
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim()
      outline = JSON.parse(cleaned)
    } catch {
      console.error('[generate-outline] JSON parse failed, using fallback')
      outline = generateFallbackOutline(trimmedKeyword, topic, competitorData)
    }

    // ══════════════════════════════════════════
    // STEP 3: Live Fact-Check (optional)
    // ══════════════════════════════════════════
    let factCheckResults: {
      checked: boolean
      claimsChecked?: number
      results?: unknown
      groundedWithGoogleSearch?: boolean
      sources?: unknown
      error?: string
    } | null = null

    if (enableFactCheck) {
      console.log('[generate-outline] Step 3/3: Running live fact-check...')

      const statementsToCheck = extractKeyClaims(outline, trimmedKeyword)

      if (statementsToCheck.length > 0) {
        try {
          const factCheckPrompt = `Fact-check these claims for a ${trimmedKeyword} article. Provide current 2026 data, statistics, and dates for each:

${statementsToCheck.map((s, i) => `${i + 1}. "${s}"`).join('\n')}

For each claim, provide:
- Verdict: ACCURATE / PARTIALLY ACCURATE / OUTDATED / NEEDS UPDATE
- Current Data: The most up-to-date information (2026)
- Recommended Revision: How to rewrite the claim accurately`

          const factResult: { text: string; groundingMetadata?: any } = await (isGeminiConfigured()
            ? geminiGenerate(factCheckPrompt, {
                enableSearchGrounding: true,
                temperature: 0.3,
                systemInstruction:
                  'You are a research fact-checker. Provide verified, current information with specific numbers and dates.',
              })
            : (() => getZAI().then(async (zai) => {
                const r = await zai.chat.completions.create({
                  messages: [
                    { role: 'system', content: 'You are a fact-checker. Verify claims and provide current data.' },
                    { role: 'user', content: factCheckPrompt },
                  ],
                })
                return { text: (r.content || '') as string, groundingMetadata: undefined }
              }))())

          factCheckResults = {
            checked: true,
            claimsChecked: statementsToCheck.length,
            results: factResult.text,
            groundedWithGoogleSearch: isGeminiConfigured() && !!factResult.groundingMetadata,
            sources: factResult.groundingMetadata?.groundingChunks
              ?.map((c: any) => c.web?.title)
              .filter(Boolean) || [],
          }
        } catch (fcError) {
          console.error('[generate-outline] Fact-check failed:', fcError)
          factCheckResults = {
            checked: false,
            error: 'Fact-check could not be completed. Proceed with caution.',
          }
        }
      }

      const step3Time = Date.now() - startTime - step1Time - step2Time
      console.log(`[generate-outline] Step 3 complete in ${step3Time}ms`)
    }

    const totalTime = Date.now() - startTime

    // ══════════════════════════════════════════
    // Return comprehensive result
    // ══════════════════════════════════════════
    return NextResponse.json({
      success: true,
      processingTime: {
        total: totalTime,
        step1_scraping: step1Time,
        step2_outline: step2Time,
        step3_factCheck: enableFactCheck ? totalTime - step1Time - step2Time : 0,
      },
      keyword: trimmedKeyword,
      geminiConfigured: isGeminiConfigured(),
      competitorAnalysis: {
        searchResults: competitorData.searchResults.map((r) => ({
          position: r.position,
          title: r.title,
          url: r.url,
          snippet: r.snippet,
        })),
        headingStructure: competitorData.scrapedPages.map((p) => ({
          url: p.url,
          title: p.title,
          headings: p.headings,
          wordCount: p.wordCount,
        })),
        commonTopics: competitorData.commonTopics,
        uniqueTopics: competitorData.uniqueTopics,
        informationGaps: competitorData.informationGaps,
        averageWordCount: competitorData.averageWordCount,
        pagesAnalyzed: competitorData.scrapedPages.length,
      },
      outline,
      factCheck: factCheckResults,
      usage: outlineResult.usageMetadata,
    })
  } catch (error: unknown) {
    if (error instanceof TaggedError) {
      return handleApiError(error, 'generate-outline')
    }
    return handleApiError(error, 'generate-outline')
  }
}

function buildOutlineSystemPrompt(tone: string, affiliatePlatform: string, enableFactCheck: boolean): string {
  const affiliateNote = affiliatePlatform && affiliatePlatform !== 'none'
    ? `\n- Include [AFFILIATE_LINK:product-name] markers for ${affiliatePlatform} affiliate placements (3-5 natural placements)`
    : ''

  const factCheckNote = enableFactCheck
    ? '\n- Include specific, verifiable claims with data points, statistics, and dates that can be fact-checked'
    : ''

  return `You are an elite SEO content strategist and competitive intelligence analyst. You create article outlines that consistently outrank top-ranking competitors on Google.

OUTPUT: Return a valid JSON object (NO markdown fences, NO preamble):
{
  "suggestedTitle": "string — optimized H1 with primary keyword",
  "metaDescription": "string — 150-160 chars for SEO",
  "informationGainScore": number 0-100,
  "estimatedWordCount": number,
  "sections": [
    {
      "heading": "string — H2",
      "level": 2,
      "purpose": "string — SEO rationale",
      "estimatedWords": number,
      "subsections": [
        {
          "heading": "string — H3",
          "level": 3,
          "keyPoints": ["string"],
          "targetKeywords": ["string"],
          "estimatedWords": number
        }
      ],
      "targetKeywords": ["string"],
      "competitiveAdvantage": "string — why this beats competitors"
    }
  ],
  "targetKeywords": ["string — 5-8 keywords"],
  "relatedKeywords": ["string — 10-15 LSI keywords"],
  "schemaMarkup": "string — Schema.org type",
  "recommendedInternalLinks": ["string"]
}

RULES:
- Write in ${tone || 'professional'} tone
- Cover ALL common competitor topics (better + deeper)
- Fill EVERY information gap competitors miss
- 5-8 H2 sections minimum, each with 2-4 H3 subsections
- Include an FAQ section for long-tail traffic
- Target featured snippet eligibility with direct answers
- Every section needs a competitive advantage explanation${affiliateNote}${factCheckNote}`
}

function buildOutlineUserPrompt(
  keyword: string,
  topic: string | undefined,
  targetLength: string,
  competitorContext: string,
  enableFactCheck: boolean
): string {
  return `Create a comprehensive, competitive article outline for:
- **Keyword**: "${keyword}"
${topic ? `- **Topic/Angle**: "${topic}"` : ''}
- **Target Length**: ${targetLength} words
${enableFactCheck ? '- **Live Fact-Check**: ENABLED — include specific verifiable claims' : ''}

${competitorContext}

ANALYSIS TASKS:
1. Identify what ALL competitors cover (common topics) → cover these BETTER
2. Identify what competitors MISS (information gaps) → fill these gaps
3. Create a UNIQUE angle that no competitor has
4. Structure for maximum SEO impact (featured snippets, People Also Ask, related questions)
5. Optimize the title to beat the current #1 result in CTR

Return ONLY the JSON object. No explanation needed.`
}

function extractKeyClaims(outline: any, keyword: string): string[] {
  const claims: string[] = []

  if (outline?.sections) {
    for (const section of outline.sections) {
      // Extract claims from key points
      if (section.subsections) {
        for (const sub of section.subsections) {
          if (sub.keyPoints) {
            for (const point of sub.keyPoints) {
              if (
                point.match(/\d+%/g) || // Contains percentages
                point.match(/\$\d+/g) || // Contains dollar amounts
                point.match(/\d{4}/g) || // Contains years
                point.match(/studies|research|data|statistics|survey|report/i)
              ) {
                claims.push(point)
              }
            }
          }
        }
      }
    }
  }

  // Ensure at least 2 claims to check
  if (claims.length === 0) {
    claims.push(
      `The ${keyword} market is projected to grow significantly in 2026`,
      `Top-rated ${keyword} products average 4.5+ star reviews across major platforms`
    )
  }

  return claims.slice(0, 5)
}

function buildCompetitorContext(data: any): string {
  let ctx = `## Competitor Analysis for "${data.keyword}"\n\n### Top 5 Ranking URLs:\n`
  for (const r of data.searchResults) {
    ctx += `${r.position}. **${r.title}** — ${r.url}\n   > ${r.snippet}\n\n`
  }

  ctx += `### Extracted Heading Structure:\n`
  for (const page of data.scrapedPages) {
    ctx += `\n**${page.title}** (${page.url}) — ~${page.wordCount} words\n`
    for (const h of page.headings) {
      ctx += `  ${'  '.repeat(h.level - 2)}${'H' + h.level}: ${h.text}\n`
    }
  }

  ctx += `\n### Common Topics (2+ competitors): ${data.commonTopics.join(', ')}\n`
  ctx += `### Information Gaps (NONE cover): ${data.informationGaps.join(', ')}\n`
  ctx += `### Avg Word Count: ${data.averageWordCount}\n`

  return ctx
}

function generateFallbackOutline(keyword: string, topic: string | undefined, data: any): any {
  const cap = keyword.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
  const sections = [
    {
      heading: `What is ${cap}?`,
      level: 2, purpose: 'Topical authority + featured snippet',
      estimatedWords: 250,
      subsections: [
        { heading: 'Definition & Market Overview', level: 3, keyPoints: [`Clear explanation of ${keyword}`, '2026 market landscape'], targetKeywords: [keyword], estimatedWords: 150 },
      ],
      targetKeywords: [keyword], competitiveAdvantage: 'More comprehensive than competitors',
    },
    {
      heading: `Best ${cap} in 2026`,
      level: 2, purpose: 'Primary product-focused section',
      estimatedWords: 500,
      subsections: [
        { heading: 'Best Overall', level: 3, keyPoints: ['Top pick with justification'], targetKeywords: [`best ${keyword}`], estimatedWords: 200 },
        { heading: 'Best Value', level: 3, keyPoints: ['Budget pick'], targetKeywords: [`affordable ${keyword}`], estimatedWords: 200 },
      ],
      targetKeywords: [`best ${keyword}`, `${keyword} 2026`],
      competitiveAdvantage: 'Includes unique picks not in competitor articles',
    },
  ]

  for (const gap of data.informationGaps.slice(0, 3)) {
    sections.push({
      heading: gap.split(' ').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
      level: 2, purpose: `Fill competitor gap`,
      estimatedWords: 200,
      subsections: [
        { heading: 'Key Insights', level: 3, keyPoints: [`Analysis of ${gap}`], targetKeywords: [`${keyword} ${gap}`], estimatedWords: 200 },
      ],
      targetKeywords: [`${keyword} ${gap}`],
      competitiveAdvantage: `No competitor covers "${gap}"`,
    })
  }

  return {
    suggestedTitle: topic ? `${cap}: ${topic} — 2026 Guide` : `The Ultimate ${cap} Guide 2026`,
    metaDescription: `Discover the best ${keyword} in 2026. Expert reviews, comparisons, and buying advice.`,
    informationGainScore: 60 + data.informationGaps.length * 5,
    estimatedWordCount: 1800,
    sections,
    targetKeywords: [keyword, `best ${keyword}`, `${keyword} review`, `${keyword} 2026`, `buy ${keyword}`],
    relatedKeywords: [`${keyword} guide`, `${keyword} comparison`, `${keyword} tips`, `${keyword} vs`, `top ${keyword}`],
    schemaMarkup: 'Article',
    recommendedInternalLinks: ['related guides', 'comparisons'],
  }
}
