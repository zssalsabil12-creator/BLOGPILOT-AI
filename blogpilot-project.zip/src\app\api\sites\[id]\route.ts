﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { testWordPressConnection } from '@/lib/wordpress';
import { encrypt } from '@/lib/encryption';

const updateSiteSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  url: z.string().min(1).max(500).optional(),
  platform: z.enum(['WordPress', 'Webhook', 'Custom']).optional(),
  apiKey: z.string().max(500).optional().nullable(),
  username: z.string().max(200).optional().nullable(),
  isActive: z.boolean().optional(),
  automationLevel: z.enum(['assist', 'review', 'autopilot']).optional(),
});

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const site = await prisma.connectedSite.findFirst({ where: { id, userId } });
    if (!site) return NextResponse.json({ ok: false, error: 'Site not found' }, { status: 404 });

    return NextResponse.json({
      ok: true,
      data: {
        site: {
          id: site.id,
          name: site.name,
          url: site.url,
          platform: site.platform,
          username: site.username,
          hasApiKey: !!site.apiKey,
          isActive: site.isActive,
          lastSyncAt: site.lastSyncAt,
          createdAt: site.createdAt,
        },
      },
    });
  } catch (error: any) {
    console.error('Get site error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load site' }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = updateSiteSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const existing = await prisma.connectedSite.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Site not found' }, { status: 404 });

    const data: any = { ...parsed.data };

    const platform = data.platform || existing.platform;
    if (data.platform || data.url || data.apiKey !== undefined || data.username !== undefined) {
      if (platform === 'WordPress') {
        const result = await testWordPressConnection({
          url: data.url || existing.url,
          username: data.username === undefined ? existing.username : data.username,
          apiKey: data.apiKey === undefined ? existing.apiKey : data.apiKey,
        });
        data.isActive = result.ok;
      } else {
        data.isActive = true;
      }
    }

    if (data.apiKey !== undefined && data.apiKey !== null) {
      data.apiKey = encrypt(data.apiKey);
    }

    const site = await prisma.connectedSite.update({ where: { id }, data });

    return NextResponse.json({
      ok: true,
      data: {
        site: {
          id: site.id,
          name: site.name,
          url: site.url,
          platform: site.platform,
          username: site.username,
          hasApiKey: !!site.apiKey,
          isActive: site.isActive,
          lastSyncAt: site.lastSyncAt,
          createdAt: site.createdAt,
        },
      },
    });
  } catch (error: any) {
    console.error('Update site error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to update site' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const existing = await prisma.connectedSite.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Site not found' }, { status: 404 });

    await prisma.article.updateMany({ where: { siteId: id }, data: { siteId: null } });
    await prisma.connectedSite.delete({ where: { id } });

    return NextResponse.json({ ok: true, data: { deleted: true, id } });
  } catch (error: any) {
    console.error('Delete site error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to delete site' }, { status: 500 });
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const site = await prisma.connectedSite.findFirst({ where: { id, userId } });
    if (!site) return NextResponse.json({ ok: false, error: 'Site not found' }, { status: 404 });

    if (site.platform !== 'WordPress') {
      await prisma.connectedSite.update({ where: { id }, data: { isActive: true } });
      return NextResponse.json({ ok: true, data: { ok: true, message: 'Site is active.' } });
    }

    const result = await testWordPressConnection({
      url: site.url,
      username: site.username,
      apiKey: site.apiKey,
    });

    await prisma.connectedSite.update({ where: { id }, data: { isActive: result.ok } });

    return NextResponse.json({ ok: true, data: { ok: result.ok, message: result.message } });
  } catch (error: any) {
    console.error('Test site connection error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to test connection' }, { status: 500 });
  }
}