import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { getValidAccessToken, listBloggerBlogs } from '@/lib/google-oauth';
import { apiError } from '@/lib/utils';

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    const accessToken = await getValidAccessToken(userId);
    if (!accessToken) {
      return NextResponse.json({ ok: false, error: 'Google account not connected' }, { status: 404 });
    }

    const blogs = await listBloggerBlogs(accessToken);
    return NextResponse.json({ ok: true, data: { blogs } });
  } catch (err) {
    return apiError('blogger/blogs', err);
  }
}
