'use client';

import { useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Plus, Trash2, Copy, Check, RotateCcw, FileJson } from 'lucide-react';

interface QAPair {
  id: number;
  question: string;
  answer: string;
}

let nextId = 3;

export default function FAQSchemaGeneratorPage() {
  const [pairs, setPairs] = useState<QAPair[]>([
    { id: 1, question: '', answer: '' },
    { id: 2, question: '', answer: '' },
  ]);
  const [output, setOutput] = useState('');
  const [jsonOnly, setJsonOnly] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [error, setError] = useState('');

  const addPair = () => {
    setPairs([...pairs, { id: nextId++, question: '', answer: '' }]);
  };

  const removePair = (id: number) => {
    if (pairs.length <= 1) return;
    setPairs(pairs.filter((p) => p.id !== id));
  };

  const updatePair = (id: number, field: 'question' | 'answer', value: string) => {
    setPairs(pairs.map((p) => (p.id === id ? { ...p, [field]: value } : p)));
  };

  const generate = () => {
    setError('');
    const validPairs = pairs.filter((p) => p.question.trim() && p.answer.trim());
    if (validPairs.length === 0) {
      setError('Please fill in at least one Question and Answer pair.');
      return;
    }

    const schema = {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: validPairs.map((p) => ({
        '@type': 'Question',
        name: p.question.trim(),
        acceptedAnswer: {
          '@type': 'Answer',
          text: p.answer.trim(),
        },
      })),
    };

    const jsonStr = JSON.stringify(schema, null, 2);
    const scriptTag = `<script type="application/ld+json">\n${jsonStr}\n</script>`;

    setOutput(scriptTag);
    setJsonOnly(jsonStr);
  };

  const copyToClipboard = async (text: string, type: 'script' | 'json') => {
    await navigator.clipboard.writeText(text);
    if (type === 'script') {
      setCopiedScript(true);
      setTimeout(() => setCopiedScript(false), 2000);
    } else {
      setCopiedJson(true);
      setTimeout(() => setCopiedJson(false), 2000);
    }
  };

  const reset = () => {
    setPairs([
      { id: 1, question: '', answer: '' },
      { id: 2, question: '', answer: '' },
    ]);
    setOutput('');
    setJsonOnly('');
    setError('');
  };

  const previewPairs = pairs.filter((p) => p.question.trim() || p.answer.trim());

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="space-y-4">
            {pairs.map((pair, index) => (
              <div key={pair.id} className="rounded-xl border border-border bg-muted/50 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">Q&A Pair {index + 1}</span>
                  <button
                    onClick={() => removePair(pair.id)}
                    disabled={pairs.length <= 1}
                    className="p-1.5 rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-500/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <input
                  type="text"
                  placeholder="Question"
                  value={pair.question}
                  onChange={(e) => updatePair(pair.id, 'question', e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <textarea
                  placeholder="Answer"
                  value={pair.answer}
                  onChange={(e) => updatePair(pair.id, 'answer', e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                />
              </div>
            ))}

            <button
              onClick={addPair}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-foreground/50 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add Question
            </button>
          </div>

          {previewPairs.length > 0 && (
            <div className="mt-4 rounded-xl border border-border bg-muted/50 p-4">
              <h3 className="text-sm font-medium text-foreground mb-2">Preview</h3>
              <div className="space-y-2">
                {previewPairs.map((p) => (
                  <div key={p.id} className="text-sm">
                    <p className="font-medium text-foreground">Q: {p.question || <span className="text-muted-foreground italic">Empty</span>}</p>
                    <p className="text-muted-foreground">A: {p.answer || <span className="italic">Empty</span>}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && <p className="text-sm text-red-500 mt-3">{error}</p>}

          <div className="flex gap-3 mt-4">
            <button
              onClick={generate}
              className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
            >
              Generate Schema
            </button>
            <button
              onClick={reset}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
          </div>
        </div>

        {output && (
          <div className="space-y-4">
            <div className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                  <FileJson className="w-4 h-4" /> JSON-LD Script Tag
                </h3>
                <button
                  onClick={() => copyToClipboard(output, 'script')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                  {copiedScript ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedScript ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">
                {output}
              </pre>
            </div>

            <div className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                  <FileJson className="w-4 h-4" /> JSON Object
                </h3>
                <button
                  onClick={() => copyToClipboard(jsonOnly, 'json')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                  {copiedJson ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedJson ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">
                {jsonOnly}
              </pre>
            </div>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
