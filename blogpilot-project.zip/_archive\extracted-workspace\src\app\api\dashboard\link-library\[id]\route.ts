import { NextResponse } from 'next/server';
import { z } from 'zod';
import { deleteLink, getLinkById, updateLink, LINK_TYPES } from '../../../../../lib/linkLibrary';
import { getCurrentUserId } from '../../../../../lib/auth';

const updateLinkSchema = z.object({
  url: z.string().url().optional(),
  title: z.string().max(200).optional(),
  description: z.string().max(2000).optional(),
  category: z.string().max(100).optional(),
  linkType: z.enum(LINK_TYPES).optional(),
  affiliate: z.boolean().optional(),
  affiliateProvider: z.string().max(100).optional().nullable(),
  anchorText: z.string().max(100).optional().nullable(),
  targetKeyword: z.string().max(100).optional().nullable(),
  preferredPlacement: z.string().max(100).optional().nullable(),
  active: z.boolean().optional(),
  productInfo: z.any().optional().nullable(),
});

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const resolvedParams = await params;
  const link = await getLinkById(userId, resolvedParams.id);
  if (!link) return NextResponse.json({ ok: false, error: 'Link not found' }, { status: 404 });
  return NextResponse.json({ ok: true, data: { link } });
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch (error) {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = updateLinkSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid update payload', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const resolvedParams = await params;
    const updated = await updateLink(userId, resolvedParams.id, parsed.data);
    if (!updated) return NextResponse.json({ ok: false, error: 'Link not found' }, { status: 404 });
    return NextResponse.json({ ok: true, data: { link: updated } });
  } catch (error: any) {
    return NextResponse.json({ ok: false, error: error?.message || 'Failed to update link' }, { status: 400 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const resolvedParams = await params;
  const deleted = await deleteLink(userId, resolvedParams.id);
  if (!deleted) return NextResponse.json({ ok: false, error: 'Link not found' }, { status: 404 });
  return NextResponse.json({ ok: true, data: { deleted: true } });
}
