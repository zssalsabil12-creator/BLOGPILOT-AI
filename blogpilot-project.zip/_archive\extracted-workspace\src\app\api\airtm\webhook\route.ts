import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { activateSubscription, type PlanTier } from '@/lib/stripe'
import { parseAirtmReference, verifyAirtmCallback, isAirtmConfigured } from '@/lib/airtm'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/airtm/webhook
 *
 * Webhook endpoint called by Airtm after a payment is confirmed or failed.
 *
 * Airtm POSTs form-encoded or JSON data with:
 *   reference  — the payment reference we generated at checkout
 *   amount     — the paid amount
 *   currency   — "USD"
 *   status     — "completed" | "failed" | "pending"
 *   signature  — HMAC-SHA256 for verification
 *
 * On successful payment (status === "completed"):
 *   1. Verify the webhook signature using AIRTM_API_TOKEN
 *   2. Parse the reference to extract userId + tier
 *   3. Call activateSubscription() to flip the user's plan to active
 *      and grant monthly credits
 *
 * Funds routing:
 *   By the time this webhook fires, the money has already been deposited
 *   into the admin's Airtm account (ADMIN_AIRTM_EMAIL). The webhook is
 *   purely for confirmation and subscription activation.
 */
export async function POST(request: Request) {
  try {
    // ─── Verify configured ───
    if (!isAirtmConfigured()) {
      return NextResponse.json(
        { error: 'Airtm not configured', code: 'not_configured' },
        { status: 503 }
      )
    }

    // ─── Parse payload ───
    let payload: Record<string, unknown> = {}

    const contentType = request.headers.get('content-type') || ''
    if (contentType.includes('application/json')) {
      payload = await request.json().catch(() => ({}))
    } else {
      // Form-encoded fallback
      const text = await request.text().catch(() => '')
      const params = new URLSearchParams(text)
      for (const [key, value] of params.entries()) {
        payload[key] = value
      }
    }

    const reference = payload.reference as string | undefined
    const amount = payload.amount as string | undefined
    const currency = payload.currency as string | undefined
    const status = payload.status as string | undefined
    const signature = payload.signature as string | undefined

    // ─── Verify signature ───
    const verification = verifyAirtmCallback({
      reference,
      amount,
      currency,
      status,
      signature,
    })

    if (!verification.valid) {
      console.warn(
        `[airtm:webhook] Signature verification failed: ${verification.reason}`,
        { reference, status }
      )
      return NextResponse.json(
        { error: 'Invalid signature', code: 'auth' },
        { status: 401 }
      )
    }

    // ─── Handle payment status ───
    if (status !== 'completed' && status !== 'COMPLETED') {
      console.info(`[airtm:webhook] Payment not completed — status: ${status}`, { reference })
      return NextResponse.json({ received: true, status })
    }

    if (!reference) {
      return NextResponse.json(
        { error: 'Missing reference', code: 'validation' },
        { status: 400 }
      )
    }

    // ─── Parse reference → userId + tier ───
    const parsed = parseAirtmReference(reference)
    if (!parsed.userId || !parsed.tier) {
      console.error(`[airtm:webhook] Could not parse reference: ${reference}`)
      return NextResponse.json(
        { error: 'Invalid reference format', code: 'validation' },
        { status: 400 }
      )
    }

    // ─── Activate subscription ───
    const result = await activateSubscription({
      userId: parsed.userId,
      tier: parsed.tier as PlanTier,
      gateway: 'airtm',
      externalId: reference,
    })

    if (!result.ok) {
      console.error(
        `[airtm:webhook] Failed to activate subscription for ${parsed.userId}: ${result.error}`
      )
      return NextResponse.json(
        { error: 'Subscription activation failed', code: 'internal' },
        { status: 500 }
      )
    }

    console.info(
      `[airtm:webhook] Activated ${parsed.tier} plan for ${parsed.userId} ` +
      `(${result.action}, ${result.creditsGranted ?? 'unlimited'} credits)`
    )

    return NextResponse.json({
      received: true,
      activated: true,
      tier: parsed.tier,
      userId: parsed.userId,
      creditsGranted: result.creditsGranted,
    })
  } catch (e) {
    return handleApiError(e, 'airtm/webhook')
  }
}
