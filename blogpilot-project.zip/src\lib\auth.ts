import crypto from 'node:crypto';
import prisma from '@/lib/prisma';

export interface AuthUser {
  id: string;
  email?: string | null;
  name?: string | null;
  credits?: number;
  subscription?: {
    plan: string;
    status: string;
    stripeSubscriptionId?: string | null;
    paypalSubscriptionId?: string | null;
  } | null;
}

function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret) {
    throw new Error('AUTH_SECRET environment variable is required. Set it in .env.local');
  }
  return secret;
}

const COOKIE_NAME = 'auth_session';

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `${salt}:${derivedKey.toString('hex')}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const [salt, key] = storedHash.split(':');
    if (!salt || !key) return false;
    const derivedKey = crypto.scryptSync(password, salt, 64);
    const keyBuffer = Buffer.from(key, 'hex');
    return crypto.timingSafeEqual(derivedKey, keyBuffer);
  } catch {
    return false;
  }
}

export function createSessionToken(payload: { userId: string; email?: string | null; name?: string | null }): string {
  const secret = getAuthSecret();
  const data = JSON.stringify({
    ...payload,
    exp: Date.now() + 30 * 24 * 60 * 60 * 1000,
  });
  const encoded = Buffer.from(data).toString('base64url');
  const signature = crypto.createHmac('sha256', secret).update(encoded).digest('base64url');
  return `${encoded}.${signature}`;
}

export function verifySessionToken(token: string): { userId: string; email?: string | null; name?: string | null } | null {
  try {
    const secret = getAuthSecret();
    const [encoded, signature] = token.split('.');
    if (!encoded || !signature) return null;
    const expectedSignature = crypto.createHmac('sha256', secret).update(encoded).digest('base64url');

    const sigBuf = Buffer.from(signature, 'base64url');
    const expectedBuf = Buffer.from(expectedSignature, 'base64url');
    if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) return null;

    const data = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
    if (data.exp && Date.now() > data.exp) return null;
    return { userId: data.userId, email: data.email, name: data.name };
  } catch {
    return null;
  }
}

function parseCookie(req: Request, name: string): string | null {
  const cookieHeader = req.headers.get('cookie');
  if (!cookieHeader) return null;
  const match = cookieHeader.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

function hashToken(token: string): string {
  return crypto.createHmac('sha256', getAuthSecret()).update(token).digest('hex');
}

/**
 * Server-side session revocation. Sessions are HMAC-signed and stateless;
 * logout records the token hash here so it is rejected everywhere afterwards:
 * getCurrentUserId checks a short-TTL cache of this table, and
 * getAuthenticatedUserId/getCurrentUser query it directly.
 */
export async function revokeSessionToken(token: string): Promise<void> {
  const payload = verifySessionToken(token);
  if (!payload) return;

  const expMs = (() => {
    try {
      const data = JSON.parse(Buffer.from(token.split('.')[0], 'base64url').toString('utf8'));
      return typeof data.exp === 'number' ? data.exp : Date.now() + 30 * 24 * 60 * 60 * 1000;
    } catch {
      return Date.now() + 30 * 24 * 60 * 60 * 1000;
    }
  })();

  await prisma.revokedSession.create({
    data: {
      tokenHash: hashToken(token),
      expiresAt: new Date(expMs),
    },
  }).catch((err: any) => {
    if (err?.code !== 'P2002') throw err;
    // Already revoked.
  });

  // Opportunistic cleanup of expired revocations (keeps the table small).
  if (Math.random() < 0.05) {
    await prisma.revokedSession.deleteMany({ where: { expiresAt: { lt: new Date() } } }).catch(() => {});
  }
}

async function isSessionRevoked(token: string): Promise<boolean> {
  const row = await prisma.revokedSession.findUnique({
    where: { tokenHash: hashToken(token) },
    select: { id: true },
  });
  return !!row;
}

/**
 * Process-local cache of recently revoked session hashes.
 *
 * `getCurrentUserId` is synchronous and used by ~50 routes; querying the DB on
 * every request would require a breaking async refactor. Instead we refresh a
 * revocation set at most once per REVOCATION_CACHE_TTL_MS from the DB, so a
 * logged-out token is rejected within seconds on this instance (and within
 * TTL across instances). This closes the previous gap where revoked tokens
 * were accepted forever until natural expiry.
 */
const REVOCATION_CACHE_TTL_MS = 60_000;
let revokedHashCache: Set<string> = new Set();
let revokedCacheLoadedAt = 0;

function getRevokedHashSet(): Set<string> {
  const now = Date.now();
  if (now - revokedCacheLoadedAt > REVOCATION_CACHE_TTL_MS) {
    revokedCacheLoadedAt = now;
    prisma.revokedSession
      .findMany({
        where: { expiresAt: { gt: new Date() } },
        select: { tokenHash: true },
      })
      .then(rows => {
        revokedHashCache = new Set(rows.map(r => r.tokenHash));
      })
      .catch(() => {
        // On failure keep serving the stale set (fail-closed for known hashes).
      });
  }
  return revokedHashCache;
}

function isTokenKnownRevoked(token: string): boolean {
  return getRevokedHashSet().has(hashToken(token));
}

export function getCurrentUserId(req?: Request): string | null {
  if (req) {
    const candidates: string[] = [];
    const auth = req.headers.get('authorization');
    if (auth && auth.startsWith('Bearer ')) candidates.push(auth.slice(7).trim());

    const cookieToken = parseCookie(req, COOKIE_NAME);
    if (cookieToken) candidates.push(cookieToken);

    for (const token of candidates) {
      const verified = verifySessionToken(token);
      if (verified && !isTokenKnownRevoked(token)) return verified.userId;
    }
  }

  return null;
}

/**
 * Authenticated user resolution WITH server-side revocation check.
 * Routes that must honor logout use this (or getCurrentUser).
 */
export async function getAuthenticatedUserId(req?: Request): Promise<string | null> {
  const token = (() => {
    const auth = req?.headers.get('authorization');
    if (auth && auth.startsWith('Bearer ')) return auth.slice(7).trim();
    return req ? parseCookie(req, COOKIE_NAME) : null;
  })();
  if (!token) return null;

  if (!verifySessionToken(token)) return null;
  if (await isSessionRevoked(token)) return null;
  const payload = verifySessionToken(token);
  return payload ? payload.userId : null;
}

export async function getCurrentUser(req?: Request): Promise<AuthUser | null> {
  const id = await getAuthenticatedUserId(req);
  if (!id) return null;

  try {
    const user = await prisma.user.findUnique({
      where: { id },
      include: { subscription: true },
    });

    if (user) {
      return {
        id: user.id,
        email: user.email,
        name: user.name,
        credits: user.credits,
        subscription: user.subscription ? {
          plan: user.subscription.plan,
          status: user.subscription.status,
          stripeSubscriptionId: user.subscription.stripeSubscriptionId,
          paypalSubscriptionId: user.subscription.paypalSubscriptionId,
        } : null,
      };
    }
  } catch (err) {
    console.error('Error fetching current user:', err);
  }

  return null;
}

export { COOKIE_NAME };
