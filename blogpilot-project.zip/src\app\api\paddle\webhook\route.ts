import { NextResponse } from 'next/server';
import { verifyPaddleWebhook, handlePaddleEvent, isPaddleConfigured } from '@/lib/paddle';

/**
 * Paddle webhook receiver. Public endpoint — authenticity is guaranteed by
 * the HMAC-SHA256 `Paddle-Signature` header verified against
 * PADDLE_WEBHOOK_SECRET before any processing.
 */
export async function POST(req: Request) {
  if (!isPaddleConfigured()) {
    return NextResponse.json({ ok: false, error: 'Paddle is not configured' }, { status: 501 });
  }

  const signature = req.headers.get('paddle-signature');
  if (!signature) {
    return NextResponse.json({ ok: false, error: 'Missing Paddle signature' }, { status: 400 });
  }

  // Raw body is required for signature verification — no JSON re-serialization.
  const body = await req.text();
  const event = verifyPaddleWebhook(body, signature);
  if (!event) {
    return NextResponse.json({ ok: false, error: 'Invalid Paddle signature' }, { status: 400 });
  }

  try {
    await handlePaddleEvent(event);
  } catch (error: any) {
    console.error('Paddle webhook handler error:', error?.message || error);
    return NextResponse.json({ ok: false, error: 'Webhook handling failed' }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}
