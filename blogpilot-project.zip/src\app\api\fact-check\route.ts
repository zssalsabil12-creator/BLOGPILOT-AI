﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { generateText } from '@/lib/gemini';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { apiError } from '@/lib/utils';
import { checkTextLength } from '@/lib/input-limits';

const bodySchema = z.object({
  content: z.string().min(50).max(50000),
  title: z.string().max(300).optional(),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const ip = getClientIp(req);
  const rl = await checkRateLimit(`fact-check:${userId}:${ip}`, RATE_LIMITS.generate);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON payload' }, { status: 400 });
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const contentSizeCheck = checkTextLength(parsed.data.content);
  if (!contentSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: contentSizeCheck.error }, { status: 413 });
  }

  const { content, title } = parsed.data;

  const prompt = `You are a fact-checking expert. Analyze the following article${title ? ` titled "${title}"` : ''} and identify factual claims that may need verification.

Article content:
${content.slice(0, 15000)}

Return a JSON object with exactly this structure:
{
  "overallScore": 85,
  "claims": [
    {
      "text": "The specific claim found in the article",
      "assessment": "likely_true | likely_false | unverified | needs_context",
      "confidence": "high | medium | low",
      "explanation": "Brief explanation of the assessment"
    }
  ],
  "suggestions": ["Suggestion 1 for improvement", "Suggestion 2"]
}

Focus on the 5-10 most important factual claims. Return ONLY valid JSON, no markdown.`;

  try {
    const result = await generateText(prompt, 3000);
    let parsed;
    try {
      const cleaned = result.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      parsed = JSON.parse(cleaned);
    } catch {
      parsed = {
        overallScore: null,
        claims: [],
        suggestions: ['Unable to parse fact-check results. The AI response may need manual review.'],
        rawText: result,
      };
    }

    return NextResponse.json({ ok: true, data: parsed });
  } catch (err) {
    return apiError('fact-check', err);
  }
}
