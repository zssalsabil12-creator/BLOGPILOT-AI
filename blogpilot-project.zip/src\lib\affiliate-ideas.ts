/**
 * Commercial Content Cluster generator.
 *
 * For an affiliate campaign, proposes the cluster of commercial + supporting
 * articles around the product (reviews, comparisons, alternatives, best-X,
 * buying guide, informational support pieces). One cached AI call.
 */

import { generateText, isGeminiConfigured } from './gemini';
import { cacheGet, cacheSet, hashKeyParts } from './cache';

export interface ClusterIdea {
  title: string;
  type: 'review' | 'comparison' | 'alternatives' | 'best-x' | 'beginners' | 'buying-guide' | 'informational';
  intent: 'commercial' | 'transactional' | 'informational';
  keyword: string;
  angle: string;
  affiliateFit: 'primary' | 'secondary' | 'support';
}

export interface CampaignIdeas {
  productName: string;
  ideas: ClusterIdea[];
  aiPowered: boolean;
  note?: string;
}

const FALLBACK_TEMPLATES: Array<Omit<ClusterIdea, 'title' | 'keyword'>> = [
  { type: 'review', intent: 'commercial', angle: 'Hands-on review covering strengths, weaknesses, and who should buy.', affiliateFit: 'primary' },
  { type: 'best-x', intent: 'commercial', angle: 'Roundup where the product competes — position honestly within a stronger list.', affiliateFit: 'primary' },
  { type: 'comparison', intent: 'commercial', angle: 'Head-to-head vs the closest competitor with a clear verdict table.', affiliateFit: 'primary' },
  { type: 'alternatives', intent: 'commercial', angle: 'Alternatives list capturing buyers comparing options before purchase.', affiliateFit: 'secondary' },
  { type: 'beginners', intent: 'informational', angle: 'Beginner guide feeding top-of-funnel traffic into the cluster.', affiliateFit: 'support' },
  { type: 'buying-guide', intent: 'transactional', angle: 'Buying guide answering pre-purchase questions with criteria-based picks.', affiliateFit: 'primary' },
  { type: 'informational', intent: 'informational', angle: 'How-it-works explainer building topical authority around the product space.', affiliateFit: 'support' },
];

export async function generateCampaignIdeas(campaign: {
  productName: string;
  targetAudience?: string | null;
  country?: string | null;
  intent?: string | null;
}): Promise<CampaignIdeas> {
  const digest = hashKeyParts(campaign.productName, campaign.targetAudience || '', campaign.country || '');
  const key = `campideas:v1:${digest}`;
  const cached = await cacheGet<{ ideas: ClusterIdea[]; aiPowered: boolean }>(key);
  if (cached) return { productName: campaign.productName, ...cached };

  if (!isGeminiConfigured()) {
    return {
      productName: campaign.productName,
      aiPowered: false,
      note: 'Heuristic template cluster (AI unavailable).',
      ideas: FALLBACK_TEMPLATES.map(t => ({
        ...t,
        title: buildTitleFromTemplate(t.type, campaign.productName),
        keyword: `${campaign.productName} ${t.type}`.toLowerCase(),
      })),
    };
  }

  const prompt = `You are an affiliate content strategist. Product: "${campaign.productName}".
Audience: ${campaign.targetAudience || 'general buyers'}. Country: ${campaign.country || 'global'}.

Design the content cluster that ranks AND converts. Return ONLY raw JSON:
{
  "ideas": [
    { "title": "<specific article title>",
      "type": "review|comparison|alternatives|best-x|beginners|buying-guide|informational",
      "intent": "commercial|transactional|informational",
      "keyword": "<primary keyword>",
      "angle": "<one-sentence unique angle that beats current results>",
      "affiliateFit": "primary|secondary|support" }
  ]
}
Rules: exactly 7 items covering all types above. Titles must be specific (include model/brand/year where natural). No generic filler.`;

  try {
    const out = await generateText(prompt, 1100);
    const cleaned = out.replace(/^```(?:json)?/m, '').replace(/```\s*$/m, '').trim();
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    const parsed = JSON.parse(cleaned.slice(start, end + 1));
    const validTypes: Set<string> = new Set(FALLBACK_TEMPLATES.map(t => t.type));
    const ideas: ClusterIdea[] = (parsed.ideas || [])
      .filter((i: any) => i && i.title && i.keyword)
      .slice(0, 7)
      .map((i: any) => ({
        title: String(i.title),
        type: (validTypes.has(String(i.type)) ? String(i.type) : 'informational') as ClusterIdea['type'],
        intent: (['commercial', 'transactional', 'informational'].includes(String(i.intent)) ? String(i.intent) : 'commercial') as ClusterIdea['intent'],
        keyword: String(i.keyword),
        angle: String(i.angle || ''),
        affiliateFit: (['primary', 'secondary', 'support'].includes(String(i.affiliateFit)) ? String(i.affiliateFit) : 'secondary') as ClusterIdea['affiliateFit'],
      }));

    if (ideas.length === 0) throw new Error('empty');
    const result = { ideas, aiPowered: true };
    await cacheSet(key, result, 24 * 3600);
    return { productName: campaign.productName, ...result };
  } catch {
    return {
      productName: campaign.productName,
      aiPowered: false,
      note: 'AI generation failed — showing heuristic template cluster.',
      ideas: FALLBACK_TEMPLATES.map(t => ({
        ...t,
        title: buildTitleFromTemplate(t.type, campaign.productName),
        keyword: `${campaign.productName} ${t.type}`.toLowerCase(),
      })),
    };
  }
}

function buildTitleFromTemplate(type: string, product: string): string {
  switch (type) {
    case 'review': return `${product} Review: Is It Worth It?`;
    case 'best-x': return `Best Alternatives to ${product}`;
    case 'comparison': return `${product} vs Competitors: Honest Comparison`;
    case 'alternatives': return `Top Alternatives to ${product} in ${new Date().getFullYear()}`;
    case 'beginners': return `${product} for Beginners: Getting Started`;
    case 'buying-guide': return `${product} Buying Guide`;
    default: return `How ${product}-Style Products Work`;
  }
}
