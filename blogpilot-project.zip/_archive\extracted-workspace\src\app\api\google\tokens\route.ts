import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { getGoogleTokensForUser, deleteGoogleToken } from '@/lib/google-oauth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * GET /api/google/tokens
 *
 * Lists the user's connected Google accounts.
 * Access tokens and refresh tokens are NEVER returned — only metadata.
 *
 * Response:
 *   200 {
 *     accounts: Array<{
 *       id: string
 *       googleEmail: string
 *       status: string
 *       isActive: boolean
 *       expiresAt: string | null
 *       lastRefreshedAt: string | null
 *       lastUsedAt: string | null
 *       scopes: string
 *       services: string
 *       createdAt: string
 *     }>
 *   }
 */
export async function GET(request: Request) {
  try {
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const tokens = await getGoogleTokensForUser(user.id)

    // Return only metadata — NEVER expose access/refresh tokens
    const accounts = tokens.map((t) => ({
      id: t.id,
      googleEmail: t.googleEmail,
      status: t.status,
      isActive: t.isActive,
      expiresAt: t.expiresAt,
      lastRefreshedAt: t.lastRefreshedAt,
      lastUsedAt: t.lastUsedAt,
      scopes: t.scope,
      services: t.services,
      createdAt: t.createdAt,
    }))

    return NextResponse.json({ accounts })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'google/tokens')
  }
}

/**
 * DELETE /api/google/tokens
 *
 * Disconnects a Google account by deleting its stored tokens.
 *
 * Body:
 *   { id: string }
 *
 * Response:
 *   200 { success: true, message: string }
 *   400 if id is missing
 *   404 if the token doesn't belong to this user
 */
export async function DELETE(request: Request) {
  try {
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => ({}))
    const id = raw.id as string | undefined

    if (!id || typeof id !== 'string' || id.trim().length === 0) {
      return NextResponse.json(
        { error: 'Token ID is required', code: 'validation' },
        { status: 400 }
      )
    }

    const deleted = await deleteGoogleToken(id.trim(), user.id)

    if (!deleted) {
      return NextResponse.json(
        { error: 'Google token not found or does not belong to you', code: 'not_found' },
        { status: 404 }
      )
    }

    console.info(`[google:tokens] User ${user.id} disconnected Google account (token ${id})`)

    return NextResponse.json({
      success: true,
      message: 'Google account disconnected successfully.',
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'google/tokens')
  }
}
