﻿import { NextResponse } from 'next/server';

const startTime = Date.now();

export async function GET() {
  try {
    const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);

    return NextResponse.json({
      ok: true,
      status: 'healthy',
      uptime_seconds: uptimeSeconds,
    });
  } catch {
    return NextResponse.json({
      ok: false,
      status: 'error',
    }, { status: 500 });
  }
}
