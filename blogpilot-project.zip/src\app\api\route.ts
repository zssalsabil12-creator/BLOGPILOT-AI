﻿import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    ok: true,
    name: 'BlogPilot AI API',
    version: '1.0.0',
    routes: {
      freeTools: '/api/free-tools/analyze',
      generate: '/api/generate',
      linkLibrary: '/api/dashboard/link-library',
      health: '/api/health',
    },
    timestamp: new Date().toISOString(),
  });
}
