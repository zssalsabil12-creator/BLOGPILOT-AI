'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Layers,
  GitMerge,
  RefreshCw,
  Search,
  Loader2,
  AlertTriangle,
  CheckCircle,
  PenTool,
  Map as MapIcon,
  Target,
  TrendingDown,
  FileQuestion,
  Sparkles,
  Link2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore, type DashboardTab } from '@/lib/store'

// ── Types ────────────────────────────────────────────────────────────────────

interface Cluster {
  name: string
  pillar: { title: string; keyword: string | null; articleId: string | null } | null
  members: Array<{ articleId: string; title: string; keyword: string | null; status: string; seoScore: number | null }>
  missingSubtopics: string[]
  coverage: 'strong' | 'partial' | 'thin'
}

interface CannibalizationIssue {
  keywords: string[]
  articles: Array<{ articleId: string; title: string; status: string }>
  recommendation: 'merge' | 're-target' | 'differentiate'
  detail: string
}

interface RoadmapItem {
  title: string
  clusterName: string
  intent: 'informational' | 'commercial' | 'comparison' | 'unknown'
  priority: 'high' | 'medium' | 'low'
  reason: string
}

interface TopicalMap {
  clusters: Cluster[]
  cannibalization: CannibalizationIssue[]
  roadmap: RoadmapItem[]
  stats: { totalArticles: number; clustersFound: number; orphanCandidates: number; aiPowered: boolean }
}

interface RefreshRec {
  url: string
  path: string
  matchedArticleId: string | null
  matchedArticleTitle: string | null
  currentClicks: number
  previousClicks: number
  clickChangePct: number | null
  currentPosition: number | null
  problems: Array<{ type: string; detail: string }>
  newQuestionsInSerp: string[]
  missingEntities: string[]
  outdatedYears: number[]
  priority: 'high' | 'medium' | 'low'
}

interface GapResult {
  keyword: string
  serp: {
    intent: string
    format: string
    avgWordCount: number
    competitors: Array<{ url: string; title?: string; position: number; wordCount: number; h2Count: number; hasFaq: boolean }>
    commonEntities: string[]
    questions: string[]
    blindSpots: string[]
    aiPowered: boolean
  }
  gap: {
    ourCoveragePct: number | null
    missingEntities: string[]
    unansweredQuestions: string[]
    blindSpotOpportunities: string[]
  }
  informationGain: {
    score: number
    verdict: 'high' | 'moderate' | 'low' | 'thin'
    checks: Array<{ key: string; label: string; points: number; max: number; detail: string }>
    uniqueContributions: string[]
  } | null
}

type SectionKey = 'topical' | 'refresh' | 'gap' | 'links'

const PRIORITY_STYLES: Record<string, string> = {
  high: 'bg-red-500/15 text-red-400 border-red-500/20',
  medium: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
  low: 'bg-muted text-muted-foreground border-transparent',
}

// ── Component ────────────────────────────────────────────────────────────────

export default function ContentStrategyPage() {
  const setDashboardTab = useAppStore(s => s.setDashboardTab)
  const [section, setSection] = useState<SectionKey>('topical')

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-foreground mb-2">Content Strategy</h1>
        <p className="text-muted-foreground mb-6">Topical authority, refresh recommendations, and SERP gap analysis</p>

        <div className="flex flex-wrap gap-2 mb-8">
          {(
            [
              { key: 'topical', label: 'Topical Map', icon: Layers },
              { key: 'refresh', label: 'Refresh Agent', icon: RefreshCw },
              { key: 'gap', label: 'SERP Gap & Info Gain', icon: Search },
              { key: 'links', label: 'Internal Links', icon: Link2 },
            ] as Array<{ key: SectionKey; label: string; icon: React.ComponentType<{ className?: string }> }>
          ).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setSection(key)}
              className={cn(
                'px-4 py-2 rounded-full text-sm font-medium border transition-colors flex items-center gap-2',
                section === key
                  ? 'border-cyan-400/40 bg-cyan-500/10 text-cyan-300'
                  : 'border-border text-muted-foreground hover:text-foreground hover:bg-accent'
              )}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {section === 'topical' && <TopicalSection />}
        {section === 'refresh' && <RefreshSection />}
        {section === 'gap' && <GapSection />}
        {section === 'links' && <InternalLinksSection />}
      </div>
    </div>
  )
}

// ── Topical Section ──────────────────────────────────────────────────────────

function TopicalSection() {
  const setDashboardTab = useAppStore(s => s.setDashboardTab)
  const [loading, setLoading] = useState(true)
  const [map, setMap] = useState<TopicalMap | null>(null)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/topical-map')
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to build topical map')
      setMap(json.data)
    } catch (err: any) {
      setError(err?.message || 'Failed to build topical map')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-28 rounded-2xl bg-card/40 border border-border animate-pulse" />
        ))}
      </div>
    )
  }

  if (error) {
    return <ErrorCard message={error} onRetry={load} />
  }

  if (!map || map.stats.totalArticles === 0) {
    return (
      <EmptyState
        icon={Layers}
        title="No articles yet"
        text="Generate articles and your topical clusters will appear here automatically."
        actionLabel="Generate your first article"
        onAction={() => setDashboardTab('generate-article' as DashboardTab)}
      />
    )
  }

  return (
    <div className="space-y-8">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Articles analyzed', value: String(map.stats.totalArticles) },
          { label: 'Topic clusters', value: String(map.stats.clustersFound) },
          { label: 'Orphan candidates', value: String(map.stats.orphanCandidates) },
          { label: 'Analysis engine', value: map.stats.aiPowered ? 'AI clustering' : 'Keyword overlap' },
        ].map(s => (
          <Card key={s.label} className="bg-card/50 border border-border backdrop-blur-xl">
            <CardContent className="p-5">
              <p className="text-2xl font-bold text-foreground">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Cannibalization */}
      {map.cannibalization.length > 0 && (
        <div>
          <SectionHeader icon={GitMerge} title={`Cannibalization warnings (${map.cannibalization.length})`} />
          <div className="space-y-3">
            {map.cannibalization.map((c, i) => (
              <Card key={i} className="bg-card/50 border border-amber-500/20 backdrop-blur-xl">
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <Badge variant="secondary" className="bg-amber-500/15 text-amber-400 border-amber-500/20 capitalize">
                      {c.recommendation.replace('-', ' ')}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{c.keywords.join(' · ')}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{c.detail}</p>
                  <ul className="text-xs text-muted-foreground/80 space-y-1 list-disc list-inside">
                    {c.articles.map(a => <li key={a.articleId}>{a.title} <span className="opacity-60">({a.status.toLowerCase()})</span></li>)}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Clusters */}
      <div>
        <SectionHeader icon={MapIcon} title={`Topic clusters (${map.clusters.length})`} />
        {map.clusters.length === 0 ? (
          <EmptyState icon={MapIcon} title="Nothing to cluster yet" text="Add target keywords to your articles to enable clustering." />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {map.clusters.map((cluster, i) => (
              <Card key={i} className="bg-card/50 border border-border backdrop-blur-xl">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between gap-2">
                    <CardTitle className="text-sm font-semibold text-foreground truncate">{cluster.name}</CardTitle>
                    <Badge variant="secondary" className={cn(
                      'text-[10px] border',
                      cluster.coverage === 'strong' && 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
                      cluster.coverage === 'partial' && 'bg-amber-500/10 text-amber-400 border-amber-500/20',
                      cluster.coverage === 'thin' && 'bg-red-500/10 text-red-400 border-red-500/20',
                    )}>
                      {cluster.coverage}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  {cluster.pillar && (
                    <p className="text-[11px] text-cyan-400 mb-2 flex items-center gap-1">
                      <Target className="w-3 h-3" /> Pillar: {cluster.pillar.title}
                    </p>
                  )}
                  <ul className="space-y-1.5">
                    {cluster.members.slice(0, 6).map(m => (
                      <li key={m.articleId} className="flex items-center justify-between text-xs text-muted-foreground gap-2">
                        <span className="truncate">{m.title}</span>
                        <span className="shrink-0 opacity-60">
                          {m.seoScore && m.seoScore > 0 ? `SEO ${m.seoScore}` : m.status.toLowerCase()}
                        </span>
                      </li>
                    ))}
                    {cluster.members.length > 6 && (
                      <li className="text-xs opacity-50">+{cluster.members.length - 6} more…</li>
                    )}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Roadmap */}
      {map.roadmap.length > 0 && (
        <div>
          <SectionHeader icon={Sparkles} title={`Recommended next content (${map.roadmap.length})`} />
          <div className="space-y-3">
            {map.roadmap.map((r, i) => (
              <Card key={i} className="bg-card/50 border border-border backdrop-blur-xl">
                <CardContent className="p-5 flex flex-col sm:flex-row sm:items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h3 className="text-sm font-semibold text-foreground">{r.title}</h3>
                      <Badge variant="secondary" className={cn('text-[10px] border capitalize', PRIORITY_STYLES[r.priority])}>
                        {r.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{r.reason}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-xl shrink-0"
                    onClick={() => {
                      try { sessionStorage.setItem('pendingOpportunity', r.title) } catch {}
                      setDashboardTab('generate-article' as DashboardTab)
                    }}
                  >
                    <PenTool className="w-3.5 h-3.5 mr-1.5" />
                    Write it
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ── Refresh Section ──────────────────────────────────────────────────────────

function RefreshSection() {
  const setDashboardTab = useAppStore(s => s.setDashboardTab)
  const [sites, setSites] = useState<Array<{ id: string; name: string; gscProperty: string | null }>>([])
  const [siteId, setSiteId] = useState<string>('')
  const [recs, setRecs] = useState<RefreshRec[] | null>(null)
  const [loading, setLoading] = useState(true)
  const [running, setRunning] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/sites?limit=100')
        const json = await res.json()
        const list = (json?.data?.sites || []) as any[]
        setSites(list.map(s => ({ id: s.id, name: s.name, gscProperty: s.gscProperty || null })))
        if (list.length === 1) setSiteId(list[0].id)
      } catch {
        // handled by empty state below
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const runAnalysis = async () => {
    if (!siteId) return
    setRunning(true)
    setError(null)
    setRecs(null)
    try {
      const res = await fetch(`/api/refresh-recommendations?siteId=${encodeURIComponent(siteId)}`)
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Refresh analysis failed')
      setRecs(json.data.recommendations)
    } catch (err: any) {
      setError(err?.message || 'Refresh analysis failed')
    } finally {
      setRunning(false)
    }
  }

  if (loading) return <div className="h-28 rounded-2xl bg-card/40 border border-border animate-pulse" />

  if (sites.length === 0) {
    return (
      <EmptyState
        icon={RefreshCw}
        title="Connect a website first"
        text="The Refresh Agent watches real Search Console data for your connected property."
        actionLabel="Go to Connected Sites"
        onAction={() => setDashboardTab('connected-sites' as DashboardTab)}
      />
    )
  }

  return (
    <div className="space-y-6">
      <Card className="bg-card/50 border border-border backdrop-blur-xl max-w-xl">
        <CardContent className="p-5 space-y-4">
          <p className="text-sm text-muted-foreground">
            Compares declining pages (last two 28-day periods) against their article and the current SERP.
            Requires the site to be linked in the SEO Opportunities tab.
          </p>
          <Select value={siteId} onValueChange={setSiteId}>
            <SelectTrigger className="w-full bg-muted/40 border-border">
              <SelectValue placeholder="Choose site…" />
            </SelectTrigger>
            <SelectContent>
              {sites.map(s => (
                <SelectItem key={s.id} value={s.id}>
                  {s.name}{!s.gscProperty ? ' (no GSC property)' : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            onClick={runAnalysis}
            disabled={!siteId || running}
            className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
          >
            {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
            Run refresh scan
          </Button>
        </CardContent>
      </Card>

      {error && (
        <div className="flex items-start gap-3 px-4 py-3 rounded-xl border border-red-500/20 bg-red-500/10 text-sm text-red-400">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {recs && recs.length === 0 && (
        <EmptyState icon={CheckCircle} title="Nothing needs refreshing" text="No significant page declines detected in this period." />
      )}

      {recs && recs.length > 0 && (
        <div className="space-y-4">
          <SectionHeader icon={TrendingDown} title={`${recs.length} page(s) flagged for refresh`} />
          {recs.map((r, i) => (
            <Card key={i} className="bg-card/50 border border-border backdrop-blur-xl">
              <CardContent className="p-5">
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <Badge variant="secondary" className={cn('text-[10px] border capitalize', PRIORITY_STYLES[r.priority])}>
                    {r.priority} priority
                  </Badge>
                  {r.clickChangePct !== null && (
                    <Badge variant="secondary" className="bg-red-500/10 text-red-400 border-red-500/20 text-[10px]">
                      {(r.clickChangePct * 100).toFixed(0)}% clicks
                    </Badge>
                  )}
                  {r.currentPosition !== null && (
                    <span className="text-[11px] text-muted-foreground">pos. {r.currentPosition.toFixed(1)}</span>
                  )}
                </div>

                <h3 className="text-sm font-semibold text-foreground mb-1">{r.matchedArticleTitle || r.path}</h3>
                <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-xs text-cyan-400 hover:underline break-all">
                  {r.url}
                </a>

                <div className="mt-4 space-y-2">
                  {r.problems.map((p, j) => (
                    <div key={j} className="flex items-start gap-2 text-xs text-muted-foreground">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400/80 shrink-0 mt-0.5" />
                      <span>{p.detail}</span>
                    </div>
                  ))}
                </div>

                {r.missingEntities.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {r.missingEntities.map(e => (
                      <Badge key={e} variant="secondary" className="bg-muted text-muted-foreground border-0 text-[10px]">{e}</Badge>
                    ))}
                  </div>
                )}

                {r.matchedArticleId ? (
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-4 rounded-xl"
                    onClick={() => {
                      try { sessionStorage.setItem('pendingOpportunity', r.matchedArticleTitle || r.path) } catch {}
                      setDashboardTab('editor' as DashboardTab)
                    }}
                  >
                    <PenTool className="w-3.5 h-3.5 mr-1.5" />
                    Review article
                  </Button>
                ) : null}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

// ── SERP Gap Section ─────────────────────────────────────────────────────────

function GapSection() {
  const [articles, setArticles] = useState<Array<{ id: string; title: string; targetKeyword: string | null }>>([])
  const [keyword, setKeyword] = useState('')
  const [articleId, setArticleId] = useState('')
  const [result, setResult] = useState<GapResult | null>(null)
  const [running, setRunning] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/articles?limit=100')
        const json = await res.json()
        setArticles((json?.data?.articles || []).map((a: any) => ({
          id: a.id, title: a.title, targetKeyword: a.targetKeyword,
        })))
      } catch {}
    })()
  }, [])

  const runGap = async (kwArg?: string) => {
    const kw = (kwArg ?? keyword).trim()
    if (!kw) {
      setError('Enter a keyword or choose an article with a target keyword.')
      return
    }
    setKeyword(kw)
    setRunning(true)
    setError(null)
    setResult(null)
    try {
      const res = await fetch('/api/serp-gap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: kw,
          articleId: articleId || undefined,
        }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'SERP analysis failed')
      setResult(json.data)
    } catch (err: any) {
      setError(err?.message || 'SERP analysis failed')
    } finally {
      setRunning(false)
    }
  }

  const selectedArticle = articles.find(a => a.id === articleId)

  return (
    <div className="space-y-6">
      <Card className="bg-card/50 border border-border backdrop-blur-xl">
        <CardContent className="p-5 space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Keyword to analyze</label>
              <Input
                value={keyword}
                onChange={e => setKeyword(e.target.value)}
                placeholder="e.g. best running shoes for flat feet"
                className="bg-muted/40 border-border"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                Compare article <span className="opacity-60">(optional)</span>
              </label>
              <Select value={articleId} onValueChange={setArticleId}>
                <SelectTrigger className="w-full bg-muted/40 border-border">
                  <SelectValue placeholder="Analyze keyword only" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Analyze keyword only</SelectItem>
                  {articles.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.title.slice(0, 70)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button
            onClick={() => runGap(selectedArticle?.targetKeyword || undefined)}
            disabled={running}
            className="rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
          >
            {running ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
            Analyze SERP gap
          </Button>
          <p className="text-[11px] text-muted-foreground/70">
            {selectedArticle?.targetKeyword && !keyword
              ? `Using target keyword from selected article: “${selectedArticle.targetKeyword}”.`
              : !articleId
                ? 'Without an article selected you\'ll see what the top results cover — pick an article to also compute its Information Gain score.'
                : null}
          </p>
        </CardContent>
      </Card>

      {error && (
        <div className="flex items-start gap-3 px-4 py-3 rounded-xl border border-red-500/20 bg-red-500/10 text-sm text-red-400">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          {error}
        </div>
      )}

      {running && (
        <div className="space-y-4">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="h-24 rounded-2xl bg-card/40 border border-border animate-pulse" />
          ))}
        </div>
      )}

      {result && (
        <div className="space-y-6">
          {/* Info Gain hero */}
          {result.informationGain && (
          <Card className="bg-card/50 border border-border backdrop-blur-xl">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                <div className="relative w-24 h-24 shrink-0">
                  <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                    <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="9" className="text-border/40" />
                    <circle
                      cx="50" cy="50" r="42" fill="none" strokeWidth="9" strokeLinecap="round"
                      strokeDasharray={`${(result.informationGain.score / 100) * 264} 264`}
                      className={cn(
                        result.informationGain.score >= 70 ? 'stroke-emerald-400' :
                        result.informationGain.score >= 50 ? 'stroke-cyan-400' :
                        result.informationGain.score >= 30 ? 'stroke-amber-400' : 'stroke-red-400'
                      )}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-2xl font-bold text-foreground">{result.informationGain.score}</span>
                    <span className="text-[9px] uppercase tracking-wide text-muted-foreground">Info Gain</span>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-semibold text-foreground capitalize mb-2">
                    {result.informationGain.verdict} information gain vs current SERP
                  </h3>
                  <div className="grid gap-1.5">
                    {result.informationGain.checks.map(c => (
                      <div key={c.key} className="flex items-center justify-between gap-3 text-xs">
                        <span className="text-muted-foreground truncate">{c.label}</span>
                        <span className="text-foreground/80 shrink-0">{c.points}/{c.max}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          )}

          {/* Coverage */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {result.gap.ourCoveragePct !== null && (
            <Card className="bg-card/50 border border-border backdrop-blur-xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Our coverage of SERP entities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-3xl font-bold text-foreground">{result.gap.ourCoveragePct}%</span>
                  <span className="text-xs text-muted-foreground">of entities top results share</span>
                </div>
                <div className="h-2 rounded-full bg-border/40 overflow-hidden mb-3">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 to-violet-500"
                    style={{ width: `${result.gap.ourCoveragePct}%` }}
                  />
                </div>
                {result.gap.missingEntities.length > 0 && (
                  <>
                    <p className="text-xs font-medium text-muted-foreground mb-1.5">Missing:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {result.gap.missingEntities.map(e => (
                        <Badge key={e} variant="secondary" className="bg-red-500/10 text-red-400 border-red-500/20 text-[10px]">{e}</Badge>
                      ))}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
            )}

            <Card className="bg-card/50 border border-border backdrop-blur-xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">SERP snapshot — “{result.keyword}”</CardTitle>
              </CardHeader>
              <CardContent className="text-xs text-muted-foreground space-y-1.5">
                <p>Intent: <span className="text-foreground capitalize">{result.serp.intent}</span> · Format: <span className="text-foreground capitalize">{result.serp.format}</span></p>
                <p>Avg depth: <span className="text-foreground">{result.serp.avgWordCount.toLocaleString()} words</span></p>
                <p>Analyzed: <span className="text-foreground">{result.serp.competitors.length} results</span> · AI extraction: <span className="text-foreground">{result.serp.aiPowered ? 'yes' : 'heuristic only'}</span></p>
                {result.serp.questions.length > 0 && (
                  <div className="pt-2">
                    <p className="font-medium mb-1">Questions in this SERP:</p>
                    <ul className="list-disc list-inside space-y-0.5">
                      {result.serp.questions.slice(0, 5).map((q, i) => <li key={i}>{q}</li>)}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Blind spots */}
          {result.gap.blindSpotOpportunities.length > 0 && (
            <Card className="bg-card/50 border border-emerald-500/20 backdrop-blur-xl">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <FileQuestion className="w-4 h-4 text-emerald-400" />
                  Information gain opportunities — none of the top results covers these
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {result.gap.blindSpotOpportunities.map((b, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      {b}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Competitors table */}
          <Card className="bg-card/50 border border-border backdrop-blur-xl">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Top competitors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2 px-3 text-muted-foreground font-medium">#</th>
                      <th className="text-left py-2 px-3 text-muted-foreground font-medium">Page</th>
                      <th className="text-right py-2 px-3 text-muted-foreground font-medium">Words</th>
                      <th className="text-right py-2 px-3 text-muted-foreground font-medium">H2</th>
                      <th className="text-right py-2 px-3 text-muted-foreground font-medium">FAQ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.serp.competitors.map((c, i) => (
                      <tr key={c.url} className="border-b border-border/40">
                        <td className="py-2.5 px-3 text-muted-foreground">{i + 1}</td>
                        <td className="py-2.5 px-3 max-w-[280px]">
                          <a href={c.url} target="_blank" rel="noopener noreferrer" className="text-foreground hover:text-cyan-400 truncate block">
                            {c.title || c.url}
                          </a>
                        </td>
                        <td className="py-2.5 px-3 text-right text-muted-foreground">{c.wordCount.toLocaleString()}</td>
                        <td className="py-2.5 px-3 text-right text-muted-foreground">{c.h2Count ?? '-'}</td>
                        <td className="py-2.5 px-3 text-right">{c.hasFaq ? '✓' : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

// ── Internal Links Section ───────────────────────────────────────────────────

interface LinkSuggestionDto {
  targetPath: string
  targetTitle: string
  anchor: string
  relevance: number
  reason: string
  placementParagraph: number
  alreadyLinked: boolean
}

function InternalLinksSection() {
  const [articles, setArticles] = useState<Array<{ id: string; title: string }>>([])
  const [articleId, setArticleId] = useState('')
  const [suggestions, setSuggestions] = useState<LinkSuggestionDto[]>([])
  const [summary, setSummary] = useState<{ pages: number; orphans: number; source: string } | null>(null)
  const [loading, setLoading] = useState(false)
  const [applying, setApplying] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch('/api/articles?limit=200')
        const json = await res.json()
        setArticles((json?.data?.articles || []).map((a: any) => ({ id: a.id, title: a.title })))
      } catch {}
    })()
  }, [])

  const analyze = async () => {
    if (!articleId) return
    setLoading(true)
    setMessage(null)
    setSuggestions([])
    setSelected(new Set())
    try {
      const res = await fetch(`/api/internal-links/suggestions?articleId=${encodeURIComponent(articleId)}`)
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Analysis failed')
      setSuggestions(json.data.suggestions || [])
      setSummary(json.data.graphSummary || null)
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Internal link analysis failed' })
    } finally {
      setLoading(false)
    }
  }

  const applyTargets = async (targets: Array<{ path: string; title: string }>) => {
    if (!articleId || targets.length === 0) return
    setApplying(true)
    try {
      const res = await fetch('/api/internal-links/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleId, targets }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to apply links')
      setMessage({ ok: true, text: `${json.data.applied} internal link(s) added to the article.` })
      setSuggestions(prev => prev.filter(s => !targets.some(t => t.path === s.targetPath)))
      setSelected(new Set())
    } catch (err: any) {
      setMessage({ ok: false, text: err?.message || 'Failed to apply links' })
    } finally {
      setApplying(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="bg-card/50 border border-border backdrop-blur-xl">
        <CardContent className="p-5 space-y-4">
          <p className="text-sm text-muted-foreground">
            Crawls your site (sitemap first), builds the internal-link graph, and suggests links for a chosen
            article — including orphan-page rescue. Applied links are inserted at the most relevant paragraph.
          </p>
          <Select value={articleId} onValueChange={(v) => { setArticleId(v); setSuggestions([]); setSummary(null); }}>
            <SelectTrigger className="w-full bg-muted/40 border-border">
              <SelectValue placeholder="Choose an article…" />
            </SelectTrigger>
            <SelectContent>
              {articles.map(a => (
                <SelectItem key={a.id} value={a.id}>{a.title.slice(0, 80)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            onClick={analyze}
            disabled={!articleId || loading}
            className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
          >
            {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Link2 className="w-4 h-4 mr-2" />}
            Find linking opportunities
          </Button>
        </CardContent>
      </Card>

      {message && (
        <div className={cn(
          'flex items-start gap-3 px-4 py-3 rounded-xl border text-sm',
          message.ok ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
        )}>
          {message.ok ? <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />}
          {message.text}
        </div>
      )}

      {(loading || applying) && (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="w-4 h-4 animate-spin" />
          {applying ? 'Applying links…' : 'Crawling site and computing suggestions…'}
        </div>
      )}

      {summary && (
        <p className="text-xs text-muted-foreground">
          Graph: {summary.pages} pages crawled ({summary.source}) · {summary.orphans} orphan(s) detected.
        </p>
      )}

      {suggestions.length > 0 && (
        <>
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm font-semibold text-foreground">{suggestions.length} opportunities found</span>
            <Button
              size="sm"
              variant="outline"
              className="rounded-xl"
              disabled={applying}
              onClick={() => applyTargets(suggestions.map(s => ({ path: s.targetPath, title: s.targetTitle })))}
            >
              Apply all
            </Button>
            <Button
              size="sm"
              variant="ghost"
              disabled={applying || selected.size === 0}
              className="rounded-xl"
              onClick={() => applyTargets(suggestions.filter(s => selected.has(s.targetPath)).map(s => ({ path: s.targetPath, title: s.targetTitle })))}
            >
              Apply selected ({selected.size})
            </Button>
          </div>
          <div className="space-y-3">
            {suggestions.map(s => (
              <Card key={s.targetPath} className="bg-card/50 border border-border backdrop-blur-xl">
                <CardContent className="p-4 flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={selected.has(s.targetPath)}
                    onChange={e => {
                      const next = new Set(selected)
                      if (e.target.checked) next.add(s.targetPath)
                      else next.delete(s.targetPath)
                      setSelected(next)
                    }}
                    className="mt-1 accent-cyan-400"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-foreground">{s.anchor}</span>
                      <Badge variant="secondary" className={cn('text-[10px] border',
                        s.relevance >= 60 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-muted text-muted-foreground border-transparent'
                      )}>
                        {s.relevance}% match
                      </Badge>
                      {s.reason.includes('orphan') && (
                        <Badge variant="secondary" className="bg-violet-500/10 text-violet-400 border-violet-500/20 text-[10px]">orphan fix</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">→ {s.targetTitle} <span className="opacity-50">({s.targetPath})</span></p>
                    <p className="text-[11px] text-muted-foreground/70 mt-0.5">{s.reason}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={applying}
                    className="shrink-0 rounded-xl text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
                    onClick={() => applyTargets([{ path: s.targetPath, title: s.targetTitle }])}
                  >
                    Apply
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  )
}

// ── Shared bits ──────────────────────────────────────────────────────────────

function SectionHeader({ icon: Icon, title }: { icon: React.ComponentType<{ className?: string }>; title: string }) {
  return (
    <div className="flex items-center gap-2 mb-4">
      <Icon className="w-4 h-4 text-cyan-400" />
      <h2 className="text-lg font-semibold text-foreground">{title}</h2>
    </div>
  )
}

function EmptyState({ icon: Icon, title, text, actionLabel, onAction }: {
  icon: React.ComponentType<{ className?: string }>
  title: string
  text: string
  actionLabel?: string
  onAction?: () => void
}) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center border border-border mb-5">
        <Icon className="w-7 h-7 text-cyan-400" />
      </div>
      <h3 className="text-base font-semibold text-foreground mb-1.5">{title}</h3>
      <p className="text-sm text-muted-foreground max-w-md mb-5">{text}</p>
      {actionLabel && onAction && (
        <Button onClick={onAction} className="rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white">
          {actionLabel}
        </Button>
      )}
    </div>
  )
}

function ErrorCard({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <AlertTriangle className="w-8 h-8 text-red-400 mb-4" />
      <p className="text-sm text-muted-foreground mb-4">{message}</p>
      <Button variant="outline" size="sm" onClick={onRetry}>Retry</Button>
    </div>
  )
}
