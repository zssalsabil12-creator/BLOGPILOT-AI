import { NextResponse } from 'next/server';
import { z } from 'zod';
import { analyzeQuery } from '../../../../lib/analyzer';
import { getCurrentUserId } from '../../../../lib/auth';

const bodySchema = z.object({
  input: z.string().min(2),
  type: z.enum(['keyword', 'article', 'website']).default('keyword'),
  numResults: z.number().min(3).max(20).optional(),
});

const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 6;
const buckets = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string) {
  const now = Date.now();
  const b = buckets.get(ip);
  if (!b || now > b.resetAt) {
    buckets.set(ip, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }
  if (b.count >= RATE_LIMIT_MAX) return { allowed: false, remaining: 0, retryAfter: Math.ceil((b.resetAt - now) / 1000) };
  b.count += 1;
  buckets.set(ip, b);
  return { allowed: true, remaining: RATE_LIMIT_MAX - b.count };
}

export async function POST(req: Request) {
  const ip = (req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown') as string;
  const rl = checkRateLimit(ip);
  if (!rl.allowed) return NextResponse.json({ error: 'Rate limit exceeded', retryAfter: rl.retryAfter }, { status: 429 });

  let body: any;
  try {
    body = await req.json();
  } catch (err) {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const parse = bodySchema.safeParse(body);
  if (!parse.success) return NextResponse.json({ error: 'Invalid input', details: parse.error.flatten() }, { status: 400 });

  const { input, numResults, type } = parse.data;

  try {
    const userId = getCurrentUserId(req);
    const opts: any = { numResults, userId };
    if (type && type !== 'keyword') opts.userUrl = input;
    const report = await analyzeQuery(input, opts);
    return NextResponse.json({ ok: true, report });
  } catch (err: any) {
    console.error('Analyze error', err);
    return NextResponse.json({ error: err?.message || 'Analyze failed' }, { status: 500 });
  }
}
