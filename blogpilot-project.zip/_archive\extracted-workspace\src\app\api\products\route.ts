/**
 * Product Fetcher API
 *
 * POST /api/products — Fetch trending products for a keyword.
 * Uses mock data by default. Can integrate with real affiliate APIs
 * (Amazon Product Advertising, eBay Browse, CJ Product Catalog).
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { decrypt } from '@/lib/crypto'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { productsSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

interface Product {
  id: string
  name: string
  brand: string
  price: number
  originalPrice?: number
  currency: string
  rating: number
  reviewCount: number
  imageUrl: string
  affiliateUrl: string
  platform: string
  specs: Record<string, string>
  pros: string[]
  cons: string[]
  badge?: string // 'Best Overall', 'Best Value', 'Premium Pick'
  inStock: boolean
}

/**
 * Generate realistic mock products for a commercial keyword.
 */
function generateMockProducts(keyword: string, platform: string): Product[] {
  const kw = keyword.toLowerCase()
  const isCamera = kw.includes('camera') || kw.includes('vlog') || kw.includes('dslr')
  const isHeadphone = kw.includes('headphone') || kw.includes('earbud') || kw.includes('audio')
  const isLaptop = kw.includes('laptop') || kw.includes('macbook') || kw.includes('computer')
  const isPhone = kw.includes('phone') || kw.includes('iphone') || kw.includes('android')

  const productTemplates: Record<string, Array<{ name: string; brand: string; price: number; specs: Record<string, string>; pros: string[]; cons: string[] }>> = {
    camera: [
      {
        name: 'Sony ZV-1 II Vlogging Camera',
        brand: 'Sony',
        price: 798,
        specs: { Sensor: '20.1MP 1-inch CMOS', Video: '4K/30fps', Screen: '3.0" Flip-out', Weight: '292g', Stabilization: 'Optical SteadyShot' },
        pros: ['Excellent autofocus for vlogging', 'Compact and lightweight', 'Flip screen for self-recording', 'Great low-light performance'],
        cons: ['Limited battery life (~45min)', 'No interchangeable lenses', 'Average built-in microphone'],
      },
      {
        name: 'Canon EOS M50 Mark II',
        brand: 'Canon',
        price: 699,
        specs: { Sensor: '24.1MP APS-C', Video: '4K/24fps', Screen: '3.0" Tilt touchscreen', Weight: '387g', Autofocus: 'Dual Pixel CMOS AF' },
        pros: ['Interchangeable lenses', 'Excellent skin tones', 'Great for beginners', 'Built-in viewfinder'],
        cons: ['4K crops to 1.6x', 'Slow autofocus in 4K', 'Limited lens selection'],
      },
      {
        name: 'DJI Osmo Pocket 3',
        brand: 'DJI',
        price: 519,
        specs: { Sensor: '1-inch CMOS', Video: '4K/120fps', Screen: '2.0" Rotatable', Weight: '179g', Stabilization: '3-axis mechanical gimbal' },
        pros: ['Incredible stabilization', 'Pocket-sized', '120fps slow motion', 'Face tracking'],
        cons: ['Small sensor in low light', 'No lens options', 'App-dependent for some features'],
      },
      {
        name: 'GoPro Hero 12 Black',
        brand: 'GoPro',
        price: 349,
        specs: { Sensor: '27MP', Video: '5.3K/60fps', Waterproof: '33ft/10m', Weight: '154g', Stabilization: 'HyperSmooth 6.0' },
        pros: ['Virtually indestructible', 'Waterproof out of the box', 'Best action stabilization', 'Wide angle'],
        cons: ['Small sensor', 'Fixed ultrawide lens', 'Poor audio without external mic'],
      },
      {
        name: 'Panasonic Lumix G7',
        brand: 'Panasonic',
        price: 497,
        specs: { Sensor: '16MP Micro Four Thirds', Video: '4K/30fps', Screen: '3.0" Touch Swivel', Weight: '410g', Autofocus: 'DFD contrast-detect' },
        pros: ['Affordable entry into 4K', 'Weather-sealed body', 'Huge lens ecosystem', '4:2:2 10-bit output'],
        cons: ['Older model', 'Slow contrast AF', 'No in-body stabilization'],
      },
    ],
    headphone: [
      {
        name: 'Sony WH-1000XM5',
        brand: 'Sony',
        price: 349,
        specs: { Driver: '30mm', ANC: 'Adaptive ANC', Battery: '30 hours', Weight: '250g', Codec: 'LDAC, AAC, SBC' },
        pros: ['Best-in-class noise cancellation', 'Premium sound quality', 'Comfortable for all-day wear', 'Multipoint connection'],
        cons: ['No foldable design', 'Expensive', 'Touch controls can be finicky'],
      },
      {
        name: 'Bose QuietComfort Ultra',
        brand: 'Bose',
        price: 379,
        specs: { Driver: '35mm', ANC: 'CustomTune ANC', Battery: '24 hours', Weight: '250g', Codec: 'aptX Adaptive, AAC' },
        pros: ['Immersive spatial audio', 'Outstanding comfort', 'Premium build quality', 'Great call quality'],
        cons: ['Lower ANC than Sony', 'Shorter battery life', 'Higher price point'],
      },
      {
        name: 'Sennheiser Momentum 4',
        brand: 'Sennheiser',
        price: 299,
        specs: { Driver: '42mm', ANC: 'Adaptive ANC', Battery: '60 hours', Weight: '293g', Codec: 'aptX Adaptive, LDAC' },
        pros: ['Incredible 60-hour battery', 'Superb sound quality', 'Audiophile-grade drivers', 'Modern design'],
        cons: ['Bulky design', 'ANC not class-leading', 'Heavy for travel'],
      },
      {
        name: 'AirPods Max',
        brand: 'Apple',
        price: 549,
        specs: { Driver: '40mm Apple-designed', ANC: 'Active with Transparency', Battery: '20 hours', Weight: '384g', Chip: 'H2' },
        pros: ['Seamless Apple ecosystem', 'Premium materials (aluminum/stainless)', 'Spatial Audio with head tracking', 'Excellent transparency mode'],
        cons: ['Very heavy', 'No foldable design', 'Lightning cable (not USB-C)', 'Premium price'],
      },
      {
        name: 'JBL Tour One M2',
        brand: 'JBL',
        price: 199,
        specs: { Driver: '40mm', ANC: 'Adaptive ANC', Battery: '50 hours', Weight: '269g', Codec: 'aptX Adaptive, LDAC' },
        pros: ['Great value for money', 'Long battery life', 'Solid ANC performance', 'Comfortable fit'],
        cons: ['Sound quality below premium tier', 'Build feels plasticky', 'No multipoint'],
      },
    ],
    laptop: [
      {
        name: 'MacBook Air M3 15-inch',
        brand: 'Apple',
        price: 1299,
        specs: { CPU: 'Apple M3 8-core', RAM: '16GB unified', Storage: '256GB SSD', Display: '15.3" Liquid Retina', Battery: '18 hours' },
        pros: ['Incredible battery life', 'Fanless silent operation', 'Beautiful large display', 'macOS ecosystem'],
        cons: ['Base storage is low', 'Not for gaming', 'Only 2 Thunderbolt ports', 'No Face ID'],
      },
      {
        name: 'Dell XPS 14 (2024)',
        brand: 'Dell',
        price: 1399,
        specs: { CPU: 'Intel Core Ultra 7', RAM: '16GB', Storage: '512GB SSD', Display: '14.5" OLED 3K', Battery: '13 hours' },
        pros: ['Stunning OLED display', 'Compact premium build', 'Good performance', 'Excellent keyboard'],
        cons: ['Fans can be loud', 'Limited ports', 'Expensive configurations', 'Average battery for OLED'],
      },
      {
        name: 'ASUS Zenbook 14 OLED',
        brand: 'ASUS',
        price: 799,
        specs: { CPU: 'AMD Ryzen 7 7730U', RAM: '16GB', Storage: '512GB SSD', Display: '14" 2.8K OLED', Battery: '10 hours' },
        pros: ['Best OLED in this price range', 'Lightweight and portable', 'Good performance', 'Great speakers'],
        cons: ['Average battery life', 'Fingerprint magnet chassis', 'Only USB-C ports', 'No number pad'],
      },
      {
        name: 'ThinkPad X1 Carbon Gen 12',
        brand: 'Lenovo',
        price: 1649,
        specs: { CPU: 'Intel Core Ultra 7', RAM: '32GB', Storage: '512GB SSD', Display: '14" 2.8K OLED', Battery: '15 hours' },
        pros: ['Best keyboard in class', 'MIL-STD-810H durable', 'Lightweight carbon fiber', 'Privacy features built-in'],
        cons: ['Expensive', 'Integrated graphics only', 'Average webcam', 'Minimal design refresh year-over-year'],
      },
      {
        name: 'Framework Laptop 16',
        brand: 'Framework',
        price: 1399,
        specs: { CPU: 'AMD Ryzen 7 7840HS', RAM: '32GB DDR5', Storage: '1TB NVMe', Display: '16" 2560x1600', Battery: '12 hours' },
        pros: ['Fully modular and repairable', 'User-upgradable GPU module', 'Customizable input deck', 'Great Linux support'],
        cons: ['Thicker than competitors', 'Battery life is average', 'Limited GPU module options', 'Premium pricing for DIY'],
      },
    ],
    phone: [
      {
        name: 'iPhone 16 Pro Max',
        brand: 'Apple',
        price: 1199,
        specs: { Display: '6.9" Super Retina XDR', Chip: 'A18 Pro', Camera: '48MP+48MP+12MP', Battery: '33 hours video', Storage: '256GB' },
        pros: ['Best smartphone camera system', 'Excellent video recording', 'ProMotion 120Hz display', 'Long software support'],
        cons: ['Very expensive', 'Heavy at 227g', 'Slow charging', 'Limited customization'],
      },
      {
        name: 'Samsung Galaxy S24 Ultra',
        brand: 'Samsung',
        price: 1049,
        specs: { Display: "6.8\" Dynamic AMOLED 2X", Chip: "Snapdragon 8 Gen 3", Camera: "200MP+50MP+12MP+10MP", Battery: "30 hours", SPen: "Built-in" },
        pros: ["Built-in S Pen", "Best Android camera", "Galaxy AI features", "Titanium frame"],
        cons: ['One UI can feel bloated', 'Expensive', 'Curved screen not for everyone', 'Slow charging'],
      },
      {
        name: 'Google Pixel 9 Pro',
        brand: 'Google',
        price: 899,
        specs: { Display: '6.3" LTPO OLED', Chip: 'Tensor G4', Camera: '50MP+48MP+48MP', Battery: '23 hours', Storage: '128GB' },
        pros: ['Best AI features', 'Clean Android experience', '7 years of updates', 'Excellent photo processing'],
        cons: ['Tensor chip lags behind in gaming', 'Shorter battery life', 'No charger in box', 'Premium price'],
      },
      {
        name: 'OnePlus 12',
        brand: 'OnePlus',
        price: 699,
        specs: { Display: '6.82" LTPO AMOLED', Chip: 'Snapdragon 8 Gen 3', Camera: '50MP+48MP+64MP', Battery: '35 hours', Charging: '100W wired' },
        pros: ['Incredible value', 'Blazing fast 100W charging', 'Smooth OxygenOS', 'Great Hasselblad cameras'],
        cons: ['No wireless charging in some regions', 'Large and heavy', 'Software support shorter than Pixel/Samsung'],
      },
      {
        name: 'Nothing Phone 2a Plus',
        brand: 'Nothing',
        price: 299,
        specs: { Display: '6.7" AMOLED 120Hz', Chip: 'Dimensity 7350 Pro', Camera: '50MP+50MP', Battery: '26 hours', Glyph: 'LED notification interface' },
        pros: ['Unique transparent design', 'Great mid-range value', 'Clean Nothing OS', 'Glyph LED interface is fun'],
        cons: ['Mid-range performance', 'Camera falls short of flagships', 'No wireless charging', 'Limited availability'],
      },
    ],
  }

  // Pick the best matching category or use a generic template
  let category = 'camera'
  if (isHeadphone) category = 'headphone'
  else if (isLaptop) category = 'laptop'
  else if (isPhone) category = 'phone'

  const templates = productTemplates[category] || productTemplates.camera
  const badges = ['Best Overall', 'Best Value', 'Premium Pick', 'Editor\'s Choice', 'Budget Friendly']

  // Capitalize keyword for product naming
  const capitalizedKw = keyword.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')

  return templates.map((t, i) => {
    const discount = i === 0 ? 0 : Math.floor(Math.random() * 15) + 5
    const originalPrice = discount > 0 ? Math.round(t.price * (1 + discount / 100)) : undefined

    // Generate a plausible image URL using a placeholder service
    const imageId = 300 + i
    const imageUrl = `https://picsum.photos/seed/${keyword.replace(/\s/g, '-')}-${i}/400/400`

    // Generate affiliate URL
    let affiliateUrl = '#'
    if (platform === 'amazon') {
      affiliateUrl = `https://amazon.com/dp/B0${Math.random().toString(36).substring(2, 10).toUpperCase()}?tag=blogpilot-20`
    } else if (platform === 'ebay') {
      affiliateUrl = `https://ebay.com/itm/${Math.random().toString(36).substring(2, 12).toUpperCase()}`
    }

    return {
      id: `prod-${Date.now()}-${i}`,
      name: t.name,
      brand: t.brand,
      price: t.price,
      originalPrice,
      currency: 'USD',
      rating: +(4.0 + Math.random() * 0.9).toFixed(1),
      reviewCount: Math.floor(Math.random() * 8000) + 500,
      imageUrl,
      affiliateUrl,
      platform,
      specs: t.specs,
      pros: t.pros,
      cons: t.cons,
      badge: i < badges.length ? badges[i] : undefined,
      inStock: Math.random() > 0.1,
    }
  })
}

/**
 * Check if a keyword has commercial intent.
 */
function isCommercialIntent(keyword: string): boolean {
  const commercialWords = [
    'best', 'top', 'review', 'buy', 'cheap', 'affordable', 'price',
    'vs', 'comparison', 'recommend', 'picks', 'worst', 'deal',
    'camera', 'headphone', 'laptop', 'phone', 'gaming', 'wireless',
    'vlog', 'monitor', 'keyboard', 'mouse', 'speaker', 'tablet',
  ]
  const kw = keyword.toLowerCase()
  return commercialWords.some(w => kw.includes(w))
}

export async function POST(request: Request) {
  try {
    // ─── Rate limit (20 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.products)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(productsSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { keyword, platform = 'amazon', limit = 5 } = body

    const trimmedKeyword = keyword.trim()

    // Check if the intent is commercial
    const commercial = isCommercialIntent(trimmedKeyword)

    if (!commercial) {
      return NextResponse.json({
        success: true,
        commercial: false,
        keyword: trimmedKeyword,
        products: [],
        message: 'Keyword does not appear to have commercial intent. Product injection skipped.',
      })
    }

    // Try to use real affiliate credentials from the database
    let products: Product[] = []
    let source = 'mock'

    try {
      const credentials = await db.affiliateKey.findMany({
        where: { isActive: true },
      })

      if (credentials.length > 0 && credentials.some(c => c.platform === platform)) {
        // In production, this would call the real Amazon/eBay/CJ Product API
        // For now, use enhanced mock data with real credential context
        console.log(`[products] Found ${credentials.length} affiliate credentials, using mock data with ${platform} context`)
        source = `${platform}-mock`
      }
    } catch (dbError) {
      console.log('[products] Database query failed, using pure mock:', dbError)
    }

    // Generate products (mock or API-enhanced)
    products = generateMockProducts(trimmedKeyword, platform).slice(0, limit)

    return NextResponse.json({
      success: true,
      commercial: true,
      keyword: trimmedKeyword,
      platform,
      source,
      products,
      productCount: products.length,
      averagePrice: Math.round(products.reduce((s, p) => s + p.price, 0) / products.length),
      highestPrice: Math.max(...products.map(p => p.price)),
      lowestPrice: Math.min(...products.map(p => p.price)),
    })
  } catch (error: unknown) {
    return handleApiError(error, 'products')
  }
}
