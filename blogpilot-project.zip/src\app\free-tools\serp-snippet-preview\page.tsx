'use client';

import React, { useState, useMemo } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Search,
  AlertTriangle,
  Globe,
} from 'lucide-react';

function estimatePixelWidth(text: string): number {
  let width = 0;
  for (const char of text) {
    if ('mwMW'.includes(char)) width += 12;
    else if ('ilItj.,:;!|'.includes(char)) width += 5;
    else if ('@'.includes(char)) width += 14;
    else if (char === char.toUpperCase() && /[A-Z]/.test(char)) width += 10;
    else width += 8;
  }
  return width;
}

function LengthIndicator({ length, max }: { length: number; max: number }) {
  const color =
    length === 0
      ? 'text-muted-foreground'
      : length <= max
        ? 'text-emerald-400'
        : length <= max + 20
          ? 'text-amber-400'
          : 'text-rose-400';
  const label =
    length === 0
      ? 'Empty'
      : length <= max
        ? 'Good'
        : length <= max + 20
          ? 'Getting long'
          : 'Will be truncated';
  return (
    <span className={`text-xs ${color}`}>
      {length} chars — {label}
    </span>
  );
}

function PixelWidthIndicator({ text, max }: { text: string; max: number }) {
  const px = estimatePixelWidth(text);
  const color =
    text.length === 0
      ? 'text-muted-foreground'
      : px <= max
        ? 'text-emerald-400'
        : px <= max + 60
          ? 'text-amber-400'
          : 'text-rose-400';
  return (
    <span className={`text-xs ${color}`}>
      ~{px}px {px > max ? '(may truncate visually)' : ''}
    </span>
  );
}

function buildBreadcrumbs(url: string): string {
  if (!url.trim()) return 'https://example.com';
  let normalized = url.trim();
  if (!normalized.startsWith('http://') && !normalized.startsWith('https://')) {
    normalized = 'https://' + normalized;
  }
  try {
    const parsed = new URL(normalized);
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length === 0) return `${parsed.hostname}`;
    const path = parts.join(' > ');
    return `${parsed.hostname} > ${path}`;
  } catch {
    return normalized;
  }
}

export default function SerpSnippetPreviewPage() {
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [description, setDescription] = useState('');

  const displayTitle = useMemo(() => {
    if (!title.trim()) return 'Page Title Example';
    return title.trim();
  }, [title]);

  const truncatedTitle = useMemo(() => {
    return displayTitle.length > 60 ? displayTitle.slice(0, 57) + '...' : displayTitle;
  }, [displayTitle]);

  const displayUrl = useMemo(() => {
    return buildBreadcrumbs(url);
  }, [url]);

  const truncatedDescription = useMemo(() => {
    const desc = description.trim();
    if (!desc) return 'A short description of your page goes here. Search engines will display up to about 155-160 characters of your meta description in search results...';
    return desc.length > 160 ? desc.slice(0, 157) + '...' : desc;
  }, [description]);

  const titleTruncated = title.length > 60;
  const descTruncated = description.trim().length > 160;

  const inputClass =
    'w-full rounded-xl border border-border bg-muted/50 py-2.5 px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30';
  const labelClass = 'text-xs font-medium text-muted-foreground';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            SERP Snippet <span className="text-gradient">Preview</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            See how your page will appear in Google search results.
            Optimize your title, URL, and description for maximum click-through rate.
          </p>
        </section>

        {/* Input */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <label className={labelClass}>Page Title</label>
                <div className="flex items-center gap-3">
                  <LengthIndicator length={title.length} max={60} />
                  {title.length > 0 && <PixelWidthIndicator text={title} max={580} />}
                </div>
              </div>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Your Page Title - Brand Name"
                className={inputClass}
                maxLength={100}
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className={labelClass}>URL / Slug</label>
              </div>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="example.com/your-page-slug"
                  className={`${inputClass} pl-11`}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className={labelClass}>Meta Description</label>
                <LengthIndicator length={description.length} max={160} />
              </div>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Write a compelling meta description that encourages searchers to click on your result..."
                rows={3}
                className={`${inputClass} resize-none`}
                maxLength={300}
              />
            </div>
          </div>
        </section>

        {/* Preview */}
        <section className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="flex items-center gap-3">
            <Search className="h-5 w-5 text-cyan-300" />
            <h2 className="text-lg font-semibold text-foreground">Google SERP Preview</h2>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            This is an approximation of how your page may appear in Google search results.
          </p>

          <div className="mt-5 rounded-xl border border-border bg-white p-5 shadow-sm">
            {/* Title */}
            <h3 className="max-w-[600px] truncate text-[20px] font-normal leading-snug text-[#1a0dab]">
              {truncatedTitle}
            </h3>
            {titleTruncated && (
              <div className="mt-1 flex items-center gap-1.5">
                <AlertTriangle className="h-3 w-3 text-amber-400" />
                <span className="text-xs text-amber-400">
                  Title exceeds ~60 characters and may be truncated in search results
                </span>
              </div>
            )}

            {/* URL */}
            <div className="mt-1 flex items-center gap-1">
              <span className="text-[14px] text-[#006621]">
                {displayUrl}
              </span>
            </div>

            {/* Description */}
            <p className="mt-1 max-w-[600px] text-[14px] leading-relaxed text-[#545454]">
              {truncatedDescription}
            </p>
            {descTruncated && (
              <div className="mt-1 flex items-center gap-1.5">
                <AlertTriangle className="h-3 w-3 text-amber-400" />
                <span className="text-xs text-amber-400">
                  Description exceeds ~160 characters and may be truncated
                </span>
              </div>
            )}
          </div>
        </section>

        {/* Tips */}
        <section className="rounded-2xl border border-border bg-card/50 p-6">
          <p className="text-xs font-medium uppercase tracking-wider text-cyan-400">Optimization Tips</p>
          <div className="mt-3 space-y-2">
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="mt-0.5 text-emerald-400">✓</span>
              <span>Keep titles between 50-60 characters to avoid truncation</span>
            </div>
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="mt-0.5 text-emerald-400">✓</span>
              <span>Keep meta descriptions between 150-160 characters</span>
            </div>
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="mt-0.5 text-emerald-400">✓</span>
              <span>Include your primary keyword near the beginning of the title</span>
            </div>
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="mt-0.5 text-emerald-400">✓</span>
              <span>Use a clean, readable URL slug with your target keyword</span>
            </div>
          </div>
        </section>
      </div>
    </FreeToolLayout>
  );
}
