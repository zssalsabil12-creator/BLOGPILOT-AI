'use client'

import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'
import {
  History as HistoryIcon,
  Search,
  Filter,
  FileText,
  ExternalLink,
  Copy,
  Trash2,
  Eye,
  Calendar,
  Target,
  BarChart3,
  ArrowUpDown,
  MoreHorizontal,
  Pencil,
  Globe,
  RefreshCw,
  Image as ImageIcon,
  ShoppingCart,
  Info,
  Loader2,
} from 'lucide-react'

interface ArticleRecord {
  id: string
  title: string
  status: 'published' | 'draft' | 'scheduled'
  seoScore: number | null
  wordCount: number | null
  targetKeyword: string | null
  language: string
  intent: 'informational' | 'commercial' | string
  publishedAt: string | null
  createdAt: string
  site: { name: string; url: string; platform: string } | null
}

const statusConfig: Record<string, { label: string; className: string; dot: string }> = {
  published: {
    label: 'Published',
    className: 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20',
    dot: 'bg-green-500',
  },
  draft: {
    label: 'Draft',
    className: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20',
    dot: 'bg-yellow-500',
  },
  scheduled: {
    label: 'Scheduled',
    className: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
    dot: 'bg-blue-500',
  },
}

const intentConfig: Record<string, { label: string; icon: React.ElementType; className: string }> = {
  commercial: {
    label: 'Commercial',
    icon: ShoppingCart,
    className: 'bg-orange-500/10 text-orange-600 dark:text-orange-400',
  },
  informational: {
    label: 'Informational',
    icon: Info,
    className: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400',
  },
}

const languageLabels: Record<string, string> = {
  en: 'English',
  ar: 'Arabic',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  it: 'Italian',
  pt: 'Portuguese',
  nl: 'Dutch',
  ru: 'Russian',
  zh: 'Chinese',
  ja: 'Japanese',
  ko: 'Korean',
  hi: 'Hindi',
  tr: 'Turkish',
}

type SortField = 'createdAt' | 'seoScore' | 'wordCount' | 'title'
type SortDir = 'asc' | 'desc'

export function HistoryPage() {
  const openEditor = useAppStore((s) => s.openEditor)
  const [articles, setArticles] = useState<ArticleRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [intentFilter, setIntentFilter] = useState('all')
  const [sortField, setSortField] = useState<SortField>('createdAt')
  const [sortDir, setSortDir] = useState<SortDir>('desc')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [deleteTarget, setDeleteTarget] = useState<ArticleRecord | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  const fetchArticles = useCallback(async (silent = false) => {
    if (silent) {
      setIsRefreshing(true)
    } else {
      setIsLoading(true)
    }
    try {
      const res = await fetch('/api/articles', { cache: 'no-store' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      setArticles(data.articles || [])
    } catch (e) {
      console.error('Failed to fetch articles:', e)
      toast.error('Failed to load articles', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }, [])

  useEffect(() => {
    fetchArticles()
  }, [fetchArticles])

  const filteredArticles = articles
    .filter((a) => {
      const q = searchQuery.toLowerCase()
      const matchesSearch =
        a.title.toLowerCase().includes(q) ||
        (a.targetKeyword || '').toLowerCase().includes(q)
      const matchesStatus = statusFilter === 'all' || a.status === statusFilter
      const matchesIntent = intentFilter === 'all' || a.intent === intentFilter
      return matchesSearch && matchesStatus && matchesIntent
    })
    .sort((a, b) => {
      let cmp = 0
      if (sortField === 'title') {
        cmp = a.title.localeCompare(b.title)
      } else if (sortField === 'seoScore') {
        cmp = (a.seoScore || 0) - (b.seoScore || 0)
      } else if (sortField === 'wordCount') {
        cmp = (a.wordCount || 0) - (b.wordCount || 0)
      } else {
        cmp = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      }
      return sortDir === 'asc' ? cmp : -cmp
    })

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDir('desc')
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setIsDeleting(true)
    try {
      const res = await fetch(`/api/articles/${deleteTarget.id}`, { method: 'DELETE' })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || `HTTP ${res.status}`)
      }
      setArticles((prev) => prev.filter((a) => a.id !== deleteTarget.id))
      toast.success('Article deleted', {
        description: deleteTarget.title.slice(0, 80),
      })
    } catch (e) {
      toast.error('Failed to delete article', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setIsDeleting(false)
      setDeleteTarget(null)
    }
  }

  const handleCopyMarkdown = async (article: ArticleRecord) => {
    try {
      // Fetch the full article to get content
      const res = await fetch(`/api/articles/${article.id}`)
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      const text = `# ${data.article.title}\n\n${data.article.content || ''}`
      await navigator.clipboard.writeText(text)
      toast.success('Copied to clipboard', {
        description: `${article.title.slice(0, 60)}...`,
      })
    } catch (e) {
      toast.error('Failed to copy', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    }
  }

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '—'
    const d = new Date(dateStr)
    return d.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const stats = {
    total: articles.length,
    published: articles.filter((a) => a.status === 'published').length,
    drafts: articles.filter((a) => a.status === 'draft').length,
    avgSeo: articles.length
      ? Math.round(
          articles.reduce((s, a) => s + (a.seoScore || 0), 0) / articles.length
        )
      : 0,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <HistoryIcon className="h-6 w-6 text-primary" />
            Article History
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            View, edit, and publish all your AI-generated articles
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => fetchArticles(true)}
          disabled={isRefreshing}
        >
          {isRefreshing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Articles', value: stats.total, icon: FileText, color: 'text-primary' },
          { label: 'Published', value: stats.published, icon: Eye, color: 'text-green-500' },
          { label: 'Drafts', value: stats.drafts, icon: Pencil, color: 'text-yellow-500' },
          { label: 'Avg. SEO Score', value: stats.avgSeo, icon: BarChart3, color: 'text-blue-500' },
        ].map((stat) => (
          <Card key={stat.label} className="border-border/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
                <p className="text-xl font-bold">{stat.value}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by title or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-40">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="published">Published</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="scheduled">Scheduled</SelectItem>
          </SelectContent>
        </Select>
        <Select value={intentFilter} onValueChange={setIntentFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="Content type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="informational">Informational</SelectItem>
            <SelectItem value="commercial">Commercial</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex border rounded-md overflow-hidden">
          <Button
            variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
            size="sm"
            className="rounded-none"
            onClick={() => setViewMode('grid')}
          >
            <BarChart3 className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'secondary' : 'ghost'}
            size="sm"
            className="rounded-none"
            onClick={() => setViewMode('list')}
          >
            <ArrowUpDown className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Loading State */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="border-border/50">
              <CardContent className="p-4">
                <div className="h-4 w-3/4 bg-muted animate-pulse rounded mb-2" />
                <div className="h-3 w-1/2 bg-muted animate-pulse rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredArticles.length === 0 ? (
        <Card className="border-dashed border-border/50">
          <CardContent className="py-16 text-center">
            <FileText className="h-12 w-12 text-muted-foreground/40 mx-auto mb-3" />
            <p className="text-sm font-medium">No articles found</p>
            <p className="text-xs text-muted-foreground mt-1">
              {articles.length === 0
                ? 'Generate your first article to see it here.'
                : 'Try adjusting your filters.'}
            </p>
          </CardContent>
        </Card>
      ) : viewMode === 'grid' ? (
        /* Grid View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredArticles.map((article) => {
            const status = statusConfig[article.status] || statusConfig.draft
            const intent = intentConfig[article.intent] || intentConfig.informational
            const IntentIcon = intent.icon
            return (
              <Card
                key={article.id}
                className="group hover:shadow-md transition-all cursor-pointer border-border/50 hover:border-primary/30"
                onClick={() => openEditor(article.id)}
              >
                <CardContent className="p-5 flex flex-col h-full">
                  {/* Status + Intent row */}
                  <div className="flex items-center justify-between mb-3">
                    <Badge variant="outline" className={`text-[10px] ${status.className}`}>
                      <span className={`h-1.5 w-1.5 rounded-full mr-1.5 ${status.dot}`} />
                      {status.label}
                    </Badge>
                    <Badge variant="secondary" className={`text-[10px] ${intent.className}`}>
                      <IntentIcon className="h-3 w-3 mr-1" />
                      {intent.label}
                    </Badge>
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-semibold leading-snug line-clamp-2 mb-2 group-hover:text-primary transition-colors">
                    {article.title}
                  </h3>

                  {/* Keyword */}
                  {article.targetKeyword && (
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-1">
                      <Target className="inline h-3 w-3 mr-1" />
                      {article.targetKeyword}
                    </p>
                  )}

                  {/* Meta grid */}
                  <div className="grid grid-cols-3 gap-2 mt-auto pt-3 border-t border-border/40">
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">SEO</p>
                      <p className={`text-sm font-mono font-bold ${
                        (article.seoScore || 0) >= 90
                          ? 'text-green-500'
                          : (article.seoScore || 0) >= 80
                          ? 'text-yellow-500'
                          : 'text-red-500'
                      }`}>
                        {article.seoScore ?? '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">Words</p>
                      <p className="text-sm font-mono font-bold">
                        {article.wordCount ? article.wordCount.toLocaleString() : '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground uppercase">Lang</p>
                      <p className="text-sm font-mono font-bold uppercase">
                        {article.language || 'en'}
                      </p>
                    </div>
                  </div>

                  {/* Date + Site footer */}
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/40 text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(article.publishedAt || article.createdAt)}
                    </span>
                    {article.site ? (
                      <span className="flex items-center gap-1 truncate ml-2">
                        <Globe className="h-3 w-3 shrink-0" />
                        <span className="truncate max-w-[100px]">{article.site.name}</span>
                      </span>
                    ) : (
                      <span className="text-muted-foreground/60">No site</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      ) : (
        /* List View */
        <Card className="border-border/50 overflow-hidden">
          <CardContent className="p-0">
            <div className="divide-y divide-border/40">
              {filteredArticles.map((article) => {
                const status = statusConfig[article.status] || statusConfig.draft
                const intent = intentConfig[article.intent] || intentConfig.informational
                const IntentIcon = intent.icon
                return (
                  <div
                    key={article.id}
                    className="group flex items-center gap-4 px-4 py-3 hover:bg-muted/30 transition-colors cursor-pointer"
                    onClick={() => openEditor(article.id)}
                  >
                    {/* Status dot */}
                    <div className={`h-2 w-2 rounded-full shrink-0 ${status.dot}`} />

                    {/* Main */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                          {article.title}
                        </p>
                        <Badge variant="secondary" className={`text-[9px] shrink-0 ${intent.className}`}>
                          <IntentIcon className="h-2.5 w-2.5 mr-1" />
                          {intent.label}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                        {article.targetKeyword && (
                          <span className="flex items-center gap-1">
                            <Target className="h-2.5 w-2.5" />
                            {article.targetKeyword}
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Calendar className="h-2.5 w-2.5" />
                          {formatDate(article.publishedAt || article.createdAt)}
                        </span>
                        {article.site && (
                          <span className="flex items-center gap-1">
                            <Globe className="h-2.5 w-2.5" />
                            {article.site.name}
                          </span>
                        )}
                        <span className="uppercase">{article.language || 'en'}</span>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="hidden md:flex items-center gap-4 shrink-0">
                      <div className="text-center">
                        <p className="text-[10px] text-muted-foreground">SEO</p>
                        <p className={`text-sm font-mono font-bold ${
                          (article.seoScore || 0) >= 90 ? 'text-green-500' : (article.seoScore || 0) >= 80 ? 'text-yellow-500' : 'text-red-500'
                        }`}>
                          {article.seoScore ?? '—'}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-[10px] text-muted-foreground">Words</p>
                        <p className="text-sm font-mono font-bold">
                          {article.wordCount ? article.wordCount.toLocaleString() : '—'}
                        </p>
                      </div>
                    </div>

                    {/* Status badge */}
                    <Badge variant="outline" className={`text-[10px] shrink-0 hidden sm:flex ${status.className}`}>
                      {status.label}
                    </Badge>

                    {/* Actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenuItem onClick={() => openEditor(article.id)}>
                          <Pencil className="h-4 w-4 mr-2" />
                          Open in Editor
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleCopyMarkdown(article)}>
                          <Copy className="h-4 w-4 mr-2" />
                          Copy Markdown
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => setDeleteTarget(article)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary bar */}
      {!isLoading && filteredArticles.length > 0 && (
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <p>
            Showing {filteredArticles.length} of {articles.length} articles
          </p>
          <p>
            Sorted by{' '}
            <button
              className="font-medium hover:text-foreground underline-offset-2 hover:underline"
              onClick={() => toggleSort(sortField)}
            >
              {sortField === 'createdAt' ? 'date' : sortField}
            </button>{' '}
            ({sortDir})
          </p>
        </div>
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this article?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove{' '}
              <span className="font-medium text-foreground">
                &ldquo;{deleteTarget?.title.slice(0, 80)}&rdquo;
              </span>{' '}
              from your history. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
