import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { signupSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

// POST /api/auth/signup
export async function POST(request: Request) {
  try {
    // ─── Rate limit (10 / minute / IP) ───
    const blocked = rateLimit(request, RATE_LIMITS.auth)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(signupSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { email, password, name } = body

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) {
      return NextResponse.json(
        { error: 'An account with this email already exists' },
        { status: 409 }
      )
    }

    // In a real app, hash the password with bcrypt/argon2
    // For this demo we store it as-is to keep the dependency tree light.
    //
    // New users start on the Free plan with status='inactive' so the
    // 3-article free-trial paywall applies. The instant they complete a
    // PayPal / Payeer / Stripe payment, the webhook flips the status to
    // 'active' and the trial counter stops mattering.
    const user = await db.user.create({
      data: {
        email,
        name,
        passwordHash: password,
        credits: 0,           // paid credits — none until they subscribe
        freeCreditsUsed: 0,   // free-trial counter — 3 articles granted on signup
        preferredLanguage: 'en',
        subscription: {
          create: {
            plan: 'free',
            status: 'inactive', // ← forces the 3-article free trial paywall
          },
        },
      },
      include: { subscription: true },
    })

    const { passwordHash: _, ...safeUser } = user

    return NextResponse.json(
      {
        user: safeUser,
        sessionToken: user.id, // In production: issue a signed JWT
      },
      { status: 201 }
    )
  } catch (error: unknown) {
    return handleApiError(error, 'auth/signup')
  }
}
