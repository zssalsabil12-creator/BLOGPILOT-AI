# BlogPilot AI — Full Audit & Phase 1 Report

Date: 2026-08-25 · Scope: full codebase audit before transformation into "AI SEO Growth Agent".

---

## 1. Current Architecture

- **Framework:** Next.js 16 App Router (standalone output), React 19, TS strict, Tailwind 4 + shadcn/ui.
- **Data:** Prisma + SQLite (dev) / PostgreSQL schema (prod). Models: User, Subscription, AffiliateKey, Article, ConnectedSite, CreditTransaction, GoogleToken, Link, ProcessedEvent (webhook idempotency), RevokedSession, AiUsage.
- **Auth:** custom HMAC session token (`auth_session` httpOnly cookie or Bearer), scrypt passwords, Google Sign-In OAuth, Blogger OAuth (offline tokens).
- **APIs:** 56 route handlers — auth, articles CRUD+publish (WordPress/Blogger/Webhook), sites, credentials, generate/generate-outline/fact-check (real Gemini + OpenRouter failover), credits, link-library suite, free-tools endpoints (SSRF-guarded), payments (Stripe/Paddle/PayPal/AirTM/Payeer, fail-closed 503 when unconfigured), health.
- **Frontend:** landing (client comp), real routes `/login`, `/signup`, `/dashboard`, `/dashboard/generate`, `/dashboard/link-library`, `/free-tools/*`; dashboard tabs are Zustand state views under one URL (`?tab=` read once on mount).
- **Free tools:** 22 tools + 3 sub-pages, registry-driven hub (`src/lib/free-tools/tool-registry.ts`).

## 2. Existing Features (verified working, keep)

AI generation (chunked, credit-reserve/refund, AiUsage ledger) · outline-first workflow · fact-check w/ Google Search grounding · competitor research libs · WordPress/Blogger/Webhook publishing · encrypted-at-rest crypto lib exists · affiliate key storage · multi-gateway billing with signature-verified webhooks + ProcessedEvent idempotency · credit metering · rate limiting (Upstash-compatible) · Zod validation everywhere · security headers/CSP · link library import/export · 9 languages UI copy in generator.

## 3. Fake/Mock Data Found (must remove)

| Location | Fabrication |
|---|---|
| `affiliate-credentials-page.tsx` | gateway "earnings" ($4,250/$2,100 defaults), last-payout dates, referrals "127", rate "30%", referral link `ref.app/USR-8K3M9X2`, commission tier table, tier badges hardcoded by index |
| `landing-page.tsx` | testimonials ×3 all "Beta User" 5★, "+320% organic traffic" float, stats-band claims conflicting with reality ("14-day trial" vs "3 articles" vs actual 10 credits), "Shopify" support claim (unsupported), "Real-time SEO Tracking…in real time" feature claim, Agency "white-label/API access" claims, placeholder social links |
| `billing-page.tsx` | invoices synthesized client-side as `INV-001…` always "paid" |
| `upgrade-dialog.tsx` | "Payment Successful!" screen on unconfigured-gateway `demo:true`; **broken selection bug** (stores `plan.name`, compares `plan.id` → activePlan always undefined → confirm step silently no-ops) |
| `analytics-page.tsx` | radar chart "SEO Scores": 4/5 axes are invented formulas; zero-state labels imply unmeasured metrics (Backlinks etc.) |
| `seoScore` field | DB default 0; **no code path computes a score** → "Avg SEO Score", history badges always show 0/100 |
| editor-page | `yoursite.com/articles/...` placeholder |

Real data already OK: weekly/monthly charts derived from real articles; stat cards; history list; sites page.

## 4. Broken / Weak Features

1. Upgrade dialog plan-selection bug (above) → checkout unreachable.
2. Logout revocation not enforced by `getCurrentUserId` (sync signature-only) — only `/api/auth/me` honors RevokedSession.
3. `/api/credentials` GET/POST return **full plaintext secrets** to browser.
4. PayPal capture **GET** has no auth binding; webhook verification auto-passes in dev without `PAYPAL_WEBHOOK_ID`.
5. Admin grant endpoint compares `role === 'ADMIN'` but nothing ever sets that casing → dead endpoint.
6. `prisma/schema.postgres.prisma` still `provider = "sqlite"` + index drift vs SQLite schema.
7. Payeer callback uses non-timing-safe string compare.
8. Dead routes: `/api/analyze`, `/api/images`, `/api/admin/config` → hard 501 stubs, zero references in frontend.
9. No SEO score computation anywhere (field exists but永远 0).
10. Editor slug preview uses fake domain.

## 5. Missing Features (roadmap)

GSC integration & real search analytics · Opportunity Center (quick wins/declining/CTR gaps) · Refresh agent · Topical maps · SERP gap/information gain scoring · internal-link graph crawl · GA4 · content calendar · autopilot levels (Assist/Review/Autopilot) · E-E-A-T layer & author schema · pre-publish quality gate · cannibalization detection · hreflang/i18n routing · AdSense slots architecture.

## 6. Security Notes

High: plaintext secrets exposure via credentials API (fixed Phase 1); logout bypass (fixed Phase 1); PayPal dev webhook bypass (fail-closed Phase 1).
Medium (deferred, documented): DNS-rebinding TOCTOU in url-validator (validate→fetch re-resolve), missing CIDR blocks (::ffff: mapped, 100.64/10, 198.18/15), http-header-checker follows redirects without re-validation; x-forwarded-for spoofable without trusted proxy; in-memory limiter per-instance when Upstash unset.
No hardcoded secrets found in source (previous embedded Gemini key already removed).

## 7. Phase 1 Implementation (this change-set)

1. Workspace hygiene: archive stale project copies (`extracted-workspace`, `merged-template`, `workspace-*`, `download`, `tool-results`) → `_archive/`; delete root logs/test junk; rename `dockerignore`→`.dockerignore`; remove dead 501 routes; drop unused `socket.io-client` dep.
2. Technical SEO: dynamic `app/sitemap.ts` + `app/robots.ts` (empty public/robots.txt removed), root layout metadata template/Twitter/robots, site-url helper, JSON-LD (WebApplication+Breadcrumb) on **all 22 tool pages** via shared layouts (was 0/22), hub breadcrumb schema.
3. Real SEO Score engine (`src/lib/seo-score.ts`): deterministic analyzer (title/meta/headings/keyword density/placement/readability/links/lists/word-count) computed server-side on article create/update/generate — replaces永远-0 field honestly.
4. Honesty pass: analytics radar removed → real score distribution; affiliate page stripped of fabricated earnings/referrals/referral-link/commission table (keeps real connect/disconnect); billing invoices → honest credit-history; upgrade dialog fixed + honest demo state; landing claims aligned to reality; editor placeholder uses connected-site URL.
5. Security: masked credential responses; revocation enforced via 60s-cached revoked-hash set (sync-safe, multi-instance lag ≤60s documented); PayPal capture GET requires session; webhook verify fail-closed without webhook ID; timing-safe Payeer compare; case-insensitive admin role; Postgres schema provider/indexes fixed.

## 8. Dependencies Added

None (Phase 1 deliberately dependency-free). GSC/GA4 phases will use raw fetch (no SDK).

## 9. Risks

- Masked secrets change credential UX (re-enter key to rotate) — accepted, safer default.
- Legacy articles keep seoScore=0 until next save → UI shows "Not scored yet" instead of fake 0.
- Multi-instance logout propagation ≤60s (documented tradeoff until token-version migration).
- Old sessions survive schema changes (no breaking DB migrations in Phase 1).

## 10. Next Phases (order)

P2 GSC/OAuth scope + Opportunity Center → P3 Refresh Agent + Topical/SERP-gap/InfoGain → P4 Internal linking + E-E-A-T + Quality Gate → P5 Affiliate campaigns/tracking → P6 Autopilot loop.
