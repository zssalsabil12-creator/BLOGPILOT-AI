'use client';

import React, { useState, useCallback, useRef } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  CaseSensitive,
  Copy,
  Check,
  RotateCcw,
} from 'lucide-react';

type CaseType = 'upper' | 'lower' | 'title' | 'sentence' | 'camel' | 'alternating' | 'inverse';

interface CaseOption {
  key: CaseType;
  label: string;
  preview: string;
}

const CASE_OPTIONS: CaseOption[] = [
  { key: 'upper', label: 'UPPERCASE', preview: 'HELLO WORLD' },
  { key: 'lower', label: 'lowercase', preview: 'hello world' },
  { key: 'title', label: 'Title Case', preview: 'Hello World' },
  { key: 'sentence', label: 'Sentence case', preview: 'Hello world' },
  { key: 'camel', label: 'camelCase', preview: 'helloWorld' },
  { key: 'alternating', label: 'aLtErNaTiNg CaSe', preview: 'hElLo WoRlD' },
  { key: 'inverse', label: 'InVeRsE CaSe', preview: 'HeLlO wOrLd' },
];

function toTitleCase(str: string): string {
  return str.replace(
    /\w\S*/g,
    (txt) => txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase()
  );
}

function toSentenceCase(str: string): string {
  const sentences = str.split(/([.!?]+\s*)/);
  return sentences
    .map((segment, i) => {
      if (/[.!?]+\s*$/.test(segment) || i === 0) {
        const trimmed = segment.trimStart();
        if (trimmed.length === 0) return segment;
        return segment.replace(trimmed, trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase());
      }
      return segment.toLowerCase();
    })
    .join('');
}

function toCamelCase(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-zA-Z0-9]+(.)/g, (_, char) => char.toUpperCase())
    .replace(/^[A-Z]/, (char) => char.toLowerCase());
}

function toAlternatingCase(str: string): string {
  return str
    .split('')
    .map((char, i) => (i % 2 === 0 ? char.toLowerCase() : char.toUpperCase()))
    .join('');
}

function toInverseCase(str: string): string {
  return str
    .split('')
    .map((char) =>
      char === char.toUpperCase() && /[a-zA-Z]/.test(char)
        ? char.toLowerCase()
        : char === char.toLowerCase() && /[a-zA-Z]/.test(char)
          ? char.toUpperCase()
          : char
    )
    .join('');
}

function convertCase(text: string, type: CaseType): string {
  switch (type) {
    case 'upper':
      return text.toUpperCase();
    case 'lower':
      return text.toLowerCase();
    case 'title':
      return toTitleCase(text);
    case 'sentence':
      return toSentenceCase(text);
    case 'camel':
      return toCamelCase(text);
    case 'alternating':
      return toAlternatingCase(text);
    case 'inverse':
      return toInverseCase(text);
    default:
      return text;
  }
}

function CopyButton({ text, size = 'sm' }: { text: string; size?: 'sm' | 'md' }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      disabled={!text}
      className={`inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 text-muted-foreground transition hover:bg-card hover:text-foreground disabled:opacity-40 disabled:cursor-not-allowed ${
        size === 'sm' ? 'px-2.5 py-1 text-xs' : 'px-3 py-1.5 text-xs'
      }`}
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

export default function TextCaseConverterPage() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [activeCase, setActiveCase] = useState<CaseType | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const handleConvert = useCallback(
    (type: CaseType) => {
      if (!input.trim()) return;
      const result = convertCase(input, type);
      setOutput(result);
      setActiveCase(type);
    },
    [input]
  );

  const handleClear = useCallback(() => {
    setInput('');
    setOutput('');
    setActiveCase(null);
    inputRef.current?.focus();
  }, []);

  const inputCharCount = input.length;
  const inputWordCount = input.trim() ? input.trim().split(/\s+/).length : 0;
  const outputCharCount = output.length;
  const outputWordCount = output.trim() ? output.trim().split(/\s+/).length : 0;

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Text Case <span className="text-gradient">Converter</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Convert your text to any case format instantly. UPPERCASE, lowercase, Title Case, camelCase, and more.
          </p>
        </section>

        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Input Text
              </label>
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste or type your text here..."
                rows={8}
                className="w-full rounded-xl border border-border bg-muted/50 p-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30 resize-y"
              />
              <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                <span>{inputCharCount.toLocaleString()} characters &middot; {inputWordCount.toLocaleString()} words</span>
                {input && (
                  <button
                    onClick={handleClear}
                    className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground"
                  >
                    <RotateCcw className="h-3 w-3" />
                    Clear
                  </button>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              {CASE_OPTIONS.map((opt) => (
                <button
                  key={opt.key}
                  onClick={() => handleConvert(opt.key)}
                  disabled={!input.trim()}
                  className={`rounded-xl border px-4 py-2.5 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-40 ${
                    activeCase === opt.key
                      ? 'border-cyan-400/50 bg-cyan-400/10 text-cyan-300'
                      : 'border-border bg-muted/50 text-muted-foreground hover:bg-card hover:text-foreground'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {output && (
          <section className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CaseSensitive className="h-5 w-5 text-cyan-300" />
                <h2 className="text-lg font-semibold text-foreground">Output</h2>
              </div>
              <CopyButton text={output} size="md" />
            </div>
            <textarea
              readOnly
              value={output}
              rows={8}
              className="mt-4 w-full rounded-xl border border-border bg-muted/50 p-4 text-foreground outline-none resize-y cursor-default"
            />
            <div className="mt-2 text-xs text-muted-foreground">
              {outputCharCount.toLocaleString()} characters &middot; {outputWordCount.toLocaleString()} words
            </div>
          </section>
        )}
      </div>
    </FreeToolLayout>
  );
}
