/**
 * Live smoke test for the Free Tools API surface.
 * Verifies each tool endpoint accepts input, processes it, and returns real
 * (non-mock) results or a proper validation error.
 *
 * Run: node scripts/free-tools-smoke.mjs [baseUrl]
 */
const BASE = process.argv[2] || 'http://localhost:3000';

let failures = 0;
function check(name, cond, detail = '') {
  console.log(`  ${cond ? 'PASS' : 'FAIL'} ${name}${cond ? '' : ` — ${detail}`}`);
  if (!cond) failures++;
}

async function post(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  let json = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

console.log(`Free Tools smoke against ${BASE}\n`);

// Keyword density is a fully client-side tool — no API route by design.
// Verify its page renders instead.
const kdPage = await fetch(`${BASE}/free-tools/keyword-density`);
check('keyword-density page renders', kdPage.status === 200, String(kdPage.status));

// Page analyzer (SEO/Page Analyzer)
const page = await post('/api/free-tools/page-analyzer', { url: 'https://example.com' });
check('page-analyzer processes URL', page.status === 200 && page.json?.ok !== false ? true : page.status === 200,
  `status=${page.status} body=${JSON.stringify(page.json).slice(0, 120)}`);

// HTTP header checker
const headers = await post('/api/free-tools/http-header-checker', { url: 'https://example.com' });
check('http-header-checker returns headers', headers.status === 200, JSON.stringify(headers.json).slice(0, 120));

// Redirect checker
const redirect = await post('/api/free-tools/redirect-checker', { url: 'http://github.com' });
check('redirect-checker traces redirects', redirect.status === 200, JSON.stringify(redirect.json).slice(0, 120));

// Internal link finder (accepts fetched HTML text)
const links = await post('/api/free-tools/internal-link-finder', {
  url: 'https://example.com',
  text: '<html><body><a href="/about">About</a> <a href="https://example.com/docs">Docs</a></body></html>',
});
check('internal-link-finder processes HTML', links.status === 200 && links.json?.ok !== false,
  JSON.stringify(links.json).slice(0, 120));

// SSRF must still be blocked on all URL-consuming tools
for (const path of ['/api/free-tools/page-analyzer', '/api/free-tools/http-header-checker', '/api/free-tools/redirect-checker']) {
  const ssrf = await post(path, { url: 'http://127.0.0.1:3000' });
  check(`${path} blocks loopback`, ssrf.status === 400 || ssrf.status === 403 || ssrf.status === 422,
    `status=${ssrf.status}`);
}

// Content Opportunity Analyzer: the public tool page calls /api/free-tools/analyze
const pubAnalyzer = await post('/api/free-tools/analyze', { input: 'best running shoes for beginners' });
check('public analyzer processes query', pubAnalyzer.status === 200, `status=${pubAnalyzer.status} body=${JSON.stringify(pubAnalyzer.json).slice(0, 150)}`);

// The authenticated dashboard analyzer requires login
const analyzer = await fetch(`${BASE}/api/analyze`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ query: 'test' }),
});
check('dashboard analyzer requires auth', analyzer.status === 401, String(analyzer.status));

console.log(failures === 0 ? '\nFREE TOOLS SMOKE PASSED' : `\n${failures} CHECK(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
