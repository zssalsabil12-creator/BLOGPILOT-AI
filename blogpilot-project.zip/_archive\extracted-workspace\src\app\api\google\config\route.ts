import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { isGoogleOAuthConfigured, getGoogleClientId } from '@/lib/google-oauth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * GET /api/google/config
 *
 * Returns the public Google OAuth config for the frontend.
 * The client ID is safe to expose (it's designed for browser use).
 * The client secret is NEVER returned.
 *
 * Response:
 *   200 {
 *     configured: boolean,
 *     clientId: string | null,
 *   }
 */
export async function GET(request: Request) {
  try {
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    await requireUser(request)

    return NextResponse.json({
      configured: isGoogleOAuthConfigured(),
      clientId: getGoogleClientId(),
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'google/config')
  }
}
