import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { getSuggestions } from '@/lib/internal-links';

const querySchema = z.object({
  articleId: z.string().min(1).max(64),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'articleId is required' }, { status: 400 });
  }

  const limit = await checkRateLimit(`intlinks:${userId}`, { windowMs: 60_000, maxRequests: 8 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  try {
    const result = await getSuggestions(userId, parsed.data.articleId);
    return NextResponse.json({ ok: true, data: result });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 502;
    return NextResponse.json({ ok: false, error: error?.message || 'Internal link analysis failed' }, { status });
  }
}
