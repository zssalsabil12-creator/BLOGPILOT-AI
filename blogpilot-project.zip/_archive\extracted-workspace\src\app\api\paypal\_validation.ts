/**
 * Validation schemas for PayPal + Payeer routes.
 *
 * Mirrors the Stripe checkout schema so the front-end can use the same
 * { tier: 'basic' | 'pro' | 'agency' } payload across all three gateways.
 */
import { z } from 'zod'

export const paypalCheckoutSchema = z.object({
  tier: z.enum(['basic', 'pro', 'agency'], {
    error: 'Tier must be one of: basic, pro, agency',
  }),
})

export const paypalCaptureSchema = z.object({
  orderId: z.string().min(1, 'PayPal order ID is required').max(100),
})
