import { Server } from "socket.io";

const io = new Server(3002, {
  cors: {
    origin: "*",
  },
});

const STAGES = [
  "Analyzing keywords...",
  "Researching topic...",
  "Generating outline...",
  "Writing content...",
  "Optimizing SEO...",
  "Embedding affiliate links...",
  "Final review...",
];

io.on("connection", (socket) => {
  console.log(`[Socket] Client connected: ${socket.id}`);
  socket.emit("connected", { message: "Connected to generation service" });

  socket.on("generate:start", (payload: { keyword: string }) => {
    console.log(`[Socket] Generation started for keyword: "${payload.keyword}"`);

    let progress = 0;
    const totalSteps = STAGES.length;
    const increment = 100 / totalSteps;

    const interval = setInterval(() => {
      progress += increment;
      if (progress > 100) progress = 100;

      const stageIndex = Math.min(
        Math.floor((progress / 100) * totalSteps),
        totalSteps - 1
      );

      socket.emit("generate:progress", {
        stage: STAGES[stageIndex],
        progress: Math.round(progress),
      });

      if (progress >= 100) {
        clearInterval(interval);

        const articleId = `art_${Date.now()}`;
        const title = `Article about ${payload.keyword}`;

        socket.emit("generate:complete", {
          articleId,
          title,
        });

        console.log(`[Socket] Generation complete: ${articleId}`);
      }
    }, 500);
  });

  socket.on("disconnect", () => {
    console.log(`[Socket] Client disconnected: ${socket.id}`);
  });
});

console.log("[Generation Service] Socket.io server running on port 3002");
