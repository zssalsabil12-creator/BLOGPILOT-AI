﻿import { NextResponse } from 'next/server';
import { getAirtmConfig } from '@/lib/airtm';

export async function GET() {
  const cfg = getAirtmConfig();
  return NextResponse.json({
    ok: true,
    data: { provider: 'airtm', enabled: cfg.enabled },
  });
}