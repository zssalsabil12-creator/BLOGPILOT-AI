'use client'

import { useState, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import {
  CreditCard,
  Coins,
  Check,
  X,
  Sparkles,
  Loader2,
  ArrowUpRight,
  RefreshCw,
  ShieldCheck,
  Calendar,
  Zap,
  Infinity as InfinityIcon,
  TrendingUp,
  AlertCircle,
  Gift,
  Lock,
  ExternalLink,
  Wallet,
} from 'lucide-react'

/* -------------------------------------------------------------------------- */
/*                                  Types                                     */
/* -------------------------------------------------------------------------- */

interface PlanInfo {
  tier: 'basic' | 'pro' | 'agency'
  label: string
  priceUsd: number
  credits: number | null
  blurb: string
  accent: string
  priceId: string
}

interface SubscriptionInfo {
  plan: string
  status: string
  currentPeriodEnd: string | null
  cancelAtPeriodEnd: boolean
  stripeCustomerId: boolean
}

interface StripeConfig {
  publishableKey: string | null
  demoMode: boolean
  stripeConfigured: boolean
  currentTier: 'free' | 'basic' | 'pro' | 'agency'
  subscription: SubscriptionInfo | null
  plans: PlanInfo[]
}

interface CreditInfo {
  balance: number
  totalUsed: number
  plan: string
  planCap: number
  remainingPercentage: number
  freeTrial?: {
    used: number
    limit: number
    remaining: number
    exhausted: boolean
  }
  hasActiveSubscription?: boolean
  subscriptionStatus?: string
  transactions: Array<{
    id: string
    amount: number
    reason: string
    description: string | null
    articleId: string | null
    balanceAfter: number
    createdAt: string
  }>
}

const tierConfig: Record<string, { label: string; accent: string; icon: React.ElementType }> = {
  free: { label: 'Free', accent: 'bg-slate-500/10 text-slate-500 border-slate-500/20', icon: ShieldCheck },
  basic: { label: 'Basic', accent: 'bg-blue-500/10 text-blue-600 border-blue-500/20', icon: Zap },
  pro: { label: 'Pro', accent: 'bg-violet-500/10 text-violet-600 border-violet-500/20', icon: Sparkles },
  agency: { label: 'Agency', accent: 'bg-amber-500/10 text-amber-600 border-amber-500/20', icon: InfinityIcon },
}

type Gateway = 'stripe' | 'paypal' | 'payeer' | 'airtm'

export function BillingPage() {
  const [config, setConfig] = useState<StripeConfig | null>(null)
  const [credits, setCredits] = useState<CreditInfo | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [checkoutTier, setCheckoutTier] = useState<string | null>(null)
  /** Which gateway is currently processing a checkout for `checkoutTier`. */
  const [checkoutGateway, setCheckoutGateway] = useState<Gateway | null>(null)
  const [isOpeningPortal, setIsOpeningPortal] = useState(false)
  /** PayPal / Payeer / Airtm config — fetched lazily when the user picks a gateway. */
  const [paypalConfig, setPaypalConfig] = useState<{ configured: boolean; clientId: string | null } | null>(null)
  const [payeerConfig, setPayeerConfig] = useState<{ configured: boolean; merchantId: string | null } | null>(null)
  const [airtmConfig, setAirtmConfig] = useState<{ configured: boolean } | null>(null)

  const fetchAll = useCallback(async (silent = false) => {
    if (silent) setIsRefreshing(true)
    else setIsLoading(true)
    try {
      const [configRes, creditsRes, paypalRes, payeerRes, airtmRes] = await Promise.all([
        fetch('/api/stripe/config', { cache: 'no-store' }),
        fetch('/api/credits', { cache: 'no-store' }),
        fetch('/api/paypal/config', { cache: 'no-store' }).catch(() => null),
        fetch('/api/payeer/config', { cache: 'no-store' }).catch(() => null),
        fetch('/api/airtm/config', { cache: 'no-store' }).catch(() => null),
      ])
      const [configData, creditsData] = await Promise.all([
        configRes.json(),
        creditsRes.json(),
      ])
      if (configRes.ok) setConfig(configData)
      if (creditsRes.ok) setCredits(creditsData)
      // PayPal / Payeer / Airtm config endpoints return 401 if not authenticated —
      // that's fine, we just leave the config null and the buttons render
      // in demo mode (or hidden).
      if (paypalRes?.ok) {
        const data = await paypalRes.json()
        setPaypalConfig({ configured: !!data.configured, clientId: data.clientId })
      }
      if (payeerRes?.ok) {
        const data = await payeerRes.json()
        setPayeerConfig({ configured: !!data.configured, merchantId: data.merchantId })
      }
      if (airtmRes?.ok) {
        const data = await airtmRes.json()
        setAirtmConfig({ configured: !!data.configured })
      }
    } catch (e) {
      console.error('Failed to load billing data:', e)
      toast.error('Failed to load billing data')
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }, [])

  useEffect(() => {
    fetchAll()
  }, [fetchAll])

  const handleCheckout = async (tier: string, gateway: Gateway = 'stripe') => {
    setCheckoutTier(tier)
    setCheckoutGateway(gateway)
    try {
      const endpoint =
        gateway === 'stripe' ? '/api/stripe/checkout' :
        gateway === 'paypal' ? '/api/paypal/checkout' :
        gateway === 'payeer' ? '/api/payeer/checkout' :
        '/api/airtm/checkout'

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tier }),
      })
      const data = await res.json()
      if (!res.ok) {
        throw new Error(data.error || `HTTP ${res.status}`)
      }

      if (data.demo) {
        toast.success('Demo upgrade complete', {
          description: data.message || `Upgraded to ${tier} via ${gateway}.`,
        })
        fetchAll(true)
        return
      }

      if (gateway === 'paypal' && data.approvalUrl) {
        // Redirect to PayPal approval page — after the buyer approves,
        // PayPal returns to data.approvalUrl's return_url which is /dashboard?paypal=success
        // The front-end then needs to call /api/paypal/capture with data.orderId.
        // We stash the orderId in sessionStorage so the success page can pick it up.
        try {
          sessionStorage.setItem('pendingPaypalOrder', JSON.stringify({ orderId: data.orderId, tier }))
        } catch { /* sessionStorage may be unavailable in private mode */ }
        window.location.href = data.approvalUrl
        return
      }

      if (gateway === 'payeer' && data.url) {
        // Redirect to Payeer merchant page — after the buyer pays, Payeer
        // redirects back to /dashboard?payeer=success. The status_url
        // (/api/payeer/callback) is called server-to-server and activates
        // the subscription without further client action.
        window.location.href = data.url
        return
      }

      if (gateway === 'airtm' && data.url) {
        // Redirect to Airtm checkout — after the buyer pays, Airtm
        // redirects back to /dashboard?airtm=success. The webhook
        // (/api/airtm/webhook) is called server-to-server and activates
        // the subscription.
        window.location.href = data.url
        return
      }

      if (data.url) {
        // Stripe Checkout redirect
        window.location.href = data.url
      }
    } catch (e) {
      toast.error(`${gateway} checkout failed`, {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setCheckoutTier(null)
      setCheckoutGateway(null)
    }
  }

  /**
   * Complete a PayPal checkout by capturing the order after the buyer
   * returns from the PayPal approval page.
   *
   * Reads the pending order id from sessionStorage (set when the user
   * was redirected to PayPal) and POSTs it to /api/paypal/capture.
   */
  const handlePaypalCapture = useCallback(async (): Promise<boolean> => {
    try {
      const pending = sessionStorage.getItem('pendingPaypalOrder')
      if (!pending) return false
      sessionStorage.removeItem('pendingPaypalOrder')
      const { orderId, tier } = JSON.parse(pending) as { orderId: string; tier: string }

      setCheckoutTier(tier)
      setCheckoutGateway('paypal')

      const res = await fetch('/api/paypal/capture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId }),
      })
      const data = await res.json()

      if (!res.ok || !data.ok) {
        throw new Error(data.error || `HTTP ${res.status}`)
      }

      toast.success('PayPal payment captured', {
        description: `Upgraded to ${data.tier}. ${
          data.creditsGranted ? `${data.creditsGranted} credits granted.` : ''
        }`,
      })
      fetchAll(true)
      return true
    } catch (e) {
      toast.error('PayPal capture failed', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
      return false
    } finally {
      setCheckoutTier(null)
      setCheckoutGateway(null)
    }
  }, [fetchAll])

  // ─── Auto-capture PayPal order on return ─────────────────────────────
  // When the buyer returns from PayPal approval, the URL contains
  // ?paypal=success&tier=... — we trigger the capture automatically.
  useEffect(() => {
    if (typeof window === 'undefined') return
    const params = new URLSearchParams(window.location.search)
    if (params.get('paypal') === 'success') {
      handlePaypalCapture()
      // Clean the URL so we don't re-trigger on refresh
      const newUrl = window.location.pathname + window.location.hash
      window.history.replaceState({}, document.title, newUrl)
    }
  }, [handlePaypalCapture])

  const handleOpenPortal = async () => {
    setIsOpeningPortal(true)
    try {
      const res = await fetch('/api/stripe/portal', { method: 'POST' })
      const data = await res.json()
      if (!res.ok) {
        throw new Error(data.error || `HTTP ${res.status}`)
      }
      if (data.demo) {
        toast.info('Demo mode', {
          description: 'Stripe Customer Portal is simulated in demo mode.',
        })
      } else if (data.url) {
        window.location.href = data.url
      }
    } catch (e) {
      toast.error('Failed to open billing portal', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setIsOpeningPortal(false)
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-72" />
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          <Skeleton className="h-48 rounded-lg" />
          <Skeleton className="h-48 rounded-lg" />
        </div>
        <Skeleton className="h-64 rounded-lg" />
      </div>
    )
  }

  const currentTier = config?.currentTier || 'free'
  const currentTierInfo = tierConfig[currentTier]
  const CurrentIcon = currentTierInfo.icon

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <CreditCard className="h-6 w-6 text-primary" />
            Billing & Subscription
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your plan, view credit usage, and access the Stripe Customer Portal
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => fetchAll(true)} disabled={isRefreshing}>
          {isRefreshing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <RefreshCw className="h-4 w-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Demo mode banner */}
      {config?.demoMode && (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardContent className="p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-medium text-amber-700 dark:text-amber-300">
                Demo Mode — Stripe not configured
              </p>
              <p className="text-xs text-amber-600/80 dark:text-amber-400/80 mt-1">
                Set <code className="px-1 py-0.5 rounded bg-amber-500/10 font-mono">STRIPE_SECRET_KEY</code>,
                <code className="px-1 py-0.5 rounded bg-amber-500/10 font-mono ml-1">STRIPE_WEBHOOK_SECRET</code>, and
                <code className="px-1 py-0.5 rounded bg-amber-500/10 font-mono ml-1">STRIPE_PRICE_*</code> in your
                <code className="px-1 py-0.5 rounded bg-amber-500/10 font-mono ml-1">.env</code> to enable live payments.
                Until then, upgrading will simulate the credit grant locally.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Free trial banner — shown only for inactive subscriptions */}
      {credits && !credits.hasActiveSubscription && credits.freeTrial && (
        <Card className={`border ${
          credits.freeTrial.exhausted
            ? 'border-red-500/30 bg-red-500/5'
            : 'border-blue-500/30 bg-blue-500/5'
        }`}>
          <CardContent className="p-4 flex items-start gap-3">
            {credits.freeTrial.exhausted ? (
              <Lock className="h-5 w-5 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
            ) : (
              <Gift className="h-5 w-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            )}
            <div className="flex-1">
              <p className={`text-sm font-medium ${
                credits.freeTrial.exhausted
                  ? 'text-red-700 dark:text-red-300'
                  : 'text-blue-700 dark:text-blue-300'
              }`}>
                {credits.freeTrial.exhausted
                  ? `Free trial exhausted — subscribe to continue generating`
                  : `Free trial: ${credits.freeTrial.remaining} of ${credits.freeTrial.limit} articles remaining`}
              </p>
              <p className={`text-xs mt-1 ${
                credits.freeTrial.exhausted
                  ? 'text-red-600/80 dark:text-red-400/80'
                  : 'text-blue-600/80 dark:text-blue-400/80'
              }`}>
                {credits.freeTrial.exhausted
                  ? 'You\'ve used all 3 free trial articles. Pick a plan below to keep generating — payments go directly to the merchant wallet via Stripe, PayPal, Payeer, or Airtm.'
                  : `Every new account gets ${credits.freeTrial.limit} free article generations. After that, you'll need to subscribe to a paid plan. Choose Stripe, PayPal, Payeer, or Airtm below.`}
              </p>
              {credits.freeTrial.exhausted && (
                <Button
                  size="sm"
                  className="mt-3"
                  onClick={() => {
                    const basicCard = document.getElementById('plan-card-basic')
                    basicCard?.scrollIntoView({ behavior: 'smooth', block: 'center' })
                  }}
                >
                  <ArrowUpRight className="h-3.5 w-3.5 mr-1.5" />
                  Choose a plan
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Plan + Credits Overview */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Current Plan Card */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <CurrentIcon className="h-4 w-4" />
              Current Plan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-3xl font-bold capitalize">{currentTierInfo.label}</p>
                {config?.subscription?.currentPeriodEnd && (
                  <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Renews on {new Date(config.subscription.currentPeriodEnd).toLocaleDateString()}
                  </p>
                )}
              </div>
              <Badge variant="outline" className={currentTierInfo.accent}>
                {config?.subscription?.status || (currentTier === 'free' ? 'active' : 'inactive')}
              </Badge>
            </div>

            {config?.subscription?.cancelAtPeriodEnd && (
              <div className="p-2 rounded-md bg-red-500/5 border border-red-500/20 text-xs text-red-600 dark:text-red-400">
                Your subscription is set to cancel at the end of the current billing period.
              </div>
            )}

            <Separator />

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-xs text-muted-foreground">Monthly Credits</p>
                <p className="font-semibold">
                  {currentTier === 'agency' ? (
                    <span className="flex items-center gap-1">
                      <InfinityIcon className="h-4 w-4" />
                      Unlimited
                    </span>
                  ) : currentTier === 'free' ? (
                    '10'
                  ) : (
                    config?.plans.find((p) => p.tier === currentTier)?.credits ?? '—'
                  )}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Stripe Customer</p>
                <p className="font-semibold text-xs">
                  {config?.subscription?.stripeCustomerId ? 'Linked' : 'Not linked'}
                </p>
              </div>
            </div>

            {currentTier !== 'free' && (
              <Button
                variant="outline"
                size="sm"
                className="w-full mt-2"
                onClick={handleOpenPortal}
                disabled={isOpeningPortal}
              >
                {isOpeningPortal ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <ArrowUpRight className="h-4 w-4 mr-2" />
                )}
                Manage Subscription via Stripe Portal
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Credits Card */}
        <Card className="border-border/50">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Coins className="h-4 w-4" />
              Credit Balance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <div className="flex items-baseline justify-between mb-2">
                <p className="text-3xl font-bold font-mono">
                  {credits?.balance ?? 0}
                </p>
                <p className="text-xs text-muted-foreground">
                  of {credits?.planCap || '∞'} cap
                </p>
              </div>
              <Progress value={credits?.remainingPercentage || 0} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1.5">
                {credits?.remainingPercentage || 0}% of plan cap remaining
              </p>
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  Total Used
                </p>
                <p className="font-semibold font-mono">{credits?.totalUsed ?? 0}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Plan</p>
                <p className="font-semibold capitalize">{credits?.plan || 'free'}</p>
              </div>
            </div>

            <div className="pt-2 text-xs text-muted-foreground">
              1 credit = 1 article generation. Credits reset monthly on paid plans.
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Available Plans */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-primary" />
            Available Plans
          </CardTitle>
          <CardDescription>
            Upgrade for more monthly credits and premium features. Pay with Stripe, PayPal, Payeer, or Airtm — all funds go directly to the merchant wallet.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-4">
            {config?.plans.map((plan) => {
              const isCurrent = currentTier === plan.tier
              const tierInfo = tierConfig[plan.tier]
              const TierIcon = tierInfo.icon
              const isBusy = checkoutTier === plan.tier
              return (
                <Card
                  key={plan.tier}
                  id={`plan-card-${plan.tier}`}
                  className={`relative overflow-hidden transition-all ${
                    isCurrent
                      ? 'border-primary border-2'
                      : 'border-border/50 hover:border-primary/30 hover:shadow-md'
                  }`}
                >
                  <CardContent className="p-5 flex flex-col h-full">
                    {isCurrent && (
                      <div className="absolute top-3 right-3">
                        <Badge className="text-[10px] bg-primary text-primary-foreground">
                          <Check className="h-3 w-3 mr-1" />
                          Current
                        </Badge>
                      </div>
                    )}

                    <div
                      className="h-10 w-10 rounded-lg flex items-center justify-center mb-3"
                      style={{ backgroundColor: `${plan.accent}15`, color: plan.accent }}
                    >
                      <TierIcon className="h-5 w-5" />
                    </div>

                    <h3 className="text-lg font-bold">{plan.label}</h3>
                    <div className="flex items-baseline gap-1 mt-1">
                      <span className="text-2xl font-bold">${plan.priceUsd}</span>
                      <span className="text-xs text-muted-foreground">/month</span>
                    </div>

                    <p className="text-xs text-muted-foreground mt-2 flex-1">{plan.blurb}</p>

                    <div className="mt-3 p-2 rounded-md bg-muted/30 text-center">
                      <p className="text-[10px] text-muted-foreground uppercase">Monthly Credits</p>
                      <p className="font-mono font-bold text-sm">
                        {plan.credits === null ? (
                          <span className="flex items-center justify-center gap-1">
                            <InfinityIcon className="h-3 w-3" />
                            Unlimited
                          </span>
                        ) : (
                          plan.credits
                        )}
                      </p>
                    </div>

                    {/* Primary Stripe checkout button — keeps the existing flow */}
                    <Button
                      className="w-full mt-4"
                      variant={isCurrent ? 'outline' : 'default'}
                      disabled={isCurrent || isBusy}
                      onClick={() => handleCheckout(plan.tier, 'stripe')}
                    >
                      {isBusy && checkoutGateway === 'stripe' ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : isCurrent ? (
                        <>
                          <Check className="h-4 w-4 mr-2" />
                          Current Plan
                        </>
                      ) : (
                        <>
                          <CreditCard className="h-4 w-4 mr-2" />
                          Pay with Stripe
                        </>
                      )}
                    </Button>

                    {/* Alternative gateways — PayPal + Payeer + Airtm */}
                    {!isCurrent && (
                      <div className="grid grid-cols-3 gap-2 mt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={isBusy}
                          onClick={() => handleCheckout(plan.tier, 'paypal')}
                          className="text-xs"
                          title={paypalConfig?.configured ? 'Pay with PayPal' : 'PayPal in demo mode'}
                        >
                          {isBusy && checkoutGateway === 'paypal' ? (
                            <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                          ) : (
                            <span className="mr-1 font-bold text-[#003087] dark:text-[#9cb3ff]">Pay</span>
                          )}
                          Pal
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={isBusy}
                          onClick={() => handleCheckout(plan.tier, 'payeer')}
                          className="text-xs"
                          title={payeerConfig?.configured ? 'Pay with Payeer' : 'Payeer in demo mode'}
                        >
                          {isBusy && checkoutGateway === 'payeer' ? (
                            <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                          ) : (
                            <ExternalLink className="h-3.5 w-3.5 mr-1.5" />
                          )}
                          Payeer
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={isBusy}
                          onClick={() => handleCheckout(plan.tier, 'airtm')}
                          className="text-xs"
                          title={airtmConfig?.configured ? 'Pay with Airtm' : 'Airtm in demo mode'}
                        >
                          {isBusy && checkoutGateway === 'airtm' ? (
                            <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                          ) : (
                            <Wallet className="h-3.5 w-3.5 mr-1.5" />
                          )}
                          Airtm
                        </Button>
                      </div>
                    )}

                    {/* Gateway status hint */}
                    {!isCurrent && (
                      <p className="text-[10px] text-muted-foreground mt-2 text-center">
                        {paypalConfig?.configured && payeerConfig?.configured && airtmConfig?.configured
                          ? 'Stripe · PayPal · Payeer · Airtm all live'
                          : paypalConfig?.configured && payeerConfig?.configured
                          ? 'Stripe · PayPal · Payeer live · Airtm in demo'
                          : paypalConfig?.configured
                          ? 'Stripe · PayPal live · Payeer · Airtm in demo'
                          : 'Some gateways in demo mode — see .env'}
                      </p>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Credit Transactions */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-sm">Recent Credit Transactions</CardTitle>
          <CardDescription>
            Last 20 credit changes (top-ups, generations, subscription grants)
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-xs">Description</TableHead>
                <TableHead className="text-xs">Reason</TableHead>
                <TableHead className="text-xs text-right">Change</TableHead>
                <TableHead className="text-xs text-right">Balance</TableHead>
                <TableHead className="text-xs text-right hidden md:table-cell">Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {credits?.transactions && credits.transactions.length > 0 ? (
                credits.transactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell className="text-sm">
                      <span className="truncate max-w-[300px] block">
                        {tx.description || tx.reason}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className={`text-[10px] ${
                          tx.amount > 0
                            ? 'bg-green-500/10 text-green-600'
                            : tx.amount < 0
                            ? 'bg-red-500/10 text-red-600'
                            : 'bg-muted'
                        }`}
                      >
                        {tx.reason}
                      </Badge>
                    </TableCell>
                    <TableCell className={`text-right font-mono text-sm font-bold ${
                      tx.amount > 0 ? 'text-green-600' : tx.amount < 0 ? 'text-red-600' : ''
                    }`}>
                      {tx.amount > 0 ? '+' : ''}{tx.amount}
                    </TableCell>
                    <TableCell className="text-right font-mono text-sm">
                      {tx.balanceAfter}
                    </TableCell>
                    <TableCell className="text-right text-xs text-muted-foreground hidden md:table-cell">
                      {new Date(tx.createdAt).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-8">
                    No transactions yet. Generate an article or upgrade your plan to see activity here.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Security notice */}
      <Card className="border-border/30 bg-muted/20">
        <CardContent className="p-4 flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium">Secure payment processing</p>
            <p className="text-xs text-muted-foreground mt-1">
              Payments are processed by Stripe, PayPal, Payeer, or Airtm over HTTPS — we never see or store your card or wallet details.
              All funds go directly to the merchant wallet configured by the admin. Subscriptions renew automatically
              and can be cancelled anytime via the respective gateway's customer portal.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
