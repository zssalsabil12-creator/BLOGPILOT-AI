import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  getStripe,
  tierFromPriceId,
  PLAN_CONFIG,
  type PlanTier,
} from '@/lib/stripe'
import { addCredits } from '@/lib/auth'

/**
 * POST /api/stripe/webhook
 *
 * Receives Stripe webhook events and updates the database accordingly.
 *
 * Handled events:
 *   - customer.subscription.created      → mark subscription as active
 *   - customer.subscription.updated      → sync plan, status, period end
 *   - customer.subscription.deleted      → downgrade to free, revoke credits cap
 *   - invoice.payment_succeeded          → top up monthly credit allotment
 *   - checkout.session.completed         → link subscription to user
 *
 * SECURITY: This route verifies the Stripe signature header BEFORE doing
 * any work. If STRIPE_WEBHOOK_SECRET is not configured, the route returns
 * 503 so you know to set the env var before going live.
 *
 * BODY: Raw request body (Stripe signs the raw bytes — Next.js Route
 * Handlers expose this via `request.text()` because we need the raw payload,
 * not the JSON-parsed version).
 */
export async function POST(request: Request) {
  const stripe = getStripe()
  if (!stripe) {
    return NextResponse.json(
      { error: 'Stripe not configured (missing STRIPE_SECRET_KEY)' },
      { status: 503 }
    )
  }

  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET
  if (!webhookSecret) {
    return NextResponse.json(
      { error: 'STRIPE_WEBHOOK_SECRET not configured' },
      { status: 503 }
    )
  }

  // Get the raw body — Stripe signs the raw bytes
  const payload = await request.text()
  const signature = request.headers.get('stripe-signature') || ''

  let event
  try {
    event = stripe.webhooks.constructEvent(payload, signature, webhookSecret)
  } catch (err) {
    console.error('[stripe/webhook] signature verification failed:', err)
    return NextResponse.json(
      { error: `Webhook signature verification failed: ${err instanceof Error ? err.message : 'unknown'}` },
      { status: 400 }
    )
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        await safeHandle('checkout.session.completed', () =>
          handleCheckoutCompleted(stripe, event.data.object)
        )
        break
      }

      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        await safeHandle(event.type, () =>
          handleSubscriptionChange(stripe, event.data.object)
        )
        break
      }

      case 'customer.subscription.deleted': {
        await safeHandle('customer.subscription.deleted', () =>
          handleSubscriptionDeleted(event.data.object)
        )
        break
      }

      case 'invoice.payment_succeeded': {
        await safeHandle('invoice.payment_succeeded', () =>
          handleInvoicePaid(event.data.object)
        )
        break
      }

      default:
        // Acknowledge unhandled events so Stripe doesn't retry
        return NextResponse.json({ received: true, unhandled: event.type })
    }

    return NextResponse.json({ received: true, type: event.type })
  } catch (err) {
    console.error(`[stripe/webhook] error handling ${event.type}:`, err)
    // Return 500 so Stripe retries with backoff — but only for genuinely
    // unexpected errors. Schema / signature issues are already handled
    // above and return 400.
    return NextResponse.json(
      { error: 'Webhook handler failed', type: event.type },
      { status: 500 }
    )
  }
}

/**
 * Wrap an event handler so partial failures (e.g., a single handler
 * throwing on a malformed payload) don't crash the whole webhook.
 *
 * We log the error and rethrow — the outer catch turns it into a 500,
 * which tells Stripe to retry. If you'd rather swallow certain errors
 * (e.g., unknown customer id), do that inside the handler itself.
 */
async function safeHandle(
  eventName: string,
  handler: () => Promise<void>
): Promise<void> {
  try {
    await handler()
  } catch (err) {
    // Enrich the log with the event name + error type so debugging
    // Stripe dashboard retries is easier.
    const errName = err instanceof Error ? err.name : 'UnknownError'
    const errMsg = err instanceof Error ? err.message : String(err)
    console.error(
      `[stripe/webhook] handler "${eventName}" failed (${errName}): ${errMsg}`
    )
    throw err
  }
}

/* -------------------------------------------------------------------------- */
/*                            Event handlers                                  */
/* -------------------------------------------------------------------------- */

/**
 * Checkout completed — link the new subscription to the user and mark plan.
 */
async function handleCheckoutCompleted(
  stripe: NonNullable<ReturnType<typeof getStripe>>,
  session: any
) {
  const userId = session.metadata?.userId
  const tier = session.metadata?.tier as PlanTier | undefined
  if (!userId || !tier) return

  // Fetch the subscription from Stripe to get the canonical data
  const subId = session.subscription as string
  if (!subId) return

  const subscription = (await stripe.subscriptions.retrieve(subId)) as any
  const priceId = subscription.items.data[0]?.price?.id
  const resolvedTier = tierFromPriceId(priceId || '') || tier

  await db.subscription.upsert({
    where: { userId },
    create: {
      userId,
      plan: resolvedTier,
      status: mapStripeStatus(subscription.status),
      stripeCustomerId: subscription.customer as string,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      currentPeriodEnd: subscription.current_period_end
        ? new Date(subscription.current_period_end * 1000)
        : null,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
    update: {
      plan: resolvedTier,
      status: mapStripeStatus(subscription.status),
      stripeCustomerId: subscription.customer as string,
      stripeSubscriptionId: subscription.id,
      stripePriceId: priceId,
      currentPeriodEnd: subscription.current_period_end
        ? new Date(subscription.current_period_end * 1000)
        : null,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
  })
}

/**
 * Subscription created or updated — sync status, plan, period end.
 */
async function handleSubscriptionChange(
  stripe: NonNullable<ReturnType<typeof getStripe>>,
  subscription: any
) {
  const customerId = subscription.customer as string
  if (!customerId) return

  // Find the user by stripe customer id
  const existing = await db.subscription.findFirst({
    where: { stripeCustomerId: customerId },
  })
  if (!existing) {
    // Stripe sent us an event for a customer we don't know — possibly
    // created via the Stripe dashboard. Look up the user via metadata.
    const userId = subscription.metadata?.userId
    if (!userId) return
    const userSub = await db.subscription.findUnique({ where: { userId } })
    if (!userSub) return
    // Re-run with the linked subscription row
    return updateSubscriptionRow(userSub.userId, subscription)
  }

  await updateSubscriptionRow(existing.userId, subscription)

  // If the price changed, sync the plan tier
  const priceId = subscription.items?.data?.[0]?.price?.id
  if (priceId) {
    const newTier = tierFromPriceId(priceId)
    if (newTier) {
      await db.subscription.update({
        where: { userId: existing.userId },
        data: { plan: newTier, stripePriceId: priceId },
      })
    }
  }
}

async function updateSubscriptionRow(userId: string, subscription: any) {
  const priceId = subscription.items?.data?.[0]?.price?.id
  await db.subscription.update({
    where: { userId },
    data: {
      stripeSubscriptionId: subscription.id,
      stripeCustomerId: subscription.customer,
      stripePriceId: priceId,
      status: mapStripeStatus(subscription.status),
      currentPeriodEnd: subscription.current_period_end
        ? new Date(subscription.current_period_end * 1000)
        : null,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
  })
}

/**
 * Subscription deleted — downgrade user to free and revoke any active
 * subscription benefits. Their remaining credit balance is preserved so
 * they can still generate articles they've already paid for.
 */
async function handleSubscriptionDeleted(subscription: any) {
  const customerId = subscription.customer as string
  if (!customerId) return

  const existing = await db.subscription.findFirst({
    where: { stripeCustomerId: customerId },
  })
  if (!existing) return

  await db.subscription.update({
    where: { userId: existing.userId },
    data: {
      plan: 'free',
      status: 'cancelled',
      stripeSubscriptionId: null,
      stripePriceId: null,
      currentPeriodEnd: null,
      cancelAtPeriodEnd: false,
    },
  })

  // Log a transaction noting the cancellation
  await db.creditTransaction.create({
    data: {
      userId: existing.userId,
      amount: 0,
      reason: 'subscription_cancelled',
      description: `Subscription cancelled (was ${existing.plan})`,
      balanceAfter: 0, // will be filled in below if needed
    },
  }).catch(() => {}) // best-effort
}

/**
 * Invoice paid — top up monthly credit allotment when a subscription
 * invoice is paid (this fires on initial purchase AND on renewals).
 *
 * Note: we top up only on `subscription_create` invoices, not on prorations
 * or one-off invoices, to avoid double-granting credits.
 */
async function handleInvoicePaid(invoice: any) {
  // Only top up on subscription cycle invoices
  if (!invoice.subscription) return

  const customerId = invoice.customer as string
  if (!customerId) return

  const existing = await db.subscription.findFirst({
    where: { stripeCustomerId: customerId },
  })
  if (!existing) return

  // Determine plan from the invoice line items
  const lineItem = invoice.lines?.data?.[0]
  const priceId = lineItem?.price?.id
  const tier = priceId ? tierFromPriceId(priceId) : (existing.plan as PlanTier)
  if (!tier || tier === 'free') return

  const credits = PLAN_CONFIG[tier].credits
  if (!credits || credits <= 0) {
    // Agency = unlimited, set a very high balance
    await db.user.update({
      where: { id: existing.userId },
      data: { credits: 99999 },
    })
    return
  }

  // For first invoice (billing_reason === 'subscription_create'), grant full credits.
  // For renewals, reset to the plan allotment (don't stack — credits don't roll over).
  const isInitial = invoice.billing_reason === 'subscription_create'
  const user = await db.user.findUnique({ where: { id: existing.userId } })
  if (!user) return

  if (isInitial) {
    // Initial — just add the credits on top of any free tier credits they had
    await addCredits(
      existing.userId,
      credits,
      'subscription_created',
      `Initial ${PLAN_CONFIG[tier].label} subscription grant (${credits} credits)`
    )
  } else {
    // Renewal — reset balance to the plan allotment
    await db.user.update({
      where: { id: existing.userId },
      data: { credits },
    })
    await db.creditTransaction.create({
      data: {
        userId: existing.userId,
        amount: credits,
        reason: 'subscription_renewed',
        description: `Monthly ${PLAN_CONFIG[tier].label} renewal — ${credits} credits reset`,
        balanceAfter: credits,
      },
    })
  }
}

/* -------------------------------------------------------------------------- */
/*                              helpers                                       */
/* -------------------------------------------------------------------------- */

function mapStripeStatus(stripeStatus: string): string {
  const map: Record<string, string> = {
    active: 'active',
    trialing: 'trialing',
    past_due: 'past_due',
    canceled: 'cancelled',
    cancelled: 'cancelled',
    unpaid: 'unpaid',
    incomplete: 'incomplete',
    incomplete_expired: 'cancelled',
    paused: 'cancelled',
  }
  return map[stripeStatus] || 'cancelled'
}

/**
 * Stripe webhooks require the raw body — Next.js Route Handlers in App
 * Router give us this automatically when we read request.text(), but we
 * also need to disable the body parser. In App Router this is done via
 * the route segment config:
 */
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
