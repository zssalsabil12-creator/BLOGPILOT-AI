import { Metadata } from 'next';
import { freeToolMetadata, breadcrumbJsonLd } from '@/lib/free-tools/seo';
import { absoluteUrl } from '@/lib/site';
import { ToolsHub } from '@/components/free-tools/tools-hub';

export const metadata: Metadata = freeToolMetadata({
  title: 'Free SEO & Content Intelligence Tools',
  description: 'Research keywords, analyze competitors, find content gaps, optimize your SEO titles, and discover internal linking opportunities — all free, no signup required.',
  path: '/free-tools',
  openGraphTitle: 'Free SEO & Content Intelligence Tools — BlogPilot AI',
  openGraphDescription: 'A suite of free, data-driven SEO tools: content opportunity analysis, SEO title optimization, heading structure analysis, and internal link discovery.',
});

const breadcrumbs = breadcrumbJsonLd([
  { name: 'BlogPilot AI', url: absoluteUrl('/') },
  { name: 'Free SEO Tools', url: absoluteUrl('/free-tools') },
]);

export default function FreeToolsPage() {
  return (
    <>
      <ToolsHub />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'CollectionPage',
            name: 'Free SEO & Content Intelligence Tools',
            description: 'A suite of free, data-driven SEO tools for keyword research, competitor analysis, content optimization, and internal linking.',
            url: absoluteUrl('/free-tools'),
            provider: {
              '@type': 'Organization',
              name: 'BlogPilot AI',
              url: absoluteUrl('/'),
            },
          }),
        }}
      />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbs) }} />
    </>
  );
}
