import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { probeGemini, getGeminiKeyVersionLabel } from '@/lib/secrets';
import { isOpenRouterConfigured } from '@/lib/gemini';
import { checkRateLimit, RATE_LIMITS } from '@/lib/rate-limit';

/**
 * Internal AI configuration health check.
 *
 * Reports ONLY a coarse status — never the key value, secret version value,
 * or any authentication material:
 *   configured            — key present and accepted by the provider
 *   not_configured        — no key present in the environment
 *   invalid               — key present but rejected by the provider
 *   temporarily_unavailable — provider unreachable / rate limited / erroring
 */
export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  // Probing costs one outbound request; keep it rate limited per user.
  const rl = await checkRateLimit(`ai-health:${userId}`, RATE_LIMITS.auth);
  if (!rl.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests' }, { status: 429 });
  }

  const { status } = await probeGemini();
  const openrouter = isOpenRouterConfigured() ? 'configured' : 'not_configured';
  const overall =
    status === 'configured' || openrouter === 'configured' ? 'configured' : status;

  return NextResponse.json({
    ok: true,
    ai: overall,
    providers: { gemini: status, openrouter },
    ...(getGeminiKeyVersionLabel() ? { version: getGeminiKeyVersionLabel() } : {}),
  });
}
