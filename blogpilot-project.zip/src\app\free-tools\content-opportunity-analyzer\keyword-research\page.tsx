import React from 'react';
import Link from 'next/link';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';

export const metadata = {
  title: 'Keyword Research Guide — Content Opportunity Analyzer | BlogPilot AI',
  description: 'Free keyword research guide and tool: discover search intent, keyword difficulty, and content gaps with BlogPilot AI\'s Content Opportunity Analyzer.',
  openGraph: { title: 'Keyword Research Guide — BlogPilot AI', description: 'Free keyword research guide and tool: discover search intent, keyword difficulty, and content gaps with BlogPilot AI.' },
};

export default function KeywordResearchPage() {
  return (
    <FreeToolLayout backHref="/free-tools" backLabel="All Free Tools">
      <article className="max-w-3xl mx-auto">
        <header className="mb-10">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Guide</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">Keyword research for modern content marketers</h1>
          <p className="mt-4 text-lg text-muted-foreground">Understand what users search for, why they search, and what content is required to rank — then use the Content Opportunity Analyzer to act on those insights instantly.</p>
        </header>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Why keyword research still matters</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">Good keyword research goes beyond single-word queries. It answers intent, uncovers related subtopics users expect, finds long-tail opportunities and informs article structure. The best-performing pages combine topical authority with clearly signaled intent (how-to, informational, commercial).</p>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">A practical approach</h2>
          <ol className="list-decimal ml-6 mt-3 text-muted-foreground space-y-3">
            <li><strong className="text-foreground">Start with intent:</strong> Identify whether the user wants to buy, learn, compare or navigate.</li>
            <li><strong className="text-foreground">Map top results:</strong> Review titles, headings and FAQ sections to spot gaps.</li>
            <li><strong className="text-foreground">Find subtopics:</strong> Build an outline that covers unanswered questions and examples.</li>
            <li><strong className="text-foreground">Prioritize:</strong> Aim for low-to-medium competition with high relevance and clear differentiation.</li>
          </ol>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Use the free analyzer</h2>
          <p className="mt-3 text-muted-foreground leading-relaxed">The Content Opportunity Analyzer runs these steps automatically: it fetches top results, extracts headings and snippets, detects missing subtopics and presents an action plan. It&apos;s free to use and works without signup for basic analysis.</p>
          <div className="mt-4">
            <a href="/free-tools/content-opportunity-analyzer" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-5 py-3 text-sm font-semibold text-slate-950">Open the Content Opportunity Analyzer →</a>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Frequently asked questions</h2>
          <div className="mt-3 space-y-4">
            <div className="rounded-xl border border-border bg-card/30 p-4">
              <h3 className="font-medium text-foreground">Is this tool really free?</h3>
              <p className="mt-2 text-sm text-muted-foreground">Yes — the basic Content Opportunity Analyzer is free and does not require an account for short analyses. Advanced features integrate with the paid BlogPilot AI workflow.</p>
            </div>
            <div className="rounded-xl border border-border bg-card/30 p-4">
              <h3 className="font-medium text-foreground">Can I export the analysis?</h3>
              <p className="mt-2 text-sm text-muted-foreground">Use the &quot;Build a Better Article&quot; CTA to transfer the analysis into the BlogPilot editor. From there, you can export, edit, and publish the drafted article.</p>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold text-foreground">Related tools</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <a href="/free-tools/content-opportunity-analyzer" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">Content Opportunity Analyzer →</span>
            </a>
            <a href="/free-tools/seo-title-analyzer" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">SEO Title & Meta Analyzer →</span>
            </a>
            <a href="/free-tools/heading-structure-analyzer" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">Heading Structure Analyzer →</span>
            </a>
            <a href="/free-tools/internal-link-finder" className="flex items-center gap-3 rounded-xl border border-border bg-card/30 p-4 transition hover:border-primary/30 hover:bg-card/50">
              <span className="text-sm font-medium text-foreground">Internal Link Opportunity Finder →</span>
            </a>
          </div>
        </section>

        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
            {
              "@type": "Question",
              "name": "Is this tool really free?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes — the basic Content Opportunity Analyzer is free and does not require an account for short analyses. Advanced features integrate with the paid BlogPilot AI workflow." }
            },
            {
              "@type": "Question",
              "name": "Can I export the analysis?",
              "acceptedAnswer": { "@type": "Answer", "text": "Use the 'Build a Better Article' CTA to transfer the analysis into the BlogPilot editor. From there, you can export, edit, and publish the drafted article." }
            }
          ]
        }) }} />

        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://blogpilot.ai/" },
            { "@type": "ListItem", "position": 2, "name": "Free Tools", "item": "https://blogpilot.ai/free-tools" },
            { "@type": "ListItem", "position": 3, "name": "Keyword Research", "item": "https://blogpilot.ai/free-tools/content-opportunity-analyzer/keyword-research" }
          ]
        }) }} />
      </article>
    </FreeToolLayout>
  );
}
