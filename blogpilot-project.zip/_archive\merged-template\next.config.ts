import type { NextConfig } from "next";

/**
 * Production-optimized Next.js 16 configuration for BlogPilot AI.
 *
 * - `output: "standalone"` produces a self-contained `.next/standalone/`
 *   bundle that can be deployed to any Node host (Vercel, Docker, fly.io,
 *   Railway, a plain VPS) without reinstalling node_modules.
 * - TypeScript build errors are NOT ignored in production. The previous
 *   `ignoreBuildErrors: true` was a development shortcut; removing it
 *   forces type-safety at build time so broken code cannot ship.
 * - ESLint runs during build (`eslint duringBuild`) but does not block
 *   builds (`ignoreDuringBuilds: false`); a failing lint step fails the
 *   Vercel deploy, which is what we want.
 * - Image optimization uses Sharp (already a dependency) and allows
 *   remote images from common CMS / CDN origins used by the app.
 * - `poweredByHeader: false` removes the `X-Powered-By: Next.js` header
 *   for minor fingerprinting reduction.
 * - `reactStrictMode: true` catches unsafe lifecycles / side-effects in
 *   development. (Was `false` previously; flipping back for prod quality.)
 * - `compress: true` enables gzip on the Node server (Vercel already
 *   handles this at the edge, but it's a no-op there and helps when
 *   self-hosting).
 * - `experimental.optimizePackageImports` enables barrel-file tree
 *   shaking for the heaviest UI libs we use, trimming client bundle size.
 * - `experimental.serverMinification` and `serverExternalPackages`
 *   keep large server-only libs (Prisma, Sharp) out of the server bundle.
 */
const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,

  // Type-safety must hold at build time. Never silently ship broken types.
  typescript: {
    ignoreBuildErrors: false,
    tsconfigPath: "./tsconfig.json",
  },

  // NOTE: ESLint is run via `bun run lint` separately — Next.js 16 dropped
  // the `eslint.ignoreDuringBuilds` config option. Run `bun run lint` in
  // your CI step before `bun run build` to keep the codebase honest.

  // Image optimization (Sharp is installed as a dependency).
  images: {
    formats: ["image/avif", "image/webp"],
    minimumCacheTTL: 60 * 60 * 24, // 24h
    remotePatterns: [
      { protocol: "https", hostname: "**.wordpress.com" },
      { protocol: "https", hostname: "**.shopify.com" },
      { protocol: "https", hostname: "**.cdn.wordpress.net" },
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "avatars.githubusercontent.com" },
      { protocol: "https", hostname: "lh3.googleusercontent.com" },
    ],
    dangerouslyAllowSVG: false,
  },

  // Headers: security hardening + caching best practices.
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
          {
            key: "Strict-Transport-Security",
            value: "max-age=63072000; includeSubDomains; preload",
          },
        ],
      },
      {
        // Static assets get a long, immutable cache.
        source: "/_next/static/(.*)",
        headers: [
          { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
        ],
      },
    ];
  },

  // Keep large server-only libs out of the bundled server.js
  serverExternalPackages: ["@prisma/client", "sharp", "@google/generative-ai"],

  experimental: {
    // Tree-shake barrel files from heavy UI libs.
    optimizePackageImports: [
      "lucide-react",
      "@radix-ui/react-icons",
      "framer-motion",
      "date-fns",
      "recharts",
    ],
    // Minify the standalone server bundle.
    serverMinification: true,
  },

  // Vercel-friendly: tell Next where to find the standalone output.
  // (Vercel auto-detects this, but it's explicit for self-hosting.)
  outputFileTracingRoot: __dirname,
};

export default nextConfig;
