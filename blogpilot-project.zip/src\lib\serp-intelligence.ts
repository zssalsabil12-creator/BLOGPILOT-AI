/**
 * Deep SERP Intelligence.
 *
 * For a given keyword, extracts what the current top results actually cover —
 * entities, questions, content format, depth, freshness — and, critically,
 * what ALL of them miss ("SERP blind spots") which becomes the information
 * gain opportunity.
 *
 * Cost model: 1 SERP call (cached), ≤5 page snapshots (cached),
 * 1 cheap Gemini extraction pass (cached by content digest).
 */

import { searchDuckDuckGoHtml, searchSerpApi } from './serp';
import { fetchPageSnapshot } from './scraper';
import { generateText, isGeminiConfigured } from './gemini';
import { cacheGet, cacheSet, hashKeyParts } from './cache';

const SERP_TTL = Number(process.env.SERP_CACHE_TTL_SEC || 900);
const SNAPSHOT_TTL = Number(process.env.SNAPSHOT_CACHE_TTL_SEC || 1800);
const INTEL_AI_TTL = Number(process.env.SERP_INTEL_AI_TTL_SEC || 86400);

export interface CompetitorProfile {
  url: string;
  title?: string;
  position: number;
  wordCount: number;
  h2Count: number;
  hasFaq: boolean;
  hasTable: boolean;
  freshnessSignal: 'fresh' | 'dated' | 'unknown'; // year mentions / "updated"
}

export interface SerpIntelligence {
  query: string;
  intent: 'informational' | 'transactional' | 'navigational' | 'commercial' | 'unknown';
  format: 'guide' | 'listicle' | 'comparison' | 'review' | 'how-to' | 'mixed' | 'unknown';
  avgWordCount: number;
  maxWordCount: number;
  competitors: CompetitorProfile[];
  /** Entities/concepts covered by ≥40% of top pages. */
  commonEntities: string[];
  /** Entities covered by only a minority — partial coverage opportunities. */
  partialEntities: string[];
  questions: string[];
  uniqueAngles: string[];
  /** Information present in NONE of the analyzed competitors. */
  serpBlindSpots: string[];
  /** Capped raw texts of analyzed competitors — enables deterministic
   *  uniqueness math downstream without extra fetches. */
  competitorTexts: string[];
  aiPowered: boolean;
}

function detectIntent(query: string): SerpIntelligence['intent'] {
  const q = query.toLowerCase();
  if (/\b(buy|price|cheap|discount|coupon|order)\b/.test(q)) return 'transactional';
  if (/\b(review|best|top \d+|vs\.?|comparison|alternative)\b/.test(q)) return 'commercial';
  if (/\b(login|sign in|download|official site)\b/.test(q)) return 'navigational';
  if (/\b(how to|what is|why|guide|tutorial|tips|ways)\b/.test(q)) return 'informational';
  return 'informational';
}

function detectFormat(snapshots: Array<{ title?: string; h2?: string[] }>): SerpIntelligence['format'] {
  const text = snapshots.map(s => [s.title, ...(s.h2 || [])].join(' ')).join(' ').toLowerCase();
  const listy = /\b(\d+\s+best|\d+\s+tips|top\s+\d+)\b/.test(text) || (text.match(/\b\d+\.\s/g) || []).length > 6;
  const comparison = /\b(vs\.?|versus|compared?|comparison)\b/.test(text);
  const howTo = /\bhow to\b/.test(text);
  const review = /\breview(s|ed)?\b/.test(text);
  if (comparison && review) return 'comparison';
  if (listy) return 'listicle';
  if (howTo) return 'how-to';
  if (review) return 'review';
  if ((snapshots[0]?.h2?.length || 0) >= 5) return 'guide';
  return 'mixed';
}

async function getSerpCached(query: string, num: number): Promise<Array<{ position: number; title?: string; link?: string; snippet?: string }>> {
  const key = `serp:v1:${num}:${hashKeyParts(query)}`;
  const cached = await cacheGet<Array<{ position: number; title?: string; link?: string; snippet?: string }>>(key);
  if (cached) return cached;

  let results: Array<{ position: number; title?: string; link?: string; snippet?: string }> = [];
  try {
    const res = await searchSerpApi(query, num);
    results = res.results;
  } catch {
    try {
      const res = await searchDuckDuckGoHtml(query, num);
      results = res.results;
    } catch (err: any) {
      console.warn('[serp-intel] both SERP sources failed:', err?.message || err);
    }
  }

  if (results.length > 0) await cacheSet(key, results, SERP_TTL);
  return results;
}

async function getSnapshotCached(url: string) {
  const key = `snap:v1:${hashKeyParts(url)}`;
  const cached = await cacheGet<any>(key);
  if (cached) return cached as Awaited<ReturnType<typeof fetchPageSnapshot>>;
  const snap = await fetchPageSnapshot(url);
  if (snap.status > 0) await cacheSet(key, snap, SNAPSHOT_TTL);
  return snap;
}

function profileCompetitor(url: string, position: number, snap: { title?: string; h2?: string[]; h3?: string[]; wordCount?: number; textSnippet?: string }, nowYear: number): CompetitorProfile {
  const headings = [...(snap.h2 || []), ...(snap.h3 || [])].map((h: string) => h.toLowerCase());
  const body = `${(snap.textSnippet || '').slice(0, 4000)}`.toLowerCase();
  const yearsMentioned = body.match(/20[12]\d/g)?.map(Number) ?? [];
  const maxYear = yearsMentioned.length ? Math.max(...yearsMentioned) : 0;

  return {
    url,
    title: snap.title,
    position,
    wordCount: snap.wordCount || 0,
    h2Count: (snap.h2 || []).length,
    hasFaq: headings.some(h => h.includes('faq') || h.includes('frequently asked') || h.includes('question')),
    hasTable: /<table/i.test(body) || /\|.+\|/.test(body) || (body.match(/\t/) || []).length > 3,
    freshnessSignal: maxYear >= nowYear ? 'fresh' : maxYear && maxYear < nowYear - 1 ? 'dated' : 'unknown',
  };
}

interface AiExtraction {
  entities: string[];
  questions: string[];
  uniqueAngles: string[];
  blindSpots: string[];
}

async function aiExtract(query: string, snapshots: Array<{ title?: string; metaDescription?: string; h2?: string[]; h3?: string[]; textSnippet?: string }>): Promise<AiExtraction> {
  const digestInput = snapshots.slice(0, 5).flatMap(s => [
    s.title || '', s.metaDescription || '',
    [...(s.h2 || []), ...(s.h3 || [])].slice(0, 8).join('; '),
    (s.textSnippet || '').slice(0, 600),
  ]);
  const key = `serpintel:v1:${hashKeyParts(query)}:${hashKeyParts(...digestInput)}`;
  const cached = await cacheGet<AiExtraction>(key);
  if (cached) return cached;

  const prompt = `Analyze the top search results for the query: "${query}"

For each result below you get title, meta, headings, and a text excerpt.

Return ONLY raw JSON (no markdown fences) with this shape:
{
  "entities": ["specific nouns/products/features/tools covered by these results"],
  "questions": ["questions these results answer or imply users ask"],
  "uniqueAngles": ["angles at least one result takes"],
  "blindSpots": ["valuable information NO result covers: missing comparisons, missing data, missing steps, outdated info, unanswered follow-ups"]
}
Rules: max 15 items per array, keep each item under 90 characters, be specific not generic.

RESULTS:
${snapshots.slice(0, 5).map((s, i) =>
  `#${i + 1} ${s.title || ''}
meta: ${s.metaDescription || '-'}
headings: ${[...(s.h2 || []), ...(s.h3 || [])].slice(0, 8).join(' | ') || '-'}
text: ${(s.textSnippet || '').slice(0, 500)}`
).join('\n\n')}`;

  try {
    const out = await generateText(prompt, 900);
    const cleaned = out.replace(/^```(?:json)?/m, '').replace(/```\s*$/m, '').trim();
    const startIdx = cleaned.indexOf('{');
    const endIdx = cleaned.lastIndexOf('}');
    const parsed = JSON.parse(cleaned.slice(startIdx, endIdx + 1));
    const extraction: AiExtraction = {
      entities: (parsed.entities || []).slice(0, 15).map(String),
      questions: (parsed.questions || []).slice(0, 15).map(String),
      uniqueAngles: (parsed.uniqueAngles || []).slice(0, 8).map(String),
      blindSpots: (parsed.blindSpots || []).slice(0, 8).map(String),
    };
    await cacheSet(key, extraction, INTEL_AI_TTL);
    return extraction;
  } catch (err: any) {
    console.warn('[serp-intel] AI extraction failed:', err?.message || err);
    return { entities: [], questions: [], uniqueAngles: [], blindSpots: [] };
  }
}

/** Deterministic entity frequency from competitor texts (no AI). */
function entityFrequency(snapshots: Array<{ title?: string; metaDescription?: string; textSnippet?: string }>): Map<string, number> {
  const freq = new Map<string, number>();
  const stop = new Set(['about', 'which', 'there', 'their', 'these', 'other', 'after', 'before', 'where', 'under', 'while', 'this', 'that', 'with', 'from', 'have', 'will', 'your', 'more', 'when']);
  for (const s of snapshots) {
    const seen = new Set<string>();
    const text = `${s.title || ''} ${s.metaDescription || ''} ${(s.textSnippet || '').slice(0, 1500)}`.toLowerCase().replace(/[^a-z\u0600-\u06FF\s]/g, ' ');
    for (const w of text.split(/\s+/)) {
      if (w.length > 4 && !stop.has(w)) seen.add(w);
    }
    for (const w of seen) freq.set(w, (freq.get(w) || 0) + 1);
  }
  return freq;
}

export async function buildSerpIntelligence(query: string, opts?: { numResults?: number }): Promise<SerpIntelligence> {
  const num = Math.min(opts?.numResults || 10, 10);
  const nowYear = new Date().getFullYear();

  const serp = await getSerpCached(query, num);
  const links = serp.map(r => r.link).filter((l): l is string => Boolean(l)).slice(0, 5);

  type LooseSnapshot = {
    url: string;
    status: number;
    title?: string;
    metaDescription?: string;
    h1?: string[];
    h2?: string[];
    h3?: string[];
    wordCount?: number;
    textSnippet?: string;
  };

  const snapshots: LooseSnapshot[] = await Promise.all(
    links.map(link => getSnapshotCached(link).catch(() => ({ url: link, status: 0 })))
  );
  const okSnaps = snapshots.filter(s => s.status > 0);

  // AI pass (may fail gracefully → deterministic fallbacks below)
  const ai = isGeminiConfigured()
    ? await aiExtract(query, okSnaps)
    : { entities: [], questions: [], uniqueAngles: [], blindSpots: [] };

  // Deterministic entity buckets from frequency analysis
  const freq = entityFrequency(okSnaps);
  const total = Math.max(okSnaps.length, 1);
  const commonEntities: string[] = [];
  const partialEntities: string[] = [];
  for (const [word, count] of freq.entries()) {
    const ratio = count / total;
    if (ratio >= 0.4) commonEntities.push(word);
    else if (ratio >= 0.2) partialEntities.push(word);
  }
  commonEntities.sort((a, b) => freq.get(b)! - freq.get(a)!);

  const competitors: CompetitorProfile[] = okSnaps.map((s, i) =>
    profileCompetitor(s.url, i + 1, s, nowYear)
  );

  const wordCounts = competitors.map(c => c.wordCount).filter(w => w > 0);
  const deterministicQuestions = okSnaps
    .flatMap(s => [...(s.h2 || []), ...(s.h3 || [])])
    .filter(h => /^(what|why|how|when|where|which|who|can|do|does|is|are|should)/i.test(h.trim()))
    .slice(0, 10);

  return {
    query,
    intent: detectIntent(query),
    format: detectFormat(okSnaps),
    avgWordCount: wordCounts.length ? Math.round(wordCounts.reduce((a, b) => a + b, 0) / wordCounts.length) : 0,
    maxWordCount: wordCounts.length ? Math.max(...wordCounts) : 0,
    competitors,
    // Merge AI + deterministic (AI first when available, deduped case-insensitively)
    commonEntities: ai.entities.length
      ? [...ai.entities, ...commonEntities.filter(c => !ai.entities.some(e => e.toLowerCase() === c))].slice(0, 18)
      : commonEntities.slice(0, 18),
    partialEntities: partialEntities.slice(0, 10),
    questions: [...deterministicQuestions, ...ai.questions].slice(0, 14),
    uniqueAngles: ai.uniqueAngles,
    serpBlindSpots: ai.blindSpots,
    competitorTexts: okSnaps.map(s => `${s.title || ''} ${(s.textSnippet || '').slice(0, 700)}`),
    aiPowered: ai.entities.length > 0 || ai.blindSpots.length > 0,
  };
}
