﻿import { NextResponse } from 'next/server';
import { isPayPalConfigured } from '@/lib/paypal';

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      provider: 'paypal',
      enabled: isPayPalConfigured(),
      mode: process.env.PAYPAL_ENV === 'live' ? 'live' : 'sandbox',
    },
  });
}