﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { createPayPalOrder, isPayPalConfigured } from '@/lib/paypal';
import { apiError } from '@/lib/utils';

const checkoutSchema = z.object({
  plan: z.enum(['starter', 'pro', 'agency']),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const { plan } = parsed.data;

  try {
    if (isPayPalConfigured()) {
      const order = await createPayPalOrder({ userId, planId: plan });
      if (order.approveUrl) {
        return NextResponse.json({
          ok: true,
          data: { provider: 'paypal', url: order.approveUrl, orderId: order.id, demo: false },
        });
      }
      return NextResponse.json({ ok: false, error: 'PayPal could not create an approval link' }, { status: 502 });
    }

    return NextResponse.json({ ok: false, error: 'Payment provider not configured' }, { status: 503 });
  } catch (error: any) {
    console.error('PayPal checkout error:', error);
    return apiError('paypal/checkout', error);
  }
}