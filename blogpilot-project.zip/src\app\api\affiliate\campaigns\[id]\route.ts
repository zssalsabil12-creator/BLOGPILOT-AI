import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';

const patchSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  isActive: z.boolean().optional(),
  commission: z.string().max(40).optional().nullable(),
  targetAudience: z.string().max(300).optional().nullable(),
  notes: z.string().max(1000).optional().nullable(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const existing = await prisma.affiliateCampaign.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Campaign not found' }, { status: 404 });

    const updated = await prisma.affiliateCampaign.update({ where: { id }, data: parsed.data });
    return NextResponse.json({ ok: true, data: { campaign: updated } });
  } catch (error: any) {
    console.error('Update campaign error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to update campaign' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const existing = await prisma.affiliateCampaign.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Campaign not found' }, { status: 404 });

    // Detach links first (SetNull handles clicks), then delete.
    await prisma.link.updateMany({ where: { campaignId: id }, data: { campaignId: null } });
    await prisma.affiliateCampaign.delete({ where: { id } });

    return NextResponse.json({ ok: true, data: { deleted: true, id } });
  } catch (error: any) {
    console.error('Delete campaign error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to delete campaign' }, { status: 500 });
  }
}
