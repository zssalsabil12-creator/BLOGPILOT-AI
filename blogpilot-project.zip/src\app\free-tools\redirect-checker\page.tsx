'use client';

import React, { useCallback, useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  ArrowRight,
  Loader2,
  AlertTriangle,
  Check,
  RotateCcw,
  Copy,
  GitBranch,
  ExternalLink,
} from 'lucide-react';

interface ChainHop {
  url: string;
  status: number;
  location?: string;
  type: string;
}

interface RedirectResult {
  chain: ChainHop[];
  finalUrl: string;
  totalHops: number;
  hasRedirect: boolean;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  }, [text]);
  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1 rounded-lg border border-border bg-muted/50 px-2 py-1 text-xs text-muted-foreground transition hover:bg-muted hover:text-foreground"
      aria-label="Copy"
    >
      {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
    </button>
  );
}

function HopBadge({ status }: { status: number }) {
  let color = 'bg-slate-500/20 text-slate-300';
  if (status === 301 || status === 308) color = 'bg-emerald-500/20 text-emerald-300';
  else if (status === 302 || status === 303) color = 'bg-amber-500/20 text-amber-300';
  else if (status === 307) color = 'bg-blue-500/20 text-blue-300';
  else if (status >= 200 && status < 300) color = 'bg-emerald-500/20 text-emerald-300';
  else if (status === 0) color = 'bg-rose-500/20 text-rose-300';

  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${color}`}>
      {status}
    </span>
  );
}

function truncateUrl(url: string, max = 60): string {
  if (url.length <= max) return url;
  return url.slice(0, max - 3) + '…';
}

export default function RedirectCheckerPage() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RedirectResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setResult(null);

    const trimmed = url.trim();
    if (!trimmed) {
      setError('Please enter a URL to check.');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/redirect-checker', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Failed to check redirects.');
        return;
      }
      setResult(data);
    } catch (err: any) {
      setError(err?.message || 'Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setUrl('');
    setResult(null);
    setError(null);
  }

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Redirect <span className="text-gradient">Checker</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Trace the full redirect chain of any URL. See every hop, status code, and the final destination.
          </p>
        </section>

        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="url-input" className="text-sm font-medium text-foreground">
                URL to Check
              </label>
              <input
                id="url-input"
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com/old-page"
                className="mt-2 w-full rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
              />
            </div>
            <div className="flex items-center justify-between">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <GitBranch className="h-4 w-4" />}
                {loading ? 'Tracing Redirects…' : 'Check Redirects'}
              </button>
              {result && (
                <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" />
                  New check
                </button>
              )}
            </div>
          </form>

          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </section>

        {loading && !result && (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="shimmer h-20 rounded-2xl border border-border bg-card/50" />
            ))}
          </div>
        )}

        {result && (
          <div className="space-y-6">
            {!result.hasRedirect ? (
              <section className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-6 text-center">
                <Check className="mx-auto h-10 w-10 text-emerald-400" />
                <h3 className="mt-3 text-lg font-semibold text-foreground">No redirect found</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  URL loads directly — no redirects detected.
                </p>
                <p className="mt-3 break-all text-xs text-muted-foreground">{result.finalUrl}</p>
              </section>
            ) : (
              <>
                <section className="rounded-2xl border border-border bg-card/50 p-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="rounded-xl border border-border bg-card/30 p-4 text-center">
                      <p className="text-2xl font-bold text-cyan-300">{result.totalHops}</p>
                      <p className="mt-1 text-xs text-muted-foreground">Total Redirects</p>
                    </div>
                    <div className="rounded-xl border border-border bg-card/30 p-4 text-center">
                      <p className="text-2xl font-bold text-violet-300">{result.chain[result.chain.length - 1]?.status}</p>
                      <p className="mt-1 text-xs text-muted-foreground">Final Status</p>
                    </div>
                  </div>
                </section>

                <section className="rounded-2xl border border-border bg-card/50 p-6">
                  <h2 className="text-lg font-semibold text-foreground">Redirect Chain</h2>
                  <div className="mt-4 space-y-0">
                    {result.chain.map((hop, i) => (
                      <React.Fragment key={i}>
                        {i > 0 && (
                          <div className="flex justify-center py-2">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <ArrowRight className="h-4 w-4" />
                              <span className="text-xs">{hop.type}</span>
                            </div>
                          </div>
                        )}
                        <div className="rounded-xl border border-border bg-card/30 p-4">
                          <div className="flex items-start gap-3">
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-xs font-bold text-cyan-300">
                              {i + 1}
                            </span>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <HopBadge status={hop.status} />
                                <span className="text-xs font-medium text-muted-foreground">{hop.type}</span>
                              </div>
                              <p
                                className="mt-1.5 break-all text-sm text-foreground"
                                title={hop.url}
                              >
                                {truncateUrl(hop.url, 80)}
                              </p>
                              {hop.location && (
                                <p className="mt-1 text-xs text-muted-foreground">
                                  Location: <span className="break-all text-foreground/70">{hop.location}</span>
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </section>

                <section className="rounded-2xl border border-border bg-card/50 p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Final URL</p>
                      <p className="mt-1.5 break-all text-sm font-medium text-foreground">{result.finalUrl}</p>
                    </div>
                    <CopyButton text={result.finalUrl} />
                  </div>
                  <a
                    href={result.finalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300"
                  >
                    <ExternalLink className="h-3 w-3" />
                    Open final URL
                  </a>
                </section>
              </>
            )}
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
