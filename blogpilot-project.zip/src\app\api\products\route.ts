﻿import { NextResponse } from 'next/server';
import { PLANS } from '@/lib/billing';
import { isStripeConfigured } from '@/lib/stripe';
import { isPayPalConfigured } from '@/lib/paypal';
import { getPayeerConfig } from '@/lib/payeer';
import { getAirtmConfig } from '@/lib/airtm';

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      plans: PLANS,
      providers: {
        stripe: { enabled: isStripeConfigured() },
        paypal: { enabled: isPayPalConfigured() },
        payeer: { enabled: getPayeerConfig().enabled },
        airtm: { enabled: getAirtmConfig().enabled },
      },
    },
  });
}