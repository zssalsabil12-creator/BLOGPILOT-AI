'use client'

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts'
import {
  BarChart3,
  TrendingUp,
  Eye,
  FileText,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Target,
  Calendar,
} from 'lucide-react'

// ── Mock Data ──────────────────────────────────────────────────────────────

const articleData = [
  { day: 'Mon', published: 4, drafts: 2 },
  { day: 'Tue', published: 6, drafts: 1 },
  { day: 'Wed', published: 3, drafts: 3 },
  { day: 'Thu', published: 7, drafts: 2 },
  { day: 'Fri', published: 5, drafts: 4 },
  { day: 'Sat', published: 2, drafts: 1 },
  { day: 'Sun', published: 4, drafts: 2 },
]

const seoDistributionData = [
  { range: '70-79', count: 3 },
  { range: '80-84', count: 5 },
  { range: '85-89', count: 8 },
  { range: '90-94', count: 18 },
  { range: '95-100', count: 13 },
]

const trafficTrendData = [
  { day: 'Mon', visitors: 1200 },
  { day: 'Tue', visitors: 1580 },
  { day: 'Wed', visitors: 1390 },
  { day: 'Thu', visitors: 2100 },
  { day: 'Fri', visitors: 1840 },
  { day: 'Sat', visitors: 1650 },
  { day: 'Sun', visitors: 1980 },
]

const topKeywords = [
  { keyword: 'best laptops 2024', views: 3842 },
  { keyword: 'gaming mouse review', views: 2156 },
  { keyword: 'wireless headphones', views: 1893 },
  { keyword: 'mechanical keyboard', views: 1447 },
  { keyword: 'budget monitor', views: 1201 },
]

const revenueByPlatform = [
  { platform: 'Amazon', amount: 1842, color: 'var(--chart-1)' },
  { platform: 'eBay', amount: 876, color: 'var(--chart-2)' },
  { platform: 'CJ', amount: 523, color: 'var(--chart-5)' },
]

const revenuePieData = revenueByPlatform.map((p) => ({
  name: p.platform,
  value: p.amount,
}))

const PIE_COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-5)']

// ── Stat Cards ──────────────────────────────────────────────────────────────

interface StatCardProps {
  title: string
  value: string
  trend: number
  icon: React.ElementType
  iconBgClass: string
}

function StatCard({ title, value, trend, icon: Icon, iconBgClass }: StatCardProps) {
  const isUp = trend >= 0

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={`flex h-9 w-9 items-center justify-center rounded-full ${iconBgClass}`}>
          <Icon className="h-4 w-4" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="mt-1 flex items-center gap-1">
          {isUp ? (
            <ArrowUpRight className="h-3.5 w-3.5 text-emerald-500" />
          ) : (
            <ArrowDownRight className="h-3.5 w-3.5 text-red-500" />
          )}
          <Badge
            variant="secondary"
            className={`text-xs px-1.5 py-0 ${
              isUp
                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'bg-red-500/10 text-red-600 dark:text-red-400'
            }`}
          >
            {isUp ? '+' : ''}{trend}%
          </Badge>
          <span className="text-xs text-muted-foreground">vs last period</span>
        </div>
      </CardContent>
    </Card>
  )
}

// ── Main Component ───────────────────────────────────────────────────────────

export function AnalyticsPage() {
  const maxViews = Math.max(...topKeywords.map((k) => k.views))

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-chart-1/15">
            <BarChart3 className="h-5 w-5 text-chart-1" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Analytics Overview</h1>
            <p className="text-sm text-muted-foreground">
              Track your content performance, SEO scores, and revenue metrics.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-2 sm:mt-0">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Last 7 days</span>
        </div>
      </div>

      {/* Stat Cards Grid */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          title="Total Articles"
          value="47"
          trend={12}
          icon={FileText}
          iconBgClass="bg-chart-1/15 text-chart-1"
        />
        <StatCard
          title="Total Views"
          value="12,847"
          trend={23}
          icon={Eye}
          iconBgClass="bg-chart-2/15 text-chart-2"
        />
        <StatCard
          title="Avg. SEO Score"
          value="91"
          trend={2}
          icon={Target}
          iconBgClass="bg-chart-4/15 text-chart-4"
        />
        <StatCard
          title="Affiliate Revenue"
          value="$3,241"
          trend={18}
          icon={DollarSign}
          iconBgClass="bg-chart-5/15 text-chart-5"
        />
      </div>

      {/* Tabs Section */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        {/* ── Overview Tab ────────────────────────────────────────────────── */}
        <TabsContent value="overview" className="space-y-4">
          {/* Line Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Articles Published</CardTitle>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <div className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: 'var(--chart-1)' }} />
                    Published
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="h-2.5 w-2.5 rounded-sm" style={{ backgroundColor: 'var(--chart-2)' }} />
                    Drafts
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={articleData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis
                    dataKey="day"
                    tickLine={false}
                    axisLine={false}
                    className="text-xs"
                    tick={{ fill: 'currentColor' }}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    className="text-xs"
                    tick={{ fill: 'currentColor' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '0.5rem',
                      fontSize: '0.75rem',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="published"
                    stroke="var(--chart-1)"
                    strokeWidth={2}
                    dot={{ r: 4, fill: 'var(--chart-1)' }}
                    activeDot={{ r: 5 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="drafts"
                    stroke="var(--chart-2)"
                    strokeWidth={2}
                    dot={{ r: 4, fill: 'var(--chart-2)' }}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Bottom Grid: Top Keywords + Revenue by Platform */}
          <div className="grid gap-4 md:grid-cols-2">
            {/* Top Keywords */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Top Keywords</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {topKeywords.map((item, i) => (
                    <div key={item.keyword} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span className="truncate font-medium">{item.keyword}</span>
                        <span className="text-muted-foreground tabular-nums ml-2 shrink-0">
                          {item.views.toLocaleString()}
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full transition-all"
                          style={{
                            width: `${(item.views / maxViews) * 100}%`,
                            backgroundColor: `var(--chart-${(i % 5) + 1})`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Revenue by Platform */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Revenue by Platform</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Mini Pie Chart */}
                  <div className="flex items-center justify-center">
                    <ResponsiveContainer width="100%" height={160}>
                      <PieChart>
                        <Pie
                          data={revenuePieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={65}
                          paddingAngle={4}
                          dataKey="value"
                        >
                          {revenuePieData.map((_, index) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={PIE_COLORS[index % PIE_COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--background))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '0.5rem',
                            fontSize: '0.75rem',
                          }}
                          formatter={(value: number) => [`$${value.toLocaleString()}`, undefined]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Platform Badges */}
                  <div className="space-y-2">
                    {revenueByPlatform.map((item) => {
                      const totalRevenue = revenueByPlatform.reduce((s, p) => s + p.amount, 0)
                      const pct = Math.round((item.amount / totalRevenue) * 100)

                      return (
                        <div key={item.platform} className="flex items-center justify-between">
                          <Badge
                            variant="outline"
                            className="text-xs"
                            style={{ borderColor: item.color, color: item.color }}
                          >
                            <div
                              className="mr-1.5 h-2 w-2 rounded-full"
                              style={{ backgroundColor: item.color }}
                            />
                            {item.platform}
                            <span className="ml-1 text-muted-foreground">{pct}%</span>
                          </Badge>
                          <span className="text-sm font-medium tabular-nums">
                            ${item.amount.toLocaleString()}
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── Performance Tab ───────────────────────────────────────────────── */}
        <TabsContent value="performance" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* SEO Score Distribution Bar Chart */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">SEO Score Distribution</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={seoDistributionData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                    <XAxis
                      dataKey="range"
                      tickLine={false}
                      axisLine={false}
                      className="text-xs"
                      tick={{ fill: 'currentColor' }}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      className="text-xs"
                      tick={{ fill: 'currentColor' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--background))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '0.5rem',
                        fontSize: '0.75rem',
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                      }}
                      formatter={(value: number) => [`${value} articles`, 'Count']}
                    />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {seoDistributionData.map((_, index) => (
                        <Cell
                          key={`bar-${index}`}
                          fill={`var(--chart-${(index % 5) + 1})`}
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Traffic Trend Area Chart */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Traffic Trend</CardTitle>
                  <Eye className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={trafficTrendData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                    <defs>
                      <linearGradient id="trafficGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--chart-3)" stopOpacity={0.3} />
                        <stop offset="100%" stopColor="var(--chart-3)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                    <XAxis
                      dataKey="day"
                      tickLine={false}
                      axisLine={false}
                      className="text-xs"
                      tick={{ fill: 'currentColor' }}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      className="text-xs"
                      tick={{ fill: 'currentColor' }}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'hsl(var(--background))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '0.5rem',
                        fontSize: '0.75rem',
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                      }}
                      formatter={(value: number) => [value.toLocaleString(), 'Visitors']}
                    />
                    <Area
                      type="monotone"
                      dataKey="visitors"
                      stroke="var(--chart-3)"
                      strokeWidth={2}
                      fill="url(#trafficGradient)"
                      dot={{ r: 4, fill: 'var(--chart-3)' }}
                      activeDot={{ r: 5 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
