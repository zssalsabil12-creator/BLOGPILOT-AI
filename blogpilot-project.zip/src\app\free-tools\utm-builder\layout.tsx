﻿import type { Metadata } from 'next';
import { ToolSeo } from '@/components/free-tools/tool-seo';
import { toolPageMetadata } from '@/lib/free-tools/tool-page';

export const metadata: Metadata = toolPageMetadata('utm-builder');

export default function Layout({ children }: { children: React.ReactNode }) {
  return <ToolSeo slug="utm-builder">{children}</ToolSeo>;
}
