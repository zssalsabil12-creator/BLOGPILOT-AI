import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { runQualityGate } from '@/lib/quality-gate';

/**
 * Runs the pre-publish quality gate WITHOUT publishing.
 * The client saves the draft first, then calls this to render the report.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const article = await prisma.article.findFirst({ where: { id, userId } });
    if (!article) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });

    const gate = await runQualityGate(
      {
        title: article.title,
        content: article.content || '',
        excerpt: article.excerpt,
        slug: article.slug,
        targetKeyword: article.targetKeyword,
        authorName: article.authorName,
        reviewerName: article.reviewerName,
        siteId: article.siteId,
      },
      { userId, currentArticleId: article.id },
    );

    return NextResponse.json({ ok: true, data: { report: gate } });
  } catch (error: any) {
    console.error('Quality gate error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to run quality gate' }, { status: 500 });
  }
}
