-- ════════════════════════════════════════════════════════════════════════════
-- BlogPilot AI — Supabase PostgreSQL schema migration
-- ════════════════════════════════════════════════════════════════════════════
-- This script converts the SQLite schema defined in `prisma/schema.prisma`
-- into a PostgreSQL schema suitable for Supabase.
--
-- Usage:
--   1. Create a new Supabase project at https://supabase.com/dashboard
--   2. Open the SQL Editor in Supabase dashboard
--   3. Paste this entire file and click "Run"
--   4. Update your `.env` `DATABASE_URL` to the Supabase connection string:
--        postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres?pgbouncer=true
--   5. In `prisma/schema.prisma`, change the datasource provider:
--        datasource db { provider = "postgresql" url = env("DATABASE_URL") }
--   6. Run `bun run db:push` to sync Prisma with the new Postgres schema.
--
-- Notes:
--   - All `cuid()` IDs in SQLite are migrated as TEXT in Postgres (Supabase
--     handles TEXT natively and we keep the same cuid strings).
--   - The `@updatedAt` behavior is replicated with a trigger function.
--   - All foreign keys use ON DELETE CASCADE to match the Prisma schema.
--   - The schema mirrors Prisma exactly, so `prisma db push` is idempotent
--     against it (it will not try to drop/recreate tables).
-- ════════════════════════════════════════════════════════════════════════════

-- ─── Extensions ─────────────────────────────────────────────────────────────
-- `pgcrypto` is required for `gen_random_uuid()` (used in some Supabase flows).
-- `citext` gives us case-insensitive email comparisons for free.
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "citext";

-- ─── Updated-at trigger function ────────────────────────────────────────────
-- Replicates Prisma's `@updatedAt` behavior automatically.
CREATE OR REPLACE FUNCTION blogpilot_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW."updatedAt" = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ════════════════════════════════════════════════════════════════════════════
-- 1. User
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "User" (
  "id"               TEXT PRIMARY KEY,
  "email"            CITEXT UNIQUE NOT NULL,
  "name"             TEXT,
  "passwordHash"     TEXT,
  "image"            TEXT,
  "credits"          INTEGER NOT NULL DEFAULT 10,
  "totalCreditsUsed" INTEGER NOT NULL DEFAULT 0,
  "freeCreditsUsed"  INTEGER NOT NULL DEFAULT 0,
  "preferredLanguage" TEXT NOT NULL DEFAULT 'en',
  "createdAt"        TIMESTAMP(3) NOT NULL DEFAULT NOW(),
  "updatedAt"        TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
-- Backfill the new column for existing rows (idempotent)
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "freeCreditsUsed" INTEGER NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS "User_email_idx" ON "User"("email");
DROP TRIGGER IF EXISTS "User_updatedAt" ON "User";
CREATE TRIGGER "User_updatedAt" BEFORE UPDATE ON "User"
  FOR EACH ROW EXECUTE FUNCTION blogpilot_set_updated_at();

-- ════════════════════════════════════════════════════════════════════════════
-- 2. Subscription
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "Subscription" (
  "id"                    TEXT PRIMARY KEY,
  "userId"                TEXT UNIQUE NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "plan"                  TEXT NOT NULL DEFAULT 'free',
  "status"                TEXT NOT NULL DEFAULT 'active',
  "stripeCustomerId"      TEXT,
  "stripeSubscriptionId"  TEXT,
  "stripePriceId"         TEXT,
  "stripeProductId"       TEXT,
  "currentPeriodEnd"      TIMESTAMP(3),
  "cancelAtPeriodEnd"     BOOLEAN NOT NULL DEFAULT FALSE,
  "createdAt"             TIMESTAMP(3) NOT NULL DEFAULT NOW(),
  "updatedAt"             TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
DROP TRIGGER IF EXISTS "Subscription_updatedAt" ON "Subscription";
CREATE TRIGGER "Subscription_updatedAt" BEFORE UPDATE ON "Subscription"
  FOR EACH ROW EXECUTE FUNCTION blogpilot_set_updated_at();

-- ════════════════════════════════════════════════════════════════════════════
-- 3. AffiliateKey
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "AffiliateKey" (
  "id"         TEXT PRIMARY KEY,
  "userId"     TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "platform"   TEXT NOT NULL,
  "apiKey"     TEXT,
  "apiSecret"  TEXT,
  "trackingId" TEXT,
  "isActive"   BOOLEAN NOT NULL DEFAULT TRUE,
  "status"     TEXT NOT NULL DEFAULT 'connected',
  "createdAt"  TIMESTAMP(3) NOT NULL DEFAULT NOW(),
  "updatedAt"  TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "AffiliateKey_userId_idx" ON "AffiliateKey"("userId");
DROP TRIGGER IF EXISTS "AffiliateKey_updatedAt" ON "AffiliateKey";
CREATE TRIGGER "AffiliateKey_updatedAt" BEFORE UPDATE ON "AffiliateKey"
  FOR EACH ROW EXECUTE FUNCTION blogpilot_set_updated_at();

-- ════════════════════════════════════════════════════════════════════════════
-- 4. ConnectedSite
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "ConnectedSite" (
  "id"        TEXT PRIMARY KEY,
  "userId"    TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "name"      TEXT NOT NULL,
  "url"       TEXT NOT NULL,
  "platform"  TEXT NOT NULL,
  "apiKey"    TEXT,
  "username"  TEXT,
  "isActive"  BOOLEAN NOT NULL DEFAULT TRUE,
  "lastSyncAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT NOW(),
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "ConnectedSite_userId_idx" ON "ConnectedSite"("userId");
DROP TRIGGER IF EXISTS "ConnectedSite_updatedAt" ON "ConnectedSite";
CREATE TRIGGER "ConnectedSite_updatedAt" BEFORE UPDATE ON "ConnectedSite"
  FOR EACH ROW EXECUTE FUNCTION blogpilot_set_updated_at();

-- ════════════════════════════════════════════════════════════════════════════
-- 5. Article
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "Article" (
  "id"            TEXT PRIMARY KEY,
  "userId"        TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "title"         TEXT NOT NULL,
  "slug"          TEXT,
  "content"       TEXT NOT NULL,
  "excerpt"       TEXT,
  "status"        TEXT NOT NULL DEFAULT 'draft',
  "targetKeyword" TEXT,
  "seoScore"      INTEGER,
  "wordCount"     INTEGER,
  "siteId"        TEXT REFERENCES "ConnectedSite"("id"),
  "language"      TEXT NOT NULL DEFAULT 'en',
  "intent"        TEXT NOT NULL DEFAULT 'informational',
  "tone"          TEXT,
  "length"        TEXT,
  "model"         TEXT,
  "tokensUsed"    INTEGER,
  "publishedAt"   TIMESTAMP(3),
  "scheduledAt"   TIMESTAMP(3),
  "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT NOW(),
  "updatedAt"     TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "Article_userId_idx"         ON "Article"("userId");
CREATE INDEX IF NOT EXISTS "Article_status_idx"         ON "Article"("status");
CREATE INDEX IF NOT EXISTS "Article_createdAt_idx"      ON "Article"("createdAt" DESC);
CREATE INDEX IF NOT EXISTS "Article_targetKeyword_idx"  ON "Article"("targetKeyword");
DROP TRIGGER IF EXISTS "Article_updatedAt" ON "Article";
CREATE TRIGGER "Article_updatedAt" BEFORE UPDATE ON "Article"
  FOR EACH ROW EXECUTE FUNCTION blogpilot_set_updated_at();

-- ════════════════════════════════════════════════════════════════════════════
-- 6. CreditTransaction
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "CreditTransaction" (
  "id"           TEXT PRIMARY KEY,
  "userId"       TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "amount"       INTEGER NOT NULL,
  "reason"       TEXT NOT NULL,
  "description"  TEXT,
  "articleId"    TEXT,
  "balanceAfter" INTEGER NOT NULL,
  "createdAt"    TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "CreditTransaction_userId_idx"   ON "CreditTransaction"("userId");
CREATE INDEX IF NOT EXISTS "CreditTransaction_createdAt_idx" ON "CreditTransaction"("createdAt" DESC);
CREATE INDEX IF NOT EXISTS "CreditTransaction_reason_idx"   ON "CreditTransaction"("reason");

-- ════════════════════════════════════════════════════════════════════════════
-- Row-Level Security (RLS) — recommended for Supabase
-- ════════════════════════════════════════════════════════════════════════════
-- Enable RLS on every table. By default, RLS blocks all access from the
-- PostgREST API (so the Supabase JS client cannot directly read/write).
-- The Next.js app talks to Postgres via Prisma (server-side, service-role
-- key) which bypasses RLS — this is the intended pattern.
ALTER TABLE "User"              ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Subscription"      ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AffiliateKey"      ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ConnectedSite"     ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Article"           ENABLE ROW LEVEL SECURITY;
ALTER TABLE "CreditTransaction" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "GoogleToken" ENABLE ROW LEVEL SECURITY;

-- ════════════════════════════════════════════════════════════════════════════
-- 7. GoogleToken (encrypted OAuth 2.0 tokens for automated publishing/indexing)
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS "GoogleToken" (
  "id"              TEXT PRIMARY KEY,
  "userId"          TEXT NOT NULL REFERENCES "User"("id") ON DELETE CASCADE,
  "googleEmail"     TEXT,
  "googleUserId"    TEXT,
  "accessToken"     TEXT,
  "refreshToken"    TEXT NOT NULL,
  "scope"           TEXT NOT NULL DEFAULT '',
  "tokenType"       TEXT NOT NULL DEFAULT 'Bearer',
  "expiresAt"       TIMESTAMP(3),
  "isActive"        BOOLEAN NOT NULL DEFAULT TRUE,
  "status"          TEXT NOT NULL DEFAULT 'connected',
  "lastRefreshedAt" TIMESTAMP(3),
  "lastUsedAt"      TIMESTAMP(3),
  "services"        TEXT NOT NULL DEFAULT '',
  "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT NOW(),
  "updatedAt"       TIMESTAMP(3) NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS "GoogleToken_userId_idx"      ON "GoogleToken"("userId");
CREATE INDEX IF NOT EXISTS "GoogleToken_googleEmail_idx"  ON "GoogleToken"("googleEmail");
CREATE INDEX IF NOT EXISTS "GoogleToken_isActive_idx"      ON "GoogleToken"("isActive");
DROP TRIGGER IF EXISTS "GoogleToken_updatedAt" ON "GoogleToken";
CREATE TRIGGER "GoogleToken_updatedAt" BEFORE UPDATE ON "GoogleToken"
  FOR EACH ROW EXECUTE FUNCTION blogpilot_set_updated_at();

-- ════════════════════════════════════════════════════════════════════════════
-- Done. Verify with:
--   SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;
-- Expected output: 7 tables (User, Subscription, AffiliateKey, ConnectedSite,
-- Article, CreditTransaction, GoogleToken) + Supabase's own auth.* tables.
-- ════════════════════════════════════════════════════════════════════════════
