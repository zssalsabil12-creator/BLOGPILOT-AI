#!/usr/bin/env python3
"""
Concatenate all BlogPilot AI source files into a single code file
for easy copying. Organized by directory structure.
"""

import os

BASE = "/home/z/my-project"
OUTPUT = "/home/z/my-project/download/BlogPilot-AI-Full-Code.txt"

# Files/dirs to skip
SKIP_DIRS = {"node_modules", ".next", ".git", "download", "scripts", "tests", "examples", "skills", "mini-services", "tool-results"}
SKIP_FILES = {"package-lock.json", "bun.lock", "worklog.md", ".DS_Store"}
SKIP_EXTENSIONS = {".log", ".pyc"}

def should_skip(path):
    parts = path.split(os.sep)
    for p in parts:
        if p in SKIP_DIRS:
            return True
    fname = os.path.basename(path)
    if fname in SKIP_FILES:
        return True
    for ext in SKIP_EXTENSIONS:
        if fname.endswith(ext):
            return True
    return False

def is_source_file(path):
    ext = os.path.splitext(path)[1].lower()
    return ext in {".ts", ".tsx", ".js", ".mjs", ".css", ".prisma", ".json", ".svg", ".txt", ".md"}

def collect_files(base):
    result = []
    for root, dirs, files in os.walk(base):
        # Filter out skipped dirs in-place
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, base)
            if not should_skip(rel) and is_source_file(full):
                result.append((rel, full))
    return sorted(result)

def main():
    files = collect_files(BASE)
    
    with open(OUTPUT, "w", encoding="utf-8") as out:
        out.write("=" * 80 + "\n")
        out.write("  BlogPilot AI - Full Source Code\n")
        out.write("  Generated: 2025-08-06\n")
        out.write("  Tech Stack: Next.js 16 + TypeScript + Tailwind CSS 4 + shadcn/ui + Prisma\n")
        out.write("  Features: Gemini AI, 4 Payment Gateways, SEO, Affiliate Marketing\n")
        out.write("=" * 80 + "\n\n")
        
        out.write("# SETUP INSTRUCTIONS\n")
        out.write("# ===================\n")
        out.write("# 1. Extract all files to your project directory\n")
        out.write("# 2. Run: npm install\n")
        out.write("# 3. Create .env file with:\n")
        out.write('#    DATABASE_URL="file:./dev.db"' + '\n')
        out.write('#    ADMIN_EMAIL=your-email@example.com' + '\n')
        out.write('#    ENCRYPTION_KEY=any-32-char-string-here-for-aes256' + '\n')
        out.write("# 4. Run: npx prisma db push\n")
        out.write("# 5. Run: npm run dev\n")
        out.write("# ===================\n\n")
        
        # Group files by top-level directory
        current_section = None
        for rel, full in files:
            # Determine section
            top_dir = rel.split(os.sep)[0] if os.sep in rel else "(root)"
            if top_dir != current_section:
                current_section = top_dir
                out.write("\n" + "#" * 80 + "\n")
                out.write(f"# SECTION: {top_dir}/\n")
                out.write("#" * 80 + "\n\n")
            
            out.write(f"// ========== FILE: {rel} ==========\n")
            out.write(f"// Path: {rel}\n\n")
            
            try:
                with open(full, "r", encoding="utf-8") as f:
                    content = f.read()
                out.write(content)
                if not content.endswith("\n"):
                    out.write("\n")
            except Exception as e:
                out.write(f"// [ERROR READING FILE: {e}]\n")
            
            out.write("\n\n")
        
        out.write("#" * 80 + "\n")
        out.write("# END OF SOURCE CODE\n")
        out.write("#" * 80 + "\n")
    
    # Count
    total_size = os.path.getsize(OUTPUT)
    print(f"Done! Generated: {OUTPUT}")
    print(f"Files: {len(files)}, Total size: {total_size:,} bytes ({total_size/1024:.1f} KB)")

if __name__ == "__main__":
    main()
