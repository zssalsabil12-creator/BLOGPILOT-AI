import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { PLAN_CONFIG, activateSubscription, type PlanTier } from '@/lib/stripe'
import {
  buildPayeerOrderId,
  buildPayeerPaymentUrl,
  isPayeerConfigured,
} from '@/lib/payeer'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { parseBody } from '@/lib/validation'
import { payeerCheckoutSchema } from '../_validation'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/payeer/checkout
 *
 * Builds a signed Payeer payment URL for upgrading to a paid plan.
 *
 * Body:
 *   { tier: 'basic' | 'pro' | 'agency' }
 *
 * Response (live mode):
 *   200 { url, orderId, demo: false }
 *
 * Response (demo mode — no PAYEER_MERCHANT_ID/SECRET_KEY configured):
 *   200 { demo: true, url, message }
 *   The demo path activates the subscription locally so the user can
 *   try the upgrade flow end-to-end without a real Payeer merchant account.
 *
 * Funds routing:
 *   When the buyer pays on payeer.com, the money lands in the Payeer
 *   account that owns PAYEER_MERCHANT_ID — i.e., the admin's Payeer
 *   wallet. There is no separate payout config.
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(payeerCheckoutSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const tier = body.tier as PlanTier
    if (!tier || !(tier in PLAN_CONFIG) || tier === 'free') {
      return NextResponse.json(
        { error: `Invalid tier. Must be one of: basic, pro, agency`, code: 'validation' },
        { status: 400 }
      )
    }

    const origin =
      request.headers.get('origin') ||
      process.env.NEXT_PUBLIC_APP_URL ||
      'http://localhost:3000'

    // ─── Demo mode ──────────────────────────────────────────────────────
    if (!isPayeerConfigured()) {
      const result = await activateSubscription({
        userId: user.id,
        tier,
        gateway: 'demo',
        externalId: `demo-payeer-${Date.now()}`,
      })

      return NextResponse.json({
        demo: true,
        url: `/dashboard?demo_checkout=success&tier=${tier}&gateway=payeer`,
        message: `Demo mode: upgraded to ${PLAN_CONFIG[tier].label} via Payeer (simulated). ${
          result.creditsGranted ? `${result.creditsGranted} credits granted.` : ''
        }`,
        orderId: `demo-order-${Date.now()}`,
      })
    }

    // ─── Live mode ──────────────────────────────────────────────────────
    const orderId = buildPayeerOrderId(user.id, tier)
    const successUrl = `${origin}/dashboard?payeer=success&tier=${tier}&order=${orderId}`
    const failUrl = `${origin}/dashboard?payeer=fail&order=${orderId}`
    const statusUrl = `${origin}/api/payeer/callback`

    const url = buildPayeerPaymentUrl({
      tier,
      userId: user.id,
      orderId,
      successUrl,
      failUrl,
      statusUrl,
    })

    if (!url) {
      return NextResponse.json(
        { error: 'Failed to build Payeer payment URL', code: 'payeer_error' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      url,
      orderId,
      demo: false,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'payeer/checkout')
  }
}
