# Gemini API Key Rotation — Production Runbook

## What the application does and does not do

**The application never creates, renews, or auto-rotates the Gemini API key.**
API keys are minted exclusively inside [Google AI Studio](https://aistudio.google.com/app/apikey)
(or Google Cloud Console). The app's only job is to read the *currently active*
secret server-side and use it — safely, without ever exposing it.

Rotation is an **external operational procedure**, described below. The
application is built so that rotation requires **no code changes and no
restarts**:

- All Gemini calls read the key through a single abstraction:
  [`src/lib/secrets.ts`](../src/lib/secrets.ts). This is the only place a
  secret backend is plugged in.
- The SDK client is cached *per resolved key value*: when the underlying
  secret changes, the next request transparently uses the new key.
- `GET /api/health/ai` (authenticated) reports only a coarse status:
  `configured` | `not_configured` | `invalid` | `temporarily_unavailable`.
  It never returns the key, version value, or auth headers.

## Supported secret backends

| Backend | How to rotate |
|---|---|
| **Vercel Environment Variables** (default) | Update `GEMINI_API_KEY` in Project → Settings → Environment Variables, then redeploy (or use the Vercel REST API for zero-downtime updates on serverless functions). |
| **Google Cloud Secret Manager** | Add a new *version* to the secret; point the alias used by the app at the new version. Plug the Secret Manager client into `resolveSecret()` in `src/lib/secrets.ts`. |
| **AWS Secrets Manager / Doppler / Infisical** | Same pattern: create new version → validate → shift alias → revoke old. |

## Rotation procedure (zero downtime)

1. **Create** a new valid Gemini API key in Google AI Studio. Do not share it,
   do not commit it.
2. **Store** it as a NEW version of the secret in your secret manager
   (never overwrite in place — keep the old value available).
3. Optionally set `GEMINI_API_KEY_VERSION` (e.g. `"7"`) to label the active
   version. This non-secret label is surfaced by `/api/health/ai` so you can
   observe which version is live.
4. **Validate** before switching traffic: call
   `GET /api/health/ai` with the new version staged (or probe manually from a
   secure shell using the new key against `models.list`). Expect
   `{"ai":"configured"}`.
5. **Switch**: shift the alias / update the env var to the new version.
   The app picks it up on the next request — no restart needed.
6. **Verify** production: run one real generation (or `/api/health/ai`) and
   confirm `configured`.
7. **Safety window**: keep the previous version available for instant
   rollback for 24–48 h. Rollback = shifting the alias back.
8. **Revoke** the old key in Google AI Studio only after step 6 succeeds and
   the safety window closes.

## Security invariants

- The key exists only in server-side environment/secret storage.
- It is never sent to the browser, never embedded in client bundles
  (nothing sensitive is prefixed `NEXT_PUBLIC_`), never returned by any API
  response, and never logged — error paths log messages only.
- `/api/health/ai` is authenticated and rate-limited; its responses contain
  status words and the optional version label only.
