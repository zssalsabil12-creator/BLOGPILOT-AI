'use client';

import React, { useState, useMemo } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Code,
  Copy,
  Check,
  RotateCcw,
  AlertTriangle,
  Tag,
} from 'lucide-react';

interface MetaTags {
  title: string;
  description: string;
  keywords: string;
  author: string;
  robotsIndex: string;
  robotsFollow: string;
  ogTitle: string;
  ogDescription: string;
  ogImageUrl: string;
  ogUrl: string;
  twitterCard: string;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground transition hover:bg-card hover:text-foreground"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function CharCounter({ count, min, max }: { count: number; min: number; max: number }) {
  const color =
    count >= min && count <= max
      ? 'text-emerald-400'
      : count < min
        ? 'text-amber-400'
        : 'text-rose-400';
  return (
    <span className={`text-xs ${color}`}>
      {count}/{max} {count >= min && count <= max ? '(ideal)' : count > max ? '(too long)' : '(too short)'}
    </span>
  );
}

function generateMetaTags(tags: MetaTags): string {
  const lines: string[] = [];

  lines.push(`<!-- Page Title -->`);
  if (tags.title.trim()) {
    lines.push(`<title>${tags.title.trim()}</title>`);
  }

  lines.push('');
  lines.push('<!-- Meta Tags -->');
  if (tags.description.trim()) {
    lines.push(`<meta name="description" content="${tags.description.trim()}" />`);
  }
  if (tags.keywords.trim()) {
    lines.push(`<meta name="keywords" content="${tags.keywords.trim()}" />`);
  }
  if (tags.author.trim()) {
    lines.push(`<meta name="author" content="${tags.author.trim()}" />`);
  }
  lines.push(`<meta name="robots" content="${tags.robotsIndex}, ${tags.robotsFollow}" />`);
  lines.push(`<link rel="canonical" href="https://example.com/page-url" />`);

  lines.push('');
  lines.push('<!-- Open Graph / Facebook -->');
  lines.push('<meta property="og:type" content="website" />');
  if (tags.ogUrl.trim()) {
    lines.push(`<meta property="og:url" content="${tags.ogUrl.trim()}" />`);
  }
  if (tags.ogTitle.trim() || tags.title.trim()) {
    lines.push(`<meta property="og:title" content="${tags.ogTitle.trim() || tags.title.trim()}" />`);
  }
  if (tags.ogDescription.trim() || tags.description.trim()) {
    lines.push(`<meta property="og:description" content="${tags.ogDescription.trim() || tags.description.trim()}" />`);
  }
  if (tags.ogImageUrl.trim()) {
    lines.push(`<meta property="og:image" content="${tags.ogImageUrl.trim()}" />`);
  }

  lines.push('');
  lines.push('<!-- Twitter Card -->');
  lines.push(`<meta name="twitter:card" content="${tags.twitterCard}" />`);
  if (tags.ogTitle.trim() || tags.title.trim()) {
    lines.push(`<meta name="twitter:title" content="${tags.ogTitle.trim() || tags.title.trim()}" />`);
  }
  if (tags.ogDescription.trim() || tags.description.trim()) {
    lines.push(`<meta name="twitter:description" content="${tags.ogDescription.trim() || tags.description.trim()}" />`);
  }
  if (tags.ogImageUrl.trim()) {
    lines.push(`<meta name="twitter:image" content="${tags.ogImageUrl.trim()}" />`);
  }

  return lines.join('\n');
}

export default function MetaTagGeneratorPage() {
  const [tags, setTags] = useState<MetaTags>({
    title: '',
    description: '',
    keywords: '',
    author: '',
    robotsIndex: 'index',
    robotsFollow: 'follow',
    ogTitle: '',
    ogDescription: '',
    ogImageUrl: '',
    ogUrl: '',
    twitterCard: 'summary_large_image',
  });
  const [generated, setGenerated] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const output = useMemo(() => {
    if (!generated) return '';
    return generateMetaTags(tags);
  }, [generated, tags]);

  function handleChange(field: keyof MetaTags, value: string) {
    setTags((prev) => ({ ...prev, [field]: value }));
    if (generated) setGenerated(false);
  }

  function handleGenerate() {
    setError(null);
    if (!tags.title.trim() && !tags.description.trim()) {
      setError('Enter at least a page title or meta description.');
      return;
    }
    setGenerated(true);
  }

  function handleReset() {
    setTags({
      title: '',
      description: '',
      keywords: '',
      author: '',
      robotsIndex: 'index',
      robotsFollow: 'follow',
      ogTitle: '',
      ogDescription: '',
      ogImageUrl: '',
      ogUrl: '',
      twitterCard: 'summary_large_image',
    });
    setGenerated(false);
    setError(null);
  }

  const inputClass =
    'w-full rounded-xl border border-border bg-muted/50 py-2.5 px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30';
  const labelClass = 'text-xs font-medium text-muted-foreground';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Meta Tag <span className="text-gradient">Generator</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Generate SEO-optimized HTML meta tags for your pages.
            Includes title, description, Open Graph, Twitter Card, and robots directives.
          </p>
        </section>

        {/* Input */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-6">
            {/* Basic SEO */}
            <div>
              <div className="mb-3 flex items-center gap-2">
                <Tag className="h-4 w-4 text-cyan-400" />
                <h2 className="text-sm font-semibold text-foreground">Basic SEO Tags</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <label className={labelClass}>Page Title</label>
                    <CharCounter count={tags.title.length} min={50} max={60} />
                  </div>
                  <input
                    value={tags.title}
                    onChange={(e) => handleChange('title', e.target.value)}
                    placeholder="My Page Title - Brand Name"
                    className={inputClass}
                    maxLength={100}
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className={labelClass}>Meta Description</label>
                    <CharCounter count={tags.description.length} min={150} max={160} />
                  </div>
                  <textarea
                    value={tags.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="A compelling description of your page that encourages users to click..."
                    rows={3}
                    className={`${inputClass} resize-none`}
                    maxLength={300}
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className={labelClass}>Target Keywords</label>
                    <input
                      value={tags.keywords}
                      onChange={(e) => handleChange('keywords', e.target.value)}
                      placeholder="keyword1, keyword2, keyword3"
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Author</label>
                    <input
                      value={tags.author}
                      onChange={(e) => handleChange('author', e.target.value)}
                      placeholder="Your Name"
                      className={inputClass}
                    />
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className={labelClass}>Robots Index</label>
                    <select
                      value={tags.robotsIndex}
                      onChange={(e) => handleChange('robotsIndex', e.target.value)}
                      className={inputClass}
                    >
                      <option value="index">index</option>
                      <option value="noindex">noindex</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelClass}>Robots Follow</label>
                    <select
                      value={tags.robotsFollow}
                      onChange={(e) => handleChange('robotsFollow', e.target.value)}
                      className={inputClass}
                    >
                      <option value="follow">follow</option>
                      <option value="nofollow">nofollow</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Open Graph */}
            <div className="border-t border-border pt-6">
              <div className="mb-3 flex items-center gap-2">
                <Code className="h-4 w-4 text-violet-400" />
                <h2 className="text-sm font-semibold text-foreground">Open Graph &amp; Social</h2>
              </div>
              <div className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <div className="flex items-center justify-between">
                      <label className={labelClass}>OG Title</label>
                      {tags.ogTitle && <CharCounter count={tags.ogTitle.length} min={0} max={70} />}
                    </div>
                    <input
                      value={tags.ogTitle}
                      onChange={(e) => handleChange('ogTitle', e.target.value)}
                      placeholder="Falls back to Page Title"
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>OG Image URL</label>
                    <input
                      value={tags.ogImageUrl}
                      onChange={(e) => handleChange('ogImageUrl', e.target.value)}
                      placeholder="https://example.com/image.jpg"
                      className={inputClass}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className={labelClass}>OG Description</label>
                    {tags.ogDescription && <CharCounter count={tags.ogDescription.length} min={0} max={200} />}
                  </div>
                  <textarea
                    value={tags.ogDescription}
                    onChange={(e) => handleChange('ogDescription', e.target.value)}
                    placeholder="Falls back to Meta Description"
                    rows={2}
                    className={`${inputClass} resize-none`}
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className={labelClass}>OG URL</label>
                    <input
                      value={tags.ogUrl}
                      onChange={(e) => handleChange('ogUrl', e.target.value)}
                      placeholder="https://example.com/page"
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label className={labelClass}>Twitter Card Type</label>
                    <select
                      value={tags.twitterCard}
                      onChange={(e) => handleChange('twitterCard', e.target.value)}
                      className={inputClass}
                    >
                      <option value="summary">summary</option>
                      <option value="summary_large_image">summary_large_image</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleGenerate}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40"
              >
                <Code className="h-4 w-4" />
                Generate Meta Tags
              </button>
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-muted/50 px-4 py-3 text-sm text-muted-foreground transition hover:bg-card hover:text-foreground"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Reset
              </button>
            </div>

            {error && (
              <div className="flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}
          </div>
        </section>

        {/* Output */}
        {generated && output && (
          <section className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Code className="h-5 w-5 text-cyan-300" />
                <h2 className="text-lg font-semibold text-foreground">Generated Meta Tags</h2>
              </div>
              <CopyButton text={output} />
            </div>
            <div className="mt-4 overflow-x-auto">
              <pre className="rounded-xl border border-border bg-muted/50 p-4 text-sm leading-relaxed text-foreground">
                <code>{output}</code>
              </pre>
            </div>
          </section>
        )}
      </div>
    </FreeToolLayout>
  );
}
