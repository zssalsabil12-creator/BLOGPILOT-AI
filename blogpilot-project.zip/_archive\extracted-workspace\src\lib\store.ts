import { create } from 'zustand'

export type AppView =
  | 'landing'
  | 'login'
  | 'signup'
  | 'dashboard'
  | 'generate-article'
  | 'connected-sites'
  | 'affiliate-credentials'
  | 'history'
  | 'editor'
  | 'billing'
  | 'analytics'

export type DashboardTab =
  | 'analytics'
  | 'generate-article'
  | 'connected-sites'
  | 'affiliate-credentials'
  | 'history'
  | 'editor'
  | 'billing'

export interface User {
  id: string
  email: string
  name: string | null
  image?: string | null
  subscription: {
    plan: string
    status: string
  } | null
}

interface AppState {
  currentView: AppView
  currentDashboardTab: DashboardTab
  /** When entering the editor, the article id to load (or null for a new blank draft) */
  currentArticleId: string | null
  user: User | null
  isSidebarOpen: boolean
  isAuthenticated: boolean

  setView: (view: AppView) => void
  setDashboardTab: (tab: DashboardTab) => void
  setUser: (user: User | null) => void
  setSidebarOpen: (open: boolean) => void
  toggleSidebar: () => void
  login: (user: User) => void
  logout: () => void
  /** Open the full-screen editor for a specific article */
  openEditor: (articleId: string) => void
  /** Close the editor and return to history (or a specified tab) */
  closeEditor: (returnTo?: DashboardTab) => void
}

export const useAppStore = create<AppState>((set) => ({
  currentView: 'landing',
  currentDashboardTab: 'analytics',
  currentArticleId: null,
  user: null,
  isSidebarOpen: true,
  isAuthenticated: false,

  setView: (view) => {
    if (view === 'dashboard') {
      set({ currentView: 'dashboard', currentDashboardTab: 'analytics' })
    } else {
      set({ currentView: view })
    }
  },

  setDashboardTab: (tab) => {
    set({ currentDashboardTab: tab, currentView: tab as AppView })
  },

  setUser: (user) => set({ user }),

  setSidebarOpen: (open) => set({ isSidebarOpen: open }),

  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),

  login: (user) => set({ user, isAuthenticated: true, currentView: 'dashboard', currentDashboardTab: 'analytics' }),

  logout: () => set({ user: null, isAuthenticated: false, currentView: 'landing' }),

  openEditor: (articleId) =>
    set({
      currentArticleId: articleId,
      currentDashboardTab: 'editor',
      currentView: 'editor',
    }),

  closeEditor: (returnTo = 'history') =>
    set({
      currentArticleId: null,
      currentDashboardTab: returnTo,
      currentView: returnTo as AppView,
    }),
}))
