'use client';

import React, { useState, useMemo, useCallback } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Link,
  Copy,
  Check,
  RotateCcw,
  Clock,
  Hash,
} from 'lucide-react';

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground transition hover:bg-card hover:text-foreground"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function generateSlug(
  text: string,
  options: { lowercase: boolean; separator: string; removeSpecial: boolean; maxLength: number }
): string {
  let slug = text;

  if (options.removeSpecial) {
    slug = slug.replace(/[^\w\s-]/g, '');
  }

  slug = slug.replace(/\s+/g, options.separator);
  slug = slug.replace(new RegExp(`[${options.separator}]+`, 'g'), options.separator);
  slug = slug.replace(new RegExp(`^[${options.separator}]+|[${options.separator}]+$`, 'g'), '');

  if (options.lowercase) {
    slug = slug.toLowerCase();
  }

  if (slug.length > options.maxLength) {
    slug = slug.slice(0, options.maxLength);
    slug = slug.replace(new RegExp(`[${options.separator}]+$`, 'g'), '');
  }

  return slug;
}

export default function UrlSlugGeneratorPage() {
  const [input, setInput] = useState('');
  const [lowercase, setLowercase] = useState(true);
  const [separator, setSeparator] = useState('-');
  const [removeSpecial, setRemoveSpecial] = useState(true);
  const [maxLength, setMaxLength] = useState(75);
  const [history, setHistory] = useState<string[]>([]);

  const slug = useMemo(() => {
    if (!input.trim()) return '';
    return generateSlug(input, { lowercase, separator, removeSpecial, maxLength });
  }, [input, lowercase, separator, removeSpecial, maxLength]);

  const addToHistory = useCallback(() => {
    if (!slug) return;
    setHistory((prev) => {
      const next = [slug, ...prev.filter((s) => s !== slug)].slice(0, 5);
      return next;
    });
  }, [slug]);

  const inputClass =
    'w-full rounded-xl border border-border bg-muted/50 py-2.5 px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30';
  const labelClass = 'text-xs font-medium text-muted-foreground';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            URL Slug <span className="text-gradient">Generator</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Convert any text into a clean, SEO-friendly URL slug.
            Customize separators, casing, and length to match your needs.
          </p>
        </section>

        {/* Input */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-5">
            <div>
              <label className={labelClass}>Enter text to convert</label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Your Page Title or Any Text Here"
                rows={3}
                className={`${inputClass} resize-none`}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 px-4 py-3">
                <input
                  type="checkbox"
                  checked={lowercase}
                  onChange={(e) => setLowercase(e.target.checked)}
                  className="h-4 w-4 rounded border-border accent-cyan-400"
                  id="lowercase"
                />
                <label htmlFor="lowercase" className="text-sm text-foreground">Lowercase</label>
              </div>
              <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 px-4 py-3">
                <input
                  type="checkbox"
                  checked={removeSpecial}
                  onChange={(e) => setRemoveSpecial(e.target.checked)}
                  className="h-4 w-4 rounded border-border accent-cyan-400"
                  id="removeSpecial"
                />
                <label htmlFor="removeSpecial" className="text-sm text-foreground">Remove special characters</label>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className={labelClass}>Replace spaces with</label>
                <select
                  value={separator}
                  onChange={(e) => setSeparator(e.target.value)}
                  className={inputClass}
                >
                  <option value="-">Hyphen (-)</option>
                  <option value="_">Underscore (_)</option>
                </select>
              </div>
              <div>
                <label className={labelClass}>Max length</label>
                <input
                  type="number"
                  value={maxLength}
                  onChange={(e) => setMaxLength(Math.max(1, parseInt(e.target.value) || 75))}
                  min={1}
                  max={200}
                  className={inputClass}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Output */}
        {slug && (
          <section className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Link className="h-5 w-5 text-cyan-300" />
                <h2 className="text-lg font-semibold text-foreground">Generated Slug</h2>
              </div>
              <div className="flex items-center gap-2">
                <CopyButton text={slug} />
                <button
                  onClick={addToHistory}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs font-medium text-muted-foreground transition hover:bg-card hover:text-foreground"
                >
                  <Clock className="h-3.5 w-3.5" />
                  Save
                </button>
              </div>
            </div>

            <div className="mt-4 rounded-xl border border-border bg-muted/50 p-4">
              <code className="block break-all text-sm text-foreground">{slug}</code>
            </div>

            <div className="mt-3 rounded-xl border border-border bg-muted/30 p-3">
              <p className="text-xs text-muted-foreground">Preview as full URL:</p>
              <p className="mt-1 text-sm text-foreground">
                https://example.com/<span className="text-cyan-400">{slug || '...'}</span>
              </p>
            </div>

            <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
              <Hash className="h-3.5 w-3.5" />
              <span>{slug.length} characters</span>
            </div>
          </section>
        )}

        {/* Reset */}
        {(input || slug) && (
          <div className="flex justify-end">
            <button
              onClick={() => {
                setInput('');
                setLowercase(true);
                setSeparator('-');
                setRemoveSpecial(true);
                setMaxLength(75);
              }}
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset all
            </button>
          </div>
        )}

        {/* History */}
        {history.length > 0 && (
          <section className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-violet-300" />
              <h2 className="text-lg font-semibold text-foreground">Recent Slugs</h2>
            </div>
            <div className="mt-4 space-y-2">
              {history.map((s, i) => (
                <div key={`${s}-${i}`} className="flex items-center justify-between rounded-xl border border-border bg-muted/30 px-4 py-2.5">
                  <code className="break-all text-sm text-foreground">{s}</code>
                  <CopyButton text={s} />
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </FreeToolLayout>
  );
}
