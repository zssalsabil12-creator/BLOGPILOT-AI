'use client'

import { useState, useEffect, useCallback } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Loader2 } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  KeyRound,
  Plus,
  Shield,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  ExternalLink,
  Trash2,
  MoreVertical,
  Zap,
  Info,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface AffiliateCredential {
  id: string
  platform: string
  hasApiKey: boolean
  hasApiSecret: boolean
  maskedKey: string | null
  trackingId: string | null
  isActive: boolean
  status: string
  createdAt: string
}

const platformMeta: Record<string, {
  color: string
  label: string
  icon: string
  keyLabel: string
  keyPlaceholder: string
  hasSecret: boolean
  secretLabel: string
  secretPlaceholder: string
  hasTrackingId: boolean
  trackingLabel: string
  trackingPlaceholder: string
  helpUrl: string
}> = {
  amazon: {
    color: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    label: 'Amazon Associates',
    icon: 'AZ',
    keyLabel: 'Access Key ID',
    keyPlaceholder: 'AKIAIOSFODNN7EXAMPLE',
    hasSecret: true,
    secretLabel: 'Secret Access Key',
    secretPlaceholder: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    hasTrackingId: true,
    trackingLabel: 'Tracking ID (Associate Tag)',
    trackingPlaceholder: 'yourtag-20',
    helpUrl: 'https://affiliate-program.amazon.com',
  },
  ebay: {
    color: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    label: 'eBay Partner Network',
    icon: 'EB',
    keyLabel: 'App ID (Client ID)',
    keyPlaceholder: 'YourApp-1234-5678-9abc-def0',
    hasSecret: true,
    secretLabel: 'Cert ID (Client Secret)',
    secretPlaceholder: 'EBAY-abc123def456-ghij',
    hasTrackingId: false,
    trackingLabel: '',
    trackingPlaceholder: '',
    helpUrl: 'https://developer.ebay.com',
  },
  cj: {
    color: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    label: 'CJ Affiliate',
    icon: 'CJ',
    keyLabel: 'Developer Key',
    keyPlaceholder: '00aabbcc-dd11-2233-4455-6677889900aa',
    hasSecret: true,
    secretLabel: 'Website ID',
    secretPlaceholder: '12345678',
    hasTrackingId: false,
    trackingLabel: '',
    trackingPlaceholder: '',
    helpUrl: 'https://developers.cj.com',
  },
  shareasale: {
    color: 'bg-teal-500/10 text-teal-500 border-teal-500/20',
    label: 'ShareASale',
    icon: 'SA',
    keyLabel: 'API Token',
    keyPlaceholder: 'your-shareasale-api-token',
    hasSecret: true,
    secretLabel: 'API Secret',
    secretPlaceholder: 'your-api-secret-key',
    hasTrackingId: true,
    trackingLabel: 'Affiliate ID',
    trackingPlaceholder: '123456',
    helpUrl: 'https://www.shareasale.com',
  },
  impact: {
    color: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
    label: 'Impact',
    icon: 'IM',
    keyLabel: 'Account SID',
    keyPlaceholder: 'your-account-sid',
    hasSecret: true,
    secretLabel: 'Auth Token',
    secretPlaceholder: 'your-auth-token',
    hasTrackingId: false,
    trackingLabel: '',
    trackingPlaceholder: '',
    helpUrl: 'https://app.impact.com',
  },
}

export function AffiliateCredentialsPage() {
  const [credentials, setCredentials] = useState<AffiliateCredential[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  // Form state
  const [newPlatform, setNewPlatform] = useState('amazon')
  const [newApiKey, setNewApiKey] = useState('')
  const [newApiSecret, setNewApiSecret] = useState('')
  const [newTrackingId, setNewTrackingId] = useState('')
  const [showApiKeys, setShowApiKeys] = useState<Record<string, boolean>>({})

  // Fetch credentials from API
  const fetchCredentials = useCallback(async () => {
    try {
      const res = await fetch('/api/credentials')
      if (res.ok) {
        const data = await res.json()
        setCredentials(data.credentials || [])
      }
    } catch (error) {
      console.error('Failed to fetch credentials:', error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchCredentials()
  }, [fetchCredentials])

  // Add a new credential
  const handleAddCredential = async () => {
    const meta = platformMeta[newPlatform]

    if (!newApiKey.trim()) {
      toast.error('Missing API Key', {
        description: `Please enter your ${meta.keyLabel}.`,
      })
      return
    }

    if (meta.hasSecret && !newApiSecret.trim()) {
      toast.error('Missing Secret', {
        description: `Please enter your ${meta.secretLabel}.`,
      })
      return
    }

    setIsSaving(true)
    try {
      const res = await fetch('/api/credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'demo-user',
          platform: newPlatform,
          apiKey: newApiKey,
          apiSecret: newApiSecret || undefined,
          trackingId: newTrackingId || undefined,
        }),
      })

      const data = await res.json()

      if (res.ok || res.status === 200) {
        toast.success(`${meta.label} connected!`, {
          description: data.updated
            ? `${meta.label} credential updated and encrypted.`
            : `${meta.label} credential saved with AES-256 encryption.`,
        })
        resetForm()
        setIsAddDialogOpen(false)
        fetchCredentials()
      } else {
        toast.error('Failed to save credential', {
          description: data.error || 'An unexpected error occurred.',
        })
      }
    } catch {
      toast.error('Save failed', {
        description: 'Could not reach the server. Please try again.',
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Toggle credential active status
  const handleToggleCredential = async (credId: string, currentState: boolean) => {
    try {
      const res = await fetch(`/api/credentials/${credId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !currentState }),
      })

      if (res.ok) {
        toast.success(currentState ? 'Credential deactivated' : 'Credential activated', {
          description: currentState
            ? 'Affiliate links from this platform will no longer be embedded.'
            : 'Affiliate links from this platform will now be embedded in articles.',
        })
        fetchCredentials()
      }
    } catch {
      toast.error('Update failed', {
        description: 'Could not update credential status.',
      })
    }
  }

  // Delete a credential
  const handleDeleteCredential = async (credId: string, platform: string) => {
    const meta = platformMeta[platform]
    try {
      const res = await fetch(`/api/credentials/${credId}`, {
        method: 'DELETE',
      })

      if (res.ok) {
        toast.success('Credential removed', {
          description: `${meta.label} credentials have been permanently deleted.`,
        })
        fetchCredentials()
      }
    } catch {
      toast.error('Deletion failed', {
        description: 'Could not remove the credential. Please try again.',
      })
    }
  }

  const resetForm = () => {
    setNewPlatform('amazon')
    setNewApiKey('')
    setNewApiSecret('')
    setNewTrackingId('')
  }

  const currentMeta = platformMeta[newPlatform]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <KeyRound className="h-6 w-6 text-primary" />
            Affiliate Credentials
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your affiliate platform API keys for automatic link embedding
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open)
            if (!open) resetForm()
          }}
        >
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Add Credential
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[540px]">
            <DialogHeader>
              <DialogTitle>Add Affiliate Credential</DialogTitle>
              <DialogDescription>
                Connect an affiliate platform to automatically embed tracking links in your articles. All credentials are encrypted with AES-256-GCM.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-5 py-2">
              {/* Platform Selector */}
              <div className="space-y-2">
                <Label>Platform</Label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {Object.entries(platformMeta).map(([key, meta]) => (
                    <button
                      key={key}
                      onClick={() => setNewPlatform(key)}
                      className={`p-3 rounded-lg border text-left transition-all ${
                        newPlatform === key
                          ? 'border-primary bg-primary/5 shadow-sm'
                          : 'border-border hover:border-border/80'
                      }`}
                    >
                      <div className={`h-6 w-6 rounded flex items-center justify-center text-[10px] font-bold mb-1.5 ${meta.color}`}>
                        {meta.icon}
                      </div>
                      <span className="text-xs font-medium">{meta.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Platform-specific form */}
              <div className="space-y-2">
                <Label htmlFor="api-key">{currentMeta.keyLabel}</Label>
                <Input
                  id="api-key"
                  placeholder={currentMeta.keyPlaceholder}
                  value={newApiKey}
                  onChange={(e) => setNewApiKey(e.target.value)}
                  type="password"
                />
                <p className="text-[11px] text-muted-foreground">
                  Find your {currentMeta.keyLabel} in the {currentMeta.label} developer dashboard.
                </p>
              </div>

              {currentMeta.hasSecret && (
                <div className="space-y-2">
                  <Label htmlFor="api-secret">{currentMeta.secretLabel}</Label>
                  <Input
                    id="api-secret"
                    placeholder={currentMeta.secretPlaceholder}
                    value={newApiSecret}
                    onChange={(e) => setNewApiSecret(e.target.value)}
                    type="password"
                  />
                </div>
              )}

              {currentMeta.hasTrackingId && (
                <div className="space-y-2">
                  <Label htmlFor="tracking-id">{currentMeta.trackingLabel}</Label>
                  <Input
                    id="tracking-id"
                    placeholder={currentMeta.trackingPlaceholder}
                    value={newTrackingId}
                    onChange={(e) => setNewTrackingId(e.target.value)}
                  />
                </div>
              )}

              {/* Help link */}
              <div className="flex items-start gap-2 rounded-lg border border-border/50 p-3">
                <Info className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-medium">Need help finding your credentials?</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    Visit the{' '}
                    <a
                      href={currentMeta.helpUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary underline underline-offset-2"
                    >
                      {currentMeta.label} Developer Portal
                    </a>{' '}
                    to generate or manage your API keys.
                  </p>
                </div>
              </div>

              {/* Encryption notice */}
              <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3">
                <Zap className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-medium">AES-256-GCM Encryption</p>
                  <p className="text-[11px] text-muted-foreground">
                    Your credentials are encrypted at rest and never exposed in API responses. You can revoke access at any time.
                  </p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setIsAddDialogOpen(false); resetForm() }}>
                Cancel
              </Button>
              <Button
                onClick={handleAddCredential}
                disabled={isSaving || !newApiKey.trim() || (currentMeta.hasSecret && !newApiSecret.trim())}
              >
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSaving ? 'Saving...' : 'Save & Encrypt'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Security Notice */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-4 flex items-start gap-3">
          <Shield className="h-5 w-5 text-primary shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium">Your credentials are encrypted</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              All API keys are encrypted with AES-256-GCM before storage and never shared with third parties. 
              Keys are only decrypted server-side when needed for affiliate link generation. 
              You can revoke access at any time by removing a credential.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Credentials List */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : credentials.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-16">
            <div className="flex flex-col items-center justify-center text-center gap-3">
              <div className="h-14 w-14 rounded-full bg-muted flex items-center justify-center">
                <KeyRound className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium">No affiliate credentials</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Add your first affiliate platform to start embedding tracking links in your articles
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {credentials.map((cred) => {
            const meta = platformMeta[cred.platform] || {
              color: 'bg-gray-500/10 text-gray-500 border-gray-500/20',
              label: cred.platform,
              icon: '??',
            }

            return (
              <Card key={cred.id} className="border-border/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Platform icon */}
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center text-xs font-bold ${meta.color}`}>
                      {meta.icon}
                    </div>

                    {/* Credential info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-sm">{meta.label}</p>
                        <Badge
                          variant="outline"
                          className={`text-[10px] ${
                            cred.status === 'connected'
                              ? 'bg-green-500/10 text-green-500 border-green-500/20'
                              : cred.status === 'expired'
                                ? 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20'
                                : 'bg-red-500/10 text-red-500 border-red-500/20'
                          }`}
                        >
                          {cred.status === 'connected' && <CheckCircle2 className="mr-1 h-3 w-3" />}
                          {cred.status === 'expired' && <AlertCircle className="mr-1 h-3 w-3" />}
                          {cred.status === 'invalid' && <AlertCircle className="mr-1 h-3 w-3" />}
                          {cred.status}
                        </Badge>
                      </div>

                      {/* Masked key display */}
                      <div className="flex items-center gap-2 mt-1.5">
                        <code className="text-xs bg-muted px-2 py-0.5 rounded font-mono">
                          {cred.maskedKey || '••••••••••••••••'}
                        </code>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() =>
                                  setShowApiKeys((prev) => ({ ...prev, [cred.id]: !prev[cred.id] }))
                                }
                                className="text-muted-foreground hover:text-foreground"
                              >
                                {showApiKeys[cred.id] ? (
                                  <EyeOff className="h-3.5 w-3.5" />
                                ) : (
                                  <Eye className="h-3.5 w-3.5" />
                                )}
                              </button>
                            </TooltipTrigger>
                            <TooltipContent>
                              {showApiKeys[cred.id] ? 'Hide key' : 'Note: Keys are stored encrypted and only masked versions are returned'}
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>

                      {/* Tracking ID */}
                      {cred.trackingId && (
                        <p className="text-xs text-muted-foreground mt-0.5">
                          Tracking: <code className="bg-muted px-1 py-0.5 rounded font-mono">{cred.trackingId}</code>
                        </p>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={cred.isActive}
                        onCheckedChange={() => handleToggleCredential(cred.id, cred.isActive)}
                        className="data-[state=checked]:bg-green-500"
                      />
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem className="text-xs" onClick={() => window.open(meta.helpUrl || '#', '_blank')}>
                            <ExternalLink className="mr-2 h-3.5 w-3.5" />
                            Developer Dashboard
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-xs text-destructive"
                            onClick={() => handleDeleteCredential(cred.id, cred.platform)}
                          >
                            <Trash2 className="mr-2 h-3.5 w-3.5" />
                            Remove
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
