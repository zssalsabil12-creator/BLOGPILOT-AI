'use client'

import { useState, useEffect, useCallback } from 'react'
import { useAppStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import {
  ArrowLeft,
  Save,
  Send,
  Eye,
  Download,
  Clock,
  FileText,
  Globe,
  Hash,
  Type,
  Loader2,
  ExternalLink,
} from 'lucide-react'

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;')
}

interface QualityGateCheck {
  key: string
  label: string
  status: 'pass' | 'warn' | 'fail'
  detail: string
}

interface QualityGateReport {
  passed: boolean
  score: number
  checks: QualityGateCheck[]
  blockers: QualityGateCheck[]
  warnings: QualityGateCheck[]
}

export default function EditorPage() {
  const { closeEditor, currentArticleId } = useAppStore()

  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [status, setStatus] = useState<'draft' | 'published'>('draft')
  const [saving, setSaving] = useState(false)
  const [publishing, setPublishing] = useState(false)
  const [loading, setLoading] = useState(false)
  const [publishLink, setPublishLink] = useState<string | null>(null)
  const [showToast, setShowToast] = useState(false)
  const [toastMessage, setToastMessage] = useState('')
  const [toastError, setToastError] = useState(false)
  const [articleId, setArticleId] = useState<string | null>(currentArticleId)
  const [showPreview, setShowPreview] = useState(false)
  const [authorName, setAuthorName] = useState('')
  const [reviewerName, setReviewerName] = useState('')
  const [gateReport, setGateReport] = useState<QualityGateReport | null>(null)
  const [gateBlocked, setGateBlocked] = useState(false)

  const wordCount = content
    .trim()
    .split(/\s+/)
    .filter((w) => w.length > 0).length
  const readingTime = Math.max(1, Math.ceil(wordCount / 200))

  const slug = title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .slice(0, 60)

  const metaDescription = content.slice(0, 155).replace(/[#*_`]/g, '')

  const triggerToast = (msg: string, isError = false) => {
    setToastMessage(msg)
    setToastError(isError)
    setShowToast(true)
    setTimeout(() => setShowToast(false), 3500)
  }

  const loadArticle = useCallback(async (id: string) => {
    try {
      setLoading(true)
      const res = await fetch(`/api/articles/${id}`)
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to load article')
      const article = json?.data?.article
      if (article) {
        setTitle(article.title || '')
        setContent(article.content || '')
        setStatus(article.status === 'PUBLISHED' ? 'published' : 'draft')
        setAuthorName(article.authorName || '')
        setReviewerName(article.reviewerName || '')
      }
    } catch (err: any) {
      console.error('Load article error:', err)
      triggerToast(err?.message || 'Failed to load article', true)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (currentArticleId) {
      setArticleId(currentArticleId)
      loadArticle(currentArticleId)
    }
  }, [currentArticleId, loadArticle])

  const saveArticle = async (targetStatus: 'DRAFT' | 'PUBLISHED' = 'DRAFT'): Promise<string | null> => {
    if (!title.trim()) {
      triggerToast('Title is required', true)
      return null
    }
    setSaving(true)
    try {
      const url = articleId ? `/api/articles/${articleId}` : '/api/articles'
      const method = articleId ? 'PATCH' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          content,
          slug: slug || undefined,
          status: targetStatus,
          authorName: authorName.trim() || null,
          reviewerName: reviewerName.trim() || null,
        }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to save article')
      const saved = json?.data?.article
      if (saved?.id) setArticleId(saved.id)
      return saved?.id || articleId
    } catch (err: any) {
      console.error('Save article error:', err)
      triggerToast(err?.message || 'Failed to save article', true)
      return null
    } finally {
      setSaving(false)
    }
  }

  const handleSave = async () => {
    const id = await saveArticle('DRAFT')
    if (id) {
      setStatus('draft')
      triggerToast('Draft saved successfully')
    }
  }

  const runGate = async (id: string): Promise<QualityGateReport | null> => {
    try {
      const res = await fetch(`/api/articles/${id}/quality-gate`, { method: 'POST' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Quality gate failed')
      const report = json?.data?.report as QualityGateReport
      setGateReport(report)
      setGateBlocked(!report.passed)
      return report
    } catch (err: any) {
      triggerToast(err?.message || 'Quality gate failed', true)
      return null
    }
  }

  const publishToSite = async (id: string, force: boolean) => {
    const sitesRes = await fetch('/api/sites')
    const sitesJson = await sitesRes.json()
    const sites: any[] = sitesRes.ok ? (sitesJson?.data?.sites || []) : []
    const activeSite = sites.find(s => s.isActive) || sites[0]

    if (!activeSite) {
      await fetch(`/api/articles/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'PUBLISHED' }),
      })
      setStatus('published')
      setGateBlocked(false)
      setGateReport(null)
      triggerToast('Article marked as published. Connect a site to publish automatically.')
      return
    }

    const res = await fetch(`/api/articles/${id}/publish`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ siteId: activeSite.id, status: 'PUBLISHED', ...(force ? { force: true } : {}) }),
    })
    const json = await res.json()
    if (!res.ok) {
      if ((json as any)?.code === 'quality_gate' && (json as any)?.report) {
        setGateReport((json as any).report as QualityGateReport)
        setGateBlocked(true)
        throw new Error('Quality gate blocked publishing — review the report.')
      }
      throw new Error(json?.error || 'Publishing failed')
    }

    setStatus('published')
    setGateBlocked(false)
    setPublishLink(json?.data?.publish?.link || null)
    triggerToast(json?.data?.publish?.link
      ? 'Article published to your site!'
      : 'Article published successfully!')
  }

  const handlePublish = async (forceOverride = false) => {
    setPublishing(true)
    try {
      const id = await saveArticle('DRAFT')
      if (!id) return

      // Gate first (unless the user already saw blockers and chose override).
      let force = forceOverride
      if (!forceOverride || gateBlocked) {
        const report = await runGate(id)
        if (!report) return
        if (!report.passed && !forceOverride) {
          setGateBlocked(true)
          triggerToast('Quality gate found issues — resolve them or publish anyway.', true)
          return
        }
        force = report.passed ? false : true
      }

      await publishToSite(id, force)
      setGateReport(null)
    } catch (err: any) {
      console.error('Publish article error:', err)
      triggerToast(err?.message || 'Publishing failed', true)
    } finally {
      setPublishing(false)
    }
  }

  const handleExport = () => {
    const html = `<h1>${escapeHtml(title)}</h1>\n<div>${escapeHtml(content)}</div>`
    const blob = new Blob([html], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${slug || 'article'}.html`
    a.click()
    URL.revokeObjectURL(url)
    triggerToast('HTML exported')
  }

  const handlePreview = () => {
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(title || 'Preview')}</title>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 720px; margin: 40px auto; padding: 0 20px; line-height: 1.7; color: #1a1a1a; }
  h1 { font-size: 2rem; margin-bottom: 0.5rem; }
  h2 { font-size: 1.5rem; margin-top: 2rem; border-bottom: 1px solid #eee; padding-bottom: 0.3rem; }
  h3 { font-size: 1.25rem; margin-top: 1.5rem; }
  p { margin: 0.8rem 0; }
  ul, ol { padding-left: 1.5rem; }
  li { margin: 0.3rem 0; }
  blockquote { border-left: 3px solid #ccc; margin: 1rem 0; padding: 0.5rem 1rem; color: #555; background: #f9f9f9; }
  code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-size: 0.9em; }
  pre { background: #f4f4f4; padding: 1rem; border-radius: 6px; overflow-x: auto; }
  pre code { background: none; padding: 0; }
  img { max-width: 100%; border-radius: 8px; }
  a { color: #2563eb; }
</style>
</head>
<body>
${content ? content.split('\n').map(rawLine => {
  const line = escapeHtml(rawLine);
  if (line.startsWith('# ')) return '<h1>' + line.slice(2) + '</h1>';
  if (line.startsWith('## ')) return '<h2>' + line.slice(3) + '</h2>';
  if (line.startsWith('### ')) return '<h3>' + line.slice(4) + '</h3>';
  if (line.startsWith('- ')) return '<li>' + line.slice(2) + '</li>';
  if (line.startsWith('> ')) return '<blockquote>' + line.slice(2) + '</blockquote>';
  if (line.trim() === '') return '<br>';
  return '<p>' + line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\*(.*?)\*/g, '<em>$1</em>') + '</p>';
}).join('\n') : '<p style="color:#999">No content yet. Start writing to see a preview.</p>'}
</body>
</html>`;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  }

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault()
        handleSave()
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [title, content, articleId])

  return (
    <div className="min-h-screen text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto flex h-14 max-w-[1600px] items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => closeEditor()}
              className="h-8 w-8 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium text-foreground/80">
                Article Editor
              </span>
            </div>
            {articleId && (
              <Badge variant="outline" className="border-border text-[10px] text-muted-foreground/60">
                {articleId.slice(0, 8)}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSave}
              disabled={saving || loading}
              className="gap-1.5 text-muted-foreground hover:text-foreground"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">Save</span>
            </Button>
            <Button
              size="sm"
              onClick={() => handlePublish(false)}
              disabled={publishing || saving || loading}
              className="gap-1.5 bg-gradient-to-r from-cyan-500 to-violet-500 text-foreground hover:opacity-90"
            >
              {publishing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">Publish</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-[1600px] px-4 py-6 sm:px-6">
        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        ) : (
          <div className="flex flex-col gap-6 lg:flex-row">
            {/* Editor Panel */}
            <div className="flex-1 space-y-4 lg:w-[70%]">
              {/* Title */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-muted-foreground/50">
                  <Type className="h-3 w-3" />
                  <span>Title</span>
                </div>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter article title..."
                  className="border-border bg-card/50 text-2xl font-semibold text-foreground placeholder:text-muted-foreground/40 focus-visible:ring-primary/40 sm:text-3xl"
                />
              </div>

              {/* Content */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-muted-foreground/50">
                  <Hash className="h-3 w-3" />
                  <span>Content (Markdown)</span>
                </div>
                <div
                  className={cn(
                    'glass overflow-hidden rounded-xl',
                    'focus-within:ring-1 focus-within:ring-primary/40'
                  )}
                >
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder={`# Introduction\n\nWrite your article content here using Markdown...\n\n## Section Title\n\n- List item one\n- List item two\n\n**Bold text** and *italic text*`}
                    className="min-h-[500px] w-full resize-y bg-transparent p-4 font-mono text-sm leading-relaxed text-foreground/80 placeholder:text-muted-foreground/40 focus:outline-none lg:min-h-[600px]"
                  />
                </div>
              </div>

              {/* Mobile Sidebar */}
              <div className="block lg:hidden">
                <Sidebar
                  title={title}
                  slug={slug}
                  metaDescription={metaDescription}
                  wordCount={wordCount}
                  readingTime={readingTime}
                  status={status}
                  publishLink={publishLink}
                  authorName={authorName}
                  reviewerName={reviewerName}
                  onAuthorChange={setAuthorName}
                  onReviewerChange={setReviewerName}
                  gateReport={gateReport}
                  gateBlocked={gateBlocked}
                  onForcePublish={() => handlePublish(true)}
                  onExport={handleExport}
                  onSave={handleSave}
                  onPublish={() => handlePublish(false)}
                  onPreview={handlePreview}
                />
              </div>
            </div>

            {/* Desktop Sidebar */}
            <div className="hidden lg:block lg:w-[30%]">
              <div className="sticky top-20">
                <Sidebar
                  title={title}
                  slug={slug}
                  metaDescription={metaDescription}
                  wordCount={wordCount}
                  readingTime={readingTime}
                  status={status}
                  publishLink={publishLink}
                  authorName={authorName}
                  reviewerName={reviewerName}
                  onAuthorChange={setAuthorName}
                  onReviewerChange={setReviewerName}
                  gateReport={gateReport}
                  gateBlocked={gateBlocked}
                  onForcePublish={() => handlePublish(true)}
                  onExport={handleExport}
                  onSave={handleSave}
                  onPublish={() => handlePublish(false)}
                  onPreview={handlePreview}
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Toast */}
      <div
        className={cn(
          'pointer-events-none fixed bottom-6 left-1/2 z-50 -translate-x-1/2 transition-all duration-300',
          showToast
            ? 'translate-y-0 opacity-100'
            : 'translate-y-4 opacity-0'
        )}
      >
        <div className={cn(
          'glass flex items-center gap-2 rounded-full px-5 py-2.5 text-sm text-foreground shadow-lg',
          toastError && '!text-red-300'
        )}>
          <div className={cn('h-1.5 w-1.5 rounded-full', toastError ? 'bg-red-400' : 'bg-emerald-400')} />
          {toastMessage}
        </div>
      </div>
    </div>
  )
}

function Sidebar({
  title,
  slug,
  metaDescription,
  wordCount,
  readingTime,
  status,
  publishLink,
  authorName,
  reviewerName,
  onAuthorChange,
  onReviewerChange,
  gateReport,
  gateBlocked,
  onForcePublish,
  onExport,
  onSave,
  onPublish,
  onPreview,
}: {
  title: string
  slug: string
  metaDescription: string
  wordCount: number
  readingTime: number
  status: 'draft' | 'published'
  publishLink: string | null
  authorName: string
  reviewerName: string
  onAuthorChange: (v: string) => void
  onReviewerChange: (v: string) => void
  gateReport: QualityGateReport | null
  gateBlocked: boolean
  onForcePublish: () => void
  onExport: () => void
  onSave: () => void
  onPublish: () => void
  onPreview: () => void
}) {
  return (
    <div className="space-y-4">
      {/* SEO Preview */}
      <Card className="glass border-border">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm text-foreground/70">
            <Globe className="h-3.5 w-3.5 text-primary" />
            SEO Preview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="rounded-lg bg-card/50 p-3">
            <p className="text-[13px] text-primary line-clamp-1">
              {title || 'Article Title'}
            </p>
            <p className="mt-0.5 text-[11px] text-emerald-400/80">
              /{slug || 'article-slug'}
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground/60 line-clamp-2">
              {metaDescription || 'Meta description will appear here...'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <Card className="glass border-border">
        <CardContent className="grid grid-cols-2 gap-3 pt-4">
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground/50">
              Words
            </p>
            <p className="text-lg font-semibold text-foreground">{wordCount}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground/50">
              Read Time
            </p>
            <p className="flex items-center gap-1 text-lg font-semibold text-foreground">
              <Clock className="h-3.5 w-3.5 text-violet-400" />
              {readingTime}m
            </p>
          </div>
        </CardContent>
      </Card>

      {/* E-E-A-T */}
      <Card className="glass border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-foreground/70">Trust & Attribution</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Input
            value={authorName}
            onChange={(e) => onAuthorChange(e.target.value)}
            placeholder="Author name"
            className="h-9 bg-muted/40 border-border text-sm"
          />
          <Input
            value={reviewerName}
            onChange={(e) => onReviewerChange(e.target.value)}
            placeholder="Reviewed by (optional)"
            className="h-9 bg-muted/40 border-border text-sm"
          />
          <p className="text-[10px] leading-relaxed text-muted-foreground/60">
            Saved with the article and injected as Article/Person schema plus a visible attribution line on publish.
          </p>
        </CardContent>
      </Card>

      {/* Quality Gate */}
      {gateReport && (
        <Card className={cn('glass border', gateReport.passed ? 'border-emerald-500/30' : 'border-red-500/30')}>
          <CardHeader className="pb-2">
            <CardTitle className={cn('text-sm flex items-center gap-2', gateReport.passed ? 'text-emerald-400' : 'text-red-400')}>
              {gateReport.passed ? '✓ Ready to publish' : `⛔ Do not publish yet — ${gateReport.blockers.length} blocker(s)`}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {gateReport.checks.map((c) => (
              <div key={c.key} className="flex items-start gap-2 text-[11px]">
                <span className={cn('shrink-0 font-bold',
                  c.status === 'pass' && 'text-emerald-400',
                  c.status === 'warn' && 'text-amber-400',
                  c.status === 'fail' && 'text-red-400',
                )}>
                  {c.status === 'pass' ? '✓' : c.status === 'warn' ? '!' : '✕'}
                </span>
                <span className="text-muted-foreground"><b className="text-foreground/80">{c.label}:</b> {c.detail}</span>
              </div>
            ))}
            {gateBlocked && (
              <Button
                size="sm"
                variant="outline"
                onClick={onForcePublish}
                className="mt-2 w-full rounded-xl border-red-500/40 text-red-300 hover:bg-red-500/10 hover:text-red-200"
              >
                Publish anyway (override)
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Status */}
      <Card className="glass border-border">
        <CardContent className="space-y-3 pt-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground/60">Status</span>
            <Badge
              variant="outline"
              className={cn(
                'text-[10px] uppercase tracking-wider',
                status === 'published'
                  ? 'border-emerald-500/30 text-emerald-400'
                  : 'border-amber-500/30 text-amber-400'
              )}
            >
              {status}
            </Badge>
          </div>
          {publishLink && (
            <a
              href={publishLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs text-primary hover:text-primary transition-colors"
            >
              <ExternalLink className="h-3 w-3" />
              View published article
            </a>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card className="glass border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm text-foreground/70">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onSave}
            className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground"
          >
            <Save className="h-3.5 w-3.5" />
            Save Draft
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onPublish}
            className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground"
          >
            <Send className="h-3.5 w-3.5" />
            Publish
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onExport}
            className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground"
          >
            <Download className="h-3.5 w-3.5" />
            Export HTML
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onPreview}
            className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground"
          >
            <Eye className="h-3.5 w-3.5" />
            Preview
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}