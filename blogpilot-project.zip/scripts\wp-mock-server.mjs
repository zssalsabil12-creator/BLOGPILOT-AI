﻿/**
 * Faithful WordPress REST API v2 emulator for integration testing.
 *
 * Implements ONLY the endpoints BlogPilot's wordpress.ts talks to, with the
 * same auth semantics (Application Passwords -> Basic auth) and response
 * shapes as real WordPress core:
 *   GET  /wp-json                     â†’ root discovery (namespaces)
 *   GET  /wp-json/wp/v2/users/me      â†’ authenticated user (401 on bad creds)
 *   POST /wp-json/wp/v2/posts         â†’ create post (201 + full shape)
 *   GET  /wp-json/wp/v2/posts         â†’ list (duplicate detection)
 *
 * Failure injection: set mode file scripts/wp-fail-on (next request to /posts
 * returns 500 once, then clears itself).
 */

import http from 'node:http';
import fs from 'node:fs';

const PORT = Number(process.env.WP_MOCK_PORT || 4310);
const USERNAME = 'blogpilot-tester';
const APP_PASSWORD = 'abcd efgh ijkl mnop'; // WP Application Password format

const posts = [];
let nextId = 42;

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const send = (status, body) => {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(body));
  };

  // Auth check helper â€” WP returns 401 with rest_forbidden code shape.
  const checkAuth = () => {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Basic ')) return false;
    const [user, pass] = Buffer.from(header.slice(6), 'base64').toString().split(':');
    return user === USERNAME && pass === APP_PASSWORD;
  };

  if (url.pathname === '/__echo-auth') {
    const h = req.headers.authorization || '';
    let decoded = null;
    try { decoded = Buffer.from(h.slice(6), 'base64').toString('utf8'); } catch {}
    return send(200, {
      received: h,
      decoded,
      decodedLen: decoded ? decoded.length : -1,
      codes: decoded ? [...decoded].slice(0, 5).map(c => c.charCodeAt(0)) : null,
      recvNonAscii: [...h].filter(c => c.charCodeAt(0) > 127).length,
      recvB64Codes: [...h.slice(6)].slice(0, 6).map(c => c.charCodeAt(0)),
      nodeVersion: process.version,
      selfDecodeTest: Buffer.from('YmxvZ3BpbG90LXRlc3RlcjphYmNkIGVmZ2ggaWprbCBtbm9w', 'base64').toString('utf8'),
      expectedUser: USERNAME,
      expectedPassLen: APP_PASSWORD.length,
    });
  }

  if (url.pathname === '/wp-json') {
    return send(200, {
      name: 'BlogPilot Test WP',
      description: 'WordPress REST emulator',
      namespaces: ['wp/v2'],
      authentication: { 'application-passwords': { endpoints: { authorization: '/wp-admin/authorize-application.php' } } },
    });
  }

  if (url.pathname === '/wp-json/wp/v2/users/me') {
    if (!checkAuth()) {
      return send(401, { code: 'rest_forbidden', message: 'Sorry, you are not allowed to do that.', data: { status: 401 } });
    }
    return send(200, { id: 1, name: 'BlogPilot Tester', slug: 'blogpilot-tester', roles: ['administrator'] });
  }

  if (url.pathname === '/wp-json/wp/v2/posts' && req.method === 'POST') {
    if (!checkAuth()) {
      return send(401, { code: 'rest_cannot_create', message: 'Sorry, you are not allowed to create posts.', data: { status: 401 } });
    }

    // Failure injection: one-shot 500 when flag file exists.
    const failFlag = 'scripts/wp-fail-on';
    if (fs.existsSync(failFlag)) {
      fs.unlinkSync(failFlag);
      return send(500, { code: 'internal_server_error', message: 'Emulated server error' });
    }

    let body = '';
    req.on('data', c => (body += c));
    req.on('end', () => {
      let parsed = {};
      try { parsed = JSON.parse(body || '{}'); } catch {}
      const id = nextId++;
      const slug = parsed.slug || `post-${id}`;
      const post = {
        id,
        date: new Date().toISOString(),
        slug,
        status: parsed.status || 'draft',
        link: `http://localhost:${PORT}/${slug}/`,
        title: { rendered: parsed.title || '' },
        content: { rendered: parsed.content || '', protected: false },
        excerpt: { rendered: parsed.excerpt || '' },
        author: 1,
        featured_media: parsed.featured_media || 0,
        categories: Array.isArray(parsed.categories) ? parsed.categories : [],
        tags: Array.isArray(parsed.tags) ? parsed.tags : [],
      };
      posts.push(post);
      console.log(`[wp-mock] created post #${id} slug=${slug} status=${post.status} cats=[${post.categories}] tags=[${post.tags}] totalPosts=${posts.length}`);
      send(201, post);
    });
    return;
  }

  if (url.pathname === '/wp-json/wp/v2/posts' && req.method === 'GET') {
    const search = (url.searchParams.get('search') || '').toLowerCase();
    const filtered = search ? posts.filter(p => p.title.rendered.toLowerCase().includes(search)) : posts;
    return send(200, filtered.map(p => ({ id: p.id, slug: p.slug, link: p.link, status: p.status, title: { rendered: p.title.rendered } })));
  }

  // Minimal homepage so crawlers can discover the site.
  if (url.pathname === '/' ) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    return res.end('<!DOCTYPE html><html><head><title>BlogPilot Test WP</title></head><body><h1>Test Site</h1><a href="/hello-world/">Hello world post</a></body></html>');
  }

  if (url.pathname === '/__stats') {
    return send(200, { totalPosts: posts.length, slugs: posts.map(p => p.slug) });
  }

  const postIdMatch = url.pathname.match(/^\/wp-json\/wp\/v2\/posts\/(\d+)$/);
  if (postIdMatch) {
    const post = posts.find(p => p.id === Number(postIdMatch[1]));
    if (!post) return send(404, { code: 'rest_post_invalid_id', message: 'Invalid post ID.' });
    return send(200, post);
  }

  send(404, { code: 'rest_no_route', message: 'No route was found matching the URL and request method.' });
});

server.listen(PORT, () => console.log(`[wp-mock] WordPress REST emulator on :${PORT}`));

