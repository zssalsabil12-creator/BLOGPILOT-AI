/**
 * Server-side secret resolution abstraction.
 *
 * This module is the SINGLE seam through which the application reads
 * provider secrets (currently the Gemini API key). It intentionally does
 * NOT implement key creation or "automatic renewal" — API keys are minted
 * exclusively inside Google AI Studio / Google Cloud and rotated externally.
 *
 * Rotation architecture (see docs/SECRET_ROTATION.md):
 *   1. Operator creates a NEW Gemini API key outside the application.
 *   2. Operator stores it as a new version of the secret in the deployment
 *      platform's secret manager (Vercel Environment Variables, Google
 *      Cloud Secret Manager, AWS Secrets Manager, Doppler, ...).
 *   3. Operator validates the new version (see GET /api/health/ai).
 *   4. The alias pointing at the active version is shifted; the app picks
 *      the new value up without code changes (client cache below is keyed
 *      by the resolved value, so a changed value takes effect immediately
 *      on the next request — no restart required).
 *   5. The previous version stays available for instant rollback during a
 *      short safety window and is disabled/revoked only after validation.
 *
 * To integrate a real Secret Manager, replace the body of `resolveSecret()`
 * with the platform SDK call (e.g. `SecretManagerServiceClient.accessSecretVersion`)
 * and keep the returned contract identical. Nothing else in the codebase
 * reads provider secrets directly.
 *
 * SECURITY INVARIANTS:
 * - Values returned here must never be logged, serialized into responses,
 *   or sent to the browser.
 * - Only boolean/status derivatives (configured / valid / invalid) may
 *   cross the API boundary.
 */

type SecretName =
  | 'GEMINI_API_KEY'
  | 'STRIPE_SECRET_KEY'
  | 'STRIPE_WEBHOOK_SECRET';

/**
 * Resolves a secret by name from the ambient environment. This is the only
 * place a deployment-specific secret backend needs to be plugged in.
 */
function resolveSecret(name: SecretName): string | undefined {
  const value = process.env[name];
  if (value && value.trim()) return value.trim();
  return undefined;
}

let cachedGeminiKey: string | null = null;

/**
 * Returns the currently active Gemini API key, or undefined when absent.
 *
 * The result is memoized per resolved value: rotating the underlying secret
 * produces a different value which naturally invalidates the cache entry,
 * so rotation requires zero restarts and zero client exposure.
 */
export function getGeminiApiKey(): string | undefined {
  // Primary name, with the historical variable as fallback so existing
  // deployments keep working after upgrade.
  const primary = resolveSecret('GEMINI_API_KEY');
  const legacyGoogle = process.env.GOOGLE_GENERATIVE_API_KEY;
  const resolved = primary || (legacyGoogle && legacyGoogle.trim()) || undefined;
  cachedGeminiKey = resolved ?? null;
  return resolved;
}

/**
 * Non-secret metadata about the active Gemini secret version, safe for logs
 * and health responses. Operators may set GEMINI_API_KEY_VERSION (e.g. "5")
 * in their secret manager to make rotation state observable without ever
 * exposing the key material itself.
 */
export function getGeminiKeyVersionLabel(): string | null {
  const v = process.env.GEMINI_API_KEY_VERSION;
  return v && v.trim() ? v.trim() : null;
}

export type GeminiStatus =
  | 'configured'
  | 'not_configured'
  | 'invalid'
  | 'temporarily_unavailable';

/**
 * Active probe: performs a minimal, read-only call against the Gemini API
 * (list models) to classify the current configuration. Never returns or
 * logs the key.
 */
export async function probeGemini(): Promise<{ status: GeminiStatus }> {
  const key = getGeminiApiKey();
  if (!key) return { status: 'not_configured' };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5_000);
  try {
    const res = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1',
      { headers: { 'x-goog-api-key': key }, signal: controller.signal },
    );
    if (res.ok) return { status: 'configured' };
    if (res.status === 401 || res.status === 403 || res.status === 400) {
      console.warn('[gemini-health] Gemini configuration invalid');
      return { status: 'invalid' };
    }
    console.warn('[gemini-health] Gemini temporarily unavailable');
    return { status: 'temporarily_unavailable' };
  } catch {
    console.warn('[gemini-health] Gemini configuration unavailable');
    return { status: 'temporarily_unavailable' };
  } finally {
    clearTimeout(timer);
  }
}
