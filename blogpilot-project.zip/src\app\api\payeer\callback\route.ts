﻿import { NextResponse } from 'next/server';
import { verifyPayeerCallback } from '@/lib/payeer';
import { activatePlan, getPlanConfig, isValidPlanId } from '@/lib/billing';

export async function POST(req: Request) {
  const formData = await req.formData().catch(() => null);
  let params: Record<string, string> = {};

  if (formData) {
    for (const [key, value] of formData.entries()) {
      params[key] = String(value);
    }
  } else {
    params = await req.json().catch(() => ({}));
  }

  if (!verifyPayeerCallback(params)) {
    return new NextResponse('INVALID_SIGN', { status: 400 });
  }

  try {
    const orderId = params.m_orderid || '';
    const [userId, planId] = orderId.split(':');
    if (userId && planId && isValidPlanId(planId)) {
      const planConfig = getPlanConfig(planId);
      const expectedAmount = planConfig.priceMonthly.toFixed(2);
      if (params.m_amount && params.m_amount !== expectedAmount) {
        return new NextResponse('AMOUNT_MISMATCH', { status: 400 });
      }
      await activatePlan(userId, planId, {
        source: 'payeer',
        description: `Payeer payment ${params.m_operation_id || ''} for the ${planId} plan`,
        idempotencyKey: `payeer:${params.m_operation_id || params.m_orderid}`,
      });
    }
  } catch (error: any) {
    console.error('Payeer callback error:', error);
    return new NextResponse('ERROR', { status: 500 });
  }

  return new NextResponse('OK');
}