export type SearchIntent = 'informational' | 'transactional' | 'navigational' | 'commercial' | 'unknown';
export type CompetitionLevel = 'low' | 'medium' | 'high' | 'very_high';
export type MonetizationPotential = 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';

export interface PageSnapshot {
  url: string;
  status: number;
  title?: string;
  metaDescription?: string;
  h1?: string[];
  h2?: string[];
  h3?: string[];
  wordCount?: number;
  textSnippet?: string;
  fetchedAt: string;
}

export interface RecommendedLink {
  url: string;
  title?: string;
  reason: string;
  suggestedAnchor: string;
  suggestedPlacement?: string | null;
  linkType?: string | null;
  monetizationPotential?: MonetizationPotential;
}

export interface AiRecommendations {
  recommended_h1?: string;
  recommended_h2?: string[];
  recommended_h3?: string[];
  suggested_faqs?: string[];
  top_improvements?: string[];
  raw?: string;
  error?: string;
}

export interface OpportunityReport {
  query: string;
  fetchedAt: string;
  topResults: PageSnapshot[];
  searchIntent: SearchIntent;
  contentGaps: string[];
  missingSubtopics: string[];
  faqOpportunities: string[];
  featuredSnippetOpportunities: string[];
  internalLinkingOpportunities: string[];
  freshnessIssues: { url: string; ageDays?: number | null }[];
  competitionLevel: CompetitionLevel;
  opportunityScore: number;
  beatTop10Highlights: string[];
  personalizedComparison?: {
    userUrl: string;
    missingTopics: string[];
    weakSections: string[];
  } | null;
  recommendedLinks?: RecommendedLink[];
  aiRecommendations?: AiRecommendations;
  serpError?: string;
}

export type ToolCategory = 'seo' | 'content' | 'technical-seo' | 'structured-data' | 'developer' | 'text' | 'keywords' | 'internal-linking' | 'analysis';

export interface ToolDefinition {
  slug: string;
  title: string;
  description: string;
  category: ToolCategory;
  icon: string;
  cta: string;
  href: string;
  featured?: boolean;
  isNew?: boolean;
  benefit?: string;
  popular?: boolean;
}
