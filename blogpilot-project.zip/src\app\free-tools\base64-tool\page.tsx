'use client';

import { useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import { Copy, Check, RotateCcw, Binary, ArrowLeftRight } from 'lucide-react';

export default function Base64ToolPage() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const process = () => {
    setError('');
    if (!input.trim()) {
      setError('Please enter some text.');
      return;
    }

    try {
      if (mode === 'encode') {
        const bytes = new TextEncoder().encode(input);
        const binary = Array.from(bytes).map((b) => String.fromCharCode(b)).join('');
        setOutput(btoa(binary));
      } else {
        const binary = atob(input.trim());
        const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
        setOutput(new TextDecoder().decode(bytes));
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Invalid input';
      if (mode === 'decode') {
        setError(`Invalid Base64 input: ${msg}`);
      } else {
        setError(`Error: ${msg}`);
      }
    }
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const swap = () => {
    setOutput('');
    setInput(output);
    setMode(mode === 'encode' ? 'decode' : 'encode');
  };

  const clear = () => {
    setInput('');
    setOutput('');
    setError('');
  };

  return (
    <FreeToolLayout>
      <div className="space-y-6">
        <div className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="flex gap-3 mb-4">
            <div className="flex rounded-lg border border-border overflow-hidden">
              <button
                onClick={() => setMode('encode')}
                className={`px-4 py-2 text-sm font-medium transition-colors ${mode === 'encode' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                Encode to Base64
              </button>
              <button
                onClick={() => setMode('decode')}
                className={`px-4 py-2 text-sm font-medium transition-colors ${mode === 'decode' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                Decode from Base64
              </button>
            </div>
          </div>

          <label className="text-sm font-medium text-foreground">{mode === 'encode' ? 'Input Text' : 'Base64 Input'}</label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={mode === 'encode' ? 'Enter text to encode...' : 'Enter Base64 string to decode...'}
            rows={6}
            className="mt-2 w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground font-mono text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-y"
          />
          <p className="text-xs text-muted-foreground mt-1">{input.length} characters</p>

          <div className="flex flex-wrap gap-3 mt-4">
            <button onClick={process} className="px-6 py-2 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
              {mode === 'encode' ? 'Encode' : 'Decode'}
            </button>
            <button onClick={swap} className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeftRight className="w-4 h-4" /> Swap
            </button>
            <button onClick={clear} className="px-4 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground transition-colors">
              Clear
            </button>
          </div>

          {error && <p className="text-sm text-red-500 mt-3">{error}</p>}
        </div>

        {output && (
          <div className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
                <Binary className="w-4 h-4" /> Output
              </h3>
              <button onClick={copyToClipboard} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <pre className="p-4 rounded-xl bg-muted/50 text-sm font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">{output}</pre>
            <p className="text-xs text-muted-foreground mt-1">{output.length} characters</p>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
