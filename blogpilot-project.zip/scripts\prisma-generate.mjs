// postinstall hook: runs `prisma generate` against the schema variant that
// matches the target database.
//
// - DATABASE_PROVIDER=postgresql OR a postgres:// DATABASE_URL
//     -> generates the client from prisma/schema.postgres.prisma
// - anything else (local dev)
//     -> generates from prisma/schema.prisma (SQLite)
import { execSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const provider = (process.env.DATABASE_PROVIDER || '').trim().toLowerCase();
const url = (process.env.DATABASE_URL || '').trim().toLowerCase();

const isPostgres =
  provider === 'postgresql' ||
  provider === 'postgres' ||
  url.startsWith('postgres://') ||
  url.startsWith('postgresql://');

if (isPostgres) {
  execSync(`node scripts/make-postgres-schema.mjs`, { cwd: root, stdio: 'inherit' });
  console.log('prisma generate -> schema.postgres.prisma');
  execSync(`npx prisma generate --schema prisma/schema.postgres.prisma`, {
    cwd: root,
    stdio: 'inherit',
  });
} else {
  console.log('prisma generate -> schema.prisma (sqlite)');
  execSync(`npx prisma generate`, { cwd: root, stdio: 'inherit' });
}
