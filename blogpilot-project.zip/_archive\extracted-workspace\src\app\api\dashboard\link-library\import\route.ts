import { NextResponse } from 'next/server';
import { z } from 'zod';
import { addLink, createLinkBodySchema, listLinks, LINK_TYPES, normalizeUrl, evaluateUrlSafety } from '../../../../../lib/linkLibrary';
import { getCurrentUserId } from '../../../../../lib/auth';

const importSchema = z.object({
  type: z.enum(['csv', 'json']),
  content: z.string().optional(),
  items: z.array(z.any()).optional(),
  confirm: z.boolean().optional(),
});

type ImportRecord = Record<string, unknown>;

function parseCsv(content: string) {
  const lines = content.trim().split(/\r?\n/).filter((line) => line.trim().length > 0);
  if (lines.length === 0) return [];
  const header = lines[0].split(',').map((cell) => cell.trim().replace(/^\uFEFF/, ''));
  return lines.slice(1).map((line) => {
    const values = line.match(/(?:"([^"]*(?:""[^"]*)*)"|[^,]+)/g)?.map((value) => {
      if (!value) return '';
      const raw = value.trim();
      if (raw.startsWith('"') && raw.endsWith('"')) {
        return raw.slice(1, -1).replace(/""/g, '"');
      }
      return raw;
    }) ?? [];
    const item: ImportRecord = {};
    header.forEach((key, index) => {
      item[key] = values[index] ?? '';
    });
    return item;
  });
}

function normalizeRecord(record: ImportRecord) {
  return {
    url: typeof record.url === 'string' ? record.url.trim() : '',
    title: typeof record.title === 'string' ? record.title.trim() : undefined,
    description: typeof record.description === 'string' ? record.description.trim() : undefined,
    category: typeof record.category === 'string' ? record.category.trim() : undefined,
    linkType: typeof record.linkType === 'string' ? record.linkType.trim().toUpperCase() : undefined,
    affiliate: record.affiliate === true || record.affiliate === 'true',
    affiliateProvider: typeof record.affiliateProvider === 'string' ? record.affiliateProvider.trim() : undefined,
    anchorText: typeof record.anchorText === 'string' ? record.anchorText.trim() : undefined,
    targetKeyword: typeof record.targetKeyword === 'string' ? record.targetKeyword.trim() : undefined,
    preferredPlacement: typeof record.preferredPlacement === 'string' ? record.preferredPlacement.trim() : undefined,
    active: record.active === undefined ? true : record.active === true || record.active === 'true',
    productInfo: record.productInfo ?? null,
  };
}

function buildImportPayload(record: ImportRecord) {
  const normalized = normalizeRecord(record);
  return {
    url: normalized.url,
    title: normalized.title,
    description: normalized.description,
    category: normalized.category,
    linkType: LINK_TYPES.includes(normalized.linkType as any) ? (normalized.linkType as any) : undefined,
    affiliate: normalized.affiliate,
    affiliateProvider: normalized.affiliateProvider,
    anchorText: normalized.anchorText,
    targetKeyword: normalized.targetKeyword,
    preferredPlacement: normalized.preferredPlacement,
    active: normalized.active,
    productInfo: normalized.productInfo,
  };
}

async function buildImportPreview(userId: string, records: ImportRecord[]) {
  const existingLinks = await listLinks(userId, { limit: 1000 });
  const existingNormalized = new Set(existingLinks.map((link) => link.urlNormalized));

  const preview = {
    valid: [] as any[],
    invalid: [] as any[],
    duplicates: [] as any[],
    unsafe: [] as any[],
  };

  for (const record of records) {
    const payload = buildImportPayload(record);
    if (!payload.url) {
      preview.invalid.push({ record, error: 'Missing URL' });
      continue;
    }

    let parsed;
    try {
      parsed = createLinkBodySchema.parse(payload);
    } catch (error: any) {
      preview.invalid.push({ record, error: error?.message || 'Validation failed' });
      continue;
    }

    const normalized = normalizeUrl(parsed.url);
    if (existingNormalized.has(normalized)) {
      preview.duplicates.push({ record, reason: 'A duplicate URL already exists in your library.' });
      continue;
    }

    const safety = evaluateUrlSafety(parsed.url);
    if (safety.status === 'UNSAFE') {
      preview.unsafe.push({ record, error: safety.reason });
      continue;
    }

    preview.valid.push({ record, payload: parsed, safety });
  }

  return preview;
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch (error) {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = importSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid import payload', details: parsed.error.flatten() }, { status: 400 });
  }

  const { type, content, items, confirm } = parsed.data;
  let records: ImportRecord[] = [];

  try {
    if (type === 'csv') {
      if (!content) throw new Error('Missing CSV content');
      records = parseCsv(content);
    } else if (items) {
      records = items;
    } else if (content) {
      const parsedJson = JSON.parse(content);
      if (!Array.isArray(parsedJson)) {
        throw new Error('JSON import payload must be an array of records.');
      }
      records = parsedJson;
    }
  } catch (error: any) {
    return NextResponse.json({ ok: false, error: 'Unable to parse import payload: ' + (error?.message || 'invalid data') }, { status: 400 });
  }

  const preview = await buildImportPreview(userId, records);
  if (!confirm) {
    return NextResponse.json({ ok: true, data: { preview } });
  }

  const inserted: any[] = [];
  const errors: any[] = [];

  for (const candidate of preview.valid) {
    try {
      const link = await addLink(userId, candidate.payload);
      inserted.push(link);
    } catch (error: any) {
      errors.push({ record: candidate.record, error: error?.message || 'Failed to import' });
    }
  }

  return NextResponse.json({ ok: true, data: { inserted, errors, preview } });
}
