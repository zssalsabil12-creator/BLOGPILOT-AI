'use client';

import React, { useCallback, useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Search,
  Loader2,
  AlertTriangle,
  Check,
  X,
  ExternalLink,
  Heading1,
  Heading2,
  Heading3,
  RotateCcw,
  Globe,
  ChevronRight,
} from 'lucide-react';

interface PageData {
  url: string;
  status: number;
  title?: string;
  metaDescription?: string;
  h1?: string[];
  h2?: string[];
  h3?: string[];
  wordCount?: number;
}

interface HeadingIssue {
  type: 'error' | 'warning' | 'info';
  message: string;
}

interface HeadingNode {
  level: number;
  text: string;
  children: HeadingNode[];
}

function buildHeadingTree(h1: string[], h2: string[], h3: string[]): HeadingNode[] {
  const root: HeadingNode[] = [];
  let currentH1: HeadingNode | null = null;
  let currentH2: HeadingNode | null = null;

  for (const text of h1) {
    currentH1 = { level: 1, text, children: [] };
    root.push(currentH1);
    currentH2 = null;
  }
  for (const text of h2) {
    currentH2 = { level: 2, text, children: [] };
    if (currentH1) {
      currentH1.children.push(currentH2);
    } else {
      root.push(currentH2);
    }
  }
  for (const text of h3) {
    const node: HeadingNode = { level: 3, text, children: [] };
    if (currentH2) {
      currentH2.children.push(node);
    } else if (currentH1) {
      currentH1.children.push(node);
    } else {
      root.push(node);
    }
  }
  return root;
}

function analyzeHeadings(data: PageData): HeadingIssue[] {
  const issues: HeadingIssue[] = [];
  const h1Count = data.h1?.length || 0;
  const h2Count = data.h2?.length || 0;
  const h3Count = data.h3?.length || 0;

  if (h1Count === 0) {
    issues.push({ type: 'error', message: 'No H1 tag found — every page should have exactly one H1.' });
  } else if (h1Count > 1) {
    issues.push({ type: 'warning', message: `Multiple H1 tags found (${h1Count}). Use only one H1 per page.` });
  }

  if (h2Count === 0 && (h3Count > 0)) {
    issues.push({ type: 'error', message: 'H3 tags exist without any H2 tags — heading levels should not be skipped.' });
  }

  if (h2Count > 0 && h3Count === 0) {
    issues.push({ type: 'info', message: 'No H3 subsections found. Consider adding H3s under H2s for deeper structure.' });
  }

  if (h2Count > 15) {
    issues.push({ type: 'warning', message: `Many H2 sections (${h2Count}). Consider consolidating related topics.` });
  }

  const wordCount = data.wordCount || 0;
  if (wordCount > 0 && h2Count > 0) {
    const wordsPerSection = Math.round(wordCount / h2Count);
    if (wordsPerSection < 100) {
      issues.push({ type: 'warning', message: `Very thin sections detected (~${wordsPerSection} words per H2). Expand your content.` });
    }
  }

  if (h1Count === 1 && h2Count >= 3 && h2Count <= 12) {
    issues.push({ type: 'info', message: 'Good heading structure — one H1 with a reasonable number of H2 sections.' });
  }

  return issues;
}

function HeadingTree({ nodes, depth = 0 }: { nodes: HeadingNode[]; depth?: number }) {
  return (
    <ul className={depth > 0 ? 'ml-4 border-l border-border pl-3' : ''}>
      {nodes.map((node, i) => (
        <li key={i} className="py-1.5">
          <div className="flex items-center gap-2">
            {node.level === 1 && <Heading1 className="h-4 w-4 shrink-0 text-cyan-300" />}
            {node.level === 2 && <Heading2 className="h-4 w-4 shrink-0 text-violet-300" />}
            {node.level === 3 && <Heading3 className="h-4 w-4 shrink-0 text-amber-300" />}
            <span className={`text-sm ${node.level === 1 ? 'font-semibold text-foreground' : 'text-muted-foreground'}`}>
              {node.text}
            </span>
          </div>
          {node.children.length > 0 && <HeadingTree nodes={node.children} depth={depth + 1} />}
        </li>
      ))}
    </ul>
  );
}

function StatsBar({ data }: { data: PageData }) {
  const stats = [
    { label: 'H1', count: data.h1?.length || 0, color: 'text-cyan-300' },
    { label: 'H2', count: data.h2?.length || 0, color: 'text-violet-300' },
    { label: 'H3', count: data.h3?.length || 0, color: 'text-amber-300' },
    { label: 'Words', count: data.wordCount || 0, color: 'text-emerald-300', format: true },
  ];
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      {stats.map((s) => (
        <div key={s.label} className="rounded-xl border border-border bg-card/30 p-3 text-center">
          <p className={`text-2xl font-bold ${s.color}`}>{s.format ? s.count.toLocaleString() : s.count}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{s.label}</p>
        </div>
      ))}
    </div>
  );
}

export default function HeadingAnalyzerPage() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [pageData, setPageData] = useState<PageData | null>(null);
  const [issues, setIssues] = useState<HeadingIssue[]>([]);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setPageData(null);
    setIssues([]);

    if (!url.trim()) {
      setError('Enter a URL to analyze its heading structure.');
      return;
    }

    let normalizedUrl = url.trim();
    if (!normalizedUrl.startsWith('http://') && !normalizedUrl.startsWith('https://')) {
      normalizedUrl = 'https://' + normalizedUrl;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/page-analyzer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: normalizedUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Failed to analyze the page.');
        return;
      }
      const snapshot: PageData = data.snapshot;
      setPageData(snapshot);
      setIssues(analyzeHeadings(snapshot));
    } catch (err: any) {
      setError(err?.message || 'Network error. Check the URL and try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setUrl('');
    setPageData(null);
    setIssues([]);
    setError(null);
  }

  const tree = pageData ? buildHeadingTree(pageData.h1 || [], pageData.h2 || [], pageData.h3 || []) : [];
  const errorCount = issues.filter((i) => i.type === 'error').length;
  const warningCount = issues.filter((i) => i.type === 'warning').length;

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Heading Structure <span className="text-gradient">Analyzer</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Enter any URL to visualize its heading hierarchy (H1–H6).
            Detect structural issues like missing H1s, skipped levels, and thin sections instantly.
          </p>
        </section>

        {/* Input */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <Globe className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  aria-label="Page URL"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com/your-page"
                  className="w-full rounded-xl border border-border bg-muted/50 py-3 pl-11 pr-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                {loading ? 'Analyzing…' : 'Analyze Headings'}
              </button>
            </div>
            {pageData && (
              <div className="flex justify-end">
                <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" />
                  New analysis
                </button>
              </div>
            )}
          </form>
          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </section>

        {/* Loading */}
        {loading && !pageData && (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="shimmer h-28 rounded-2xl border border-border bg-card/50" />
            ))}
          </div>
        )}

        {/* Results */}
        {pageData && (
          <div className="space-y-6">
            {/* Page Info */}
            <section className="rounded-2xl border border-border bg-card/50 p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Analyzed Page</p>
                  <a href={pageData.url} target="_blank" rel="noreferrer" className="mt-1 inline-flex items-center gap-1.5 text-sm font-medium text-foreground hover:underline">
                    {pageData.title || new URL(pageData.url).hostname}
                    <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                  </a>
                </div>
              </div>
            </section>

            {/* Stats */}
            <StatsBar data={pageData} />

            {/* Issues Summary */}
            {issues.length > 0 && (
              <section className="rounded-2xl border border-border bg-card/50 p-6">
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-semibold text-foreground">Issues Found</h2>
                  <div className="flex items-center gap-2">
                    {errorCount > 0 && (
                      <span className="rounded-full bg-rose-400/10 px-2.5 py-0.5 text-xs font-medium text-rose-300">
                        {errorCount} error{errorCount !== 1 ? 's' : ''}
                      </span>
                    )}
                    {warningCount > 0 && (
                      <span className="rounded-full bg-amber-400/10 px-2.5 py-0.5 text-xs font-medium text-amber-300">
                        {warningCount} warning{warningCount !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                </div>
                <ul className="mt-4 space-y-2">
                  {issues.map((issue, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      {issue.type === 'error' && <X className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />}
                      {issue.type === 'warning' && <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />}
                      {issue.type === 'info' && <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />}
                      <span className="text-muted-foreground">{issue.message}</span>
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {/* Heading Tree */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <h2 className="text-lg font-semibold text-foreground">Heading Hierarchy</h2>
              <p className="mt-1 text-sm text-muted-foreground">Visual representation of the page's heading structure.</p>
              <div className="mt-4">
                {tree.length > 0 ? (
                  <HeadingTree nodes={tree} />
                ) : (
                  <p className="text-sm text-muted-foreground">No headings found on this page.</p>
                )}
              </div>
            </section>

            {/* Heading List */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <h2 className="text-lg font-semibold text-foreground">All Headings</h2>
              <div className="mt-4 space-y-1">
                {(pageData.h1 || []).map((h, i) => (
                  <div key={`h1-${i}`} className="flex items-center gap-2 rounded-lg bg-cyan-400/5 px-3 py-2">
                    <span className="shrink-0 rounded bg-cyan-400/20 px-1.5 py-0.5 text-[10px] font-bold text-cyan-300">H1</span>
                    <span className="text-sm text-foreground">{h}</span>
                  </div>
                ))}
                {(pageData.h2 || []).map((h, i) => (
                  <div key={`h2-${i}`} className="flex items-center gap-2 rounded-lg bg-violet-400/5 px-3 py-2 pl-6">
                    <span className="shrink-0 rounded bg-violet-400/20 px-1.5 py-0.5 text-[10px] font-bold text-violet-300">H2</span>
                    <span className="text-sm text-muted-foreground">{h}</span>
                  </div>
                ))}
                {(pageData.h3 || []).map((h, i) => (
                  <div key={`h3-${i}`} className="flex items-center gap-2 rounded-lg bg-amber-400/5 px-3 py-2 pl-12">
                    <span className="shrink-0 rounded bg-amber-400/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-300">H3</span>
                    <span className="text-sm text-muted-foreground">{h}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Next Steps */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <p className="text-xs font-medium uppercase tracking-wider text-cyan-400">Improve This Page</p>
              <div className="mt-3 space-y-2">
                <a
                  href={`/free-tools/seo-title-analyzer?url=${encodeURIComponent(url)}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
                >
                  <ChevronRight className="h-4 w-4" />
                  Analyze title & meta description
                </a>
                <a href="/free-tools/content-opportunity-analyzer" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                  <ChevronRight className="h-4 w-4" />
                  Run a full Content Opportunity Analysis
                </a>
                <a href="/free-tools/internal-link-finder" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                  <ChevronRight className="h-4 w-4" />
                  Find internal linking opportunities
                </a>
              </div>
            </section>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
