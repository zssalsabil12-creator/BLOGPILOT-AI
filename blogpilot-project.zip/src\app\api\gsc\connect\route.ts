import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { getGscAccessToken, listGscSites } from '@/lib/gsc';

const connectSchema = z.object({
  siteId: z.string().min(1).max(64).nullable(),
  propertyUrl: z
    .string()
    .min(4)
    .max(300)
    .refine(v => v.startsWith('sc-https://') || v.startsWith('http') || v.startsWith('sc-domain:'), {
      message: 'Invalid Search Console property URL',
    }),
});

async function verifyOwnership(userId: string, propertyUrl: string): Promise<void> {
  // Real verification: the authenticated user must have this property
  // registered in their own Search Console account.
  const access = await getGscAccessToken(userId);
  if (!access.ok) {
    throw Object.assign(new Error(
      access.reason === 'needs_reconnect'
        ? 'Reconnect your Google account with Search Console access first.'
        : 'Connect your Google account first.'
    ), { statusCode: access.reason === 'needs_reconnect' ? 409 : 400 });
  }
  const sites = await listGscSites(access.accessToken);
  if (!sites.some(s => s.siteUrl === propertyUrl)) {
    throw Object.assign(new Error('Property not found in your Search Console account.'), { statusCode: 403 });
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = connectSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const { siteId, propertyUrl } = parsed.data;

  try {
    await verifyOwnership(userId, propertyUrl);
  } catch (err: any) {
    return NextResponse.json({ ok: false, error: err?.message || 'Verification failed' }, { status: err?.statusCode || 502 });
  }

  try {
    // Unbind this property from any other site of this user (one-to-one).
    await prisma.connectedSite.updateMany({
      where: { userId, gscProperty: propertyUrl },
      data: { gscProperty: null },
    });

    if (siteId) {
      const site = await prisma.connectedSite.findFirst({ where: { id: siteId, userId } });
      if (!site) {
        return NextResponse.json({ ok: false, error: 'Site not found' }, { status: 404 });
      }
      await prisma.connectedSite.update({
        where: { id: site.id },
        data: { gscProperty: propertyUrl, lastSyncAt: new Date() },
      });
    }

    return NextResponse.json({ ok: true, data: { propertyUrl, siteId } });
  } catch (error: any) {
    console.error('GSC connect error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to save Search Console binding' }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const propertyUrl = url.searchParams.get('property');
  if (!propertyUrl) {
    return NextResponse.json({ ok: false, error: 'property query parameter is required' }, { status: 400 });
  }

  try {
    const result = await prisma.connectedSite.updateMany({
      where: { userId, gscProperty: propertyUrl },
      data: { gscProperty: null },
    });
    return NextResponse.json({ ok: true, data: { unbound: result.count } });
  } catch (error: any) {
    console.error('GSC disconnect error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to remove binding' }, { status: 500 });
  }
}
