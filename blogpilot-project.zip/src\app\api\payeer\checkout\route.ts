﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { getPlanConfig } from '@/lib/billing';
import { buildPayeerUrl, getPayeerConfig } from '@/lib/payeer';
import { apiError } from '@/lib/utils';

const checkoutSchema = z.object({
  plan: z.enum(['starter', 'pro', 'agency']),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const { plan } = parsed.data;

  try {
    if (getPayeerConfig().enabled) {
      const url = buildPayeerUrl({
        orderId: `${userId}:${plan}:${Date.now()}`,
        amount: getPlanConfig(plan).priceMonthly,
        description: `BlogPilot ${getPlanConfig(plan).name} Plan`,
      });
      return NextResponse.json({ ok: true, data: { provider: 'payeer', url, demo: false } });
    }

    return NextResponse.json({ ok: false, error: 'Payment provider not configured' }, { status: 503 });
  } catch (error: any) {
    console.error('Payeer checkout error:', error);
    return apiError('payeer/checkout', error);
  }
}