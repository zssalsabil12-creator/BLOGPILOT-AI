/**
 * Information Gain Engine.
 *
 * Measures what an article ADDS beyond what the current top results already
 * say — not keyword density. Deterministic (no AI at score time): compares
 * the article text against SERP-intelligence entity sets and competitor
 * coverage, so scores are explainable and cheap to compute.
 */

import type { SerpIntelligence } from './serp-intelligence';

export interface IgCheck {
  key: string;
  label: string;
  points: number; // contribution toward final score
  max: number;
  detail: string;
}

export interface InformationGainResult {
  score: number; // 0-100
  verdict: 'high' | 'moderate' | 'low' | 'thin';
  checks: IgCheck[];
  /** Entities the article covers that competitors commonly do too. */
  coveredEntities: string[];
  /** SERP-common entities the article misses. */
  missingEntities: string[];
  /** Concepts present in the article but NOT in competitor texts. */
  uniqueContributions: string[];
  unansweredQuestions: string[];
}

function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z\u0600-\u06FF\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 3)
  );
}

/** Generic words excluded from "unique contribution" credit. */
const NOISE_WORDS = new Set([
  'this', 'that', 'with', 'from', 'have', 'will', 'your', 'more', 'when', 'them',
  'they', 'their', 'there', 'these', 'those', 'than', 'then', 'were', 'been',
  'also', 'into', 'just', 'only', 'very', 'make', 'made', 'using', 'used', 'use',
  'after', 'before', 'while', 'about', 'which', 'should', 'could', 'would',
  'really', 'actually', 'because', 'however', 'without', 'through', 'during',
]);

function meaningfulTokens(text: string): string[] {
  return Array.from(tokenize(text)).filter(w => !NOISE_WORDS.has(w));
}

export function computeInformationGain(
  content: string,
  intel: SerpIntelligence,
  opts?: { competitorTexts?: string[] }
): InformationGainResult {
  const tokens = tokenize(content);
  const checks: IgCheck[] = [];

  // ── 1. Coverage of common entities (max 25) ──
  const common = intel.commonEntities.filter(e => e.length > 3);
  const covered: string[] = [];
  const missing: string[] = [];
  for (const e of common) {
    if (tokens.has(e.toLowerCase()) || content.toLowerCase().includes(e.toLowerCase())) covered.push(e);
    else missing.push(e);
  }
  const coverageRatio = common.length ? covered.length / common.length : 0;
  checks.push({
    key: 'entity-coverage',
    label: 'Topic coverage',
    points: Math.round(coverageRatio * 25),
    max: 25,
    detail: common.length
      ? `Covers ${covered.length}/${common.length} entities that top results share.`
      : 'No entity baseline available for this keyword yet.',
  });

  // ── 2. Unique contributions — concepts absent from ALL competitor texts (max 30) ──
  let unique: string[] = [];
  if (opts?.competitorTexts && opts.competitorTexts.length > 0) {
    const competitorTokens = new Set<string>();
    for (const t of opts.competitorTexts) {
      for (const w of meaningfulTokens(t)) competitorTokens.add(w);
    }
    // Concept-like words in our doc that appear in no competitor text.
    unique = meaningfulTokens(content).filter(w => !competitorTokens.has(w));
    // Cap noise: keep words appearing reasonably "concept-like" (not super rare typos)
    unique = unique.slice(0, 60);
  } else {
    // Without raw competitor texts fall back to partial+blind-spot signals.
    unique = Array.from(tokens).filter(w =>
      !intel.commonEntities.includes(w) &&
      intel.serpBlindSpots.some(b => b.toLowerCase().includes(w))
    );
  }

  // Novelty needs substance: a thin article can't claim much information gain.
  // Gate scales credit by length until the article reaches ~500 words.
  const wordTotal = content.trim() ? content.trim().split(/\s+/).length : 0;
  const substanceGate = Math.min(1, wordTotal / 500);
  const uniquenessRatio = Math.min(1, unique.length / 25) * substanceGate;
  checks.push({
    key: 'unique-info',
    label: 'Unique information',
    points: Math.round(uniquenessRatio * 30),
    max: 30,
    detail: `${unique.length} concept(s)/terms appear in your content but in none of the top ${intel.competitors.length} results${wordTotal < 500 ? ` — scaled down for thin draft (${wordTotal.toLocaleString()} words)` : ''}.`,
  });

  // ── 3. Answers questions the SERP leaves open (max 15) ──
  const answeredQuestions = intel.questions.filter(q => {
    const qTokens = Array.from(tokenize(q)).slice(0, 8);
    return qTokens.filter(t => tokens.has(t)).length >= Math.max(2, qTokens.length * 0.5);
  });
  checks.push({
    key: 'question-answer',
    label: 'Question coverage',
    points: intel.questions.length ? Math.round((answeredQuestions.length / intel.questions.length) * 15) : 6,
    max: 15,
    detail: intel.questions.length
      ? `Addresses ${answeredQuestions.length}/${intel.questions.length} questions detected in the SERP.`
      : 'No question set extracted — defaulting to neutral.',
  });
  const unansweredQuestions = intel.questions.filter(q => !answeredQuestions.includes(q));

  // ── 4. First-party value signals (max 15) ──
  const lower = content.toLowerCase();
  const firstPartySignals = [
    /\bwe tested\b/, /\bour (data|testing|experience|results|team)\b/,
    /\bin our (review|analysis|experiment)\b/, /\bcase study\b/,
    /\boriginal (research|survey|data)\b/, /\bwe measured\b/, /\bafter testing\b/,
  ];
  const hasFirstParty = firstPartySignals.some(r => r.test(lower));
  const hasTable = /\|.+\|/.test(content);
  const hasSteps = /^\s*\d+\.\s+/m.test(content);
  let fpPoints = 0;
  if (hasFirstParty) fpPoints += 8;
  if (hasTable) fpPoints += 4;
  if (hasSteps) fpPoints += 3;
  checks.push({
    key: 'first-party',
    label: 'First-party value',
    points: Math.min(fpPoints, 15),
    max: 15,
    detail: [
      hasFirstParty && 'Original experience/data markers found.',
      hasTable && 'Contains a comparison table.',
      hasSteps && 'Step-by-step structure present.',
    ].filter(Boolean).join(' ') || 'No original data, tests, tables, or step frameworks detected.',
  });

  // ── 5. Depth vs SERP (max 10) ──
  const words = content.trim() ? content.trim().split(/\s+/).length : 0;
  const depthRatio = intel.avgWordCount > 0 ? Math.min(1.2, words / intel.avgWordCount) : (words > 800 ? 1 : words / 800);
  checks.push({
    key: 'depth',
    label: 'Depth vs competitors',
    points: Math.round(Math.min(depthRatio, 1) * 10),
    max: 10,
    detail: intel.avgWordCount
      ? `~${words.toLocaleString()} words vs top-result average of ${intel.avgWordCount.toLocaleString()}.`
      : `~${words.toLocaleString()} words.`,
  });

  // ── 6. Addresses SERP blind spots (max 5 bonus-style) ──
  const blindSpotHits = intel.serpBlindSpots.filter(b => {
    const bTokens = Array.from(tokenize(b)).filter(t => t.length > 4);
    return bTokens.length > 0 && bTokens.filter(t => tokens.has(t)).length >= Math.max(1, bTokens.length * 0.4);
  });
  checks.push({
    key: 'blind-spots',
    label: 'Fills SERP gaps',
    points: intel.serpBlindSpots.length ? Math.round((blindSpotHits.length / intel.serpBlindSpots.length) * 5) : 0,
    max: 5,
    detail: intel.serpBlindSpots.length
      ? `${blindSpotHits.length} of ${intel.serpBlindSpots.length} known SERP blind spots addressed.`
      : 'No blind-spot data available for this keyword.',
  });

  const maxTotal = checks.reduce((s, c) => s + c.max, 0);
  const earned = checks.reduce((s, c) => s + c.points, 0);
  const score = Math.round((earned / maxTotal) * 100);

  const verdict: InformationGainResult['verdict'] =
    score >= 70 ? 'high' : score >= 50 ? 'moderate' : score >= 30 ? 'low' : 'thin';

  return {
    score,
    verdict,
    checks,
    coveredEntities: covered.slice(0, 12),
    missingEntities: missing.slice(0, 12),
    uniqueContributions: unique.slice(0, 15),
    unansweredQuestions: unansweredQuestions.slice(0, 8),
  };
}
