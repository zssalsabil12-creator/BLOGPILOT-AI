import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { buildTopicalMap } from '@/lib/topical-map';

const querySchema = z.object({
  siteId: z.string().max(64).optional(),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters' }, { status: 400 });
  }

  const limit = await checkRateLimit(`topical:${userId}`, { windowMs: 60_000, maxRequests: 6 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  try {
    const map = await buildTopicalMap(userId, parsed.data.siteId || null);
    return NextResponse.json({ ok: true, data: map });
  } catch (error: any) {
    console.error('Topical map error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'Topical analysis failed' },
      { status: 502 },
    );
  }
}
