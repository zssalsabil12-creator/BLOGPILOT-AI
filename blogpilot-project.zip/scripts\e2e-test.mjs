/**
 * End-to-end production-hardening test suite.
 * Runs against a live server (default http://localhost:3000).
 *
 * Covers: register -> login -> dashboard -> generate -> credits -> SEO analysis
 * -> free tools -> link library (+ CSV injection) -> WordPress/Blogger errors
 * -> billing -> Stripe unconfigured -> logout, plus: unauthorized request,
 * invalid login, insufficient credits, duplicate webhook, unsafe URL, large
 * payload.
 *
 * Run: node scripts/e2e-test.mjs [baseUrl]
 */
import { PrismaClient } from '@prisma/client';
import crypto from 'node:crypto';
import fs from 'node:fs';

const BASE = process.argv[2] || 'http://localhost:3000';
const prisma = new PrismaClient();

let passed = 0;
let failed = 0;
const failures = [];

function check(name, cond, detail = '') {
  if (cond) {
    passed++;
    console.log(`  PASS ${name}`);
  } else {
    failed++;
    failures.push(name);
    console.log(`  FAIL ${name} ${detail}`);
  }
}

function loadEnvSecret(key) {
  for (const f of ['.env.local', '.env']) {
    try {
      const content = fs.readFileSync(f, 'utf8');
      const m = content.match(new RegExp(`^${key}=(.*)$`, 'm'));
      if (m) return m[1].trim();
    } catch {}
  }
  return null;
}

async function api(path, { method = 'GET', body, cookie, redirect = 'manual', timeoutMs = 600_000 } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (cookie) headers['Cookie'] = cookie;
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      redirect,
      // Real full-article generation chains many provider calls (outline +
      // sections, each with retries/escalation) and can legitimately take
      // several minutes. Keep the harness patient; on very slow legs undici's
      // own 300s headers timeout may still fire on some Node versions — we
      // degrade that to a per-check failure instead of crashing the suite.
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (err) {
    return { status: 0, json: null, text: String(err?.cause?.code || err?.message || err) };
  }
  let json = null;
  const text = await res.text();
  try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text, headers: res.headers };
}

async function main() {
  console.log(`E2E against ${BASE}\n`);

  // ---- Health -------------------------------------------------------------
  const health = await api('/api/health');
  check('health endpoint responds', health.status === 200);

  // ---- Unauthorized request ------------------------------------------------
  const unauth = await api('/api/articles');
  check('unauthenticated API request rejected (401)', unauth.status === 401);
  const dashUnauth = await api('/dashboard');
  check('unauthenticated dashboard redirects to login', dashUnauth.status === 307 || dashUnauth.status === 302 || (dashUnauth.status >= 300 && dashUnauth.status < 400));

  // ---- Register ------------------------------------------------------------
  const email = `e2e-${Date.now()}@test.com`;
  const password = 'Sup3rSecurePass!';
  const signup = await api('/api/auth/signup', { method: 'POST', body: { email, password, name: 'E2E Tester' } });
  if (signup.status === 429) {
    console.log('\nSignup rate-limited (429). Restart the server to clear the in-memory limiter, then re-run.');
    console.log(`========== RESULTS: ${passed} passed, ${failed} failed (aborted early) ==========`);
    process.exit(1);
  }
  check('register returns 201', signup.status === 201, `got ${signup.status}`);
  const setCookie = signup.headers.get('set-cookie') || '';
  const sessionCookie = setCookie.split(';')[0];
  check('session cookie issued', sessionCookie.startsWith('auth_session='));

  // ---- Invalid login -------------------------------------------------------
  const badLogin = await api('/api/auth/login', { method: 'POST', body: { email, password: 'wrong-password' } });
  check('invalid login rejected (401)', badLogin.status === 401);

  // ---- Login ----------------------------------------------------------------
  const login = await api('/api/auth/login', { method: 'POST', body: { email, password } });
  check('login succeeds', login.status === 200 && login.json?.ok === true);
  const authCookie = (login.headers.get('set-cookie') || '').split(';')[0];

  // ---- Me / Dashboard --------------------------------------------------------
  const me = await api('/api/auth/me', { headers: {} , cookie: authCookie });
  check('auth/me returns user', me.status === 200 && me.json?.user?.email === email);
  const dash = await api('/dashboard', { cookie: authCookie });
  check('dashboard renders (200 HTML)', dash.status === 200 && dash.text.includes('<'));
  check('dashboard leaks no other-user data', !dash.text.includes('passwordHash'));

  // ---- Insufficient credits ---------------------------------------------------
  await prisma.user.update({ where: { email }, data: { credits: 0 } });
  const noCredits = await api('/api/generate', {
    method: 'POST',
    cookie: authCookie,
    body: { title: 'Insufficient credits test article', query: 'insufficient credits test' },
  });
  check('generation blocked at zero credits (402)', noCredits.status === 402, `got ${noCredits.status}`);
  const u0 = await prisma.user.findUnique({ where: { email } });
  check('zero-credit rejection did not mutate balance', u0.credits === 0);
  await prisma.user.update({ where: { email }, data: { credits: 3 } });

  // ---- Generate article (real AI path; refunds on failure) --------------------
  const gen = await api('/api/generate', {
    method: 'POST',
    cookie: authCookie,
    body: {
      title: 'The Complete Guide to Evergreen Content',
      query: 'evergreen content strategy',
      instructions: 'Keep it concise for testing purposes.',
    },
  });
  const uGen = await prisma.user.findUnique({ where: { email } });
  if (gen.status === 200) {
    check('article generated', typeof gen.json?.article === 'string' && gen.json.article.length > 200);
    check('credit charged exactly once after generation', uGen.credits === 2, `balance=${uGen.credits}`);
  } else {
    // AI unavailable/failed: a precise, leak-free error (500 internal or 503
    // ai_not_configured / ai_temporarily_unavailable), and the reserved
    // credit MUST be refunded.
    const msg = String(gen.json?.error || '');
    const safe = gen.status === 500 || (gen.status === 503 && ['ai_not_configured', 'ai_temporarily_unavailable'].includes(gen.json?.code));
    const noLeak = !/(sk-|key|api[_-]?key|Bearer|generativelanguage|models\/)/i.test(msg);
    check('failed generation returns precise error without leaks', safe && noLeak, `got ${gen.status} code=${gen.json?.code}`);
    check('failed generation refunded the reserved credit', uGen.credits === 3, `balance=${uGen.credits}`);
  }

  // ---- SEO analysis (SERP + fallbacks) -----------------------------------------
  const analyze = await api('/api/free-tools/analyze', {
    method: 'POST',
    cookie: authCookie,
    body: { input: 'best project management software', type: 'keyword', numResults: 3 },
  });
  check('SEO analysis completes', analyze.status === 200 && analyze.json?.ok === true, `got ${analyze.status}`);

  // ---- Free tools: unsafe URL blocked --------------------------------------------
  const unsafe1 = await api('/api/free-tools/page-analyzer', { method: 'POST', cookie: authCookie, body: { url: 'http://127.0.0.1:8080/admin' } });
  check('loopback URL blocked (SSRF)', unsafe1.status === 400, `got ${unsafe1.status}`);
  const unsafe2 = await api('/api/free-tools/page-analyzer', { method: 'POST', cookie: authCookie, body: { url: 'http://169.254.169.254/latest/meta-data/' } });
  check('metadata IP blocked (SSRF)', unsafe2.status === 400, `got ${unsafe2.status}`);
  const unsafe3 = await api('/api/free-tools/http-header-checker', { method: 'POST', cookie: authCookie, body: { url: 'file:///etc/passwd' } });
  check('non-http scheme blocked', unsafe3.status === 400, `got ${unsafe3.status}`);

  // ---- Large payload ---------------------------------------------------------------
  const big = await api('/api/fact-check', { method: 'POST', cookie: authCookie, body: { content: 'x'.repeat(60000) } });
  check('oversized payload rejected', big.status === 400 || big.status === 413, `got ${big.status}`);

  // ---- Link library + CSV formula injection ------------------------------------------
  const addLink = await api('/api/dashboard/link-library', {
    method: 'POST',
    cookie: authCookie,
    body: { url: 'https://example.com/injection-test', title: '=HYPERLINK("http://evil.com","click")', description: '+SUM(A1:A9)', category: '-cmd|\' /C calc\'!A0', anchorText: '@IMPORT url(javascript:x)' },
  });
  check('link created', addLink.status === 201 || addLink.status === 200, `got ${addLink.status}`);

  const csvRes = await api('/api/dashboard/link-library/export?format=csv', { cookie: authCookie });
  check('CSV export works', csvRes.status === 200 && csvRes.text.includes('url,title'));
  const csvLines = csvRes.text.split('\n').filter((l) => l.includes('injection-test') || l.includes(`'HYPERLINK`));
  const injectionEscaped = !/^https?:\/\/example\.com.*,(=|\+|-|@)/m.test(csvRes.text.replace(/'([=+@])/g, 'X$1')) &&
    csvLines.every((l) => !/(?<=,|=)'?(?<!')=HYPERLINK/.test(l));
  check('CSV cells beginning with = are escaped', csvRes.text.includes("'=HYPERLINK") || !csvRes.text.match(/(^|,)"?=HYPERLINK/), csvLines[0]?.slice(0, 120));
  check('CSV cells beginning with + - @ are escaped', ["'+SUM", "'-cmd", "'@IMPORT"].every((p) => csvRes.text.includes(p) || !csvRes.text.includes(p.slice(1))), '');

  // ---- WordPress / Blogger failure paths ----------------------------------------------
  const publishNone = await api('/api/articles/doesnotexist/publish', { method: 'POST', cookie: authCookie, body: {} });
  check('publish unknown article -> 404', publishNone.status === 404);

  const blogger = await api('/api/blogger/blogs', { cookie: authCookie });
  check('blogger endpoint responds without crash', [200, 404, 501].includes(blogger.status), `got ${blogger.status}`);

  // ---- Billing / Stripe unconfigured -----------------------------------------------------
  const stripeCheckout = await api('/api/stripe/checkout', { method: 'POST', cookie: authCookie, body: { plan: 'pro' } });
  check('stripe checkout without keys -> 503 (no bypass)', stripeCheckout.status === 503, `got ${stripeCheckout.status}`);

  const paypalCapture = await api('/api/paypal/capture?token=fake-order-id');
  check('paypal capture of fake order fails safely', paypalCapture.status >= 300 && paypalCapture.status < 400 ? (paypalCapture.headers.get('location') || '').includes('payment=failed') : paypalCapture.status >= 400, `got ${paypalCapture.status}`);

  // ---- Duplicate webhook (signed Airtm callback delivered twice) ---------------------------
  const airtmSecret = loadEnvSecret('AIRTM_SECRET');
  const airtmId = loadEnvSecret('AIRTM_MERCHANT_ID');
  if (airtmSecret && airtmId) {
    const planId = 'starter';
    const amount = '29.00';
    const orderId = `${u0.id}:${planId}`;
    const sign = crypto.createHmac('sha256', airtmSecret).update(`${orderId}:${amount}:USD`).digest('hex');
    const params = new URLSearchParams({ order_id: orderId, amount, currency: 'USD', status: 'success', sign, merchant_id: airtmId });

    const before = (await prisma.user.findUnique({ where: { id: u0.id } })).credits;
    const wh1 = await fetch(`${BASE}/api/airtm/webhook`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
    const mid = (await prisma.user.findUnique({ where: { id: u0.id } })).credits;
    const wh2 = await fetch(`${BASE}/api/airtm/webhook`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params.toString() });
    const afterWh = (await prisma.user.findUnique({ where: { id: u0.id } })).credits;

    check('webhook #1 accepted', wh1.status === 200);
    check('webhook #1 granted starter credits once', mid === before + 50, `before=${before} after=${mid}`);
    check('duplicate webhook accepted but grants nothing', wh2.status === 200 && afterWh === mid, `after dup=${afterWh}`);

    // Tampered signature must be rejected.
    const badParams = new URLSearchParams({ order_id: orderId, amount, currency: 'USD', status: 'success', sign: 'deadbeef'.repeat(8), merchant_id: airtmId });
    const whBad = await fetch(`${BASE}/api/airtm/webhook`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: badParams.toString() });
    check('tampered webhook signature rejected', whBad.status === 400);
  } else {
    console.log('  SKIP duplicate-webhook test (AIRTM_SECRET not configured)');
  }

  // ---- Stripe webhook replay protection (unsigned must fail) -------------------------------
  const sw = await api('/api/stripe/webhook', { method: 'POST', body: { id: 'evt_fake', type: 'checkout.session.completed' } });
  check('unsigned stripe webhook rejected', sw.status >= 400, `got ${sw.status}`);

  // ---- Credits ledger consistency -----------------------------------------------------------
  const txs = await prisma.creditTransaction.findMany({ where: { userId: u0.id }, orderBy: { createdAt: 'asc' } });
  let running = null;
  let consistent = true;
  for (const tx of txs) {
    if (running === null) running = tx.balanceAfter;
    else {
      running = tx.balanceAfter;
    }
  }
  const dbUser = await prisma.user.findUnique({ where: { id: u0.id } });
  consistent = running === null || running === dbUser.credits;
  check('credit ledger ends at current balance', consistent, `ledger=${running} user=${dbUser.credits}`);

  // ---- Logout ---------------------------------------------------------------------------------
  const logout = await api('/api/auth/logout', { method: 'POST', cookie: authCookie });
  check('logout succeeds', logout.status === 200);
  const meAfter = await api('/api/auth/me', { cookie: authCookie });
  check('session invalid after logout', meAfter.status === 401 || (meAfter.json?.user == null), `got ${meAfter.status}`);

  // ---- Cleanup ----------------------------------------------------------------------------------
  await prisma.user.delete({ where: { id: dbUser.id } }).catch(() => {});

  console.log(`\n========== RESULTS: ${passed} passed, ${failed} failed ==========`);
  if (failures.length) {
    console.log('Failed:', failures.join(' | '));
    process.exit(1);
  }
}

main()
  .catch((err) => {
    console.error('E2E crashed:', err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
