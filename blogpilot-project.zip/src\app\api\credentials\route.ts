﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { encrypt } from '@/lib/encryption';

const createCredentialSchema = z.object({
  platform: z.string().min(1, 'Platform is required').max(50),
  apiKey: z.string().max(500).optional().nullable(),
  apiSecret: z.string().max(500).optional().nullable(),
  trackingId: z.string().max(200).optional().nullable(),
});

const PLATFORMS = ['Stripe', 'PayPal', 'Payeer', 'Airtm'];

function maskSecret(value?: string | null): string | null {
  if (!value) return null;
  const trimmed = value.trim();
  if (trimmed.length <= 6) return '••••••';
  return `${trimmed.slice(0, 3)}${'•'.repeat(Math.min(trimmed.length - 5, 24))}${trimmed.slice(-2)}`;
}

function publicCredential(cred: {
  id: string;
  platform: string;
  apiKey?: string | null;
  apiSecret?: string | null;
  trackingId?: string | null;
  isActive: boolean;
  status: string;
  createdAt: Date;
}) {
  return {
    id: cred.id,
    platform: cred.platform,
    hasApiKey: !!cred.apiKey,
    hasApiSecret: !!cred.apiSecret,
    apiKeyMasked: maskSecret(cred.apiKey),
    apiSecretMasked: maskSecret(cred.apiSecret),
    trackingId: cred.trackingId,
    isActive: cred.isActive,
    status: cred.status,
    createdAt: cred.createdAt,
  };
}

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    const credentials = await prisma.affiliateKey.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    const byPlatform = new Map<string, (typeof credentials)[number]>();
    for (const cred of credentials) byPlatform.set(cred.platform, cred);

    return NextResponse.json({
      ok: true,
      data: {
        credentials: credentials.map(publicCredential),
        platforms: PLATFORMS.map(platform => ({
          platform,
          connected: byPlatform.has(platform) && !!byPlatform.get(platform)!.isActive,
        })),
      },
    });
  } catch (error: any) {
    console.error('List credentials error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load credentials' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = createCredentialSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const data = parsed.data;

  try {
    const existing = await prisma.affiliateKey.findFirst({ where: { userId, platform: data.platform } });

    let credential;
    if (existing) {
      credential = await prisma.affiliateKey.update({
        where: { id: existing.id },
        data: {
          apiKey: data.apiKey ? encrypt(data.apiKey) : existing.apiKey,
          apiSecret: data.apiSecret ? encrypt(data.apiSecret) : existing.apiSecret,
          trackingId: data.trackingId ?? existing.trackingId,
          isActive: true,
          status: 'connected',
        },
      });
    } else {
      credential = await prisma.affiliateKey.create({
        data: {
          userId,
          platform: data.platform,
          apiKey: data.apiKey ? encrypt(data.apiKey) : null,
          apiSecret: data.apiSecret ? encrypt(data.apiSecret) : null,
          trackingId: data.trackingId,
          isActive: true,
          status: 'connected',
        },
      });
    }

    return NextResponse.json({
      ok: true,
      data: { credential: publicCredential(credential) },
    }, { status: 201 });
  } catch (error: any) {
    console.error('Create credential error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to save credential' }, { status: 500 });
  }
}