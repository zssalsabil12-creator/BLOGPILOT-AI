'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { CreditCard, Receipt, AlertTriangle, CheckCircle, ArrowUpRight, Loader2, ExternalLink, Sparkles, Wallet, Globe, Shield, Copy } from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'
import { useAppStore } from '@/lib/store'

interface Plan {
  id: string
  name: string
  priceMonthly: number
  creditsPerMonth: number
  description: string
}

interface CreditActivity {
  id: string
  date: string
  credits: number
  description: string
}

const paymentMethods = [
  {
    id: 'paddle',
    name: 'Credit / Debit Card',
    description: 'Pay with Visa or Mastercard via Paddle',
    icon: CreditCard,
    color: 'from-indigo-500/15 to-blue-500/15 text-indigo-400 border-indigo-500/20',
    provider: 'paddle',
  },
  {
    id: 'airtm',
    name: 'AirTM',
    description: 'Pay with your AirTM digital wallet (US Dollar balance)',
    icon: Wallet,
    color: 'from-cyan-500/15 to-teal-500/15 text-cyan-400 border-cyan-500/20',
    provider: 'airtm',
  },
  {
    id: 'paypal',
    name: 'PayPal',
    description: 'Pay with your PayPal account or card',
    icon: Globe,
    color: 'from-sky-500/15 to-blue-500/15 text-sky-400 border-sky-500/20',
    provider: 'paypal',
  },
  {
    id: 'payeer',
    name: 'Payeer',
    description: 'Pay with Payeer wallet, cards, or crypto',
    icon: Shield,
    color: 'from-emerald-500/15 to-teal-500/15 text-emerald-400 border-emerald-500/20',
    provider: 'payeer',
  },
]

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.07 } },
}

const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' as const } },
}

function humanizeReason(reason?: string | null): string {
  if (!reason) return 'Credit adjustment'
  return reason
    .split(/[_-]+/)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ')
}

export default function BillingPage() {
  const user = useAppStore(s => s.user)
  const login = useAppStore(s => s.login)

  const [plans, setPlans] = useState<Plan[]>([])
  const [loading, setLoading] = useState(true)
  const [checkoutPlan, setCheckoutPlan] = useState<string | null>(null)
  const [selectedPayment, setSelectedPayment] = useState('paddle')
  const [cancelling, setCancelling] = useState(false)
  const [showCancelConfirm, setShowCancelConfirm] = useState(false)
  const [cancelled, setCancelled] = useState(false)
  const [message, setMessage] = useState<{ ok: boolean; message: string } | null>(null)
  const [invoices, setInvoices] = useState<CreditActivity[]>([])

  const currentPlanId = user?.subscription?.plan || 'starter'
  const currentPlan = plans.find(p => p.id === currentPlanId) || {
    id: currentPlanId,
    name: user?.subscription?.plan || 'Starter',
    priceMonthly: plans.find(p => p.id === currentPlanId)?.priceMonthly || 29,
    creditsPerMonth: plans.find(p => p.id === currentPlanId)?.creditsPerMonth || 50,
    description: '',
  }

  const usagePercent = Math.min(100, Math.round(((user?.credits ?? 0) / Math.max(1, currentPlan.creditsPerMonth)) * 100))

  const loadPlans = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/products')
      if (res.ok) {
        const json = await res.json()
        setPlans(json?.data?.plans || [])
      } else {
        setPlans([
          { id: 'starter', name: 'Starter', priceMonthly: 29, creditsPerMonth: 50, description: 'For individual bloggers starting out' },
          { id: 'pro', name: 'Pro', priceMonthly: 79, creditsPerMonth: 200, description: 'For serious content creators and marketers' },
          { id: 'agency', name: 'Agency', priceMonthly: 199, creditsPerMonth: 2000, description: 'For agencies and large teams' },
        ])
      }
    } catch {
      setPlans([
        { id: 'starter', name: 'Starter', priceMonthly: 29, creditsPerMonth: 50, description: 'For individual bloggers starting out' },
        { id: 'pro', name: 'Pro', priceMonthly: 79, creditsPerMonth: 200, description: 'For serious content creators and marketers' },
        { id: 'agency', name: 'Agency', priceMonthly: 199, creditsPerMonth: 2000, description: 'For agencies and large teams' },
      ])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadPlans()
    fetch('/api/credits').then(r => r.ok ? r.json() : null).then(json => {
      const txs = json?.data?.transactions || []
      // Real credit ledger entries only — amounts are credits, not currency.
      setInvoices(
        txs.map((tx: any) => ({
          id: tx.id,
          date: new Date(tx.createdAt).toLocaleDateString(),
          credits: tx.amount,
          description: tx.description || humanizeReason(tx.reason),
        }))
      )
    }).catch(() => {})
  }, [loadPlans])

  const refreshUser = async () => {
    try {
      const res = await fetch('/api/auth/me')
      if (res.ok) {
        const json = await res.json()
        if (json?.user) login(json.user)
      }
    } catch {
      // ignore
    }
  }

  const handleUpgrade = async (planId: string) => {
    if (planId === currentPlanId) return
    setCheckoutPlan(planId)
    setMessage(null)
    try {
      const provider = selectedPayment
      const res = await fetch(`/api/${provider}/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: planId, mode: 'subscription' }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Checkout failed')
      if (json?.data?.url) {
        if (json.data.url && json.data.url.startsWith('https://')) {
          window.location.href = json.data.url
        }
        return
      }
      if (json?.data?.demo) {
        setMessage({ ok: false, message: 'Payment provider is not configured yet — no upgrade was applied. Contact the site administrator.' })
      }
    } catch (err: any) {
      console.error('Upgrade error:', err)
      setMessage({ ok: false, message: err?.message || 'Upgrade failed' })
    } finally {
      setCheckoutPlan(null)
    }
  }

  const handleCancel = async () => {
    setCancelling(true)
    setMessage(null)
    try {
      const sub = user?.subscription
      if (sub?.stripeSubscriptionId) {
        const res = await fetch('/api/stripe/portal', { method: 'POST' })
        const json = await res.json()
        if (!res.ok) throw new Error(json?.error || 'Failed to cancel')
        if (json?.data?.url) {
          if (json.data.url && json.data.url.startsWith('https://')) {
            window.location.href = json.data.url
          }
          return
        }
        if (json?.data?.demo) {
          setShowCancelConfirm(false)
          setMessage({ ok: false, message: 'Stripe is not configured — connect a subscription provider to manage cancellations.' })
        }
      } else if (sub?.paypalSubscriptionId) {
        const res = await fetch('/api/paypal/subscription/cancel', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ subscriptionId: sub.paypalSubscriptionId }),
        })
        const json = await res.json()
        if (!res.ok) throw new Error(json?.error || 'Failed to cancel PayPal subscription')
        setCancelled(true)
        setShowCancelConfirm(false)
        setMessage({ ok: true, message: 'PayPal subscription cancelled.' })
        await refreshUser()
      } else {
        const res = await fetch('/api/subscription/cancel', { method: 'POST' })
        const json = await res.json()
        if (!res.ok) throw new Error(json?.error || 'Failed to cancel')
        setCancelled(true)
        setShowCancelConfirm(false)
        setMessage({ ok: true, message: 'Subscription cancelled.' })
        await refreshUser()
      }
    } catch (err: any) {
      console.error('Cancel error:', err)
      setMessage({ ok: false, message: err?.message || 'Failed to cancel' })
    } finally {
      setCancelling(false)
    }
  }

  return (
    <div className="p-6 md:p-10">
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <h1 className="text-2xl font-bold text-foreground">Billing & Subscription</h1>
        <p className="text-sm text-muted-foreground mt-1">Manage your plan, payment methods, and credit activity</p>
      </motion.div>

      {message && (
        <div className={cn(
          'mb-6 flex items-center gap-3 px-4 py-3 rounded-xl border text-sm',
          message.ok
            ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400'
            : 'bg-red-500/10 border-red-500/20 text-red-600 dark:text-red-400'
        )}>
          {message.ok
            ? <CheckCircle className="w-4 h-4 shrink-0" />
            : <AlertTriangle className="w-4 h-4 shrink-0" />}
          {message.message}
        </div>
      )}

      <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <motion.div variants={item} className="lg:col-span-2">
            <Card className="bg-card/50 border border-border backdrop-blur-xl h-full">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center border border-cyan-500/20">
                      <Receipt className="w-6 h-6 text-cyan-500" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider">Current Plan</p>
                      <p className="text-xl font-bold text-gradient">{currentPlan.name}</p>
                    </div>
                  </div>
                  <Badge className="bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border-cyan-500/20 text-sm px-3 py-1">
                    ${currentPlan.priceMonthly}/month
                  </Badge>
                </div>
                <div className="mt-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Credits Used</span>
                    <span className="text-sm font-medium text-foreground">
                      {user?.credits ?? 0} / {currentPlan.creditsPerMonth}
                    </span>
                  </div>
                  <div className="relative h-3 rounded-full bg-muted overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${usagePercent}%` }}
                      transition={{ duration: 1, ease: 'easeOut' as const, delay: 0.3 }}
                      className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-cyan-500 to-violet-500"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1.5">{usagePercent}% of monthly credits used</p>
                </div>
                <div className="flex items-center gap-3 mt-6 pt-5 border-t border-border">
                  {cancelled || user?.subscription?.status === 'cancelled' ? (
                    <Button variant="ghost" className="text-emerald-500 hover:text-emerald-600 hover:bg-emerald-500/10" disabled>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Subscription Cancelled
                    </Button>
                  ) : showCancelConfirm ? (
                    <div className="flex items-center gap-3">
                      <Button onClick={handleCancel} disabled={cancelling} className="bg-red-500/15 text-red-600 dark:text-red-400 border border-red-500/20 hover:bg-red-500/25">
                        {cancelling ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                        Confirm Cancel
                      </Button>
                      <Button variant="ghost" onClick={() => setShowCancelConfirm(false)} className="text-muted-foreground hover:text-foreground hover:bg-accent">
                        Keep Plan
                      </Button>
                    </div>
                  ) : (
                    <Button variant="ghost" onClick={() => setShowCancelConfirm(true)} className="text-muted-foreground hover:text-red-500 hover:bg-red-500/10">
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      Cancel Subscription
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={item}>
            <Card className="bg-card/50 border border-border backdrop-blur-xl h-full">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <h3 className="text-foreground font-medium">Payment Method</h3>
                </div>
                <div className="space-y-2">
                  {paymentMethods.map(pm => {
                    const Icon = pm.icon
                    return (
                      <button
                        key={pm.id}
                        onClick={() => setSelectedPayment(pm.id)}
                        className={cn(
                          'w-full flex items-center gap-3 p-3 rounded-xl border transition-all duration-200 text-left',
                          selectedPayment === pm.id
                            ? 'border-primary/50 bg-primary/5 ring-1 ring-primary/20'
                            : 'border-border bg-card/30 hover:border-border hover:bg-accent'
                        )}
                      >
                        <div className={cn('w-9 h-9 rounded-lg bg-gradient-to-br flex items-center justify-center border shrink-0', pm.color)}>
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-foreground">{pm.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{pm.description}</p>
                        </div>
                        {selectedPayment === pm.id && (
                          <CheckCircle className="w-4 h-4 text-primary shrink-0" />
                        )}
                      </button>
                    )
                  })}
                </div>
                {selectedPayment === 'airtm' && (
                  <div className="mt-3 p-3 rounded-xl bg-cyan-500/5 border border-cyan-500/10">
                    <p className="text-xs text-muted-foreground">
                      Payments are processed to <span className="font-medium text-foreground">zenkhriselsabil@gmail.com</span> via AirTM merchant.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <motion.div variants={item}>
          <Card className="bg-card/50 border border-border backdrop-blur-xl">
            <CardHeader>
              <CardTitle className="text-foreground text-lg flex items-center gap-2">
                <Receipt className="w-5 h-5 text-cyan-500" />
                Credit Activity
              </CardTitle>
              <p className="text-sm text-muted-foreground">Every credit grant and usage event on your account. Provider invoices appear in your payment provider dashboard.</p>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 text-muted-foreground font-medium">Date</th>
                      <th className="text-left py-3 px-4 text-muted-foreground font-medium">Activity</th>
                      <th className="text-right py-3 px-4 text-muted-foreground font-medium">Credits</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="py-8 text-center text-muted-foreground">No credit activity yet</td>
                      </tr>
                    ) : invoices.map(tx => (
                      <tr key={tx.id} className="border-b border-border/50 hover:bg-accent/50 transition-colors">
                        <td className="py-3.5 px-4 text-muted-foreground">{tx.date}</td>
                        <td className="py-3.5 px-4 text-foreground">{tx.description}</td>
                        <td className={cn(
                          'py-3.5 px-4 text-right font-medium',
                          tx.credits > 0 ? 'text-emerald-400' : 'text-muted-foreground'
                        )}>
                          {tx.credits > 0 ? '+' : ''}{tx.credits}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">Upgrade Your Plan</h2>
            <Badge variant="secondary" className="bg-muted text-muted-foreground border-0">
              <Sparkles className="w-3 h-3 mr-1 text-cyan-500" />
              Instant activation
            </Badge>
          </div>
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="w-7 h-7 text-cyan-500 animate-spin" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {plans.map(plan => {
                const isCurrent = plan.id === currentPlanId
                return (
                  <Card
                    key={plan.id}
                    className={cn(
                      'bg-card/50 border backdrop-blur-xl transition-all duration-300',
                      isCurrent
                        ? 'border-primary/30 ring-1 ring-primary/10'
                        : 'border-border hover:border-primary/20'
                    )}
                  >
                    <CardContent className="p-6">
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-foreground font-semibold text-lg">{plan.name}</h3>
                          {isCurrent && (
                            <Badge className="bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border-cyan-500/20 text-xs">
                              Current
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className={cn(
                            'text-3xl font-bold',
                            isCurrent ? 'text-gradient' : 'text-foreground'
                          )}>
                            ${plan.priceMonthly}
                          </span>
                          <span className="text-muted-foreground text-sm">/month</span>
                        </div>
                        <p className="mt-2 text-xs text-muted-foreground">{plan.description}</p>
                        <p className="mt-1 text-xs text-cyan-500/70">{plan.creditsPerMonth} credits / month</p>
                      </div>
                      {isCurrent ? (
                        <Button className="w-full bg-muted text-muted-foreground hover:bg-muted border border-border rounded-xl" disabled>
                          Current Plan
                        </Button>
                      ) : (
                        <Button
                          onClick={() => handleUpgrade(plan.id)}
                          disabled={checkoutPlan === plan.id}
                          className="w-full bg-gradient-to-r from-cyan-500 to-violet-500 hover:from-cyan-400 hover:to-violet-400 text-white rounded-xl"
                        >
                          {checkoutPlan === plan.id ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          ) : (
                            <ArrowUpRight className="w-4 h-4 mr-2" />
                          )}
                          Upgrade
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </motion.div>

        <motion.div variants={item}>
          <Card className="bg-card/50 border border-border backdrop-blur-xl">
            <CardContent className="p-6">
              <h3 className="text-foreground font-semibold mb-4">Accepted Payment Methods</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {paymentMethods.map(pm => {
                  const Icon = pm.icon
                  return (
                    <div key={pm.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 border border-border">
                      <div className={cn('w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center border shrink-0', pm.color)}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-medium text-foreground">{pm.name}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  )
}
