/**
 * Validation schema for Payeer checkout request body.
 */
import { z } from 'zod'

export const payeerCheckoutSchema = z.object({
  tier: z.enum(['basic', 'pro', 'agency'], {
    error: 'Tier must be one of: basic, pro, agency',
  }),
})
