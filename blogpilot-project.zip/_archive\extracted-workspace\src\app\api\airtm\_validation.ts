/**
 * Validation schemas for Airtm routes.
 *
 * Mirrors the Stripe / PayPal / Payeer checkout schema so the front-end
 * can use the same { tier: 'basic' | 'pro' | 'agency' } payload across
 * all four gateways.
 */
import { z } from 'zod'

export const airtmCheckoutSchema = z.object({
  tier: z.enum(['basic', 'pro', 'agency'], {
    error: 'Tier must be one of: basic, pro, agency',
  }),
})
