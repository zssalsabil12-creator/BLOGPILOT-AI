﻿import { NextResponse } from 'next/server';
import { isStripeConfigured } from '@/lib/stripe';

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      provider: 'stripe',
      enabled: isStripeConfigured(),
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || null,
    },
  });
}