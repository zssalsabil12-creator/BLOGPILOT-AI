﻿import type { Metadata } from 'next';
import { ToolSeo } from '@/components/free-tools/tool-seo';
import { toolPageMetadata } from '@/lib/free-tools/tool-page';

export const metadata: Metadata = toolPageMetadata('internal-link-finder');

export default function Layout({ children }: { children: React.ReactNode }) {
  return <ToolSeo slug="internal-link-finder">{children}</ToolSeo>;
}
