/**
 * Image Generation API
 *
 * POST /api/images — Fetch context-matching images for article sections.
 * Uses Unsplash Source API (free, no key required) as primary source.
 * Falls back to placeholder images if Unsplash is unavailable.
 */

import { NextResponse } from 'next/server'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { imagesSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

interface ImageResult {
  url: string
  alt: string
  width: number
  height: number
  source: 'unsplash' | 'placeholder'
  photographer?: string
  photographerUrl?: string
  seoAltText: string // SEO-optimized alt text for the image
  purpose?: 'hero' | 'product' | 'context'
}

/**
 * Fetch an image from Unsplash for a given search query.
 * Uses Unsplash Source API (free, no API key needed for low-traffic use).
 */
async function fetchUnsplashImage(
  query: string,
  width: number = 800,
  height: number = 600
): Promise<ImageResult | null> {
  try {
    const encodedQuery = encodeURIComponent(query)
    const url = `https://source.unsplash.com/${width}x${height}/?${encodedQuery}&sig=${Date.now()}`

    // We test with a HEAD request to verify the URL resolves
    // Unsplash source API redirects to the actual image
    const response = await fetch(url, {
      method: 'HEAD',
      signal: AbortSignal.timeout(8000),
      redirect: 'follow',
    })

    if (response.ok) {
      // Use the final URL after redirects
      const finalUrl = response.url || url
      const seoAlt = buildSeoAltText(query)

      return {
        url: finalUrl,
        alt: query,
        width,
        height,
        source: 'unsplash' as const,
        seoAltText: seoAlt,
      }
    }
  } catch {
    // Unsplash might be unavailable, fall back to placeholder
  }

  return null
}

/**
 * Generate a placeholder image URL.
 */
function generatePlaceholderImage(
  query: string,
  index: number,
  width: number = 800,
  height: number = 600
): ImageResult {
  const seoAlt = buildSeoAltText(query)
  const id = Math.abs(hashCode(query + index)) % 1000

  return {
    url: `https://picsum.photos/seed/${query.replace(/\s/g, '-').substring(0, 30)}-${id}/${width}/${height}`,
    alt: query,
    width,
    height,
    source: 'placeholder' as const,
    seoAltText: seoAlt,
  }
}

/**
 * Build SEO-optimized alt text from a query.
 */
function buildSeoAltText(query: string): string {
  return `${query} — high-quality product photo for ${query} buying guide and review`
}

/**
 * Simple string hash for consistent placeholder IDs.
 */
function hashCode(str: string): number {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash |= 0 // Convert to 32bit integer
  }
  return hash
}

/**
 * Generate contextual image queries from article sections/products.
 */
function generateImageQueries(
  keyword: string,
  products: Array<{ name: string; brand?: string }>,
  sectionCount: number
): Array<{ query: string; purpose: 'hero' | 'product' | 'context' }> {
  const queries: Array<{ query: string; purpose: 'hero' | 'product' | 'context' }> = []

  // Hero image for the article
  queries.push({
    query: `${keyword} featured hero image professional`,
    purpose: 'hero',
  })

  // Product images
  for (const product of products.slice(0, 5)) {
    queries.push({
      query: `${product.brand ?? 'brand'} ${product.name.split(' ').slice(0, 3).join(' ')} product photo`,
      purpose: 'product',
    })
  }

  // Context images for additional sections
  const contextQueries = [
    `${keyword} comparison setup lifestyle`,
    `${keyword} usage example demonstration`,
    `${keyword} accessories and add-ons`,
  ]

  for (let i = 0; i < Math.min(contextQueries.length, sectionCount - products.length - 1); i++) {
    queries.push({
      query: contextQueries[i],
      purpose: 'context',
    })
  }

  return queries
}

export async function POST(request: Request) {
  try {
    // ─── Rate limit (20 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.images)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(imagesSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const {
      keyword,
      products = [],
      sectionCount = 5,
      includeHero = true,
      width = 800,
      height = 600,
    } = body

    const trimmedKeyword = keyword.trim()

    // Generate image queries from context
    const imageQueries = generateImageQueries(trimmedKeyword, products, sectionCount)

    const images: ImageResult[] = []
    const batchSize = 3 // Fetch in parallel batches

    for (let i = 0; i < imageQueries.length; i += batchSize) {
      const batch = imageQueries.slice(i, i + batchSize)

      const batchResults = await Promise.allSettled(
        batch.map(async (imgQuery, batchIdx) => {
          const idx = i + batchIdx
          const isHero = imgQuery.purpose === 'hero'

          // Try Unsplash first (skip for non-hero to avoid rate limits)
          if (isHero) {
            const unsplashResult = await fetchUnsplashImage(
              imgQuery.query,
              isHero ? 1200 : width,
              isHero ? 630 : height
            )
            if (unsplashResult) return unsplashResult
          }

          // Use placeholder as default (reliable, no rate limits)
          return generatePlaceholderImage(
            imgQuery.query,
            idx,
            isHero ? 1200 : width,
            isHero ? 630 : height
          )
        })
      )

      for (let r = 0; r < batchResults.length; r++) {
        const result = batchResults[r]
        if (result.status === 'fulfilled' && result.value) {
          images.push({ ...result.value, purpose: batch[r]?.purpose })
        }
      }
    }

    return NextResponse.json({
      success: true,
      keyword: trimmedKeyword,
      images,
      imageCount: images.length,
      heroImage: images.find(i => i.source === 'unsplash' || i.purpose === 'hero') || images[0] || null,
    })
  } catch (error: unknown) {
    return handleApiError(error, 'images')
  }
}
