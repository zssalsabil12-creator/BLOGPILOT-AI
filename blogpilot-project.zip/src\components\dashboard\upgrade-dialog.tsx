'use client'

import { useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { Check, CreditCard, ArrowRight, Sparkles, Zap, Shield, Crown, AlertTriangle } from 'lucide-react'

interface UpgradeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

const plans = [
  {
    id: 'starter',
    name: 'Basic',
    price: 29,
    features: ['50 articles/mo', '3 sites', 'Basic SEO'],
    icon: Zap,
    color: 'cyan',
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 79,
    features: ['200 articles/mo', '15 sites', 'Advanced SEO', 'All affiliates'],
    popular: true,
    icon: Shield,
    color: 'violet',
  },
  {
    id: 'agency',
    name: 'Agency',
    price: 199,
    features: ['Unlimited articles', 'Unlimited sites', 'Full analytics', 'API access'],
    icon: Crown,
    color: 'amber',
  },
]

const paymentMethods = [
  { id: 'stripe', name: 'Stripe', icon: CreditCard },
  { id: 'paypal', name: 'PayPal', icon: CreditCard },
  { id: 'payeer', name: 'Payeer', icon: CreditCard },
  { id: 'airtm', name: 'Airtm', icon: CreditCard },
]

const steps = ['Choose Plan', 'Payment', 'Confirm']

export default function UpgradeDialog({ open, onOpenChange }: UpgradeDialogProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [demoNotice, setDemoNotice] = useState(false)
  const [error, setError] = useState('')

  const activePlan = plans.find((p) => p.id === selectedPlan)

  const handleNext = async () => {
    if (currentStep < 2) {
      setCurrentStep((s) => s + 1)
      return
    }
    if (!activePlan || !selectedPayment) return
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/${selectedPayment}/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: activePlan.id }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Checkout failed')

      if (json?.data?.url) {
        if (json.data.url && json.data.url.startsWith('https://')) {
          window.location.href = json.data.url
        }
        return
      }
      if (json?.data?.demo) {
        // Gateway not configured — be explicit that nothing was purchased.
        setDemoNotice(true)
        return
      }
    } catch (err: any) {
      console.error('Checkout error:', err)
      setError(err?.message || 'Checkout failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleBack = () => {
    if (currentStep > 0) setCurrentStep((s) => s - 1)
  }

  const handleClose = () => {
    onOpenChange(false)
    setTimeout(() => {
      setCurrentStep(0)
      setSelectedPlan(null)
      setSelectedPayment(null)
      setCompleted(false)
      setDemoNotice(false)
    }, 300)
  }

  const canProceed =
    (currentStep === 0 && selectedPlan !== null) ||
    (currentStep === 1 && selectedPayment !== null) ||
    currentStep === 2

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="glass max-w-2xl border-border bg-background/95 text-foreground backdrop-blur-2xl sm:max-w-3xl">
        <DialogHeader className="space-y-4">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="h-5 w-5 text-amber-400" />
            Upgrade Your Plan
          </DialogTitle>

          {/* Step Indicator */}
          <div className="flex items-center gap-2">
            {steps.map((step, i) => (
              <div key={step} className="flex items-center gap-2">
                <div
                  className={cn(
                    'flex h-7 w-7 items-center justify-center rounded-full text-xs font-medium transition-all',
                    i < currentStep
                      ? 'bg-cyan-500 text-white'
                      : i === currentStep
                        ? 'bg-gradient-to-r from-cyan-500 to-violet-500 text-white'
                        : 'bg-foreground/5 text-foreground/30'
                  )}
                >
                  {i < currentStep ? (
                    <Check className="h-3.5 w-3.5" />
                  ) : (
                    i + 1
                  )}
                </div>
                <span
                  className={cn(
                    'text-xs transition-colors',
                    i <= currentStep ? 'text-foreground/70' : 'text-foreground/20'
                  )}
                >
                  {step}
                </span>
                {i < steps.length - 1 && (
                  <div
                    className={cn(
                      'mx-1 h-px w-6',
                      i < currentStep ? 'bg-cyan-500' : 'bg-foreground/10'
                    )}
                  />
                )}
              </div>
            ))}
          </div>
        </DialogHeader>

        {/* Step Content */}
        <div className="mt-4 min-h-[320px]">
          {demoNotice ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/15 border border-amber-500/30">
                <AlertTriangle className="h-8 w-8 text-amber-400" />
              </div>
              <h3 className="text-xl font-semibold text-foreground">Payment provider not configured</h3>
              <p className="mt-2 max-w-sm text-sm text-foreground/50">
                No payment was processed and your plan was not changed. The site administrator needs to enable a
                payment provider before checkout can complete.
              </p>
              <Button
                onClick={handleClose}
                variant="outline"
                className="mt-6"
              >
                Close
              </Button>
            </div>
          ) : completed ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-r from-cyan-500 to-violet-500">
                <Check className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-foreground">Payment Successful!</h3>
              <p className="mt-2 text-sm text-foreground/50">
                Your plan has been upgraded. Enjoy your new features.
              </p>
              <Button
                onClick={handleClose}
                className="mt-6 bg-gradient-to-r from-cyan-500 to-violet-500 text-white hover:opacity-90"
              >
                Get Started
              </Button>
            </div>
          ) : (
            <>
              {/* Step 0: Plan Selection */}
              {currentStep === 0 && (
                <div className="grid gap-4 sm:grid-cols-3">
                  {plans.map((plan) => {
                    const Icon = plan.icon
                    const isSelected = selectedPlan === plan.id
                    return (
                      <button
                        key={plan.name}
                        onClick={() => setSelectedPlan(plan.id)}
                        className={cn(
                          'glass relative flex flex-col rounded-xl border p-5 text-left transition-all hover:border-border',
                          isSelected
                            ? 'border-cyan-500/50 ring-1 ring-cyan-500/30'
                            : 'border-border'
                        )}
                      >
                        {plan.popular && (
                          <Badge className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-cyan-500 to-violet-500 text-[10px] text-white">
                            Most Popular
                          </Badge>
                        )}
                        <div className="mb-3 flex items-center gap-2">
                          <Icon
                            className={cn(
                              'h-4 w-4',
                              plan.color === 'cyan'
                                ? 'text-cyan-400'
                                : plan.color === 'violet'
                                  ? 'text-violet-400'
                                  : 'text-amber-400'
                            )}
                          />
                          <span className="text-sm font-medium text-foreground/80">
                            {plan.name}
                          </span>
                        </div>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-foreground">${plan.price}</span>
                          <span className="text-xs text-foreground/30">/mo</span>
                        </div>
                        <ul className="space-y-2">
                          {plan.features.map((f) => (
                            <li
                              key={f}
                              className="flex items-center gap-2 text-xs text-foreground/50"
                            >
                              <Check className="h-3 w-3 shrink-0 text-emerald-400" />
                              {f}
                            </li>
                          ))}
                        </ul>
                        <div
                          className={cn(
                            'mt-4 h-1 w-full rounded-full',
                            isSelected
                              ? 'bg-gradient-to-r from-cyan-500 to-violet-500'
                              : 'bg-foreground/5'
                          )}
                        />
                      </button>
                    )
                  })}
                </div>
              )}

              {/* Step 1: Payment Method */}
              {currentStep === 1 && (
                <div className="space-y-4">
                  {activePlan && (
                    <div className="glass rounded-lg border border-border p-4">
                      <p className="text-xs text-foreground/40">Selected Plan</p>
                      <p className="mt-1 text-sm font-medium text-foreground">
                        {activePlan.name} — ${activePlan.price}/mo
                      </p>
                    </div>
                  )}
                  <div className="grid gap-3 sm:grid-cols-2">
                    {paymentMethods.map((pm) => {
                      const Icon = pm.icon
                      const isSelected = selectedPayment === pm.id
                      return (
                        <button
                          key={pm.id}
                          onClick={() => setSelectedPayment(pm.id)}
                          className={cn(
                            'glass flex items-center gap-3 rounded-xl border p-4 text-left transition-all hover:border-border',
                            isSelected
                              ? 'border-cyan-500/50 ring-1 ring-cyan-500/30'
                              : 'border-border'
                          )}
                        >
                          <div
                            className={cn(
                              'flex h-10 w-10 items-center justify-center rounded-lg',
                              isSelected
                                ? 'bg-cyan-500/20 text-cyan-400'
                                : 'bg-foreground/5 text-foreground/40'
                            )}
                          >
                            <Icon className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-foreground">{pm.name}</p>
                            <p className="text-[10px] text-foreground/30">
                              {pm.id === 'stripe' && 'Credit/Debit Card'}
                              {pm.id === 'paypal' && 'PayPal Account'}
                              {pm.id === 'payeer' && 'Payeer Wallet'}
                              {pm.id === 'airtm' && 'Airtm Balance'}
                            </p>
                          </div>
                          <div
                            className={cn(
                              'ml-auto h-4 w-4 rounded-full border-2 transition-all',
                              isSelected
                                ? 'border-cyan-400 bg-cyan-400'
                                : 'border-border'
                            )}
                          >
                            {isSelected && (
                              <div className="flex h-full items-center justify-center">
                                <div className="h-1.5 w-1.5 rounded-full bg-background" />
                              </div>
                            )}
                          </div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Step 2: Confirm */}
              {currentStep === 2 && (
                <div className="space-y-4">
                  <div className="glass rounded-xl border border-border p-6">
                    <h4 className="text-sm font-medium text-foreground/60">Order Summary</h4>
                    <div className="mt-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-foreground/80">Plan</span>
                        <span className="text-sm font-medium text-foreground">
                          {activePlan?.name}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-foreground/80">Payment</span>
                        <span className="text-sm font-medium text-foreground capitalize">
                          {selectedPayment}
                        </span>
                      </div>
                      <div className="border-t border-border pt-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-foreground/80">Total</span>
                          <span className="text-2xl font-bold text-foreground">
                            ${activePlan?.price}
                            <span className="text-xs font-normal text-foreground/40">/mo</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-center text-xs text-foreground/30">
                    By confirming, you agree to our Terms of Service. Cancel anytime.
                  </p>
                  {error && (
                    <div className="flex items-center gap-2 rounded-lg border border-red-500/20 bg-red-500/10 px-3 py-2 text-xs text-red-400">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      {error}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Actions */}
        {!completed && (
          <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
            <Button
              variant="ghost"
              onClick={handleBack}
              disabled={currentStep === 0}
              className="text-foreground/50 hover:text-foreground disabled:opacity-30"
            >
              Back
            </Button>
            <Button
              onClick={handleNext}
              disabled={!canProceed || loading}
              className="gap-2 bg-gradient-to-r from-cyan-500 to-violet-500 text-white hover:opacity-90 disabled:opacity-50"
            >
              {loading ? (
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-border border-t-white" />
              ) : currentStep === 2 ? (
                <>
                  Confirm & Pay
                  <Sparkles className="h-3.5 w-3.5" />
                </>
              ) : (
                <>
                  Continue
                  <ArrowRight className="h-3.5 w-3.5" />
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
