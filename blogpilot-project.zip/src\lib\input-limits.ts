const MAX_URL_LENGTH = 2048;
const MAX_TEXT_LENGTH = 50_000;
const MAX_JSON_BODY_SIZE = 1_048_576; // 1MB

export function checkUrlLength(url: string): { ok: boolean; error?: string } {
  if (url.length > MAX_URL_LENGTH) {
    return { ok: false, error: `URL exceeds maximum length of ${MAX_URL_LENGTH} characters` };
  }
  return { ok: true };
}

export function checkTextLength(text: string, maxLen = MAX_TEXT_LENGTH): { ok: boolean; error?: string } {
  if (text.length > maxLen) {
    return { ok: false, error: `Text exceeds maximum length of ${maxLen} characters` };
  }
  return { ok: true };
}

export async function checkBodySize(req: Request, maxBytes = MAX_JSON_BODY_SIZE): Promise<{ ok: boolean; error?: string }> {
  const contentLength = req.headers.get('content-length');
  if (contentLength && parseInt(contentLength) > maxBytes) {
    return { ok: false, error: `Request body exceeds maximum size of ${Math.round(maxBytes / 1024)}KB` };
  }
  return { ok: true };
}
