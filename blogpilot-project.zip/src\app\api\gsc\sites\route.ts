import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { getGscAccessToken, listGscSites } from '@/lib/gsc';
import prisma from '@/lib/prisma';
import { checkRateLimit } from '@/lib/rate-limit';

const querySchema = z.object({
  refresh: z.enum(['1', '0']).optional(),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters' }, { status: 400 });
  }

  const limit = await checkRateLimit(`gsc-sites:${userId}`, { windowMs: 60_000, maxRequests: 20 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  const access = await getGscAccessToken(userId);

  if (!access.ok) {
    // Honest states — the client shows the appropriate connect/reconnect UI.
    return NextResponse.json({
      ok: true,
      data: { connected: false, needsReconnect: access.reason === 'needs_reconnect' },
    });
  }

  try {
    const sites = await listGscSites(access.accessToken);

    const bindings = await prisma.connectedSite.findMany({
      where: { userId, gscProperty: { not: null } },
      select: { id: true, name: true, url: true, gscProperty: true },
    });

    return NextResponse.json({
      ok: true,
      data: {
        connected: true,
        googleEmail: access.googleEmail,
        properties: sites,
        bindings,
      },
    });
  } catch (error: any) {
    console.error('GSC list sites error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'Unable to list Search Console properties' },
      { status: 502 },
    );
  }
}
