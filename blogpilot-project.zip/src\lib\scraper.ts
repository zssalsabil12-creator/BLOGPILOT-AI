﻿export type PageSnapshot = {
  url: string;
  status: number;
  title?: string;
  metaDescription?: string;
  h1?: string[];
  h2?: string[];
  h3?: string[];
  wordCount?: number;
  textSnippet?: string;
  fetchedAt: string;
};

function extractAll(html: string, tag: string) {
  const re = new RegExp(`<${tag}[^>]*>([\s\S]*?)<\/${tag}>`, 'gi');
  const matches: string[] = [];
  let m;
  while ((m = re.exec(html))) {
    const text = m[1].replace(/<[^>]+>/g, '').trim();
    if (text) matches.push(text);
  }
  return matches;
}

export async function fetchPageSnapshot(url: string): Promise<PageSnapshot> {
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': 'BlogPilotBot/1.0 (+https://blogpilot.ai)' },
      redirect: 'follow',
      signal: AbortSignal.timeout(15000),
    });
    const status = res.status;
    const html = await res.text();

    const titleMatch = html.match(/<title>([\s\S]*?)<\/title>/i);
    const title = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : undefined;
    const metaMatch = html.match(/<meta\s+name=['\"]description['\"]\s+content=['\"]([\s\S]*?)['\"]/i) || html.match(/<meta\s+content=['\"]([\s\S]*?)['\"]\s+name=['\"]description['\"]/i);
    const metaDescription = metaMatch ? metaMatch[1].trim() : undefined;

    const h1 = extractAll(html, 'h1');
    const h2 = extractAll(html, 'h2');
    const h3 = extractAll(html, 'h3');

    const body = html.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<style[\s\S]*?<\/style>/gi, '');
    const text = body.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    const words = text ? text.split(' ').length : 0;

    return {
      url,
      status,
      title,
      metaDescription,
      h1,
      h2,
      h3,
      wordCount: words,
      textSnippet: text ? text.slice(0, 2000) : undefined,
      fetchedAt: new Date().toISOString(),
    };
  } catch (err) {
    return {
      url,
      status: 0,
      fetchedAt: new Date().toISOString(),
    };
  }
}

