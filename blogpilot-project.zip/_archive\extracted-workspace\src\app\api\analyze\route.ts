import { NextResponse } from 'next/server'
import { analyzeCompetitors } from '@/lib/competitor-scraper'
import { geminiGenerate, isGeminiConfigured } from '@/lib/gemini'
import ZAI from 'z-ai-web-dev-sdk'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { analyzeSchema, parseBody } from '@/lib/validation'
import { handleApiError, TaggedError } from '@/lib/api-errors'

let _zai: any = null
async function getZAI() {
  if (!_zai) _zai = await ZAI.create()
  return _zai as any
}

/**
 * POST /api/analyze
 *
 * Step 1: Scrape top 5 competitor pages for the keyword
 * Step 2: Feed structural data into Gemini to identify gaps (Information Gain)
 * Step 3: Return a comprehensive article outline
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit (8 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.analyze)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(analyzeSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { keyword, topic, tone = 'professional' } = body

    // ──── Step 1: Competitor Scraping ────
    // Wrap with a 25-second timeout — scraping should never take more
    // than that, and a hung fetch here blocks the entire pipeline.
    console.log(`[analyze] Step 1: Scraping competitors for "${keyword}"`)
    let competitorData
    try {
      competitorData = await Promise.race([
        analyzeCompetitors(keyword.trim()),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new TaggedError('scrape_unreachable', 'Competitor scraping timed out', 504, { retryable: true, retryAfter: 10 })),
            25_000
          )
        ),
      ])
    } catch (scrapeError) {
      if (scrapeError instanceof TaggedError) throw scrapeError
      throw new TaggedError(
        'scrape_unreachable',
        scrapeError instanceof Error ? scrapeError.message : 'Scraper error',
        502,
        { retryable: true, retryAfter: 10 }
      )
    }

    // ──── Step 2: Context Prompting with Gemini ────
    console.log('[analyze] Step 2: Generating optimized outline via AI')

    // Build a structured context from competitor data
    const competitorContext = buildCompetitorContext(competitorData)

    const outlineSystemPrompt = `You are an expert SEO content strategist and competitive analyst. Your specialty is analyzing competitor content and identifying opportunities to create superior, higher-ranking articles.

OUTPUT FORMAT
Return a valid JSON object with this exact structure (no markdown, no code fences):
{
  "suggestedTitle": "string — An optimized H1 title that beats competitors",
  "metaDescription": "string — 150-160 char SEO meta description",
  "informationGainScore": number 0-100 — how much this outline improves on competitors,
  "estimatedWordCount": number,
  "sections": [
    {
      "heading": "string — H2 heading",
      "level": 2,
      "purpose": "string — why this section matters for SEO/ranking",
      "subsections": [
        {
          "heading": "string — H3 heading",
          "level": 3,
          "keyPoints": ["string — main point to cover"],
          "targetKeywords": ["string — keywords to include"],
          "wordCountEstimate": number
        }
      ],
      "targetKeywords": ["string"],
      "competitiveAdvantage": "string — what makes this section better than competitors"
    }
  ],
  "targetKeywords": ["string — primary and secondary keywords"],
  "internalLinkSuggestions": ["string — suggested anchor text for internal links"],
  "schemaMarkup": "string — recommended Schema.org type (Article, HowTo, FAQPage, etc.)"
}

GUIDELINES:
- Write in a ${tone || 'professional'} tone
- Each section should have 2-4 subsections
- Include sections that fill information gaps competitors missed
- Target 1,500-2,500 words total for the outline
- Optimize for featured snippet eligibility
- Include FAQ section if appropriate
- Suggest a compelling, click-worthy title that includes the primary keyword
- Information Gain Score: rate how significantly this outline improves upon existing content`

    const outlineUserPrompt = `Analyze the following competitor data for the keyword "${keyword.trim()}"${topic ? ` with topic focus: "${topic}"` : ''} and create a superior article outline.

${competitorContext}

Create an article outline that:
1. Covers all common topics competitors address (but better)
2. Fills the information gaps they missed
3. Adds unique angles and original insights
4. Is structured to outrank all 5 competitors on Google

${topic ? `The user wants to focus specifically on the angle: "${topic}". Incorporate this throughout the outline.` : ''}

Return the outline as a JSON object following the exact format specified.`

    let outlineResult: any

    try {
      if (isGeminiConfigured()) {
        // Use Gemini 2.5 Flash
        outlineResult = await geminiGenerate(outlineUserPrompt, {
          systemInstruction: outlineSystemPrompt,
          temperature: 0.7,
          maxOutputTokens: 8192,
          jsonMode: true,
        })
      } else {
        // Fallback to z-ai-web-dev-sdk
        const zai = await getZAI()
        const result = await zai.chat.completions.create({
          messages: [
            { role: 'system', content: outlineSystemPrompt },
            { role: 'user', content: outlineUserPrompt },
          ],
        })
        outlineResult = { text: result.content || result.choices?.[0]?.message?.content || '' }
      }
    } catch (aiError) {
      throw new TaggedError(
        'ai_unreachable',
        aiError instanceof Error ? aiError.message : 'AI provider error',
        503,
        { retryable: true, retryAfter: 15 }
      )
    }

    // Parse the JSON response
    let outline
    try {
      const rawText = outlineResult.text
      // Handle potential markdown code fences
      const cleaned = rawText
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim()
      outline = JSON.parse(cleaned)
    } catch (parseError) {
      console.error('[analyze] Failed to parse outline JSON:', parseError)
      // Generate a structured fallback outline
      outline = generateFallbackOutline(keyword.trim(), topic, competitorData, tone)
    }

    // ──── Step 3: Return comprehensive result ────
    return NextResponse.json({
      success: true,
      competitorAnalysis: {
        keyword: competitorData.keyword,
        searchResults: competitorData.searchResults.map((r) => ({
          position: r.position,
          title: r.title,
          url: r.url,
        })),
        commonTopics: competitorData.commonTopics,
        uniqueTopics: competitorData.uniqueTopics,
        informationGaps: competitorData.informationGaps,
        averageWordCount: competitorData.averageWordCount,
        pagesAnalyzed: competitorData.scrapedPages.length,
      },
      outline,
      usage: outlineResult.usageMetadata,
    })
  } catch (error: unknown) {
    // TaggedErrors carry their own status / category — let handleApiError
    // translate them properly instead of masking as 500.
    if (error instanceof TaggedError) {
      return handleApiError(error, 'analyze')
    }
    return handleApiError(error, 'analyze')
  }
}

/**
 * Build a structured context string from competitor analysis data.
 */
function buildCompetitorContext(data: any): string {
  let ctx = `## Competitor Analysis for "${data.keyword}"

### Top 5 Ranking Pages:
`
  for (const result of data.searchResults) {
    ctx += `${result.position}. **${result.title}** (${result.url})\n   Snippet: "${result.snippet}"\n\n`
  }

  ctx += `\n### H2/H3 Heading Structure Extracted:\n`
  for (const page of data.scrapedPages) {
    ctx += `\n**Page: ${page.title}** (${page.url})\n`
    ctx += `Word Count: ~${page.wordCount}\n`
    for (const heading of page.headings) {
      const prefix = heading.level === 2 ? '  H2' : '    H3'
      ctx += `${prefix}: ${heading.text}\n`
    }
  }

  ctx += `\n### Common Topics (covered by 2+ competitors):\n`
  for (const topic of data.commonTopics) {
    ctx += `- ${topic}\n`
  }

  ctx += `\n### Information Gaps (missed by ALL competitors):\n`
  for (const gap of data.informationGaps) {
    ctx += `- ${gap}\n`
  }

  ctx += `\n### Stats:
- Average word count across competitors: ${data.averageWordCount}
- Unique topics found: ${data.uniqueTopics.length}
- Common topics: ${data.commonTopics.length}
- Information gaps identified: ${data.informationGaps.length}
`

  return ctx
}

/**
 * Generate a fallback outline when AI response parsing fails.
 */
function generateFallbackOutline(
  keyword: string,
  topic: string | undefined,
  competitorData: any,
  tone: string
): any {
  const capitalized = keyword
    .split(' ')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ')

  const sections = [
    {
      heading: `What is ${capitalized}?`,
      level: 2,
      purpose: 'Establish topical authority and capture featured snippet',
      subsections: [
        {
          heading: 'Definition and Overview',
          level: 3,
          keyPoints: [
            `Clear definition of ${keyword}`,
            'Current market landscape in 2026',
            'Why it matters for readers',
          ],
          targetKeywords: [keyword, `what is ${keyword}`],
          wordCountEstimate: 200,
        },
      ],
      targetKeywords: [keyword],
      competitiveAdvantage: 'More comprehensive and up-to-date than competitors',
    },
    {
      heading: `Top ${capitalized} Recommendations`,
      level: 2,
      purpose: 'Primary content section for product-focused queries',
      subsections: [
        {
          heading: 'Best Overall Pick',
          level: 3,
          keyPoints: [
            'Editor choice and reasoning',
            'Key specifications',
            'Pros and cons',
          ],
          targetKeywords: [`best ${keyword}`],
          wordCountEstimate: 300,
        },
        {
          heading: 'Best Value Option',
          level: 3,
          keyPoints: [
            'Budget-friendly recommendation',
            'Price-performance analysis',
            'Who it is best for',
          ],
          targetKeywords: [`affordable ${keyword}`],
          wordCountEstimate: 250,
        },
      ],
      targetKeywords: [`best ${keyword}`, `${keyword} review`],
      competitiveAdvantage: 'Includes affiliate links and more detailed comparisons',
    },
  ]

  // Add gap-filling sections
  for (const gap of competitorData.informationGaps.slice(0, 3)) {
    const gapCapitalized = gap
      .split(' ')
      .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ')
    sections.push({
      heading: gapCapitalized,
      level: 2,
      purpose: `Fill information gap — competitors don't cover this`,
      subsections: [
        {
          heading: `Why ${gapCapitalized} Matters`,
          level: 3,
          keyPoints: [`Expert analysis of ${gap}`, 'Actionable insights'],
          targetKeywords: [`${keyword} ${gap}`],
          wordCountEstimate: 200,
        },
      ],
      targetKeywords: [`${keyword} ${gap}`],
      competitiveAdvantage: `No competitor covers "${gap}" — unique content opportunity`,
    })
  }

  // Add FAQ section
  sections.push({
    heading: 'Frequently Asked Questions',
    level: 2,
    purpose: 'Capture long-tail traffic and featured snippets',
    subsections: [
      {
        heading: `What is the best ${keyword} in 2026?`,
        level: 3,
        keyPoints: ['Direct answer for featured snippet', 'Brief justification'],
        targetKeywords: [`best ${keyword} 2026`],
        wordCountEstimate: 100,
      },
    ],
    targetKeywords: [`${keyword} FAQ`, `${keyword} questions`],
    competitiveAdvantage: 'Targets People Also Ask boxes and FAQ rich results',
  })

  return {
    suggestedTitle: topic
      ? `${capitalized}: ${topic.charAt(0).toUpperCase() + topic.slice(1)} — Complete 2026 Guide`
      : `The Ultimate ${capitalized} Guide 2026: Expert Picks & Reviews`,
    metaDescription: `Discover the best ${keyword} options in 2026. Our expert guide covers reviews, comparisons, pricing, and everything you need to know.`,
    informationGainScore: Math.min(95, 60 + competitorData.informationGaps.length * 5),
    estimatedWordCount: 1800,
    sections,
    targetKeywords: [
      keyword,
      `best ${keyword}`,
      `${keyword} review`,
      `${keyword} 2026`,
      `buy ${keyword}`,
    ],
    internalLinkSuggestions: ['related guides', 'comparison articles'],
    schemaMarkup: 'Article',
  }
}
