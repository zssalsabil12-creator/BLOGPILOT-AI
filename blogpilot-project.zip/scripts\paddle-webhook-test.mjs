/**
 * Paddle subscription flow E2E — runs fully offline against a dev/prod server
 * that has PADDLE_WEBHOOK_SECRET configured (PADDLE_API_KEY is not needed:
 * signature verification is local HMAC-SHA256 and the user is resolved from
 * custom_data, so no Paddle API calls occur in this flow).
 *
 * Verifies:
 *  1. transaction.completed grants plan credits exactly once (+50 for starter,
 *     or the configured plan's allocation).
 *  2. The same transaction delivered again under a DIFFERENT event id grants
 *     nothing (transaction-scoped idempotency).
 *  3. A second distinct completed payment grants a fresh allocation
 *     (monthly renewal semantics).
 *  4. subscription.updated syncs status + paddle ids.
 *  5. subscription.canceled marks the entitlement cancelled.
 *  6. Bad signatures are rejected with 400; missing signature too.
 *
 * Run: node scripts/paddle-webhook-test.mjs [baseUrl]
 */
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const BASE = process.argv[2] || 'http://localhost:3000';
const prisma = new PrismaClient();

const WEBHOOK_SECRET = process.env.PADDLE_WEBHOOK_SECRET;
if (!WEBHOOK_SECRET) {
  console.error('PADDLE_WEBHOOK_SECRET must be set on the server AND in this process.');
  process.exit(1);
}

function signedEvent(event) {
  const payload = JSON.stringify(event);
  const ts = Math.floor(Date.now() / 1000);
  const h1 = crypto.createHmac('sha256', WEBHOOK_SECRET).update(`${ts}:${payload}`).digest('hex');
  return { header: `ts=${ts};h1=${h1}`, payload };
}

async function deliver(event) {
  const { header, payload } = signedEvent(event);
  const res = await fetch(`${BASE}/api/paddle/webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Paddle-Signature': header },
    body: payload,
  });
  let json = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

let failures = 0;
function check(name, cond, detail = '') {
  console.log(`  ${cond ? 'PASS' : 'FAIL'} ${name}${cond ? '' : ` — ${detail}`}`);
  if (!cond) failures++;
}

async function main() {
  console.log(`Paddle webhook flow against ${BASE}\n`);

  // --- setup user -----------------------------------------------------------
  const email = `paddle-e2e-${Date.now()}@test.com`;
  await fetch(`${BASE}/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'Sup3rSecurePass!', name: 'Paddle E2E' }),
  });
  const loginRes = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'Sup3rSecurePass!' }),
  });
  const authCookie = (loginRes.headers.get('set-cookie') || '').split(';')[0];
  check('login works', !!authCookie, 'no cookie');
  const user = await prisma.user.findUnique({ where: { email } });
  const userId = user.id;

  const balance = async () => (await prisma.user.findUnique({ where: { id: userId } })).credits;
  const before = await balance();
  check('initial balance recorded', typeof before === 'number', String(before));

  // Checkout reachability: unauthenticated request must be rejected cleanly.
  const coRes = await fetch(`${BASE}/api/paddle/checkout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ plan: 'starter' }),
  });
  check('paddle checkout requires auth', coRes.status === 401, `got ${coRes.status}`);

  const subId = `sub_pdl_${Date.now()}`;
  const custId = `ctm_pdl_${Date.now()}`;
  const priceId = process.env.PADDLE_PRICE_ID_STARTER || null;

  const txPayload = (txId) => ({
    event_id: `evt_tx1_${Date.now()}_${txId.slice(-6)}`,
    event_type: 'transaction.completed',
    occurred_at: new Date().toISOString(),
    data: {
      id: txId,
      status: 'completed',
      subscription_id: subId,
      customer_id: custId,
      currency_code: 'USD',
      custom_data: { userId, planId: 'starter' },
      details: { line_items: [{ price: { id: priceId }, quantity: 1 }] },
    },
  });

  // --- 1. first completed payment: exactly one grant --------------------------
  const tx1 = `txn_test_1_${Date.now()}`;
  const r1 = await deliver(txPayload(tx1));
  check('transaction.completed accepted', r1.status === 200, `got ${r1.status}`);
  const afterFirst = await balance();
  check('first payment granted starter credits (+50)', afterFirst === before + 50, `${before} -> ${afterFirst}`);
  const subRow = await prisma.subscription.findUnique({ where: { userId } }).catch(() => null);
  check(
    'plan activated to starter with paddle subscription id',
    subRow?.plan === 'starter' && subRow?.paddleSubscriptionId === subId,
    JSON.stringify({ plan: subRow?.plan, sub: subRow?.paddleSubscriptionId }),
  );

  // --- 2. same transaction replayed under a NEW event id: no double grant -----
  const r2 = await deliver(txPayload(tx1));   // handler generates a fresh outer event id
  check('replayed transaction accepted', r2.status === 200, `got ${r2.status}`);
  const afterReplay = await balance();
  check('replayed payment granted nothing', afterReplay === afterFirst, `${afterFirst} -> ${afterReplay}`);

  // --- 3. renewal (distinct transaction): fresh allocation --------------------
  const r3 = await deliver(txPayload(`txn_test_2_${Date.now()}`));
  check('renewal transaction.completed accepted', r3.status === 200, `got ${r3.status}`);
  const afterRenewal = await balance();
  check('renewal granted fresh credits once', afterRenewal === afterFirst + 50, `${afterFirst} -> ${afterRenewal}`);

  // --- 4. subscription.updated syncs -------------------------------------------
  const r4 = await deliver({
    event_id: `evt_sub_${Date.now()}`,
    event_type: 'subscription.updated',
    occurred_at: new Date().toISOString(),
    data: {
      id: subId,
      status: 'active',
      customer_id: custId,
      next_billed_at: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
      custom_data: { userId, planId: 'starter' },
      items: [{ price: { id: priceId } }],
    },
  });
  check('subscription.updated accepted', r4.status === 200, `got ${r4.status}`);
  const subAfter = await prisma.subscription.findUnique({ where: { userId } });
  check(
    'subscription synced active with period end',
    subAfter?.status === 'active' && !!subAfter?.currentPeriodEnd && subAfter?.paddleCustomerId === custId,
    JSON.stringify({ status: subAfter?.status }),
  );

  // --- 5. cancellation ---------------------------------------------------------
  const r5 = await deliver({
    event_id: `evt_cancel_${Date.now()}`,
    event_type: 'subscription.canceled',
    occurred_at: new Date().toISOString(),
    data: { id: subId, status: 'canceled', custom_data: { userId } },
  });
  check('subscription.canceled accepted', r5.status === 200, `got ${r5.status}`);
  const subCancelled = await prisma.subscription.findUnique({ where: { userId } });
  check('subscription marked cancelled', subCancelled?.status === 'cancelled', String(subCancelled?.status));

  // --- 6. bad / missing signatures rejected -------------------------------------
  const bad = await fetch(`${BASE}/api/paddle/webhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Paddle-Signature': 'ts=123;h1=deadbeef' },
    body: '{}',
  });
  check('bad signature rejected (400)', bad.status === 400, `got ${bad.status}`);
  const missing = await fetch(`${BASE}/api/paddle/webhook`, { method: 'POST', body: '{}' });
  check('missing signature rejected (400)', missing.status === 400, `got ${missing.status}`);

  // --- cleanup -------------------------------------------------------------------
  await prisma.creditTransaction.deleteMany({ where: { userId } }).catch(() => {});
  await prisma.subscription.deleteMany({ where: { userId } }).catch(() => {});
  await prisma.processedEvent.deleteMany({ where: { eventId: { startsWith: 'paddle:tx:' } } }).catch(() => {});
  await prisma.processedEvent.deleteMany({ where: { eventId: { startsWith: 'evt_' } } }).catch(() => {});
  await prisma.user.delete({ where: { id: userId } }).catch(() => {});

  console.log(failures === 0 ? '\nPADDLE FLOW TEST PASSED' : `\n${failures} CHECK(S) FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
