# BlogPilot AI — Production Deployment Guide

This guide covers deploying the BlogPilot AI SaaS app to **Vercel** (frontend + API) with a **Supabase** PostgreSQL database. Total setup time: ~30 minutes.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Database Setup (Supabase)](#2-database-setup-supabase)
3. [Code Repository Setup](#3-code-repository-setup)
4. [Vercel Deployment](#4-vercel-deployment)
5. [Stripe Webhook Configuration](#5-stripe-webhook-configuration)
6. [Post-Deployment Verification](#6-post-deployment-verification)
7. [Self-Hosting Alternative (Docker / VPS)](#7-self-hosting-alternative-docker--vps)
8. [Troubleshooting](#8-troubleshooting)

---

## 1. Prerequisites

Before you begin, you'll need accounts and API keys for:

| Service | Purpose | Sign-up URL |
|---------|---------|-------------|
| **GitHub** | Host the code repository | https://github.com |
| **Vercel** | Host the Next.js app (frontend + API) | https://vercel.com |
| **Supabase** | Host the PostgreSQL database | https://supabase.com |
| **Google AI Studio** | Gemini API key for AI generation | https://aistudio.google.com/app/apikey |
| **Serper.dev** | Google Search API (competitor research) | https://serper.dev |
| **Jina.ai** | Reader API (URL → markdown) | https://jina.ai |
| **Stripe** | Subscription payments | https://stripe.com |

> The app runs in **demo mode** when Stripe, Gemini, Serper, or Jina keys are absent — useful for first deploy and quick smoke testing.

---

## 2. Database Setup (Supabase)

### 2.1 Create the project

1. Go to https://supabase.com/dashboard → **New project**
2. Pick a name (e.g. `blogpilot-prod`), set a strong DB password, choose a region close to your Vercel region (e.g. `us-west-1` if you'll deploy to `sfo1`).
3. Wait ~2 minutes for provisioning to finish.

### 2.2 Run the schema migration

1. In the Supabase dashboard, open the **SQL Editor** (left sidebar).
2. Click **New query**.
3. Open the file `supabase/migrations/0001_init.sql` from this repo, copy its entire contents, paste into the SQL editor, and click **Run**.
4. Verify by running:
   ```sql
   SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;
   ```
   Expected output: 6 tables — `AffiliateKey`, `Article`, `ConnectedSite`, `CreditTransaction`, `Subscription`, `User`.

### 2.3 Get the connection string

1. In Supabase dashboard, go to **Project Settings** (gear icon) → **Database**.
2. Under **Connection string**, choose **URI**.
3. Pick the **Transaction pooler** URL (port `6543` — uses PgBouncer for connection pooling, which Vercel Serverless requires):
   ```
   postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres?pgbouncer=true
   ```
4. Copy this string — you'll paste it into Vercel as `DATABASE_URL` in step 4.3.

### 2.4 Switch Prisma to PostgreSQL

Open `prisma/schema.prisma` and change the datasource provider:

```prisma
datasource db {
  provider = "postgresql"   // was "sqlite"
  url      = env("DATABASE_URL")
}
```

Commit this change to your repo before deploying to Vercel — Vercel runs `bun run build` which triggers `prisma generate` automatically.

---

## 3. Code Repository Setup

### 3.1 Push to GitHub

```bash
# From the project root
git init
git add .
git commit -m "Initial commit — BlogPilot AI production build"
git branch -M main
git remote add origin https://github.com/<your-username>/blogpilot-ai.git
git push -u origin main
```

### 3.2 Generate the ENCRYPTION_KEY

This key is used by AES-256-GCM to encrypt stored credentials (WordPress app passwords, Shopify API keys, affiliate keys) at rest.

```bash
openssl rand -base64 32
```

The output will be a 44-character string. **Save it somewhere safe** — if you lose it, all encrypted credentials become unrecoverable.

### 3.3 Set up local environment

```bash
cp .env.example .env
# Edit .env and fill in real values for every variable
bun install
bun run db:push     # syncs Prisma schema to Supabase
bun run dev         # start local dev server at localhost:3000
```

---

## 4. Vercel Deployment

### 4.1 Import the repo

1. Go to https://vercel.com/new
2. Connect your GitHub account if not already connected.
3. Select the `blogpilot-ai` repo → **Import**.

### 4.2 Configure build settings

Vercel auto-detects Next.js 16. Verify these settings (or set them explicitly):

| Setting | Value |
|---------|-------|
| **Framework Preset** | Next.js |
| **Build Command** | `bun run build` |
| **Output Directory** | `.next` (auto-detected) |
| **Install Command** | `bun install` |
| **Root Directory** | `./` (default) |

The `vercel.json` file in the repo already declares these, so Vercel will pick them up automatically.

### 4.3 Add environment variables

In the Vercel project's **Settings → Environment Variables**, add each of these (use the **Production**, **Preview**, and **Development** scopes for all of them):

| Key | Value | Notes |
|-----|-------|-------|
| `DATABASE_URL` | `postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:6543/postgres?pgbouncer=true` | From Supabase step 2.3 |
| `GEMINI_API_KEY` | `AIza...` | From Google AI Studio |
| `SERPER_API_KEY` | `c5...` | From serper.dev dashboard |
| `JINA_API_KEY` | `jina_...` | From jina.ai dashboard |
| `STRIPE_SECRET_KEY` | `sk_live_...` or `sk_test_...` | From Stripe dashboard |
| `STRIPE_PUBLISHABLE_KEY` | `pk_live_...` or `pk_test_...` | From Stripe dashboard |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` | See step 5.2 below |
| `STRIPE_PRICE_BASIC` | `price_...` | See step 5.1 below |
| `STRIPE_PRICE_PRO` | `price_...` | See step 5.1 below |
| `STRIPE_PRICE_AGENCY` | `price_...` | See step 5.1 below |
| `ENCRYPTION_KEY` | `<44-char base64>` | From step 3.2 |
| `NEXT_PUBLIC_APP_URL` | `https://your-app.vercel.app` | Your Vercel URL (after first deploy) |

### 4.4 Deploy

1. Click **Deploy** on Vercel.
2. Wait for the build to finish (~2 minutes).
3. Once deployed, Vercel gives you a URL like `https://blogpilot-ai.vercel.app`. Update `NEXT_PUBLIC_APP_URL` in your Vercel env vars to this URL and trigger a redeploy.

---

## 5. Stripe Webhook Configuration

### 5.1 Create subscription products

1. In Stripe dashboard, go to **Products** → **Add product**.
2. Create three products, each with a **recurring monthly price**:
   - **Basic** — $19/month → copy the `price_...` ID → set as `STRIPE_PRICE_BASIC`
   - **Pro** — $49/month → copy the `price_...` ID → set as `STRIPE_PRICE_PRO`
   - **Agency** — $199/month → copy the `price_...` ID → set as `STRIPE_PRICE_AGENCY`
3. Redeploy Vercel after setting these env vars.

### 5.2 Register the webhook endpoint

1. In Stripe dashboard, go to **Developers** → **Webhooks** → **Add endpoint**.
2. Set the endpoint URL to: `https://your-app.vercel.app/api/stripe/webhook`
3. Select these events to send:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
4. Click **Add endpoint**.
5. On the endpoint detail page, under **Signing secret**, click **Reveal** → copy the `whsec_...` value → set as `STRIPE_WEBHOOK_SECRET` in Vercel.
6. Redeploy Vercel.

### 5.3 Test the webhook

1. In the Stripe webhook endpoint page, click **Send test webhook**.
2. Pick `checkout.session.completed` → send.
3. Check Vercel logs (under **Deployments** → click the latest → **Logs**) for the success log line.

---

## 6. Post-Deployment Verification

### 6.1 Smoke test

Visit `https://your-app.vercel.app` and verify:

- [ ] Landing page renders
- [ ] Sign-up flow creates a user (check Supabase Table Editor → `User`)
- [ ] New users get 10 free credits (check Supabase → `User.credits`)
- [ ] Generating an article decrements credits by 1
- [ ] Generated article appears in History page
- [ ] Editor opens with full content
- [ ] Billing page shows 3 tiers
- [ ] Clicking "Upgrade" starts a Stripe Checkout session
- [ ] After completing checkout (use Stripe test card `4242 4242 4242 4242`), credits are granted

### 6.2 Health check

Visit `https://your-app.vercel.app/api/health` — should return JSON like:

```json
{
  "status": "ok",
  "uptime": 123.45,
  "env": {
    "required": [{ "name": "DATABASE_URL", "configured": true }],
    "ai": [{ "name": "GEMINI_API_KEY", "configured": true }],
    "scraping": [...],
    "stripe": [...]
  }
}
```

If any `required` field shows `configured: false`, the corresponding env var is missing on Vercel.

### 6.3 Performance check

Run a Lighthouse audit on the deployed URL — target scores:
- **Performance**: 90+
- **Accessibility**: 95+
- **Best Practices**: 100
- **SEO**: 95+

---

## 7. Self-Hosting Alternative (Docker / VPS)

If you prefer not to use Vercel, the app's `output: "standalone"` config produces a self-contained Node bundle that runs anywhere.

### 7.1 Dockerfile

```dockerfile
FROM node:20-alpine AS base
WORKDIR /app
RUN apk add --no-cache libc6-compat openssl

FROM base AS builder
COPY package.json bun.lock ./
RUN npm install -g bun && bun install --frozen-lockfile
COPY . .
RUN bun run build

FROM base AS runner
ENV NODE_ENV=production
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public
EXPOSE 3000
CMD ["node", "server.js"]
```

### 7.2 Run with Docker

```bash
docker build -t blogpilot-ai .
docker run -p 3000:3000 \
  -e DATABASE_URL=$DATABASE_URL \
  -e GEMINI_API_KEY=$GEMINI_API_KEY \
  -e ENCRYPTION_KEY=$ENCRYPTION_KEY \
  -e STRIPE_SECRET_KEY=$STRIPE_SECRET_KEY \
  -e STRIPE_PUBLISHABLE_KEY=$STRIPE_PUBLISHABLE_KEY \
  -e STRIPE_WEBHOOK_SECRET=$STRIPE_WEBHOOK_SECRET \
  -e STRIPE_PRICE_BASIC=$STRIPE_PRICE_BASIC \
  -e STRIPE_PRICE_PRO=$STRIPE_PRICE_PRO \
  -e STRIPE_PRICE_AGENCY=$STRIPE_PRICE_AGENCY \
  -e NEXT_PUBLIC_APP_URL=https://your-domain.com \
  blogpilot-ai
```

### 7.3 VPS (systemd)

If running on a VPS without Docker:

```bash
git clone https://github.com/<your-username>/blogpilot-ai.git
cd blogpilot-ai
bun install
bun run build

# Create /etc/systemd/system/blogpilot.service
sudo tee /etc/systemd/system/blogpilot.service <<EOF
[Unit]
Description=BlogPilot AI
After=network.target

[Service]
Type=simple
User=deploy
WorkingDirectory=/home/deploy/blogpilot-ai
EnvironmentFile=/home/deploy/blogpilot-ai/.env
ExecStart=/usr/bin/node .next/standalone/server.js
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable blogpilot
sudo systemctl start blogpilot
```

Put a reverse proxy (Caddy / nginx) in front to terminate TLS:

```caddyfile
your-domain.com {
  reverse_proxy localhost:3000
}
```

---

## 8. Troubleshooting

### Build fails with "Cannot find module 'socket.io'"

The `examples/` folder has a websocket demo that isn't part of the app. It's excluded from `tsconfig.json` and `eslint.config.mjs` — if your build still picks it up, make sure you didn't accidentally import from `examples/` in `src/`.

### Prisma error: "Database connection timeout"

You're using the **Direct connection** URL instead of the **Transaction pooler** URL. Go back to Supabase → Database → Connection string and pick the pooler URL (port `6543`).

### Stripe webhook returns 503

`STRIPE_WEBHOOK_SECRET` is missing or wrong. Re-copy from Stripe dashboard → Developers → Webhooks → your endpoint → Signing secret.

### `ENCRYPTION_KEY` error on startup

The key must be exactly 44 characters (base64-encoded 32 bytes). Regenerate with `openssl rand -base64 32` and update Vercel env vars.

### Credits not granted after Stripe checkout

Check Vercel function logs at `/api/stripe/webhook`. The most common cause is the webhook event arriving before the env var redeploy completed. Send a test webhook from the Stripe dashboard to re-process.

### Images not loading

The `next/image` component only allows remote images from whitelisted domains (defined in `next.config.ts`). If you add new image sources (CDN, CMS), add their hostnames to `images.remotePatterns`.

---

**That's it.** Your BlogPilot AI app is now live in production. 🎉
