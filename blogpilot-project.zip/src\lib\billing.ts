import prisma from '@/lib/prisma';

export type PlanId = 'free' | 'starter' | 'pro' | 'agency';

export interface PlanConfig {
  id: PlanId;
  name: string;
  priceMonthly: number;
  creditsPerMonth: number;
  maxSites: number;
  autoPublish: boolean;
  description: string;
}

export const PLANS: PlanConfig[] = [
  { id: 'free', name: 'Free', priceMonthly: 0, creditsPerMonth: 10, maxSites: 1, autoPublish: false, description: '10 free articles, 1 site' },
  { id: 'starter', name: 'Starter', priceMonthly: 29, creditsPerMonth: 50, maxSites: 3, autoPublish: false, description: '50 articles/mo, 3 connected sites, basic SEO' },
  { id: 'pro', name: 'Pro', priceMonthly: 79, creditsPerMonth: 200, maxSites: 15, autoPublish: true, description: '200 articles/mo, 15 sites, advanced SEO, auto-publish' },
  { id: 'agency', name: 'Agency', priceMonthly: 199, creditsPerMonth: 2000, maxSites: 999, autoPublish: true, description: 'Unlimited articles, unlimited sites, API access' },
];

export function getPlanConfig(id: string | null | undefined): PlanConfig {
  return PLANS.find(p => p.id === id) || PLANS[0];
}

export function isValidPlanId(id: string): boolean {
  return PLANS.some(p => p.id === id);
}

export function getStripePriceId(plan: PlanConfig): string | undefined {
  return process.env[`STRIPE_PRICE_ID_${plan.id.toUpperCase()}`] || undefined;
}

/**
 * Reverse lookup: maps a Stripe Price ID back to the plan it was configured
 * for. This is the authoritative way to resolve a plan from an invoice line
 * item — it cannot be spoofed by client-controlled metadata because the
 * price IDs come exclusively from server-side environment configuration.
 */
export function getPlanByStripePriceId(priceId: string | null | undefined): PlanId | null {
  if (!priceId) return null;
  for (const plan of PLANS) {
    if (getStripePriceId(plan) === priceId) return plan.id;
  }
  return null;
}

export function getPaddlePriceId(plan: PlanConfig): string | undefined {
  return process.env[`PADDLE_PRICE_ID_${plan.id.toUpperCase()}`] || undefined;
}

/** Same trust model as Stripe price mapping, applied to Paddle Price IDs. */
export function getPlanByPaddlePriceId(priceId: string | null | undefined): PlanId | null {
  if (!priceId) return null;
  for (const plan of PLANS) {
    if (getPaddlePriceId(plan) === priceId) return plan.id;
  }
  return null;
}

export async function activatePlan(
  userId: string,
  planId: string,
  opts?: { source?: string; description?: string; idempotencyKey?: string; forceGrant?: boolean },
) {
  const plan = getPlanConfig(planId);
  if (!isValidPlanId(planId)) {
    throw new Error(`Invalid plan: ${planId}`);
  }

  return prisma.$transaction(async (tx) => {
    // Exactly-once guard for payment-provider driven calls. The claim commits
    // atomically with the credit grant, so a replayed webhook can never
    // allocate credits twice.
    if (opts?.idempotencyKey) {
      try {
        await tx.processedEvent.create({
          data: { eventId: opts.idempotencyKey, eventType: `plan_activation:${planId}` },
        });
      } catch (err: any) {
        if (err?.code === 'P2002') {
          return { plan: plan.id, planName: plan.name, creditsAdded: 0, credits: null, duplicate: true };
        }
        throw err;
      }
    }

    const existing = await tx.subscription.findUnique({ where: { userId } });
    const alreadyActive = existing && existing.plan === planId && existing.status === 'active';
    const planOrder = ['free', 'starter', 'pro', 'agency'];
    const currentIdx = existing ? planOrder.indexOf(existing.plan) : -1;
    const newIdx = planOrder.indexOf(planId);
    const isUpgrade = newIdx > currentIdx;
    // forceGrant is used ONLY by Stripe invoice.paid, where the invoice-
    // scoped idempotency key already guarantees one grant per billing
    // period. It lets monthly renewals allocate fresh credits even though
    // the subscription row is already active — without opening a downgrade/
    // resubscribe credit-cycling hole anywhere else.
    const creditsAdded = opts?.forceGrant
      ? plan.creditsPerMonth
      : alreadyActive ? 0 : (isUpgrade ? plan.creditsPerMonth : 0);

    // Atomic increment — never read-then-write the balance.
    const updatedUser = creditsAdded > 0
      ? await tx.user.update({
          where: { id: userId },
          data: { credits: { increment: creditsAdded } },
        })
      : null;

    await tx.subscription.upsert({
      where: { userId },
      create: {
        userId,
        plan: planId,
        status: 'active',
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
      update: {
        plan: planId,
        status: 'active',
        cancelAtPeriodEnd: false,
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    });

    if (creditsAdded > 0 && updatedUser) {
      await tx.creditTransaction.create({
        data: {
          userId,
          amount: creditsAdded,
          reason: 'plan_purchase',
          description: opts?.description || `Purchased the ${plan.name} plan (${plan.creditsPerMonth} credits)`,
          balanceAfter: updatedUser.credits,
        },
      });
    }

    return { plan: plan.id, planName: plan.name, creditsAdded, credits: updatedUser ? updatedUser.credits : null };
  });
}

export async function grantCredits(
  userId: string,
  amount: number,
  reason: string,
  description?: string | null,
) {
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error('Invalid credit amount');
  }

  return prisma.$transaction(async (tx) => {
    const updated = await tx.user.update({
      where: { id: userId },
      data: { credits: { increment: amount } },
    });
    await tx.creditTransaction.create({
      data: {
        userId,
        amount,
        reason,
        description: description || null,
        balanceAfter: updated.credits,
      },
    });
    return updated;
  });
}

export async function cancelSubscription(userId: string) {
  const existing = await prisma.subscription.findUnique({ where: { userId } });
  if (!existing) return { cancelled: false };
  await prisma.subscription.update({
    where: { userId },
    data: { status: 'cancelled', cancelAtPeriodEnd: true },
  });
  return { cancelled: true };
}
