import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/auth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { updateArticleSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

interface RouteParams {
  params: Promise<{ id: string }>
}

/**
 * GET /api/articles/[id]
 * Returns a single article owned by the authenticated user.
 */
export async function GET(request: Request, { params }: RouteParams) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)
    const { id } = await params

    const article = await db.article.findFirst({
      where: { id, userId: user.id },
      include: {
        site: { select: { id: true, name: true, url: true, platform: true } },
      },
    })

    if (!article) {
      return NextResponse.json({ error: 'Article not found' }, { status: 404 })
    }

    return NextResponse.json({ article })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'articles/get')
  }
}

/**
 * PATCH /api/articles/[id]
 * Updates the editable fields of an article (title, content, excerpt, etc.)
 * Recomputes wordCount from the new content.
 */
export async function PATCH(request: Request, { params }: RouteParams) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)
    const { id } = await params

    // Verify ownership
    const existing = await db.article.findFirst({
      where: { id, userId: user.id },
      select: { id: true },
    })
    if (!existing) {
      return NextResponse.json({ error: 'Article not found' }, { status: 404 })
    }

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(updateArticleSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const {
      title,
      content,
      excerpt,
      targetKeyword,
      tone,
      length,
      language,
      intent,
      seoScore,
      status,
      siteId,
    } = body

    // Build update payload with only provided fields
    const data: Record<string, unknown> = {}
    if (typeof title === 'string' && title.trim()) data.title = title.trim()
    if (typeof content === 'string') data.content = content
    if (typeof excerpt === 'string') data.excerpt = excerpt || null
    if (typeof targetKeyword === 'string') data.targetKeyword = targetKeyword || null
    if (typeof tone === 'string') data.tone = tone || null
    if (typeof length === 'string') data.length = length || null
    if (typeof language === 'string') data.language = language
    if (typeof intent === 'string') data.intent = intent
    if (typeof seoScore === 'number') data.seoScore = seoScore
    if (typeof status === 'string') {
      // updateArticleSchema already constrains to enum, but defence-in-depth
      const allowed = ['draft', 'published', 'scheduled']
      if (!allowed.includes(status)) {
        return NextResponse.json({ error: `Invalid status: ${status}`, code: 'validation' }, { status: 400 })
      }
      data.status = status
      if (status === 'published') {
        data.publishedAt = new Date()
      }
    }
    if (siteId !== undefined) {
      data.siteId = siteId || null
    }

    // Recompute word count if content was updated
    if (typeof content === 'string') {
      data.wordCount = content ? content.split(/\s+/).filter(Boolean).length : 0
    }

    const updated = await db.article.update({
      where: { id },
      data,
      include: {
        site: { select: { id: true, name: true, url: true, platform: true } },
      },
    })

    return NextResponse.json({ article: updated })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'articles/update')
  }
}

/**
 * DELETE /api/articles/[id]
 * Permanently removes an article owned by the authenticated user.
 */
export async function DELETE(request: Request, { params }: RouteParams) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)
    const { id } = await params

    const existing = await db.article.findFirst({
      where: { id, userId: user.id },
      select: { id: true },
    })
    if (!existing) {
      return NextResponse.json({ error: 'Article not found' }, { status: 404 })
    }

    await db.article.delete({ where: { id } })

    return NextResponse.json({ success: true, id })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'articles/delete')
  }
}
