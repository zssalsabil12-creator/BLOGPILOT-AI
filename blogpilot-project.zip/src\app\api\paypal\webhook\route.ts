﻿import { NextResponse } from 'next/server';
import { verifyPayPalWebhook, handlePayPalWebhook } from '@/lib/paypal';

export async function POST(req: Request) {
  const body = await req.text();
  if (!body) {
    return NextResponse.json({ ok: false, error: 'Empty body' }, { status: 400 });
  }

  const valid = await verifyPayPalWebhook(req.headers, body);
  if (!valid) {
    return NextResponse.json({ ok: false, error: 'Invalid webhook signature' }, { status: 400 });
  }

  try {
    const event = JSON.parse(body);
    await handlePayPalWebhook(event);
    return NextResponse.json({ received: true });
  } catch (error: any) {
    console.error('PayPal webhook handler error:', error);
    return NextResponse.json({ ok: false, error: 'Webhook handling failed' }, { status: 500 });
  }
}