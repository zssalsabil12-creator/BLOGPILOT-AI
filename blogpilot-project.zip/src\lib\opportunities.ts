/**
 * SEO Opportunity Engine.
 *
 * Computes actionable opportunities from REAL Search Console data:
 * quick wins, declining pages, high-impression/low-CTR pages, and
 * content gaps. No fabricated numbers — every item cites its data.
 */

import type { GscAnalyticsRow } from '@/lib/gsc';

export type OpportunityAction =
  | 'write-article'
  | 'refresh-article'
  | 'improve-title-meta'
  | 'strengthen-page';

export interface Opportunity {
  id: string;
  type: 'quick-win' | 'declining' | 'low-ctr' | 'content-gap';
  title: string;
  target: string; // query or page the opportunity is about
  why: string;
  impact: string;
  confidence: 'high' | 'medium' | 'low';
  action: OpportunityAction;
  actionLabel: string;
  metrics: {
    position?: number;
    clicks?: number;
    impressions?: number;
    ctr?: number;
    changePct?: number;
  };
}

export interface OpportunityInput {
  byQuery: GscAnalyticsRow[]; // current period, dimension [query]
  byPage: GscAnalyticsRow[]; // current period, dimension [page]
  byPagePrev?: GscAnalyticsRow[]; // previous period, dimension [page]
}

const QUICK_WIN_MAX_POSITION = 20;
const QUICK_WIN_MIN_IMPRESSIONS = 30;
const DECLINE_MIN_PREV_CLICKS = 10;
const DECLINE_PCT = 0.2;
const LOW_CTR_MIN_IMPRESSIONS = 300;
const GAP_MIN_IMPRESSIONS = 100;
const GAP_POSITION = 25;

/** Rough expected CTR by average position bucket (industry heuristics). */
function expectedCtr(position: number): number {
  if (position <= 1) return 0.32;
  if (position <= 3) return 0.18;
  if (position <= 5) return 0.10;
  if (position <= 10) return 0.06;
  if (position <= 15) return 0.03;
  return 0.02;
}

function confidenceFor(impressions: number): 'high' | 'medium' | 'low' {
  if (impressions >= 1000) return 'high';
  if (impressions >= 200) return 'medium';
  return 'low';
}

function pct(n: number): string {
  return `${(n * 100).toFixed(1)}%`;
}

export function computeOpportunities(input: OpportunityInput): Opportunity[] {
  const opportunities: Opportunity[] = [];

  // ── Quick Wins: rank 4–20, meaningful impressions, realistic CTR uplift ──
  for (const row of input.byQuery) {
    const [query] = row.keys;
    if (!query || row.impressions < QUICK_WIN_MIN_IMPRESSIONS) continue;
    if (row.position < 4 || row.position > QUICK_WIN_MAX_POSITION) continue;

    const targetCtr = expectedCtr(Math.max(4, Math.min(row.position, 8)));
    const potentialClicks = Math.round((targetCtr - row.ctr) * row.impressions);
    if (potentialClicks < 3) continue;

    opportunities.push({
      id: `quick-win:${query}`,
      type: 'quick-win',
      title: `“${query}” can reach page one`,
      target: query,
      why: `Average position ${row.position.toFixed(1)} — just outside top results, with ${row.impressions.toLocaleString()} impressions.`,
      impact: `~+${Math.max(potentialClicks, 3).toLocaleString()} clicks/month if CTR improves toward ${pct(targetCtr)} (now ${pct(row.ctr)}).`,
      confidence: confidenceFor(row.impressions),
      action: row.position <= 10 ? 'strengthen-page' : 'refresh-article',
      actionLabel: row.position <= 10 ? 'Strengthen this page' : 'Refresh & expand coverage',
      metrics: { position: row.position, clicks: row.clicks, impressions: row.impressions, ctr: row.ctr },
    });
  }

  // ── Declining Pages: period-over-period click drop ──
  if (input.byPagePrev && input.byPagePrev.length > 0) {
    const prevMap = new Map<string, GscAnalyticsRow>();
    for (const r of input.byPagePrev) prevMap.set(r.keys[0], r);

    for (const cur of input.byPage) {
      const url = cur.keys[0];
      const prev = prevMap.get(url);
      if (!prev || prev.clicks < DECLINE_MIN_PREV_CLICKS) continue;

      const changePct = prev.clicks > 0 ? (cur.clicks - prev.clicks) / prev.clicks : 0;
      if (changePct >= -DECLINE_PCT) continue;

      const shortUrl = url.replace(/^https?:\/\/[^/]+/, '') || '/';
      opportunities.push({
        id: `declining:${url}`,
        type: 'declining',
        title: `Traffic down on ${shortUrl}`,
        target: url,
        why: `Clicks fell from ${prev.clicks.toLocaleString()} to ${cur.clicks.toLocaleString()} (${(changePct * 100).toFixed(0)}%) vs previous period.`,
        impact: 'Recovering this page protects existing traffic — usually cheaper than new content.',
        confidence: prev.clicks >= 50 ? 'high' : 'medium',
        action: 'refresh-article',
        actionLabel: 'Analyze & refresh article',
        metrics: { clicks: cur.clicks, impressions: cur.impressions, ctr: cur.ctr, changePct },
      });
    }
  }

  // ── High Impressions / Low CTR → title & meta problems ──
  for (const row of input.byPage) {
    const url = row.keys[0];
    if (!url || row.impressions < LOW_CTR_MIN_IMPRESSIONS) continue;

    const benchmark = expectedCtr(row.position);
    // Underperforming = less than half of what this position typically gets.
    if (row.ctr >= benchmark * 0.5) continue;

    const shortUrl = url.replace(/^https?:\/\/[^/]+/, '') || '/';
    const lostClicks = Math.round((benchmark - row.ctr) * row.impressions);
    opportunities.push({
      id: `low-ctr:${url}`,
      type: 'low-ctr',
      title: `Low click-through on ${shortUrl}`,
      target: url,
      why: `${row.impressions.toLocaleString()} impressions but only ${pct(row.ctr)} CTR (position avg ${row.position.toFixed(1)}) — the snippet isn't earning clicks.`,
      impact: `A stronger title/meta could recover ~${lostClicks.toLocaleString()} clicks/month at the same ranking.`,
      confidence: confidenceFor(row.impressions),
      action: 'improve-title-meta',
      actionLabel: 'Rewrite title & meta description',
      metrics: { position: row.position, clicks: row.clicks, impressions: row.impressions, ctr: row.ctr },
    });
  }

  // ── Content Gaps: visible for queries with no page ranking ≤ 25 ──
  const strongPages = input.byPage.filter(r => r.position > 0 && r.position <= GAP_POSITION);
  const strongTokens = new Set<string>();
  for (const p of strongPages) {
    // Tokenize page URLs so we can approximate which queries they serve.
    const path = p.keys[0].replace(/^https?:\/\//, '').replace(/[-_/]/g, ' ').toLowerCase();
    for (const t of path.split(/\s+/)) if (t.length > 3) strongTokens.add(t);
  }

  for (const row of input.byQuery) {
    const [query] = row.keys;
    if (!query || row.impressions < GAP_MIN_IMPRESSIONS) continue;
    if (row.position > 0 && row.position <= GAP_POSITION) continue; // already ranks

    const qTokens = query.toLowerCase().split(/\s+/).filter(t => t.length > 3);
    const covered = qTokens.length > 0 && qTokens.every(t => strongTokens.has(t));
    if (covered) continue; // a dedicated page likely exists but ranks poorly → quick-win handles it

    opportunities.push({
      id: `content-gap:${query}`,
      type: 'content-gap',
      title: `No strong page for “${query}”`,
      target: query,
      why: `${row.impressions.toLocaleString()} impressions with best position ${row.position > 0 ? row.position.toFixed(1) : '> 50'} — searchers see your domain but no page targets this query well.`,
      impact: 'A dedicated article could convert these impressions into clicks and establish topical depth.',
      confidence: confidenceFor(row.impressions),
      action: 'write-article',
      actionLabel: 'Create article for this keyword',
      metrics: { position: row.position, clicks: row.clicks, impressions: row.impressions },
    });
  }

  // Prioritize: estimated impact first (clicks potential proxy), then confidence.
  const impactScore = (o: Opportunity): number => {
    let s = o.metrics.impressions ?? 0;
    if (o.type === 'quick-win') s *= 1.6;
    if (o.type === 'declining') s += Math.abs(o.metrics.changePct ?? 0) * 500 + 200;
    if (o.confidence === 'high') s *= 1.3;
    else if (o.confidence === 'low') s *= 0.7;
    return s;
  };

  return opportunities.sort((a, b) => impactScore(b) - impactScore(a));
}
