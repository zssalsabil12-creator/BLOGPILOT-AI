import React, { Suspense } from 'react';
import { GenerateArticlePage } from '../../../components/dashboard/generate-article-page';

interface DashboardGeneratePageProps {
  searchParams?: Promise<{ [key: string]: string | string[] | undefined }>;
}

export default function DashboardGeneratePage({ searchParams }: DashboardGeneratePageProps) {
  return (
    <div className="p-6">
      <Suspense fallback={<div className="text-slate-400">Loading article builder…</div>}>
        <GenerateArticlePage />
      </Suspense>
    </div>
  );
}
