﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId, getCurrentUser } from '@/lib/auth';
import { createStripeCheckoutSession, isStripeConfigured } from '@/lib/stripe';
import { apiError } from '@/lib/utils';

const checkoutSchema = z.object({
  plan: z.enum(['starter', 'pro', 'agency']),
  mode: z.enum(['subscription', 'payment']).optional(),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = checkoutSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const { plan, mode = 'subscription' } = parsed.data;

  try {
    if (isStripeConfigured()) {
      const user = await getCurrentUser(req);
      const url = await createStripeCheckoutSession({
        userId,
        email: user?.email,
        planId: plan,
        mode,
      });
      if (url) {
        return NextResponse.json({ ok: true, data: { provider: 'stripe', url, demo: false } });
      }
    }

    return NextResponse.json({ ok: false, error: 'Payment provider not configured' }, { status: 503 });
  } catch (error: any) {
    console.error('Stripe checkout error:', error);
    return apiError('stripe/checkout', error);
  }
}