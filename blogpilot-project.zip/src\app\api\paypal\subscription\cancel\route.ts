import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { isPayPalConfigured, getPayPalAccessToken } from '@/lib/paypal';
import { cancelSubscription } from '@/lib/billing';
import prisma from '@/lib/prisma';

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json().catch(() => ({}));
  const subscriptionId = body.subscriptionId as string | undefined;

  if (isPayPalConfigured() && subscriptionId) {
    const userSub = await prisma.subscription.findUnique({ where: { userId } });
    if (!userSub?.paypalSubscriptionId || userSub.paypalSubscriptionId !== subscriptionId) {
      return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 403 });
    }
    try {
      const token = await getPayPalAccessToken();
      const base = process.env.PAYPAL_MODE === 'live'
        ? 'https://api-m.paypal.com'
        : 'https://api-m.sandbox.paypal.com';
      await fetch(`${base}/v1/billing/subscriptions/${subscriptionId}/cancel`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
    } catch (err: any) {
      console.error('PayPal cancel API error:', err);
    }
  }

  await cancelSubscription(userId);

  if (subscriptionId) {
    await prisma.subscription.updateMany({
      where: { userId },
      data: { paypalSubscriptionId: null, status: 'cancelled' },
    }).catch(() => {});
  }

  return NextResponse.json({ ok: true, message: 'Subscription cancelled.' });
}
