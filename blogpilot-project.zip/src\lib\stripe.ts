﻿import Stripe from 'stripe';
import prisma from '@/lib/prisma';
import { APP_URL } from '@/lib/env';
import { getPlanConfig, getStripePriceId, getPlanByStripePriceId, activatePlan, isValidPlanId } from '@/lib/billing';
import { claimEvent, releaseEvent, deductCreditsCapped } from '@/lib/credits';

let client: Stripe | null = null;

export function isStripeConfigured(): boolean {
  return !!process.env.STRIPE_SECRET_KEY;
}

export function getStripe(): Stripe | null {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) return null;
  if (!client) client = new Stripe(key);
  return client;
}

export async function createStripeCheckoutSession(params: {
  userId: string;
  email?: string | null;
  planId: string;
  mode: 'subscription' | 'payment';
}): Promise<string | null> {
  const stripe = getStripe();
  if (!stripe) return null;

  const plan = getPlanConfig(params.planId);
  const mode = params.mode;

  let lineItems: Stripe.Checkout.SessionCreateParams.LineItem[];
  if (mode === 'subscription') {
    const priceId = getStripePriceId(plan);
    if (!priceId) throw new Error(`No Stripe price configured for the ${plan.name} plan. Set STRIPE_PRICE_ID_${plan.id.toUpperCase()}.`);
    lineItems = [{ price: priceId, quantity: 1 }];
  } else {
    lineItems = [{
      price_data: {
        currency: 'usd',
        product_data: { name: `BlogPilot ${plan.name} Plan`, description: plan.description },
        unit_amount: plan.priceMonthly * 100,
      },
      quantity: 1,
    }];
  }

  const session = await stripe.checkout.sessions.create({
    mode,
    line_items: lineItems,
    customer_email: params.email || undefined,
    metadata: { userId: params.userId, planId: plan.id },
    subscription_data: mode === 'subscription'
      ? { metadata: { userId: params.userId, planId: plan.id } }
      : undefined,
    success_url: `${APP_URL}/dashboard?tab=billing&payment=success`,
    cancel_url: `${APP_URL}/dashboard?tab=billing&payment=cancelled`,
    allow_promotion_codes: true,
  });

  return session.url;
}

export async function createStripePortalSession(customerId: string): Promise<string | null> {
  const stripe = getStripe();
  if (!stripe) return null;
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${APP_URL}/dashboard?tab=billing`,
  });
  return session.url;
}

export function verifyStripeWebhook(body: string | Buffer, signature: string): Stripe.Event | null {
  const stripe = getStripe();
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!stripe || !secret) return null;
  try {
    return stripe.webhooks.constructEvent(body, signature, secret);
  } catch {
    return null;
  }
}

export async function handleStripeEvent(event: Stripe.Event): Promise<void> {
  // Claim the event BEFORE processing. The unique constraint on
  // ProcessedEvent.eventId arbitrates concurrent deliveries (Stripe retries,
  // replay attacks): exactly one invocation wins, the rest see claimed=false.
  const claimed = await claimEvent(event.id, event.type);
  if (!claimed) {
    return;
  }

  try {
    await processStripeEvent(event);
  } catch (err) {
    // Release the claim so Stripe's retry can be processed again.
    await releaseEvent(event.id);
    throw err;
  }
}

interface ResolvedSubscription {
  userId: string | null;
  planId: string | null;
  stripeSubscriptionId: string | null;
  currentPeriodEnd: Date | null;
}

/**
 * Resolves a subscription referenced by an invoice. Prefers our local record;
 * falls back to fetching the subscription from Stripe so out-of-order webhook
 * delivery (invoice.paid before checkout.session.completed) still resolves
 * the owning user through server-side metadata.
 */
async function resolveSubscription(subId: string): Promise<ResolvedSubscription> {
  const local = await prisma.subscription.findFirst({ where: { stripeSubscriptionId: subId } });
  if (local?.userId) {
    return {
      userId: local.userId,
      planId: isValidPlanId(local.plan) ? local.plan : null,
      stripeSubscriptionId: subId,
      currentPeriodEnd: local.currentPeriodEnd,
    };
  }

  const stripe = getStripe();
  if (!stripe) return { userId: null, planId: null, stripeSubscriptionId: subId, currentPeriodEnd: null };
  try {
    const remote = (await stripe.subscriptions.retrieve(subId)) as Stripe.Subscription & {
      current_period_end?: number;
    };
    return {
      userId: remote.metadata?.userId || null,
      planId: remote.metadata?.planId && isValidPlanId(remote.metadata.planId) ? remote.metadata.planId : null,
      stripeSubscriptionId: subId,
      currentPeriodEnd: remote.current_period_end ? new Date(remote.current_period_end * 1000) : null,
    };
  } catch (err) {
    console.error('[stripe] Failed to retrieve subscription from API:', err);
    return { userId: null, planId: null, stripeSubscriptionId: subId, currentPeriodEnd: null };
  }
}

/**
 * Grants plan credits for a paid billing period.
 *
 * Credit allocation happens HERE — and only here — for subscriptions:
 * every invoice represents exactly one billing period, and the idempotency
 * key is scoped to the invoice ID, so:
 *   - duplicate invoice.paid deliveries        → one grant
 *   - invoice.paid + payment_succeeded doubles → one grant
 *   - monthly renewals                         → fresh allocation per period
 * The plan is resolved preferentially from the invoice's Price ID (server-side
 * env configuration), never from client-controlled data.
 */
async function handleInvoicePaid(event: Stripe.Event): Promise<void> {
  const invoice = event.data.object as {
    id?: string;
    subscription?: string | { id: string } | null;
    customer?: string | { id: string } | null;
    lines?: { data?: Array<{ pricing?: { price_details?: { price?: string } }; price?: { id?: string } }> };
    subscription_details?: { metadata?: Record<string, string> };
  };

  const invoiceId = invoice.id;
  const subId = typeof invoice.subscription === 'string' ? invoice.subscription : invoice.subscription?.id;
  if (!invoiceId || !subId) return;

  const resolved = await resolveSubscription(subId);
  if (!resolved.userId) {
    console.warn(`[stripe] invoice.paid ${invoiceId}: could not resolve user for subscription ${subId}`);
    return;
  }

  // Plan resolution order (most trustworthy first):
  // 1. Invoice line item's Price ID mapped through server-side STRIPE_PRICE_ID_* config.
  // 2. Subscription metadata set by OUR checkout creation code.
  // 3. Locally stored plan as a last resort.
  let planId: string | null = null;
  const line = invoice.lines?.data?.[0] as any;
  const priceId: string | undefined =
    line?.pricing?.price_details?.price || line?.price?.id || undefined;
  if (priceId) {
    planId = getPlanByStripePriceId(priceId);
  }
  if (!planId) {
    const stripe = getStripe();
    if (stripe) {
      try {
        const remote = (await stripe.subscriptions.retrieve(subId)) as Stripe.Subscription;
        const metaPlan = remote.metadata?.planId;
        if (metaPlan && isValidPlanId(metaPlan)) planId = metaPlan;
      } catch {
        // fall through to local plan
      }
    }
  }
  if (!planId && resolved.planId) planId = resolved.planId;
  if (!planId || !isValidPlanId(planId)) {
    console.warn(`[stripe] invoice.paid ${invoiceId}: no valid plan could be resolved`);
    return;
  }

  await activatePlan(resolved.userId, planId, {
    source: 'stripe',
    description: `Stripe billing period: ${getPlanConfig(planId).name} plan`,
    idempotencyKey: `stripe:invoice:${invoiceId}`,
    forceGrant: true,
  });

  if (resolved.currentPeriodEnd) {
    await prisma.subscription.updateMany({
      where: { userId: resolved.userId },
      data: { currentPeriodEnd: resolved.currentPeriodEnd },
    }).catch((err) => console.error('[stripe] period end update failed:', err));
  }
}

async function processStripeEvent(event: Stripe.Event): Promise<void> {
  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.userId;
      const planId = session.metadata?.planId;

      if (!userId || !planId || !isValidPlanId(planId)) break;

      if (session.mode === 'subscription') {
        // Subscriptions are granted credits exclusively by `invoice.paid`
        // (one grant per billing period, keyed on the invoice ID). Recording
        // the subscription row here is bookkeeping only — no credits.
        await prisma.subscription.upsert({
          where: { userId },
          create: {
            userId,
            plan: planId,
            status: 'active',
            stripeCustomerId: typeof session.customer === 'string' ? session.customer : undefined,
            stripeSubscriptionId:
              typeof session.subscription === 'string' ? session.subscription : session.subscription?.id,
          },
          update: {
            plan: planId,
            status: 'active',
            ...(typeof session.customer === 'string' && session.customer ? { stripeCustomerId: session.customer } : {}),
            ...(session.subscription
              ? { stripeSubscriptionId: typeof session.subscription === 'string' ? session.subscription : session.subscription.id }
              : {}),
          },
        }).catch((err) => console.error('[stripe] checkout sub upsert failed:', err));
      } else {
        // One-time payment: activate exactly once per event.
        await activatePlan(userId, planId, {
          source: 'stripe',
          description: `Stripe purchase: ${getPlanConfig(planId).name} plan`,
          idempotencyKey: event.id,
        });
      }
      break;
    }
    case 'invoice.paid': {
      await handleInvoicePaid(event);
      break;
    }
    case 'invoice.payment_failed': {
      const invoice = event.data.object as { subscription?: string | { id: string } | null; customer?: string | { id: string } | null };
      const subId = typeof invoice.subscription === 'string' ? invoice.subscription : invoice.subscription?.id;
      if (subId) {
        const sub = await prisma.subscription.findFirst({ where: { stripeSubscriptionId: subId } });
        if (sub && sub.userId) {
          await prisma.subscription.update({
            where: { userId: sub.userId },
            data: { status: 'past_due' },
          }).catch((err) => console.error('[stripe] Failed to mark subscription past_due:', err));
          console.warn(`[stripe] Payment failed for subscription ${subId}, user ${sub.userId}`);
        }
      }
      break;
    }
    case 'charge.refunded': {
      const charge = event.data.object as { invoice?: string | { id: string } | null; customer?: string | { id: string } | null; amount_refunded?: number; amount?: number };
      const invoiceId = typeof charge.invoice === 'string' ? charge.invoice : charge.invoice?.id;
      if (invoiceId) {
        const stripe = getStripe();
        if (stripe) {
          try {
            const invoice = await stripe.invoices.retrieve(invoiceId);
            const invObj = invoice as unknown as { subscription?: string | { id: string } | null };
            const subId = typeof invObj.subscription === 'string' ? invObj.subscription : invObj.subscription?.id;
            if (subId) {
              const sub = await prisma.subscription.findFirst({ where: { stripeSubscriptionId: subId } });
              if (sub && sub.userId) {
                // Only end entitlements when the invoice was FULLY refunded;
                // partial refunds keep the subscription intact.
                const fullyRefunded =
                  typeof charge.amount_refunded === 'number' &&
                  typeof charge.amount === 'number' &&
                  charge.amount_refunded >= charge.amount;
                if (fullyRefunded) {
                  await prisma.subscription.update({
                    where: { userId: sub.userId },
                    data: { status: 'cancelled' },
                  }).catch(() => {});
                }
                // Atomic, clamped deduction — can never go negative and is
                // safe under concurrent spends.
                const deducted = await deductCreditsCapped(
                  sub.userId,
                  10,
                  'refund',
                  `Credits deducted due to Stripe refund (charge ${event.id})`,
                );
                console.warn(`[stripe] Refund processed for invoice ${invoiceId}, user ${sub.userId}, credits deducted: ${deducted}`);
              }
            }
          } catch (err) {
            console.error('[stripe] Error processing refund:', err);
          }
        }
      }
      break;
    }
    case 'customer.subscription.created':
    case 'customer.subscription.updated': {
      const sub = event.data.object as Stripe.Subscription;
      const userId = sub.metadata?.userId;
      const planId = sub.metadata?.planId;
      const periodEnd = sub.items?.data?.[0]?.current_period_end;

      if (userId && planId && isValidPlanId(planId)) {
        await prisma.subscription.upsert({
          where: { userId },
          create: {
            userId,
            plan: planId,
            status: sub.status === 'active' ? 'active' : sub.status,
            stripeSubscriptionId: sub.id,
            stripeCustomerId: typeof sub.customer === 'string' ? sub.customer : sub.customer?.id,
            currentPeriodEnd: periodEnd ? new Date(periodEnd * 1000) : undefined,
            cancelAtPeriodEnd: sub.cancel_at_period_end,
          },
          update: {
            plan: planId,
            status: sub.status === 'active' ? 'active' : sub.status,
            stripeSubscriptionId: sub.id,
            stripeCustomerId: typeof sub.customer === 'string' ? sub.customer : sub.customer?.id,
            currentPeriodEnd: periodEnd ? new Date(periodEnd * 1000) : undefined,
            cancelAtPeriodEnd: sub.cancel_at_period_end,
          },
        }).catch((err) => console.error('Stripe sub upsert failed:', err));
      }
      break;
    }
     case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription;
      const userId = sub.metadata?.userId;
      if (userId) {
        await prisma.subscription.update({
          where: { userId },
          data: { status: 'cancelled' },
        }).catch((err) => console.error('Stripe sub delete failed:', err));
      }
      break;
    }
  }
}
