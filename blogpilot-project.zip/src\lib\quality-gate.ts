/**
 * Pre-Publish Quality Gate.
 *
 * Deterministic, network-free checks that run right before an article is
 * allowed to go live. Blockers must be resolved (or explicitly overridden);
 * warnings are surfaced but don't stop publishing.
 */

import { computeSeoScore } from './seo-score';

export interface GateCheck {
  key: string;
  label: string;
  status: 'pass' | 'warn' | 'fail';
  detail: string;
}

export interface QualityGateInput {
  title: string;
  content: string;
  excerpt?: string | null;
  slug?: string | null;
  targetKeyword?: string | null;
  authorName?: string | null;
  reviewerName?: string | null;
  siteId?: string | null;
}

export interface QualityGateResult {
  passed: boolean;
  score: number; // recomputed on-page SEO score at gate time
  checks: GateCheck[];
  blockers: GateCheck[];
  warnings: GateCheck[];
}

export async function runQualityGate(
  input: QualityGateInput,
  ctx: { userId: string; currentArticleId?: string }
): Promise<QualityGateResult> {
  const content = input.content || '';
  const words = content.trim() ? content.trim().split(/\s+/).length : 0;
  const checks: GateCheck[] = [];

  // ── Content exists ──
  checks.push({
    key: 'has-content',
    label: 'Has content',
    status: words > 0 ? 'pass' : 'fail',
    detail: words > 0 ? `${words.toLocaleString()} words.` : 'Article body is empty.',
  });

  // ── Depth ──
  checks.push({
    key: 'depth',
    label: 'Content depth',
    status: words >= 300 ? 'pass' : words >= 150 ? 'warn' : 'fail',
    detail:
      words >= 300
        ? `${words.toLocaleString()} words is publishable depth.`
        : `${words} words — thin content rarely competes. Target 300+ minimum.`,
  });

  // ── On-page SEO (recomputed live, not trusted from stored field) ──
  const seo = computeSeoScore({
    title: input.title,
    content,
    excerpt: input.excerpt,
    targetKeyword: input.targetKeyword,
  });
  const seoCheck: GateCheck = {
    key: 'seo-score',
    label: 'On-page SEO',
    status: seo.score >= 50 ? 'pass' : seo.score >= 35 ? 'warn' : 'fail',
    detail: `Score ${seo.score}/100. Weakest areas: ${seo.checks
      .filter(c => c.status === 'bad')
      .slice(0, 2)
      .map(c => c.label)
      .join(', ') || 'none'}.`,
  };
  checks.push(seoCheck);

  // ── Meta description ──
  const excerptLen = (input.excerpt || '').trim().length;
  checks.push({
    key: 'meta-description',
    label: 'Meta description',
    status: excerptLen >= 100 ? 'pass' : excerptLen > 0 ? 'warn' : 'warn',
    detail:
      excerptLen > 0
        ? `${excerptLen} chars${excerptLen < 100 ? ' — aim for 120-160 for full SERP display.' : '.'}`
        : 'No meta description/excerpt set.',
  });

  // ── Keyword in title ──
  if (input.targetKeyword) {
    const inTitle = input.title.toLowerCase().includes(input.targetKeyword.toLowerCase());
    checks.push({
      key: 'keyword-title',
      label: 'Target keyword in title',
      status: inTitle ? 'pass' : 'warn',
      detail: inTitle ? 'Present.' : `"${input.targetKeyword}" is missing from the title.`,
    });
  }

  // ── Structure ──
  const h2Count = (content.match(/^##\s+/gm) || []).length;
  checks.push({
    key: 'structure',
    label: 'Heading structure',
    status: h2Count >= 2 ? 'pass' : h2Count === 1 ? 'warn' : 'fail',
    detail: `${h2Count} H2 section(s) found.`,
  });

  // ── Citations / sources ──
  const externalLinks = (content.match(/\]\(https?:\/\/[^)]+\)/g) || []).length;
  const hasSourcesSection = /^##?\s*(sources|references|citations)/im.test(content);
  checks.push({
    key: 'sources',
    label: 'Sources & citations',
    status: externalLinks >= 2 || hasSourcesSection ? 'pass' : externalLinks === 1 ? 'warn' : 'warn',
    detail:
      externalLinks === 0 && !hasSourcesSection
        ? 'No external citations or Sources section — claims are unbacked.'
        : `${externalLinks} external link(s)${hasSourcesSection ? ', Sources section present' : ''}.`,
  });

  // ── Internal links ──
  const internalLinks = (content.match(/\]\((\/[^)]*|#)[^)]*\)/g) || []).length +
    // absolute links to the target site also count when we know the domain later
    (content.match(/\]\((https?:\/\/[^)]+)\)/g) || []).length - externalLinks;
  checks.push({
    key: 'internal-links',
    label: 'Internal links',
    status: internalLinks >= 1 ? 'pass' : 'warn',
    detail: internalLinks >= 1 ? `${Math.max(internalLinks, 0)} internal link(s).` : 'No internal links found — try the Internal Links tool.',
  });

  // ── E-E-A-T attribution ──
  checks.push({
    key: 'author',
    label: 'Author attribution',
    status: (input.authorName || '').trim() ? 'pass' : 'warn',
    detail: (input.authorName || '').trim()
      ? `Author: ${input.authorName}${input.reviewerName ? `, reviewed by ${input.reviewerName}` : ''}.`
      : 'No author set — authorship strengthens trust signals.',
  });

  // ── Cannibalization: same keyword already published on this site ──
  if (input.targetKeyword && input.siteId) {
    const { default: prisma } = await import('@/lib/prisma');
    const normalized = input.targetKeyword.toLowerCase().trim();
    const siblings = await prisma.article.findMany({
      where: {
        userId: ctx.userId,
        siteId: input.siteId,
        status: 'PUBLISHED',
        ...(ctx.currentArticleId ? { id: { not: ctx.currentArticleId } } : {}),
      },
      select: { id: true, title: true, targetKeyword: true },
      take: 200,
    });
    const clash = siblings.find(
      s => s.targetKeyword && s.targetKeyword.toLowerCase().trim() === normalized
    );
    checks.push({
      key: 'cannibalization',
      label: 'Keyword overlap check',
      status: clash ? 'warn' : 'pass',
      detail: clash
        ? `"${clash.title}" is already published targeting "${normalized}" — consider merging or re-targeting.`
        : 'No published article targets the same keyword on this site.',
    });
  }

  const blockers = checks.filter(c => c.status === 'fail');
  const warnings = checks.filter(c => c.status === 'warn');

  return {
    passed: blockers.length === 0,
    score: seo.score,
    checks,
    blockers,
    warnings,
  };
}
