'use client';

import React, { useCallback, useState } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Search,
  Loader2,
  AlertTriangle,
  Check,
  X,
  ExternalLink,
  Type,
  FileText,
  Globe,
  RotateCcw,
} from 'lucide-react';

interface PageData {
  url: string;
  status: number;
  title?: string;
  metaDescription?: string;
  h1?: string[];
  h2?: string[];
  h3?: string[];
  wordCount?: number;
  textSnippet?: string;
}

interface TitleAnalysis {
  title: string;
  length: number;
  pixelWidth: number;
  hasKeyword: boolean;
  keywordInFront: boolean;
  hasBrand: boolean;
  issues: string[];
  suggestions: string[];
}

interface MetaAnalysis {
  description: string;
  length: number;
  hasKeyword: boolean;
  issues: string[];
  suggestions: string[];
}

const BRAND_NAME = 'BlogPilot AI';

function analyzeTitle(title: string, targetKeyword?: string): TitleAnalysis {
  const length = title.length;
  const pixelWidth = estimatePixelWidth(title);
  const hasKeyword = targetKeyword ? title.toLowerCase().includes(targetKeyword.toLowerCase()) : false;
  const keywordInFront = targetKeyword ? title.toLowerCase().indexOf(targetKeyword.toLowerCase()) < title.length / 2 : false;
  const hasBrand = title.includes(BRAND_NAME);
  const issues: string[] = [];
  const suggestions: string[] = [];

  if (length === 0) {
    issues.push('No title tag found');
    suggestions.push('Add a descriptive title tag to every page');
  } else {
    if (length < 30) issues.push('Title is too short');
    if (length > 60) issues.push('Title may be truncated in search results');
    if (pixelWidth > 580) issues.push('Title may be visually truncated (exceeds pixel width)');
    if (!hasKeyword && targetKeyword) {
      issues.push('Target keyword not found in title');
      suggestions.push(`Include "${targetKeyword}" in the title`);
    }
    if (hasKeyword && !keywordInFront) {
      suggestions.push('Consider moving the keyword closer to the beginning of the title');
    }
    if (!hasBrand) {
      suggestions.push(`Consider adding "| ${BRAND_NAME}" for brand recognition`);
    }
    if (title === title.toUpperCase()) {
      issues.push('Title is in ALL CAPS');
    }
    if (!/[A-Z]/.test(title[0])) {
      suggestions.push('Capitalize the first letter of the title');
    }
    if (length >= 55 && length <= 60) {
      suggestions.push('Title length is good — within the ideal range');
    }
  }
  return { title, length, pixelWidth, hasKeyword, keywordInFront, hasBrand, issues, suggestions };
}

function analyzeMeta(description: string, targetKeyword?: string): MetaAnalysis {
  const length = description.length;
  const hasKeyword = targetKeyword ? description.toLowerCase().includes(targetKeyword.toLowerCase()) : false;
  const issues: string[] = [];
  const suggestions: string[] = [];

  if (length === 0) {
    issues.push('No meta description found');
    suggestions.push('Write a compelling meta description to improve click-through rates');
  } else {
    if (length < 70) issues.push('Meta description is too short');
    if (length > 160) issues.push('Meta description may be truncated in search results');
    if (length >= 120 && length <= 155) suggestions.push('Meta description length is ideal');
    if (!hasKeyword && targetKeyword) {
      issues.push('Target keyword not found in meta description');
      suggestions.push(`Include "${targetKeyword}" naturally in the description`);
    }
  }
  return { description, length, hasKeyword, issues, suggestions };
}

function estimatePixelWidth(text: string): number {
  let width = 0;
  for (const char of text) {
    if ('mwMW'.includes(char)) width += 12;
    else if ('ilItj.,:;!|'.includes(char)) width += 5;
    else if ('@'.includes(char)) width += 14;
    else if (char === char.toUpperCase() && /[A-Z]/.test(char)) width += 10;
    else width += 8;
  }
  return width;
}

function ScoreBadge({ score, label }: { score: number; label: string }) {
  const color = score >= 80 ? 'text-emerald-400' : score >= 50 ? 'text-amber-400' : 'text-rose-400';
  const bg = score >= 80 ? 'bg-emerald-400/10' : score >= 50 ? 'bg-amber-400/10' : 'bg-rose-400/10';
  return (
    <div className={`flex items-center gap-3 rounded-xl ${bg} px-4 py-3`}>
      <span className={`text-2xl font-bold ${color}`}>{score}</span>
      <div>
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <p className={`text-xs font-medium ${color}`}>
          {score >= 80 ? 'Good' : score >= 50 ? 'Needs improvement' : 'Critical issues'}
        </p>
      </div>
    </div>
  );
}

function IssueList({ items, type }: { items: string[]; type: 'issue' | 'suggestion' }) {
  if (items.length === 0) return null;
  return (
    <ul className="space-y-1.5">
      {items.map((item, i) => (
        <li key={i} className="flex items-start gap-2 text-sm">
          {type === 'issue' ? (
            <X className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-400" />
          ) : (
            <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
          )}
          <span className="text-muted-foreground">{item}</span>
        </li>
      ))}
    </ul>
  );
}

export default function SeoTitleAnalyzerPage() {
  const [url, setUrl] = useState('');
  const [keyword, setKeyword] = useState('');
  const [loading, setLoading] = useState(false);
  const [pageData, setPageData] = useState<PageData | null>(null);
  const [titleAnalysis, setTitleAnalysis] = useState<TitleAnalysis | null>(null);
  const [metaAnalysis, setMetaAnalysis] = useState<MetaAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setError(null);
    setPageData(null);
    setTitleAnalysis(null);
    setMetaAnalysis(null);

    if (!url.trim()) {
      setError('Enter a URL to analyze.');
      return;
    }

    let normalizedUrl = url.trim();
    if (!normalizedUrl.startsWith('http://') && !normalizedUrl.startsWith('https://')) {
      normalizedUrl = 'https://' + normalizedUrl;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/free-tools/page-analyzer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: normalizedUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Failed to analyze the page.');
        return;
      }
      const snapshot: PageData = data.snapshot;
      setPageData(snapshot);
      setTitleAnalysis(analyzeTitle(snapshot.title || '', keyword || undefined));
      setMetaAnalysis(analyzeMeta(snapshot.metaDescription || '', keyword || undefined));
    } catch (err: any) {
      setError(err?.message || 'Network error. Check the URL and try again.');
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setUrl('');
    setKeyword('');
    setPageData(null);
    setTitleAnalysis(null);
    setMetaAnalysis(null);
    setError(null);
  }

  const titleScore = titleAnalysis ? Math.max(0, 100 - titleAnalysis.issues.length * 20 - (titleAnalysis.length === 0 ? 50 : 0)) : 0;
  const metaScore = metaAnalysis ? Math.max(0, 100 - metaAnalysis.issues.length * 25 - (metaAnalysis.length === 0 ? 50 : 0)) : 0;
  const overallScore = Math.round((titleScore + metaScore) / 2);

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            SEO Title & <span className="text-gradient">Meta Analyzer</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Enter any URL to analyze its title tag, meta description, and heading structure.
            Get actionable optimization tips to improve your search rankings.
          </p>
        </section>

        {/* Input */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <Globe className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  aria-label="Page URL"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com/your-page"
                  className="w-full rounded-xl border border-border bg-muted/50 py-3 pl-11 pr-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                {loading ? 'Analyzing…' : 'Analyze Page'}
              </button>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="relative flex-1 sm:max-w-xs">
                <input
                  type="text"
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  placeholder="Target keyword (optional)"
                  className="w-full rounded-xl border border-border bg-muted/50 py-2.5 px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                />
              </div>
              {pageData && (
                <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                  <RotateCcw className="h-3.5 w-3.5" />
                  New analysis
                </button>
              )}
            </div>
          </form>
          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </section>

        {/* Loading */}
        {loading && !pageData && (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="shimmer h-28 rounded-2xl border border-border bg-card/50" />
            ))}
          </div>
        )}

        {/* Results */}
        {pageData && titleAnalysis && metaAnalysis && (
          <div className="space-y-6">
            {/* Score Overview */}
            <section className="grid gap-4 sm:grid-cols-3">
              <ScoreBadge score={overallScore} label="Overall Score" />
              <ScoreBadge score={titleScore} label="Title Score" />
              <ScoreBadge score={metaScore} label="Meta Description Score" />
            </section>

            {/* Page Info */}
            <section className="rounded-2xl border border-border bg-card/50 p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Analyzed Page</p>
                  <a href={pageData.url} target="_blank" rel="noreferrer" className="mt-1 inline-flex items-center gap-1.5 text-sm font-medium text-foreground hover:underline">
                    {new URL(pageData.url).hostname}
                    <ExternalLink className="h-3.5 w-3.5 text-muted-foreground" />
                  </a>
                </div>
                <span className="rounded-full bg-muted/50 px-2.5 py-0.5 text-xs text-muted-foreground">
                  {pageData.wordCount?.toLocaleString() || '—'} words
                </span>
              </div>
            </section>

            {/* Title Analysis */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center gap-3">
                <Type className="h-5 w-5 text-cyan-300" />
                <h2 className="text-lg font-semibold text-foreground">Title Tag Analysis</h2>
              </div>
              <div className="mt-4 rounded-xl border border-border bg-card/30 p-4">
                <p className="text-foreground font-medium">{titleAnalysis.title || '(no title)'}</p>
                <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
                  <span>{titleAnalysis.length} chars</span>
                  <span>~{titleAnalysis.pixelWidth}px</span>
                  <span className={titleAnalysis.length >= 30 && titleAnalysis.length <= 60 ? 'text-emerald-400' : 'text-amber-400'}>
                    {titleAnalysis.length >= 30 && titleAnalysis.length <= 60 ? 'Ideal length' : 'Suboptimal length'}
                  </span>
                  {keyword && (
                    <span className={titleAnalysis.hasKeyword ? 'text-emerald-400' : 'text-rose-400'}>
                      Keyword {titleAnalysis.hasKeyword ? 'present' : 'missing'}
                    </span>
                  )}
                </div>
              </div>
              {titleAnalysis.issues.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Issues</p>
                  <div className="mt-2">
                    <IssueList items={titleAnalysis.issues} type="issue" />
                  </div>
                </div>
              )}
              {titleAnalysis.suggestions.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Suggestions</p>
                  <div className="mt-2">
                    <IssueList items={titleAnalysis.suggestions} type="suggestion" />
                  </div>
                </div>
              )}
            </section>

            {/* Meta Description Analysis */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center gap-3">
                <FileText className="h-5 w-5 text-violet-300" />
                <h2 className="text-lg font-semibold text-foreground">Meta Description Analysis</h2>
              </div>
              <div className="mt-4 rounded-xl border border-border bg-card/30 p-4">
                <p className="text-sm text-foreground">{metaAnalysis.description || '(no meta description)'}</p>
                <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
                  <span>{metaAnalysis.length} chars</span>
                  <span className={metaAnalysis.length >= 120 && metaAnalysis.length <= 155 ? 'text-emerald-400' : 'text-amber-400'}>
                    {metaAnalysis.length >= 120 && metaAnalysis.length <= 155 ? 'Ideal length' : 'Suboptimal length'}
                  </span>
                  {keyword && (
                    <span className={metaAnalysis.hasKeyword ? 'text-emerald-400' : 'text-rose-400'}>
                      Keyword {metaAnalysis.hasKeyword ? 'present' : 'missing'}
                    </span>
                  )}
                </div>
              </div>
              {metaAnalysis.issues.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Issues</p>
                  <div className="mt-2">
                    <IssueList items={metaAnalysis.issues} type="issue" />
                  </div>
                </div>
              )}
              {metaAnalysis.suggestions.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Suggestions</p>
                  <div className="mt-2">
                    <IssueList items={metaAnalysis.suggestions} type="suggestion" />
                  </div>
                </div>
              )}
            </section>

            {/* Heading Structure Preview */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Page Headings</p>
              <div className="mt-3 space-y-1">
                {(pageData.h1 || []).map((h, i) => (
                  <p key={`h1-${i}`} className="text-sm font-semibold text-foreground pl-0">H1: {h}</p>
                ))}
                {(pageData.h2 || []).slice(0, 8).map((h, i) => (
                  <p key={`h2-${i}`} className="text-sm text-muted-foreground pl-4">H2: {h}</p>
                ))}
                {(pageData.h3 || []).slice(0, 6).map((h, i) => (
                  <p key={`h3-${i}`} className="text-sm text-muted-foreground pl-8">H3: {h}</p>
                ))}
                {(!pageData.h1?.length && !pageData.h2?.length) && (
                  <p className="text-sm text-muted-foreground">No headings found.</p>
                )}
              </div>
              <div className="mt-4">
                <a
                  href={`/free-tools/heading-structure-analyzer?url=${encodeURIComponent(url)}`}
                  className="inline-flex items-center gap-1.5 text-sm text-cyan-400 hover:text-cyan-300"
                >
                  Full heading structure analysis →
                </a>
              </div>
            </section>

            {/* Next Steps */}
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <p className="text-xs font-medium uppercase tracking-wider text-cyan-400">Next Steps</p>
              <div className="mt-3 space-y-2">
                <a href="/free-tools/content-opportunity-analyzer" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Run a full Content Opportunity Analysis for this topic
                </a>
                <a href="/free-tools/heading-structure-analyzer" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Check the full heading structure with the Heading Analyzer
                </a>
                <a href="/free-tools/internal-link-finder" className="block text-sm text-muted-foreground hover:text-foreground">
                  → Find internal linking opportunities for this content
                </a>
              </div>
            </section>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
