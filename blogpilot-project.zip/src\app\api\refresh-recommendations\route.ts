import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { computeRefreshRecommendations } from '@/lib/refresh-agent';

const querySchema = z.object({
  siteId: z.string().min(1).max(64),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters' }, { status: 400 });
  }

  const limit = await checkRateLimit(`refresh:${userId}`, { windowMs: 60_000, maxRequests: 6 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  try {
    const result = await computeRefreshRecommendations(userId, parsed.data.siteId);
    return NextResponse.json({
      ok: true,
      data: {
        propertyUrl: result.propertyUrl,
        recommendations: result.recommendations,
        generatedAt: new Date().toISOString(),
      },
    });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 502;
    return NextResponse.json(
      { ok: false, error: error?.message || 'Refresh analysis failed', code: status === 409 ? 'gsc_required' : undefined },
      { status },
    );
  }
}
