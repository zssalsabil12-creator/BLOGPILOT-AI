/**
 * Agent governance: audit log + guardrails.
 *
 * Every autonomous action is recorded in AgentActivity. Actions classified as
 * requiring approval are stored with status 'pending_approval' and a payload
 * describing exactly what will run when approved — nothing executes until a
 * human approves via the Approval Queue.
 */

import prisma from '@/lib/prisma';
import { randomUUID } from 'node:crypto';

export type AgentName = 'seo' | 'affiliate' | 'content' | 'system';

export interface LogActivityInput {
  userId: string;
  siteId?: string | null;
  executionId?: string;
  agent: AgentName;
  action: string;
  targetType?: string;
  targetId?: string;
  targetLabel?: string;
  reason?: string;
  beforeState?: unknown;
  afterState?: unknown;
  status?: 'success' | 'failed' | 'pending_approval' | 'rejected';
  payload?: unknown;
  error?: string;
}

export function newExecutionId(): string {
  return randomUUID();
}

export async function logActivity(input: LogActivityInput): Promise<string> {
  const executionId = input.executionId || newExecutionId();
  try {
    await prisma.agentActivity.create({
      data: {
        userId: input.userId,
        siteId: input.siteId || null,
        executionId,
        agent: input.agent,
        action: input.action,
        targetType: input.targetType,
        targetId: input.targetId,
        targetLabel: input.targetLabel?.slice(0, 300),
        reason: input.reason?.slice(0, 500),
        beforeState: input.beforeState === undefined ? undefined : (input.beforeState as any),
        afterState: input.afterState === undefined ? undefined : (input.afterState as any),
        status: input.status || 'success',
        payload: input.payload === undefined ? undefined : (input.payload as any),
        error: input.error?.slice(0, 500),
      },
    });
  } catch (err: any) {
    // Auditing must never break the user flow; surface in server logs.
    console.error('[audit] failed to record activity:', err?.message || err);
  }
  return executionId;
}

// ── Guardrails ──

export type ActionKey = 'internalLinks' | 'brokenAffiliates' | 'metadata';

/** Actions that can NEVER be automated, regardless of policy/level. */
export const HUMAN_ONLY_ACTIONS = new Set([
  'publish-article',
  'delete-article',
  'change-canonical',
  'merge-pages',
  'create-redirect',
  'major-content-rewrite',
  'change-affiliate-destination',
  'change-site-settings',
]);

export interface SitePolicy {
  level: 'assist' | 'review' | 'autopilot';
  permissions?: {
    internalLinks?: 'auto' | 'ask';
    brokenAffiliates?: 'auto' | 'ask';
    metadata?: 'auto' | 'ask';
  } | null;
}

export type Decision = 'auto' | 'ask' | 'skip';

/**
 * Decide whether an action runs automatically for this site.
 *
 * assist            → everything is skip (report only)
 * review (default)  → ask unless permission explicitly says auto
 * autopilot         → auto unless permission explicitly says ask
 */
export function decideAction(action: ActionKey, policy: SitePolicy): Decision {
  if (policy.level === 'assist') return 'skip';

  const override = policy.permissions?.[action];
  if (override === 'ask') return 'ask';
  if (override === 'auto') return 'auto';

  if (policy.level === 'autopilot') return 'auto';
  return 'ask'; // review default
}

/** Queue an action for human approval instead of executing it now. */
export async function queueForApproval(input: {
  userId: string;
  siteId?: string | null;
  executionId: string;
  agent: AgentName;
  action: string;
  targetLabel: string;
  reason: string;
  payload: Record<string, unknown>;
}): Promise<string> {
  await prisma.agentActivity.create({
    data: {
      userId: input.userId,
      siteId: input.siteId || null,
      executionId: input.executionId,
      agent: input.agent,
      action: input.action,
      targetType: 'queued-action',
      targetLabel: input.targetLabel.slice(0, 300),
      reason: input.reason.slice(0, 500),
      status: 'pending_approval',
      payload: input.payload as any,
    },
  });
  return input.executionId;
}
