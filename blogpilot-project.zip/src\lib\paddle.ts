import crypto from 'crypto';
import prisma from '@/lib/prisma';
import { APP_URL } from '@/lib/env';
import {
  getPlanConfig,
  getPaddlePriceId,
  getPlanByPaddlePriceId,
  activatePlan,
  isValidPlanId,
} from '@/lib/billing';
import { claimEvent, releaseEvent, deductCreditsCapped } from '@/lib/credits';

/**
 * Paddle Billing integration (card payments — Visa/Mastercard).
 *
 * Live flow:
 *   1. POST /api/paddle/checkout (authenticated) creates a Paddle transaction
 *      bound to the plan's configured Price ID with server-side custom_data.
 *   2. The user completes payment on Paddle-hosted checkout.
 *   3. Paddle delivers `transaction.completed` webhooks; each successful
 *      payment grants exactly one allocation of plan credits, keyed
 *      idempotently on the Paddle transaction ID.
 *
 * All trust anchors are server-side: the price → plan mapping comes from env
 * configuration and userId/planId come from OUR checkout-created
 * custom_data — never from client-controlled input.
 */

const API_BASES = {
  live: 'https://api.paddle.com',
  sandbox: 'https://sandbox-api.paddle.com',
} as const;

export function getPaddleEnv(): 'live' | 'sandbox' {
  const explicit = process.env.PADDLE_ENV;
  if (explicit === 'sandbox' || explicit === 'live') return explicit;
  // Infer from key prefix when possible (pdl_live_* / pdl_sdbx_*).
  return process.env.PADDLE_API_KEY?.startsWith('pdl_sdbx_') ? 'sandbox' : 'live';
}

export function isPaddleConfigured(): boolean {
  return !!process.env.PADDLE_API_KEY;
}

function isWebhookSecretConfigured(): boolean {
  return !!process.env.PADDLE_WEBHOOK_SECRET;
}

async function paddleApi<T = any>(
  method: string,
  path: string,
  body?: unknown,
): Promise<{ ok: boolean; status: number; data?: T; error?: string }> {
  const key = process.env.PADDLE_API_KEY;
  if (!key) return { ok: false, status: 0, error: 'PADDLE_API_KEY is not configured' };
  try {
    const res = await fetch(`${API_BASES[getPaddleEnv()]}${path}`, {
      method,
      headers: {
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
      },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      signal: AbortSignal.timeout(20_000),
    });
    const json = await res.json().catch(() => null);
    if (!res.ok) {
      // Log only the top-level error code/message — never auth material.
      const msg = json?.error?.detail || json?.error?.code || `HTTP ${res.status}`;
      console.warn(`[paddle] API ${method} ${path} failed: ${msg}`);
      return { ok: false, status: res.status, error: msg };
    }
    return { ok: true, status: res.status, data: json?.data };
  } catch (err: any) {
    console.error('[paddle] API request error:', err?.message || err);
    return { ok: false, status: 0, error: String(err?.message || err) };
  }
}

/**
 * Creates a Paddle-hosted checkout for a plan subscription.
 * Returns the hosted checkout URL, or null when unconfigured / on failure.
 */
export async function createPaddleCheckout(params: {
  userId: string;
  email?: string | null;
  planId: string;
}): Promise<string | null> {
  if (!isPaddleConfigured()) return null;

  const plan = getPlanConfig(params.planId);
  const priceId = getPaddlePriceId(plan);
  if (!priceId) {
    throw new Error(
      `No Paddle price configured for the ${plan.name} plan. Set PADDLE_PRICE_ID_${plan.id.toUpperCase()} in your environment.`,
    );
  }

  // `custom_data` is created server-side here and travels through Paddle
  // untouched; it is the trusted source for user/plan attribution in webhooks.
  const { ok, data, error } = await paddleApi('POST', '/transactions', {
    items: [{ price_id: priceId, quantity: 1 }],
    customer_email: params.email || undefined,
    custom_data: { userId: params.userId, planId: plan.id },
    currency_code: 'USD',
    collection_mode: 'automatic',
    checkout: { url: `${APP_URL}/dashboard?tab=billing&payment=success` },
  });

  if (!ok || !data) {
    throw new Error(error || 'Paddle transaction creation failed');
  }

  const url: string | undefined = data?.checkout?.url;
  if (!url) {
    console.error('[paddle] Transaction created but no checkout URL returned');
    return null;
  }
  return url;
}

/**
 * Verifies a Paddle webhook request against its `Paddle-Signature` header.
 * Format: "ts=<unix>;h1=<hex hmac-sha256>" over "<ts>:<rawBody>".
 */
export function verifyPaddleWebhook(body: string | Buffer, signatureHeader: string): PaddleEvent | null {
  const secret = process.env.PADDLE_WEBHOOK_SECRET;
  if (!secret) return null;

  const parts = Object.fromEntries(
    signatureHeader.split(';').map((kv) => kv.split('=') as [string, string]),
  );
  const ts = parts['ts'];
  const h1 = parts['h1'];
  if (!ts || !h1) return null;

  // Replay window: reject stamped signatures older than 5 seconds beyond
  // Paddle's own guidance to tolerate clock skew while bounding replays.
  const tsMs = Number(ts) * 1000;
  if (!Number.isFinite(tsMs) || Math.abs(Date.now() - tsMs) > 15_000) return null;

  const expected = crypto
    .createHmac('sha256', secret)
    .update(`${ts}:${typeof body === 'string' ? body : body.toString('utf8')}`)
    .digest('hex');

  const a = Buffer.from(expected, 'utf8');
  const b = Buffer.from(h1, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  try {
    return JSON.parse(typeof body === 'string' ? body : body.toString('utf8')) as PaddleEvent;
  } catch {
    return null;
  }
}

export interface PaddleEvent {
  event_id?: string;
  event_type?: string;
  occurred_at?: string;
  data?: any;
}

export async function handlePaddleEvent(event: PaddleEvent): Promise<void> {
  // Exactly-once arbitration identical to the Stripe flow: unique constraint
  // on ProcessedEvent.eventId; concurrent/replayed deliveries see claimed=false.
  const eventId = event.event_id || `${event.event_type}:${event.occurred_at}`;
  const claimed = await claimEvent(eventId, event.event_type || 'unknown');
  if (!claimed) return;

  try {
    await processPaddleEvent(event);
  } catch (err) {
    await releaseEvent(eventId);
    throw err;
  }
}

/** Resolves the owning user for a Paddle subscription id. */
async function resolvePaddleSubscription(subId: string): Promise<{ userId: string | null; planId: string | null }> {
  const local = await prisma.subscription.findFirst({ where: { paddleSubscriptionId: subId } });
  return local?.userId
    ? { userId: local.userId, planId: isValidPlanId(local.plan) ? local.plan : null }
    : { userId: null, planId: null };
}

async function processPaddleEvent(event: PaddleEvent): Promise<void> {
  switch (event.event_type) {
    case 'transaction.completed':
    case 'transaction.paid': {
      const tx = event.data as {
        id?: string;
        subscription_id?: string;
        customer_id?: string;
        custom_data?: { userId?: string; planId?: string };
        details?: { line_items?: Array<{ price?: { id?: string } }> };
      };

      const txId = tx?.id;
      if (!txId) break;

      // Plan resolution order (most trustworthy first):
      // 1. Server-configured Price ID mapping (env).
      // 2. custom_data.planId set by OUR checkout creation code.
      let planId: string | null = null;
      const linePriceId = tx.details?.line_items?.[0]?.price?.id;
      if (linePriceId) planId = getPlanByPaddlePriceId(linePriceId);
      if (!planId && tx.custom_data?.planId && isValidPlanId(tx.custom_data.planId)) {
        planId = tx.custom_data.planId;
      }

      // User resolution: custom_data first, then our local subscription row.
      let userId: string | null = tx.custom_data?.userId || null;
      if (!userId && tx.subscription_id) {
        ({ userId } = await resolvePaddleSubscription(tx.subscription_id));
      }

      if (!userId || !planId || !isValidPlanId(planId)) {
        console.warn(`[paddle] ${event.event_type} ${txId}: could not resolve user/plan`);
        break;
      }

      // One grant per completed payment. The idempotency key is scoped to the
      // Paddle transaction ID: initial subscriptions AND monthly renewals each
      // emit exactly one transaction.completed, so this yields one fresh
      // allocation per billing period with no double-grant on retries.
      await activatePlan(userId, planId, {
        source: 'paddle',
        description: `Paddle billing period: ${getPlanConfig(planId).name} plan`,
        idempotencyKey: `paddle:tx:${txId}`,
        forceGrant: true,
      });

      // Persist provider identifiers as soon as we learn them so later
      // webhooks resolve the user even when events arrive out of order.
      if (tx.subscription_id) {
        await prisma.subscription.updateMany({
          where: { userId },
          data: {
            paddleSubscriptionId: tx.subscription_id,
            ...(typeof tx.customer_id === 'string' && tx.customer_id ? { paddleCustomerId: tx.customer_id } : {}),
          },
        }).catch((err) => console.error('[paddle] subscription id backfill failed:', err));
      }
      break;
    }

    case 'subscription.created':
    case 'subscription.updated': {
      const sub = event.data as {
        id?: string;
        status?: string;
        customer_id?: string;
        next_billed_at?: string;
        custom_data?: { userId?: string; planId?: string };
        items?: Array<{ price?: { id?: string } }>;
      };
      if (!sub?.id) break;

      let userId = sub.custom_data?.userId || null;
      let planId =
        sub.custom_data?.planId && isValidPlanId(sub.custom_data.planId)
          ? sub.custom_data.planId
          : null;
      if (!userId) ({ userId } = await resolvePaddleSubscription(sub.id));

      if (!userId) break;

      const periodEnd = sub.next_billed_at ? new Date(sub.next_billed_at) : undefined;
      const status = sub.status === 'active' || sub.status === 'trialing' ? 'active' : sub.status;

      await prisma.subscription.upsert({
        where: { userId },
        create: {
          userId,
          plan: planId && isValidPlanId(planId) ? planId : 'free',
          status,
          paddleSubscriptionId: sub.id,
          paddleCustomerId: sub.customer_id,
          currentPeriodEnd: periodEnd,
        },
        update: {
          ...(planId && isValidPlanId(planId) ? { plan: planId } : {}),
          status,
          paddleSubscriptionId: sub.id,
          ...(sub.customer_id ? { paddleCustomerId: sub.customer_id } : {}),
          ...(periodEnd ? { currentPeriodEnd: periodEnd } : {}),
          cancelAtPeriodEnd: false,
        },
      }).catch((err) => console.error('[paddle] subscription upsert failed:', err));
      break;
    }

    case 'subscription.canceled':
    case 'subscription.cancelled': {
      const sub = event.data as { id?: string; custom_data?: { userId?: string } };
      let userId = sub?.custom_data?.userId || null;
      if (!userId && sub?.id) ({ userId } = await resolvePaddleSubscription(sub.id));
      if (userId) {
        await prisma.subscription.updateMany({
          where: { userId },
          data: { status: 'cancelled', cancelAtPeriodEnd: true },
        }).catch((err) => console.error('[paddle] cancel update failed:', err));
      }
      break;
    }

    case 'adjustment.created':
    case 'adjustment.updated': {
      // Refunds / chargebacks. Mirror of the Stripe refund semantics:
      // end entitlements on approval and claw back credits atomically
      // (clamped at zero so concurrent spends can never drive negative).
      const adj = event.data as {
        id?: string;
        action?: string;
        status?: string;
        transaction_id?: string;
      };
      if (!adj?.transaction_id) break;
      const isRefund = adj.action === 'refund' || adj.action === 'chargeback';
      const approved = adj.status === 'approved' || adj.status === 'reversed';
      if (!isRefund || !approved) break;

      const txn = await paddleApi<any>('GET', `/transactions/${adj.transaction_id}`);
      const subId: string | undefined = txn.data?.subscription_id;
      const customUserId: string | undefined = txn.data?.custom_data?.userId;

      let userId: string | null = customUserId || null;
      if (!userId && subId) ({ userId } = await resolvePaddleSubscription(subId));
      if (!userId) break;

      if (isRefund) {
        await prisma.subscription.updateMany({
          where: { userId },
          data: { status: 'cancelled' },
        }).catch(() => {});
      }
      const deducted = await deductCreditsCapped(
        userId,
        10,
        'refund',
        `Credits deducted due to Paddle refund (adjustment ${adj.id})`,
      );
      console.warn(`[paddle] Refund processed for adjustment ${adj.id}, user ${userId}, credits deducted: ${deducted}`);
      break;
    }
  }
}
