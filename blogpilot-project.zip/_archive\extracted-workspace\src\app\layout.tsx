import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { Toaster } from "@/components/ui/sonner";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "BlogPilot AI — Free SEO Content Research",
  description: "The smarter way to research keywords, analyze competitors, and build SEO-friendly articles with AI.",
  metadataBase: new URL("https://blogpilot.ai"),
  openGraph: {
    title: "BlogPilot AI — Free SEO Content Research",
    description: "The smarter way to research keywords, analyze competitors, and build SEO-friendly articles with AI.",
    type: "website",
    url: "https://blogpilot.ai",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} antialiased bg-slate-950 text-slate-100 transition-colors duration-200`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          themes={["light", "dark"]}
          disableTransitionOnChange
        >
          <div className="min-h-screen bg-background text-foreground transition-colors duration-200">
            <header className="border-b border-slate-800/80 bg-slate-950/90 backdrop-blur">
              <div className="mx-auto flex flex-wrap items-center justify-between gap-4 px-4 py-4 max-w-7xl">
                <a href="/" className="text-xl font-semibold tracking-tight text-white">
                  BlogPilot AI
                </a>
                <nav className="flex flex-wrap items-center gap-4 text-sm text-slate-300">
                  <a href="/free-tools" className="transition hover:text-white">
                    Free Tools
                  </a>
                  <a href="/dashboard/generate" className="transition hover:text-white">
                    Generate Article
                  </a>
                  <a href="/dashboard/link-library" className="transition hover:text-white">
                    Link Library
                  </a>
                </nav>
                <div className="flex items-center gap-3">
                  <ThemeToggle />
                  <a
                    href="/dashboard/generate"
                    className="inline-flex items-center justify-center rounded-full bg-cyan-500 px-5 py-2.5 text-sm font-semibold text-slate-950 transition hover:bg-cyan-400"
                  >
                    Start Article Builder
                  </a>
                </div>
              </div>
            </header>
            <main className="mx-auto w-full max-w-7xl px-4 py-8">
              {children}
            </main>
            <Toaster />
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}
