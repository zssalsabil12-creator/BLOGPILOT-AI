'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { ThemeToggle } from '@/components/theme-toggle'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  Sparkles,
  Search,
  DollarSign,
  Zap,
  ArrowRight,
  Check,
  Bot,
  FileText,
  Link2,
  BarChart3,
  Globe,
  Shield,
  Clock,
  Target,
  TrendingUp,
  Wrench,
  Star,
  Quote,
  Menu,
  X,
  Rocket,
  Gauge,
  PenTool,
  Network,
  CircleCheck,
  ArrowUpRight,
  Cpu,
} from 'lucide-react'
import { ALL_TOOLS } from '@/lib/free-tools/tool-registry'

const fadeInUp = {
  initial: { opacity: 0, y: 24 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const },
}

const stagger = {
  whileInView: { transition: { staggerChildren: 0.09 } },
  viewport: { once: true, margin: '-80px' },
}

function SectionHeading({
  badge,
  title,
  subtitle,
}: {
  badge: string
  title: React.ReactNode
  subtitle?: string
}) {
  return (
    <motion.div className="mx-auto max-w-2xl text-center" {...fadeInUp}>
      <Badge
        variant="secondary"
        className="glass mb-5 px-3.5 py-1.5 text-xs font-medium text-primary uppercase tracking-widest"
      >
        {badge}
      </Badge>
      <h2 className="text-3xl font-bold tracking-tight text-balance md:text-5xl">{title}</h2>
      {subtitle && (
        <p className="mt-5 text-base text-muted-foreground md:text-lg text-pretty">{subtitle}</p>
      )}
    </motion.div>
  )
}

function DashboardMockup() {
  return (
    <div className="relative mx-auto mt-16 max-w-4xl md:mt-24">
      {/* Glow behind */}
      <div className="absolute -inset-8 rounded-[40px] bg-gradient-to-r from-cyan-500/20 via-violet-500/20 to-fuchsia-500/20 blur-3xl animate-pulse-glow" />

      {/* Main mockup */}
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
        className="glass-strong relative rounded-2xl border border-border shadow-2xl shadow-black/40"
      >
        {/* Window chrome */}
        <div className="flex items-center gap-2 border-b border-border px-4 py-3">
          <div className="flex gap-1.5">
            <span className="h-3 w-3 rounded-full bg-rose-500/80" />
            <span className="h-3 w-3 rounded-full bg-amber-400/80" />
            <span className="h-3 w-3 rounded-full bg-emerald-400/80" />
          </div>
          <div className="mx-auto flex items-center gap-2 rounded-full bg-accent px-4 py-1 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            app.blogpilot.ai/generate
          </div>
          <span className="text-xs text-muted-foreground">⌘K</span>
        </div>

        <div className="grid grid-cols-1 gap-0 md:grid-cols-[220px_1fr]">
          {/* Sidebar */}
          <div className="hidden border-r border-border p-4 md:block">
            <div className="flex items-center gap-2 px-2 py-1.5">
              <div className="flex h-6 w-6 items-center justify-center rounded-md bg-gradient-to-r from-cyan-400 to-violet-500">
                <Sparkles className="h-3.5 w-3.5 text-slate-950" />
              </div>
              <span className="text-sm font-semibold">BlogPilot</span>
            </div>
            <nav className="mt-5 space-y-1 text-sm">
              {[
                { icon: Gauge, label: 'Analytics', active: false },
                { icon: PenTool, label: 'Generate Article', active: true },
                { icon: Network, label: 'Connected Sites', active: false },
                { icon: Link2, label: 'Link Library', active: false },
                { icon: BarChart3, label: 'History', active: false },
              ].map((item) => (
                <div
                  key={item.label}
                  className={`flex items-center gap-2.5 rounded-lg px-3 py-2 ${
                    item.active
                      ? 'bg-gradient-to-r from-cyan-400/15 to-violet-500/15 text-cyan-300'
                      : 'text-muted-foreground'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </div>
              ))}
            </nav>
          </div>

          {/* Main panel */}
          <div className="p-5 md:p-6">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-400">
              Article builder
            </p>
            <div className="mt-4 rounded-xl border border-border bg-card/50 p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Article title</span>
                <Badge className="bg-emerald-400/15 text-emerald-300">Draft saved</Badge>
              </div>
              <div className="mt-2 rounded-lg border border-border bg-muted/50 px-3 py-2.5 text-sm text-slate-200">
                The Ultimate Guide to Affiliate SEO in 2026
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {['affiliate seo', 'backlinks', 'content strategy'].map((k) => (
                  <span
                    key={k}
                    className="rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-xs text-cyan-300"
                  >
                    #{k}
                  </span>
                ))}
              </div>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-sm text-muted-foreground">SEO Score</span>
                <span className="font-mono text-sm font-bold text-emerald-300">92 / 100</span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-accent">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '92%' }}
                  transition={{ duration: 1.4, delay: 0.9, ease: 'easeOut' }}
                  className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-violet-400 to-emerald-400"
                />
              </div>
              <div className="mt-5 flex items-center justify-between">
                <div className="flex -space-x-2">
                  {['from-cyan-400 to-blue-500', 'from-violet-400 to-fuchsia-500', 'from-amber-400 to-rose-500'].map(
                    (g, i) => (
                      <div
                        key={i}
                        className={`h-7 w-7 rounded-full border-2 border-slate-900 bg-gradient-to-br ${g}`}
                      />
                    ),
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-lg border border-border bg-accent px-3 py-2 text-xs text-muted-foreground">
                    Save draft
                  </span>
                  <span className="rounded-lg bg-gradient-to-r from-cyan-400 to-violet-500 px-4 py-2 text-xs font-semibold text-slate-950 shadow-lg shadow-cyan-500/30">
                    Generate →
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Floating card: traffic */}
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, delay: 1.1 }}
        className="glass-strong absolute -left-6 top-24 hidden rounded-2xl p-4 lg:block animate-float-slow"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-400/15">
            <TrendingUp className="h-5 w-5 text-emerald-300" />
          </div>
          <div>
            <p className="text-lg font-bold">9 languages</p>
            <p className="text-xs text-muted-foreground">Multilingual content</p>
          </div>
        </div>
      </motion.div>

      {/* Floating card: SEO score */}
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.7, delay: 1.25 }}
        className="glass-strong absolute -right-6 top-10 hidden rounded-2xl p-4 lg:block animate-float-slower"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-400/15">
            <Gauge className="h-5 w-5 text-cyan-300" />
          </div>
          <div>
            <p className="text-lg font-bold">SEO scoring</p>
            <p className="text-xs text-muted-foreground">On every save</p>
          </div>
        </div>
      </motion.div>

      {/* Floating card: published */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 1.4 }}
        className="glass-strong absolute -bottom-6 left-1/2 hidden -translate-x-1/2 items-center gap-2 rounded-full px-4 py-2.5 lg:flex"
      >
        <CircleCheck className="h-4 w-4 text-emerald-300" />
        <span className="text-xs font-medium">One-click publishing to your site</span>
      </motion.div>
    </div>
  )
}

export function LandingPage() {
  const router = useRouter()
  const [mobileOpen, setMobileOpen] = useState(false)

  const features = [
    {
      icon: Bot,
      title: 'AI-Powered Generation',
      description:
        'Generate high-quality, SEO-optimized blog articles automatically using advanced AI models trained on top-performing content.',
      size: 'lg',
    },
    {
      icon: Search,
      title: 'Smart Keyword Targeting',
      description:
        'Automatically identify high-value keywords and optimize your content for maximum search visibility.',
      size: 'md',
    },
    {
      icon: DollarSign,
      title: 'Affiliate Integration',
      description:
        'Embed affiliate links from Amazon, eBay, CJ, and more. Earn commissions on autopilot.',
      size: 'md',
    },
    {
      icon: Globe,
      title: 'Multi-Site Publishing',
      description:
        'Connect WordPress, Blogger, or custom sites via webhook. Publish directly to your blogs with one click.',
      size: 'md',
    },
    {
      icon: BarChart3,
      title: 'SEO Quality Scoring',
      description:
        'Every article gets an honest on-page SEO analysis — structure, depth, keyword usage, and readability — with clear improvement tips.',
      size: 'md',
    },
    {
      icon: Shield,
      title: 'Enterprise-Grade Security',
      description:
        'Encrypted credential storage, rate-limited APIs, validated inputs, and signed sessions protecting your account.',
      size: 'lg',
    },
  ]

  const freeTools = [
    {
      icon: Target,
      title: 'Keyword Research',
      description: 'Understand what users search for, why they search, and what content it takes to rank.',
      tag: 'Free forever',
      href: '/free-tools/content-opportunity-analyzer/keyword-research',
    },
    {
      icon: BarChart3,
      title: 'Competitor Analysis',
      description: 'Dissect top-ranking pages to learn what they do well — and what they miss.',
      tag: 'Free forever',
      href: '/free-tools/content-opportunity-analyzer/competitor-analysis',
    },
    {
      icon: TrendingUp,
      title: 'Beat the Top 10',
      description: 'Get a prioritized list of improvements to outrank the leading results.',
      tag: 'Free forever',
      href: '/free-tools/content-opportunity-analyzer/beat-top-10',
    },
    {
      icon: Wrench,
      title: 'Content Opportunity Analyzer',
      description: 'Enter a keyword, URL, or website and instantly discover content gaps worth owning.',
      tag: 'Flagged',
      href: '/free-tools/content-opportunity-analyzer',
    },
  ]

  const plans = [
    {
      name: 'Starter',
      price: '$29',
      period: '/month',
      description: 'For individual bloggers getting started with AI-powered content.',
      features: [
        '50 AI-generated articles/month',
        '3 connected sites',
        'On-page SEO scoring',
        'Affiliate link support',
        'Email support',
      ],
      cta: 'Get Started',
      popular: false,
    },
    {
      name: 'Pro',
      price: '$79',
      period: '/month',
      description: 'For serious creators scaling their content operations.',
      features: [
        '200 AI-generated articles/month',
        '15 connected sites',
        'Advanced SEO scoring',
        'All affiliate platforms',
        'Scheduled publishing',
        'Priority support',
      ],
      cta: 'Get Started',
      popular: true,
    },
    {
      name: 'Agency',
      price: '$199',
      period: '/month',
      description: 'For agencies and teams managing multiple clients.',
      features: [
        '2,000 AI-generated articles/month',
        'Unlimited connected sites',
        'Auto-publishing',
        'Full SEO analytics suite',
        'Priority support',
        'Multilingual content (9 languages)',
      ],
      cta: 'Get Started',
      popular: false,
    },
  ]

  const faqs = [
    {
      q: 'How does the free plan work?',
      a: 'Every new account gets 10 free article credits — no credit card required. Use them to generate full articles, then pick the plan that fits your publishing volume. Cancel anytime.',
    },
    {
      q: 'Are the free SEO tools really free?',
      a: 'Yes. All 20+ tools — keyword research, competitor analysis, meta tag generation, schema generators, and more — are free to use with no account required.',
    },
    {
      q: 'Which platforms can I publish to?',
      a: 'WordPress (via application passwords), Blogger, and any custom site via webhook. Connect as many as your plan allows and publish with one click from the dashboard.',
    },
    {
      q: 'How does the SEO scoring work?',
      a: 'Each article is analyzed when saved against on-page SEO factors: title quality, keyword placement and density, heading structure, content depth, links, and readability — with specific recommendations for improvement.',
    },
    {
      q: 'Which payment methods do you accept?',
      a: 'Credit/debit cards via Paddle, plus PayPal, Payeer, and AirTM — so you can pay the way that works best for you, no matter where you are in the world.',
    },
  ]

  const navLinks = [
    { label: 'Features', href: '#features' },
    { label: 'Free Tools', href: '/free-tools' },
    { label: 'Pricing', href: '#pricing' },
    { label: 'FAQ', href: '#faq' },
  ]

  return (
    <div className="relative min-h-screen overflow-x-clip">
      {/* ---- Background layers ---- */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-grid mask-fade-y opacity-70" />
        <div className="absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-cyan-500/15 blur-[140px] animate-pulse-glow" />
        <div className="absolute top-[30%] -left-40 h-[460px] w-[460px] rounded-full bg-violet-600/15 blur-[130px]" />
        <div className="absolute top-[55%] -right-40 h-[480px] w-[480px] rounded-full bg-fuchsia-600/10 blur-[130px]" />
      </div>

      {/* ---- Navbar ---- */}
      <header className="sticky top-0 z-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="glass mt-4 flex h-16 items-center justify-between rounded-2xl px-4 sm:px-5">
            <a href="/" className="flex items-center gap-2.5">
              <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30">
                <Sparkles className="h-4.5 w-4.5 text-slate-950" />
              </div>
              <span className="text-lg font-bold tracking-tight">
                BlogPilot <span className="text-gradient">AI</span>
              </span>
            </a>

            <nav className="hidden items-center gap-1 md:flex">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="rounded-lg px-3.5 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            <div className="hidden items-center gap-2 md:flex">
              <ThemeToggle />
              <Button
                variant="ghost"
                onClick={() => router.push('/login')}
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                Log in
              </Button>
              <Button
                onClick={() => router.push('/signup')}
                className="bg-gradient-to-r from-cyan-400 to-violet-500 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/25 transition hover:shadow-cyan-400/40"
              >
                Get Started
                <ArrowUpRight className="h-4 w-4" />
              </Button>
            </div>

            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-accent md:hidden"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="mx-auto mt-2 max-w-7xl px-4 sm:px-6 md:hidden"
            >
              <div className="glass-strong rounded-2xl p-4">
                <nav className="flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <a
                      key={link.label}
                      href={link.href}
                      onClick={() => setMobileOpen(false)}
                      className="rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-accent hover:text-foreground"
                    >
                      {link.label}
                    </a>
                  ))}
                </nav>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    onClick={() => router.push('/login')}
                    className="w-full"
                  >
                    Log in
                  </Button>
                  <Button
                    onClick={() => router.push('/signup')}
                    className="w-full bg-gradient-to-r from-cyan-400 to-violet-500 text-slate-950"
                  >
                    Get Started
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* ---- Hero ---- */}
      <main>
        <section className="relative px-4 pb-16 pt-16 sm:px-6 md:pt-28">
          <div className="mx-auto max-w-4xl text-center">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <a
                href="/free-tools"
                className="glass shimmer-badge inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground transition hover:text-foreground"
              >
                <Zap className="h-3.5 w-3.5 text-cyan-400" />
                New: Free SEO research tools are live
                <ArrowRight className="h-3.5 w-3.5" />
              </a>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="mt-7 text-4xl font-extrabold leading-[1.08] tracking-display text-balance sm:text-6xl md:text-7xl"
            >
              Your <span className="text-gradient">AI SEO Growth Agent</span>, not just another AI writer
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="mx-auto mt-6 max-w-2xl text-base text-muted-foreground md:text-lg text-pretty"
            >
              Connect your website and let the agent discover opportunities, create optimized content,
              publish it, measure real results in Search Console, and keep improving — with your approval
              at every important step.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
            >
              <Button
                size="lg"
                onClick={() => router.push('/signup')}
                className="relative w-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-8 text-base font-semibold text-slate-950 shadow-xl shadow-cyan-500/30 transition hover:scale-[1.02] hover:shadow-cyan-400/50 sm:w-auto"
              >
                <span className="pointer-events-none absolute inset-0 rounded-full ring-1 ring-inset ring-white/30" />
                Start Free Trial
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => router.push('/free-tools')}
                className="glass w-full rounded-full px-8 text-base sm:w-auto"
              >
                Explore Free Tools
              </Button>
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.45 }}
              className="mt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs text-muted-foreground"
            >
              <span className="flex items-center gap-1.5">
                <Check className="h-3.5 w-3.5 text-emerald-400" /> No credit card required
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="h-3.5 w-3.5 text-emerald-400" /> 3-article free trial
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="h-3.5 w-3.5 text-emerald-400" /> Cancel anytime
              </span>
            </motion.p>
          </div>

          <DashboardMockup />
        </section>

        {/* ---- Stats ---- */}
        <section className="relative mx-auto mt-16 max-w-6xl px-4 sm:px-6 md:mt-24">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6 }}
            className="card-premium grid grid-cols-2 gap-px overflow-hidden rounded-3xl md:grid-cols-4"
          >
            {[
              { value: `${ALL_TOOLS.length}`, label: 'Free SEO tools', accent: 'text-cyan-300' },
              { value: '4', label: 'Publishing platforms', accent: 'text-violet-300' },
              { value: '9', label: 'Content languages', accent: 'text-emerald-300' },
              { value: '$0', label: 'Free to start', accent: 'text-fuchsia-300' },
            ].map((stat) => (
              <div key={stat.label} className="bg-card/30 px-6 py-8 text-center">
                <p className={`text-3xl font-extrabold tracking-tight md:text-4xl ${stat.accent}`}>
                  {stat.value}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </section>

        {/* ---- Features ---- */}
        <section id="features" className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 md:py-32">
          <SectionHeading
            badge="Features"
            title={
              <>
                Everything you need to <span className="text-gradient">automate</span> the content lifecycle
              </>
            }
            subtitle="From keyword research to publishing, BlogPilot AI handles every step — while you focus on growing revenue."
          />

          <motion.div {...stagger} className="mt-16 grid gap-4 md:grid-cols-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                {...fadeInUp}
                className={`card-premium hover-lift group relative overflow-hidden rounded-3xl p-7 ${
                  feature.size === 'lg' ? 'md:col-span-4' : 'md:col-span-2'
                } ${i === 0 ? 'md:row-span-1' : ''}`}
              >
                <div className="absolute -right-16 -top-16 h-40 w-40 rounded-full bg-cyan-400/0 blur-3xl transition-all duration-500 group-hover:bg-cyan-400/15" />
                <div className="relative">
                  <div className="icon-tile h-12 w-12 transition group-hover:scale-110">
                    <feature.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-5 text-xl font-semibold tracking-tight">{feature.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {feature.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* ---- Free Tools ---- */}
        <section id="free-tools" className="relative border-y border-border/50 bg-card/30 py-24 md:py-32">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <SectionHeading
              badge="Free Tools"
              title={
                <>
                  Research like a pro — <span className="text-gradient">free forever</span>
                </>
              }
              subtitle="Launch keyword research, content gap analysis, and competitor insights instantly. No signup needed for basic analysis."
            />

            <motion.div {...stagger} className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {freeTools.map((tool) => (
                <motion.button
                  key={tool.title}
                  {...fadeInUp}
                  type="button"
                  onClick={() => router.push(tool.href)}
                  className="group relative flex flex-col rounded-3xl border border-border bg-card/50 p-6 text-left transition-all duration-300 hover:-translate-y-1 hover:border-violet-400/30 hover:bg-accent/50 hover:shadow-2xl hover:shadow-violet-500/10"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-400/20 to-fuchsia-500/20 ring-1 ring-white/10">
                      <tool.icon className="h-5.5 w-5.5 text-violet-300" />
                    </div>
                    <Badge className="border-emerald-400/20 bg-emerald-400/10 text-emerald-300">
                      {tool.tag}
                    </Badge>
                  </div>
                  <h3 className="mt-5 text-lg font-semibold tracking-tight">{tool.title}</h3>
                  <p className="mt-2.5 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {tool.description}
                  </p>
                  <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-cyan-300 transition group-hover:gap-2.5">
                    Try it free
                    <ArrowRight className="h-4 w-4" />
                  </span>
                </motion.button>
              ))}
            </motion.div>

            <motion.div {...fadeInUp} className="mt-12 text-center">
              <Button
                variant="link"
                onClick={() => router.push('/free-tools')}
                className="text-base text-muted-foreground hover:text-foreground"
              >
                Browse all free tools
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </motion.div>
          </div>
        </section>

        {/* ---- How it works ---- */}
        <section className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 md:py-32">
          <SectionHeading
            badge="How it works"
            title={
              <>
                From idea to published article in <span className="text-gradient">three steps</span>
              </>
            }
          />
          <motion.div {...stagger} className="mt-16 grid gap-10 md:grid-cols-3 md:gap-8">
            {[
              {
                step: '01',
                icon: Link2,
                title: 'Connect your sites',
                description:
                  'Link WordPress, Shopify, or custom sites and add your affiliate credentials once.',
              },
              {
                step: '02',
                icon: Cpu,
                title: 'Generate articles',
                description:
                  'Set target keywords and let AI create SEO-optimized content with embedded affiliate links.',
              },
              {
                step: '03',
                icon: Rocket,
                title: 'Publish & grow',
                description:
                  'Publish directly to your sites and watch organic traffic and revenue grow.',
              },
            ].map((item) => (
              <motion.div key={item.step} {...fadeInUp} className="relative text-center">
                <div className="relative mx-auto mb-7 flex h-20 w-20 items-center justify-center">
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400/25 to-violet-500/25 blur-xl" />
                  <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl border border-border bg-card/70">
                    <item.icon className="h-8 w-8 text-cyan-300" />
                    <span className="absolute -right-2.5 -top-2.5 flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-violet-500 text-xs font-bold text-slate-950">
                      {item.step}
                    </span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold tracking-tight">{item.title}</h3>
                <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* ---- Pricing ---- */}
        <section id="pricing" className="relative border-y border-border/50 bg-card/30 py-24 md:py-32">
          <div className="mx-auto max-w-7xl px-4 sm:px-6">
            <SectionHeading
              badge="Pricing"
              title={
                <>
                  Simple, transparent pricing that <span className="text-gradient">scales with you</span>
                </>
              }
              subtitle="Start free with 3 trial articles. Pay with Visa/Mastercard (Paddle), PayPal, AirTM or Payeer — the choice is yours."
            />

            <motion.div {...stagger} className="mt-16 grid gap-6 lg:grid-cols-3">
              {plans.map((plan) => (
                <motion.div key={plan.name} {...fadeInUp}>
                  <div
                    className={`hover-lift relative flex h-full flex-col rounded-3xl p-8 transition-all duration-300 ${
                      plan.popular
                        ? 'gradient-ring bg-gradient-to-b from-cyan-400/[0.09] to-violet-500/[0.07] shadow-2xl shadow-cyan-500/10 lg:-my-3 lg:py-11'
                        : 'card-premium'
                    }`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                        <Badge className="shimmer-badge bg-gradient-to-r from-cyan-400 to-violet-500 px-4 py-1.5 text-xs font-semibold text-slate-950 shadow-lg shadow-cyan-500/30">
                          Most Popular
                        </Badge>
                      </div>
                    )}
                    <h3 className="text-lg font-semibold">{plan.name}</h3>
                    <p className="mt-1.5 text-sm text-muted-foreground">{plan.description}</p>
                    <div className="mt-6 flex items-baseline gap-1">
                      <span className="text-5xl font-extrabold tracking-tight">{plan.price}</span>
                      <span className="text-sm text-muted-foreground">{plan.period}</span>
                    </div>
                    <ul className="mt-8 flex-1 space-y-3.5">
                      {plan.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-3 text-sm">
                          <span
                            className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
                              plan.popular
                                ? 'bg-gradient-to-br from-cyan-400 to-violet-500 text-slate-950'
                                : 'bg-accent text-cyan-300'
                            }`}
                          >
                            <Check className="h-3 w-3" />
                          </span>
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      className={`mt-8 w-full rounded-full ${
                        plan.popular
                          ? 'bg-gradient-to-r from-cyan-400 to-violet-500 text-slate-950 shadow-lg shadow-cyan-500/25 hover:shadow-cyan-400/40'
                          : 'border border-border bg-accent hover:bg-accent'
                      }`}
                      variant={plan.popular ? 'default' : 'outline'}
                      onClick={() => router.push('/signup')}
                    >
                      {plan.cta}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ---- Why BlogPilot ---- */}
        <section className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 md:py-32">
          <SectionHeading
            badge="Why BlogPilot"
            title={
              <>
                Built for <span className="text-gradient">results</span>, not just word count
              </>
            }
          />
          <motion.div {...stagger} className="mt-16 grid gap-5 md:grid-cols-3">
            {[
              {
                title: 'Research before writing',
                description:
                  'The agent studies live search results and top-ranking competitors before drafting — so your article fills real gaps instead of repeating the same advice.',
              },
              {
                title: 'Verified sources included',
                description:
                  'Claims are checked against current web sources and cited in a Sources section. No invented statistics, no hallucinated references.',
              },
              {
                title: 'Publish in one click',
                description:
                  'Send the finished article straight to your WordPress or Blogger site — formatted, titled, tagged, and ready for readers.',
              },
            ].map((card) => (
              <motion.div
                key={card.title}
                {...fadeInUp}
                className="group relative flex flex-col rounded-3xl border border-border bg-card/50 p-7 transition-all duration-300 hover:border-border hover:bg-accent/50"
              >
                <Quote className="absolute right-6 top-6 h-8 w-8 text-muted-foreground/20" />
                <h3 className="mt-2 text-lg font-semibold">{card.title}</h3>
                <p className="mt-4 flex-1 text-sm leading-relaxed text-slate-300">{card.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* ---- FAQ ---- */}
        <section id="faq" className="relative mx-auto max-w-3xl px-4 pb-24 sm:px-6 md:pb-32">
          <SectionHeading
            badge="FAQ"
            title="Frequently asked questions"
          />
          <motion.div {...fadeInUp} className="mt-12">
            <Accordion type="single" collapsible className="space-y-3">
              {faqs.map((faq, i) => (
                <AccordionItem
                  key={i}
                  value={`item-${i}`}
                  className="rounded-2xl border border-border bg-card/50 px-2 transition-colors hover:border-border"
                >
                  <AccordionTrigger className="px-4 py-4 text-left text-sm font-semibold md:text-base">
                    {faq.q}
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pb-5 text-sm leading-relaxed text-muted-foreground">
                    {faq.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </section>

        {/* ---- CTA ---- */}
        <section className="relative mx-auto max-w-7xl px-4 pb-24 sm:px-6 md:pb-32">
          <motion.div
            {...fadeInUp}
            className="relative overflow-hidden rounded-[40px] border border-border bg-gradient-to-br from-cyan-500/[0.12] via-slate-900/40 to-violet-500/[0.14] px-6 py-20 text-center md:py-28"
          >
            <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" />
            <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-violet-500/20 blur-3xl" />
            <div className="bg-grid absolute inset-0 opacity-40 mask-fade-y" />
            <div className="relative mx-auto max-w-2xl">
              <h2 className="text-3xl font-extrabold tracking-tight text-balance md:text-5xl">
                Ready to put your content growth <span className="text-gradient">on autopilot?</span>
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground md:text-lg">
                AI-powered content tools. Start for free — no credit card required.
              </p>
              <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Button
                  size="lg"
                  onClick={() => router.push('/signup')}
                  className="w-full rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-9 text-base font-semibold text-slate-950 shadow-xl shadow-cyan-500/30 hover:shadow-cyan-400/50 sm:w-auto"
                >
                  Get Started Free
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="lg"
                  onClick={() => router.push('/free-tools')}
                  className="w-full rounded-full text-muted-foreground hover:text-foreground sm:w-auto"
                >
                  Try the free tools first
                </Button>
              </div>
              <p className="mt-6 text-xs text-muted-foreground">
                10 free credits on signup · No credit card required · Cancel anytime
              </p>
            </div>
          </motion.div>
        </section>
      </main>

      {/* ---- Footer ---- */}
      <footer className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
          <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
            <div>
              <a href="/" className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-violet-500">
                  <Sparkles className="h-4 w-4 text-slate-950" />
                </div>
                <span className="text-base font-bold tracking-tight text-foreground">
                  BlogPilot <span className="text-gradient">AI</span>
                </span>
              </a>
              <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
                The AI-powered workspace for SEO content, affiliate links, and publishing — on
                autopilot.
              </p>
            </div>

            {[
              {
                title: 'Product',
                links: [
                  { label: 'Features', href: '#features' },
                  { label: 'Pricing', href: '#pricing' },
                  { label: 'Free Tools', href: '/free-tools' },
                  { label: 'Changelog', href: null },
                ],
              },
              {
                title: 'Resources',
                links: [
                  { label: 'SEO Guides', href: '/free-tools' },
                  { label: 'Affiliate Playbook', href: '/free-tools' },
                  { label: 'API Docs', href: null },
                  { label: 'Support', href: null },
                ],
              },
              {
                title: 'Company',
                links: [
                  { label: 'About', href: null },
                  { label: 'Blog', href: null },
                  { label: 'Contact', href: null },
                ],
              },
            ].map((col) => (
              <div key={col.title}>
                <h4 className="text-sm font-semibold text-foreground">{col.title}</h4>
                <ul className="mt-4 space-y-3">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      {link.href ? (
                        <a
                          href={link.href}
                          className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                        >
                          {link.label}
                        </a>
                      ) : (
                        <span className="text-sm text-muted-foreground">{link.label}</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 md:flex-row">
            <p className="text-xs text-muted-foreground">
              &copy; {new Date().getFullYear()} BlogPilot AI. All rights reserved.
            </p>
            <div className="flex items-center gap-6 text-xs text-muted-foreground">
              <span>Privacy</span>
              <span>Terms</span>
              <span>Security</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
