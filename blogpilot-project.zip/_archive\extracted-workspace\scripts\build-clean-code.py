#!/usr/bin/env python3
"""
Build a clean, copy-ready source code file for BlogPilot AI.
Excludes shadcn/ui boilerplate (installable via CLI) and keeps only custom code.
"""

import os

BASE = "/home/z/my-project"
OUTPUT = "/home/z/my-project/download/BlogPilot-AI-Source-Code.txt"

SKIP_DIRS = {"node_modules", ".next", ".git", "download", "scripts", "tests", 
            "examples", "skills", "mini-services", "tool-results", "ui"}
SKIP_FILES = {"package-lock.json", "bun.lock", "worklog.md", ".DS_Store", "use-toast.ts", "use-mobile.ts"}
SKIP_EXTENSIONS = {".log", ".pyc"}

def should_skip(rel):
    parts = rel.replace(os.sep, "/").split("/")
    for p in parts:
        if p in SKIP_DIRS:
            return True
    fname = os.path.basename(rel)
    if fname in SKIP_FILES:
        return True
    for ext in SKIP_EXTENSIONS:
        if fname.endswith(ext):
            return True
    return False

def is_source(path):
    ext = os.path.splitext(path)[1].lower()
    return ext in {".ts", ".tsx", ".js", ".mjs", ".css", ".prisma", ".json", ".svg", ""}

def collect():
    result = []
    for root, dirs, files in os.walk(BASE):
        dirs[:] = [d for d in dirs if d not in {"node_modules", ".next", ".git", "download", 
                                                    "scripts", "tests", "examples", "skills", 
                                                    "mini-services", "tool-results"}]
        for f in files:
            full = os.path.join(root, f)
            rel = os.path.relpath(full, BASE).replace(os.sep, "/")
            if not should_skip(rel) and is_source(full):
                result.append((rel, full))
    return sorted(result)

def main():
    files = collect()
    
    with open(OUTPUT, "w", encoding="utf-8") as out:
        out.write("BlogPilot AI - Complete Source Code\n")
        out.write("=" * 70 + "\n")
        out.write("Next.js 16 | TypeScript | Tailwind CSS 4 | Prisma | Gemini AI\n")
        out.write("4 Payment Gateways | SEO | Affiliate Marketing | TipTap Editor\n")
        out.write("=" * 70 + "\n\n")
        
        out.write("SETUP:\n")
        out.write("1. Save this file as BlogPilot-AI-Source-Code.txt\n")
        out.write("2. npm install\n")
        out.write("3. npx shadcn@latest init (then add needed components)\n")
        out.write("4. Create .env: DATABASE_URL, ADMIN_EMAIL, ENCRYPTION_KEY\n")
        out.write("5. npx prisma db push\n")
        out.write("6. npm run dev\n\n")
        out.write("=" * 70 + "\n\n")
        
        cur_sec = None
        for rel, full in files:
            top = rel.split("/")[0] if "/" in rel else "(root)"
            if top != cur_sec:
                cur_sec = top
                out.write("\n" + "#" * 70 + "\n")
                out.write(f"# {top}/\n")
                out.write("#" * 70 + "\n\n")
            
            out.write(f"# === {rel} ===\n")
            try:
                with open(full, "r", encoding="utf-8") as f:
                    content = f.read()
                out.write(content)
                if not content.endswith("\n"):
                    out.write("\n")
            except Exception as e:
                out.write(f"# [ERROR: {e}]\n")
            out.write("\n\n")
        
        out.write("#" * 70 + "\n")
        out.write("# END\n")
        out.write("#" * 70 + "\n")
    
    sz = os.path.getsize(OUTPUT)
    print(f"Done! {len(files)} files, {sz:,} bytes ({sz/1024:.1f} KB)")

if __name__ == "__main__":
    main()
