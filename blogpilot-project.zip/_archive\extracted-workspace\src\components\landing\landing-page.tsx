'use client'

import { ThemeToggle } from '@/components/theme-toggle'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { motion } from 'framer-motion'
import Link from 'next/link'
import {
  Sparkles,
  Search,
  DollarSign,
  Zap,
  ArrowRight,
  Check,
  Bot,
  FileText,
  Link2,
  BarChart3,
  Globe,
  Shield,
  Clock,
} from 'lucide-react'

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
}

const stagger = {
  animate: { transition: { staggerChildren: 0.1 } },
}

export function LandingPage() {
  const features = [
    {
      icon: Bot,
      title: 'AI-Powered Generation',
      description: 'Generate high-quality, SEO-optimized blog articles automatically using advanced AI models trained on top-performing content.',
    },
    {
      icon: Search,
      title: 'Smart Keyword Targeting',
      description: 'Automatically identify high-value keywords and optimize your content for maximum search engine visibility.',
    },
    {
      icon: DollarSign,
      title: 'Affiliate Integration',
      description: 'Seamlessly embed affiliate links from Amazon, eBay, CJ, and more. Earn commissions on autopilot.',
    },
    {
      icon: Globe,
      title: 'Multi-Site Publishing',
      description: 'Connect WordPress, Shopify, or custom sites. Publish articles directly to your blogs with one click.',
    },
    {
      icon: BarChart3,
      title: 'SEO Performance Tracking',
      description: 'Monitor your articles\' SEO scores, keyword rankings, and organic traffic growth in real time.',
    },
    {
      icon: Clock,
      title: 'Scheduled Publishing',
      description: 'Plan and schedule content in advance. Maintain a consistent publishing cadence effortlessly.',
    },
  ]

  const plans = [
    {
      name: 'Basic',
      price: '$29',
      period: '/month',
      description: 'Perfect for individual bloggers getting started with AI-powered content.',
      features: [
        '50 AI-generated articles/month',
        '3 connected sites',
        'Basic SEO scoring',
        'Amazon affiliate integration',
        'Email support',
      ],
      cta: 'Start Free Trial',
      popular: false,
    },
    {
      name: 'Pro',
      price: '$79',
      period: '/month',
      description: 'For serious content creators and affiliate marketers scaling their operations.',
      features: [
        '200 AI-generated articles/month',
        '15 connected sites',
        'Advanced SEO scoring & analytics',
        'All affiliate platforms',
        'Scheduled publishing',
        'Priority support',
      ],
      cta: 'Start Free Trial',
      popular: true,
    },
    {
      name: 'Agency',
      price: '$249',
      period: '/month',
      description: 'For agencies and teams managing multiple clients and high-volume publishing.',
      features: [
        'Unlimited AI-generated articles',
        'Unlimited connected sites',
        'Full SEO analytics suite',
        'All affiliate platforms',
        'API access',
        'White-label reports',
        'Dedicated account manager',
        'Team collaboration',
      ],
      cta: 'Contact Sales',
      popular: false,
    },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <main className="flex-1">
        <section className="container mx-auto px-4 sm:px-6 py-20 md:py-32">
          <motion.div
            className="mx-auto max-w-3xl text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge variant="secondary" className="mb-4 px-3 py-1 text-xs font-medium">
              <Zap className="mr-1 h-3 w-3" />
              AI-Powered Content Engine
            </Badge>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight leading-tight">
              Autonomous SEO &
              <br />
              <span className="text-primary">Affiliate Blogging</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Generate SEO-optimized articles, embed affiliate links, and publish directly to your blogs — all on autopilot. Let AI handle the content while you focus on growing your revenue.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button size="lg" asChild className="w-full sm:w-auto px-8">
                <Link href="/signup">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild className="w-full sm:w-auto px-8">
                <Link href="/login">View Demo</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              No credit card required · 14-day free trial · Cancel anytime
            </p>
          </motion.div>
        </section>

        {/* Stats Bar */}
        <section className="border-y border-border/40 bg-muted/50">
          <div className="container mx-auto px-4 sm:px-6 py-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {[
                { label: 'Articles Generated', value: '2.4M+' },
                { label: 'Active Users', value: '12K+' },
                { label: 'Avg. SEO Score', value: '92/100' },
                { label: 'Revenue Generated', value: '$8.7M+' },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="text-2xl md:text-3xl font-bold">{stat.value}</p>
                  <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="container mx-auto px-4 sm:px-6 py-20 md:py-28">
          <motion.div
            className="text-center mb-16"
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <Badge variant="secondary" className="mb-3 px-3 py-1 text-xs font-medium">
              Features
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
              Everything You Need to Automate
            </h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              From keyword research to publishing, BlogPilot AI handles every step of the content lifecycle.
            </p>
          </motion.div>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={stagger}
          >
            {features.map((feature) => (
              <motion.div key={feature.title} variants={fadeInUp}>
                <Card className="h-full border-border/50 hover:border-border transition-colors group">
                  <CardHeader>
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <feature.icon className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-lg mt-3">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* How It Works */}
        <section className="bg-muted/50 border-y border-border/40">
          <div className="container mx-auto px-4 sm:px-6 py-20 md:py-28">
            <motion.div
              className="text-center mb-16"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <Badge variant="secondary" className="mb-3 px-3 py-1 text-xs font-medium">
                How It Works
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                Three Simple Steps
              </h2>
            </motion.div>
            <motion.div
              className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={stagger}
            >
              {[
                {
                  step: '01',
                  icon: Link2,
                  title: 'Connect Your Sites',
                  description: 'Link your WordPress, Shopify, or custom sites. Add your affiliate credentials once.',
                },
                {
                  step: '02',
                  icon: FileText,
                  title: 'Generate Articles',
                  description: 'Set your target keywords and let AI create SEO-optimized content with embedded affiliate links.',
                },
                {
                  step: '03',
                  icon: BarChart3,
                  title: 'Publish & Grow',
                  description: 'Publish directly to your sites and watch your organic traffic and revenue grow.',
                },
              ].map((item) => (
                <motion.div key={item.step} variants={fadeInUp} className="text-center">
                  <div className="relative mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 border-2 border-primary/20">
                    <item.icon className="h-7 w-7 text-primary" />
                    <span className="absolute -top-2 -right-2 flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="container mx-auto px-4 sm:px-6 py-20 md:py-28">
          <motion.div
            className="text-center mb-16"
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={fadeInUp}
          >
            <Badge variant="secondary" className="mb-3 px-3 py-1 text-xs font-medium">
              Pricing
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
              Simple, Transparent Pricing
            </h2>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              Start free with 3 trial articles. Scale as you grow — pay with Stripe, PayPal, or Payeer.
            </p>
            <div className="mt-4 flex items-center justify-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Check className="h-3 w-3 text-green-500" />
                3-article free trial
              </span>
              <span className="text-border">·</span>
              <span className="flex items-center gap-1">
                <Check className="h-3 w-3 text-green-500" />
                Cancel anytime
              </span>
              <span className="text-border">·</span>
              <span className="flex items-center gap-1">
                <Check className="h-3 w-3 text-green-500" />
                No credit card to start
              </span>
            </div>
          </motion.div>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto"
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            variants={stagger}
          >
            {plans.map((plan) => (
              <motion.div key={plan.name} variants={fadeInUp}>
                <Card className={`h-full relative ${plan.popular ? 'border-primary shadow-lg shadow-primary/10' : 'border-border/50'}`}>
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <Badge className="px-3 py-1 text-xs font-medium shadow-sm">
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  <CardHeader className="pt-6">
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <Separator className="mb-4" />
                    <ul className="space-y-3">
                      {plan.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-2 text-sm">
                          <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="pt-4">
                    <Button
                      className="w-full"
                      variant={plan.popular ? 'default' : 'outline'}
                      asChild
                    >
                      <Link href="/signup">{plan.cta}</Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </section>

        {/* CTA Section */}
        <section className="bg-muted/50 border-t border-border/40">
          <div className="container mx-auto px-4 sm:px-6 py-20">
            <motion.div
              className="mx-auto max-w-2xl text-center"
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">
                Ready to Automate Your Blog?
              </h2>
              <p className="mt-4 text-muted-foreground text-lg">
                Join thousands of content creators who are scaling their affiliate revenue with AI.
              </p>
              <div className="mt-8">
                <Button size="lg" asChild className="px-8">
                  <Link href="/signup">
                    Get Started Free
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 bg-background">
        <div className="container mx-auto px-4 sm:px-6 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary">
                <Sparkles className="h-3.5 w-3.5 text-primary-foreground" />
              </div>
              <span className="text-sm font-semibold">BlogPilot AI</span>
            </div>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
              <a href="#" className="hover:text-foreground transition-colors">Terms</a>
              <a href="#" className="hover:text-foreground transition-colors">Support</a>
            </div>
            <p className="text-xs text-muted-foreground">
              &copy; 2026 BlogPilot AI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
