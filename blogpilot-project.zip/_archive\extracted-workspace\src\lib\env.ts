/**
 * Environment Variable Validation
 *
 * Centralized, non-throwing access to all sensitive environment variables
 * (Stripe, Gemini, database, scraper keys). Each accessor returns a typed
 * result so callers can branch cleanly instead of guessing.
 *
 * Design principles:
 *   - NEVER throw at module load time — that would crash the whole server
 *     just because one optional key is missing. Instead, each accessor
 *     returns `{ configured: false, reason: '...' }` and the route handler
 *     decides what to do (skip the feature, return 503, fall back to demo).
 *   - Surface the "is this key still the placeholder value?" check so
 *     accidental commits of `your-gemini-api-key-here` are caught.
 *   - Provide a `validateEnv()` helper that produces a human-readable
 *     health report — useful for `/api/health` and for startup logs.
 *
 * Categories:
 *   1. REQUIRED (server won't function without these) — DATABASE_URL
 *   2. AI_KEYS (paid upstreams)        — GEMINI_API_KEY
 *   3. SCRAPING_KEYS (paid upstreams)  — SERPER_API_KEY, JINA_API_KEY
 *   4. STRIPE (payments, optional — demo mode when absent)
 *   5. PUBLIC (safe to expose to client)
 */

export interface EnvCheck {
  /** Variable name. */
  name: string
  /** Whether the variable is set to a non-placeholder value. */
  configured: boolean
  /** Why it isn't configured (placeholder / empty / wrong prefix). */
  reason?: string
  /** Whether this variable is required for the server to start. */
  required: boolean
  /** Category for grouping in the health report. */
  category: 'required' | 'ai' | 'scraping' | 'stripe' | 'public'
}

/**
 * List of known placeholder values that ship in `.env.example`.
 * If a variable matches one of these, we treat it as "not configured".
 */
const PLACEHOLDER_VALUES = new Set([
  '',
  'your-gemini-api-key-here',
  'your-serper-api-key-here',
  'your-jina-api-key-here',
  'sk_test_xxx',
  'pk_test_xxx',
  'whsec_xxx',
  'price_xxx',
  'sk_live_xxx',
  'pk_live_xxx',
  'your-paypal-client-id',
  'your-paypal-client-secret',
  'your-paypal-webhook-id',
  'your-payeer-merchant-id',
  'your-payeer-secret-key',
  'your-payeer-api-key',
  'your-airtm-api-token',
  'admin-airtm-email-placeholder',
  'your-google-client-id',
  'your-google-client-secret',
])

function isPlaceholder(value: string | undefined): boolean {
  if (value === undefined) return true
  return PLACEHOLDER_VALUES.has(value.trim())
}

function checkEnv(name: string, opts: {
  required?: boolean
  category: EnvCheck['category']
  /** Optional prefix validator (e.g. Stripe secret keys start with sk_). */
  expectedPrefix?: string
}): EnvCheck {
  const value = process.env[name]
  const required = opts.required ?? false

  if (isPlaceholder(value)) {
    return {
      name,
      configured: false,
      reason: value === undefined ? 'not_set' : 'placeholder_value',
      required,
      category: opts.category,
    }
  }

  if (opts.expectedPrefix && !value!.startsWith(opts.expectedPrefix)) {
    return {
      name,
      configured: false,
      reason: `expected_prefix_${opts.expectedPrefix}`,
      required,
      category: opts.category,
    }
  }

  return { name, configured: true, required, category: opts.category }
}

/* -------------------------------------------------------------------------- */
/*                          Individual env accessors                         */
/* -------------------------------------------------------------------------- */

export const env = {
  /** Database URL — required. The app cannot start without this. */
  databaseUrl: () =>
    checkEnv('DATABASE_URL', { required: true, category: 'required' }),

  /** Gemini API key (paid upstream for AI generation). */
  geminiApiKey: () =>
    checkEnv('GEMINI_API_KEY', { category: 'ai' }),

  /** Serper.dev API key (paid upstream for Google search scraping). */
  serperApiKey: () =>
    checkEnv('SERPER_API_KEY', { category: 'scraping' }),

  /** Jina Reader API key (paid upstream for content extraction). */
  jinaApiKey: () =>
    checkEnv('JINA_API_KEY', { category: 'scraping' }),

  /** Stripe secret key (sk_test_... or sk_live_...). */
  stripeSecretKey: () =>
    checkEnv('STRIPE_SECRET_KEY', {
      category: 'stripe',
      expectedPrefix: 'sk_',
    }),

  /** Stripe publishable key (pk_test_... or pk_live_...). */
  stripePublishableKey: () =>
    checkEnv('STRIPE_PUBLISHABLE_KEY', {
      category: 'stripe',
      expectedPrefix: 'pk_',
    }),

  /** Stripe webhook signing secret (whsec_...). */
  stripeWebhookSecret: () =>
    checkEnv('STRIPE_WEBHOOK_SECRET', {
      category: 'stripe',
      expectedPrefix: 'whsec_',
    }),

  /** Stripe Price IDs — one per plan tier. */
  stripePriceBasic: () =>
    checkEnv('STRIPE_PRICE_BASIC', { category: 'stripe', expectedPrefix: 'price_' }),
  stripePricePro: () =>
    checkEnv('STRIPE_PRICE_PRO', { category: 'stripe', expectedPrefix: 'price_' }),
  stripePriceAgency: () =>
    checkEnv('STRIPE_PRICE_AGENCY', { category: 'stripe', expectedPrefix: 'price_' }),

  /* ─── PayPal (alternative payment gateway) ──────────────────────────────
   * PAYPAL_CLIENT_ID  — public, safe to expose to the browser SDK
   * PAYPAL_CLIENT_SECRET — server-side secret used by /api/paypal/* routes
   * PAYPAL_WEBHOOK_ID — webhook ID for signature verification
   * PAYPAL_MODE — 'sandbox' | 'live' (defaults to 'sandbox')
   */
  paypalClientId: () =>
    checkEnv('PAYPAL_CLIENT_ID', { category: 'stripe' }),
  paypalClientSecret: () =>
    checkEnv('PAYPAL_CLIENT_SECRET', { category: 'stripe' }),
  paypalWebhookId: () =>
    checkEnv('PAYPAL_WEBHOOK_ID', { category: 'stripe' }),
  paypalMode: () =>
    checkEnv('PAYPAL_MODE', { category: 'public' }),

  /* ─── Payeer (alternative payment gateway) ──────────────────────────────
   * PAYEER_MERCHANT_ID — your Payeer shop ID
   * PAYEER_SECRET_KEY  — server-side secret used to sign payment URLs
   * PAYEER_API_KEY     — server-side API key for status queries
   */
  payeerMerchantId: () =>
    checkEnv('PAYEER_MERCHANT_ID', { category: 'stripe' }),
  payeerSecretKey: () =>
    checkEnv('PAYEER_SECRET_KEY', { category: 'stripe' }),
  payeerApiKey: () =>
    checkEnv('PAYEER_API_KEY', { category: 'stripe' }),

  /* ─── Airtm (alternative payment gateway — email-based) ────────────────
   * ADMIN_AIRTM_EMAIL — admin's Airtm account email. Used at runtime to
   *   generate direct payment invoices for users. No email is ever hardcoded
   *   in application code — the value is read exclusively from this env var.
   * AIRTM_API_TOKEN    — optional server-side API token for webhook verification
   */
  adminAirtmEmail: () =>
    checkEnv('ADMIN_AIRTM_EMAIL', { category: 'stripe' }),
  airtmApiToken: () =>
    checkEnv('AIRTM_API_TOKEN', { category: 'stripe' }),

  /* ─── Google OAuth 2.0 (auto-renewing tokens for publishing/indexing) ──
   * GOOGLE_CLIENT_ID     — public OAuth client ID (safe to expose to browser)
   * GOOGLE_CLIENT_SECRET — server-side secret for token exchange + refresh
   * GOOGLE_REDIRECT_URI   — must match the redirect URI in Google Cloud Console
   */
  googleClientId: () =>
    checkEnv('GOOGLE_CLIENT_ID', { category: 'stripe' }),
  googleClientSecret: () =>
    checkEnv('GOOGLE_CLIENT_SECRET', { category: 'stripe' }),
  googleRedirectUri: () =>
    checkEnv('GOOGLE_REDIRECT_URI', { category: 'public' }),

  /** Public app URL (used for Stripe redirect URLs). */
  publicAppUrl: () =>
    checkEnv('NEXT_PUBLIC_APP_URL', { category: 'public' }),

  /** Admin email — the user with this email is treated as admin. */
  adminEmail: () =>
    checkEnv('ADMIN_EMAIL', { category: 'public' }),

  /**
   * AES-256-GCM key used to encrypt stored credentials.
   *
   * Marked as optional (category 'required' but not required=true) because
   * the crypto module falls back to a deterministic dev key when this is
   * absent. In production, set this — the /api/health endpoint will surface
   * a "degraded" warning so ops can catch the missing key during deploy
   * review.
   */
  encryptionKey: () =>
    checkEnv('ENCRYPTION_KEY', { category: 'required' }),
}

/* -------------------------------------------------------------------------- */
/*                              Health report                                 */
/* -------------------------------------------------------------------------- */

/**
 * Run all env checks and return a structured report.
 * Safe to expose at `/api/health` (omits raw values — only statuses).
 */
export function validateEnv(): {
  ok: boolean
  missing: EnvCheck[]
  configured: EnvCheck[]
  all: EnvCheck[]
} {
  const all: EnvCheck[] = [
    env.databaseUrl(),
    env.encryptionKey(),
    env.geminiApiKey(),
    env.serperApiKey(),
    env.jinaApiKey(),
    env.stripeSecretKey(),
    env.stripePublishableKey(),
    env.stripeWebhookSecret(),
    env.stripePriceBasic(),
    env.stripePricePro(),
    env.stripePriceAgency(),
    env.paypalClientId(),
    env.paypalClientSecret(),
    env.paypalWebhookId(),
    env.paypalMode(),
    env.payeerMerchantId(),
    env.payeerSecretKey(),
    env.payeerApiKey(),
    env.adminAirtmEmail(),
    env.airtmApiToken(),
    env.googleClientId(),
    env.googleClientSecret(),
    env.googleRedirectUri(),
    env.publicAppUrl(),
    env.adminEmail(),
  ]

  const missing = all.filter((c) => !c.configured && c.required)
  const configured = all.filter((c) => c.configured)

  return {
    // "ok" means no REQUIRED env is missing. Optional categories (AI,
    // scraping, Stripe) all have graceful fallbacks.
    ok: missing.length === 0,
    missing,
    configured,
    all,
  }
}

/**
 * Convenience: log a startup banner summarizing env health.
 * Call from instrumentation.ts or the root layout.
 */
export function logEnvHealth() {
  const report = validateEnv()
  if (report.ok) {
    console.info(
      `[env] ✓ All required env vars configured. ` +
      `${report.configured.length}/${report.all.length} total.`
    )
  } else {
    const missingNames = report.missing.map((m) => m.name).join(', ')
    console.error(
      `[env] ✗ Missing required env vars: ${missingNames}. ` +
      'The server may not function correctly.'
    )
  }

  // Warn about optional-but-unset categories (without crashing)
  const optionalMissing = report.all.filter(
    (c) => !c.configured && !c.required
  )
  for (const c of optionalMissing) {
    console.warn(
      `[env] optional ${c.category}/${c.name} not configured — ` +
      'feature will run in degraded / demo mode.'
    )
  }
}
