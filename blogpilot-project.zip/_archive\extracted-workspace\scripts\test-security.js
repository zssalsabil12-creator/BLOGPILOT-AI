/**
 * Prompt 9 — Security Hardening Test Suite (fast version)
 *
 * Verifies:
 *   1. /api/health works and doesn't leak secrets
 *   2. Zod validation rejects XSS / oversized / malformed input
 *   3. URL validation rejects javascript: scheme
 *   4. Rate limiting kicks in after threshold
 *   5. Error responses are user-friendly (no stack traces)
 */

const BASE = 'http://localhost:3000'

let passed = 0
let failed = 0

async function req(method, path, body, headers = {}) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', ...headers },
    signal: AbortSignal.timeout(8000),
  }
  if (body !== undefined) opts.body = typeof body === 'string' ? body : JSON.stringify(body)
  try {
    const res = await fetch(`${BASE}${path}`, opts)
    let json = null
    try { json = await res.json() } catch { /* allow empty body */ }
    return { status: res.status, json, headers: res.headers }
  } catch (err) {
    return { status: 0, json: null, headers: new Headers(), error: err.message }
  }
}

function check(name, condition, detail = '') {
  if (condition) {
    passed++
    console.log(`  ✓ ${name}`)
  } else {
    failed++
    console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`)
  }
}

async function main() {
  console.log('━'.repeat(70))
  console.log(' Prompt 9 — Security Hardening Test Suite')
  console.log('━'.repeat(70))

  // ─── 1. Health endpoint ──────────────────────────────────────────────
  console.log('\n[1] /api/health — env health report')
  {
    const r = await req('GET', '/api/health')
    check(
      'returns 200 (or 503 — both are valid health signals)',
      r.status === 200 || r.status === 503,
      `got ${r.status}`
    )
    check(
      'reports env per category',
      r.json?.env && typeof r.json.env === 'object',
      `env keys: ${Object.keys(r.json?.env || {}).join(',')}`
    )
    check(
      'does NOT leak secret values',
      JSON.stringify(r.json || {}).length < 5000,
      `response too long — possible leak`
    )
    check(
      'reports memory + uptime',
      typeof r.json?.uptime === 'number' && typeof r.json?.memory?.rss === 'number'
    )
  }

  // ─── 2. Zod validation: keyword XSS ─────────────────────────────────
  console.log('\n[2] Zod validation — XSS in keyword rejected')
  {
    const r = await req('POST', '/api/generate', {
      keyword: '<script>alert(1)</script>',
    })
    check('returns 400', r.status === 400, `got ${r.status}`)
    check(
      'error is user-friendly (no stack trace)',
      !!r.json?.error && !r.json.error.includes('at '),
      `error: ${r.json?.error}`
    )
    check(
      'error code is "validation"',
      r.json?.code === 'validation',
      `code: ${r.json?.code}`
    )
  }

  // ─── 3. Zod validation: oversized keyword ───────────────────────────
  console.log('\n[3] Zod validation — oversized keyword rejected')
  {
    const r = await req('POST', '/api/generate', {
      keyword: 'x'.repeat(500),
    })
    check('returns 400', r.status === 400, `got ${r.status}`)
    check(
      'mentions max length',
      (r.json?.error || '').toLowerCase().includes('max') ||
        (r.json?.error || '').toLowerCase().includes('too long'),
      `error: ${r.json?.error}`
    )
  }

  // ─── 4. Zod validation: invalid enum ────────────────────────────────
  console.log('\n[4] Zod validation — invalid enum value rejected')
  {
    const r = await req('POST', '/api/generate', {
      keyword: 'wireless headphones',
      intent: 'invalid_intent',
    })
    check('returns 400', r.status === 400, `got ${r.status}`)
  }

  // ─── 5. Zod validation: malformed JSON ──────────────────────────────
  console.log('\n[5] Zod validation — malformed JSON body rejected')
  {
    const r = await req('POST', '/api/generate', 'not-valid-json{', {
      'Content-Type': 'application/json',
    })
    check(
      'returns 400 (not 500)',
      r.status === 400,
      `got ${r.status} — should be 400, not 500`
    )
    check(
      'error mentions invalid JSON',
      (r.json?.error || '').toLowerCase().includes('json') ||
        (r.json?.error || '').toLowerCase().includes('invalid'),
      `error: ${r.json?.error}`
    )
  }

  // ─── 6. Zod validation: signup with weak password ───────────────────
  console.log('\n[6] Zod validation — weak password rejected at signup')
  {
    const r = await req('POST', '/api/auth/signup', {
      email: 'test@example.com',
      password: '123',
      name: 'Test User',
    })
    check('returns 400', r.status === 400, `got ${r.status}`)
    check(
      'error mentions password length',
      (r.json?.error || '').toLowerCase().includes('password') ||
        (r.json?.error || '').toLowerCase().includes('character'),
      `error: ${r.json?.error}`
    )
  }

  // ─── 7. URL validation: javascript: scheme ──────────────────────────
  console.log('\n[7] Zod validation — javascript: URL rejected')
  {
    const r = await req('POST', '/api/sites', {
      userId: 'demo-user',
      name: 'Test Site',
      url: 'javascript:alert(1)',
      platform: 'wordpress',
    })
    check('returns 400', r.status === 400, `got ${r.status}`)
    check(
      'error mentions http/https requirement',
      (r.json?.error || '').toLowerCase().includes('http') ||
        (r.json?.error || '').toLowerCase().includes('valid'),
      `error: ${r.json?.error}`
    )
  }

  // ─── 8. Rate limiting — auth endpoint ───────────────────────────────
  console.log('\n[8] Rate limiting — /api/auth/login (10/min threshold)')
  {
    // Sequential — the server is single-threaded, 13 parallel requests
    // would overwhelm it before the limiter kicks in. Sequential firing
    // still tests the limiter correctly because the limiter is sync.
    const statuses = []
    let blocked = null
    for (let i = 0; i < 13; i++) {
      const r = await req('POST', '/api/auth/login', {
        email: 'ratelimit-test@example.com',
        password: 'wrong',
      })
      statuses.push(r.status)
      if (r.status === 429 && !blocked) blocked = r
    }
    check(
      'at least one request returns 429',
      !!blocked,
      `statuses: ${statuses.join(',')}`
    )
    if (blocked) {
      check(
        'sets Retry-After header',
        !!blocked.headers.get('retry-after'),
        `retry-after: ${blocked.headers.get('retry-after')}`
      )
      check(
        'sets X-RateLimit-Limit header',
        !!blocked.headers.get('x-ratelimit-limit'),
        `limit: ${blocked.headers.get('x-ratelimit-limit')}`
      )
      check(
        'error code is "rate_limited"',
        blocked.json?.code === 'rate_limited',
        `code: ${blocked.json?.code}`
      )
      check(
        'error message is user-friendly',
        !!blocked.json?.error && !blocked.json.error.includes('Error:'),
        `error: ${blocked.json?.error}`
      )
    }
  }

  // ─── 9. Rate limiting — generate endpoint ───────────────────────────
  console.log('\n[9] Rate limiting — /api/generate (10/min threshold)')
  {
    // Use invalid keyword so we get 400 fast — testing the limiter, not the pipeline
    const statuses = []
    let blocked = null
    for (let i = 0; i < 13; i++) {
      const r = await req('POST', '/api/generate', { keyword: '' })
      statuses.push(r.status)
      if (r.status === 429 && !blocked) blocked = r
    }
    check(
      'at least one request returns 429',
      !!blocked,
      `statuses: ${statuses.join(',')}`
    )
    if (blocked) {
      check(
        'limiter name exposed for debugging',
        !!blocked.json?.limiter,
        `limiter: ${blocked.json?.limiter}`
      )
    }
  }

  // ─── 10. Error handler — non-existent article returns 404 ────────────
  console.log('\n[10] Error handler — non-existent article returns 404')
  {
    const r = await req('GET', '/api/articles/non-existent-id-12345')
    check(
      'returns 404 (not 500)',
      r.status === 404 || r.status === 401,
      `got ${r.status}`
    )
  }

  // ─── 11. Stripe checkout — invalid tier rejected ────────────────────
  console.log('\n[11] Stripe checkout — invalid tier rejected')
  {
    const r = await req('POST', '/api/stripe/checkout', {
      tier: 'invalid',
    })
    check(
      'returns 400 (validation)',
      r.status === 400 || r.status === 401,
      `got ${r.status}`
    )
  }

  // ─── Summary ────────────────────────────────────────────────────────
  console.log('\n' + '━'.repeat(70))
  console.log(` Results: ${passed} passed, ${failed} failed`)
  console.log('━'.repeat(70))

  process.exit(failed > 0 ? 1 : 0)
}

// Add a hard 120s timeout so the suite never hangs indefinitely
setTimeout(() => {
  console.error('\n!! Test suite hit hard 120s timeout — aborting')
  process.exit(2)
}, 120_000)

main().catch((err) => {
  console.error('Test suite crashed:', err)
  process.exit(1)
})
