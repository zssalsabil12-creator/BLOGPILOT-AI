'use client';

import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import { Moon, Sun } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ThemeToggle() {
  const { theme, setTheme, systemTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- hydration-safe mounted flag; first render must match server
    setMounted(true);
  }, []);

  const current = theme === 'system' ? (systemTheme || 'dark') : theme;

  const toggle = () => {
    if (current === 'dark') {
      setTheme('light');
    } else {
      setTheme('dark');
    }
  };

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label="Toggle dark mode"
      className={cn(
        'inline-flex h-9 w-9 items-center justify-center rounded-2xl border border-border bg-background text-foreground transition hover:border-primary hover:text-primary',
      )}
    >
      {mounted && (current === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />)}
    </button>
  );
}
