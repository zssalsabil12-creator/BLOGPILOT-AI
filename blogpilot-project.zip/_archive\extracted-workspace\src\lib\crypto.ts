/**
 * Encryption utility for API keys and sensitive credentials.
 *
 * Uses AES-256-GCM via Node.js built-in `crypto` module.
 * In production, ENCRYPTION_KEY should be a 32-byte hex string stored in environment variables.
 * For local dev, we derive a key from a fixed fallback.
 */

import { createCipheriv, createDecipheriv, randomBytes, createHash } from 'crypto'

// 32-byte encryption key (from env or fallback for dev)
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'blogpilot-dev-key-32bytes-fallback!!!'
const ALGORITHM = 'aes-256-gcm'
const IV_LENGTH = 12
const AUTH_TAG_LENGTH = 16

/**
 * Normalize a key string to exactly 32 bytes using SHA-256.
 * This ensures we always have a valid AES-256 key regardless of input length.
 */
function normalizeKey(key: string): Buffer {
  return createHash('sha256').update(key).digest()
}

/**
 * Encrypt a plaintext string. Returns a base64-encoded string containing
 * the IV (12 bytes) + auth tag (16 bytes) + ciphertext.
 */
export function encrypt(plaintext: string): string {
  if (!plaintext) return ''

  const key = normalizeKey(ENCRYPTION_KEY)
  const iv = randomBytes(IV_LENGTH)
  const cipher = createCipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH,
  })

  let encrypted = cipher.update(plaintext, 'utf8', 'base64')
  encrypted += cipher.final('base64')
  const authTag = cipher.getAuthTag()

  // Combine: IV + authTag + ciphertext, all base64
  const combined = Buffer.concat([
    iv,
    authTag,
    Buffer.from(encrypted, 'base64'),
  ])

  return combined.toString('base64')
}

/**
 * Decrypt a base64-encoded string back to the original plaintext.
 */
export function decrypt(encoded: string): string {
  if (!encoded) return ''

  try {
    const key = normalizeKey(ENCRYPTION_KEY)
    const combined = Buffer.from(encoded, 'base64')

    // Extract IV, authTag, and ciphertext
    const iv = combined.subarray(0, IV_LENGTH)
    const authTag = combined.subarray(IV_LENGTH, IV_LENGTH + AUTH_TAG_LENGTH)
    const ciphertext = combined.subarray(IV_LENGTH + AUTH_TAG_LENGTH)

    const decipher = createDecipheriv(ALGORITHM, key, iv, {
      authTagLength: AUTH_TAG_LENGTH,
    })
    decipher.setAuthTag(authTag)

    let decrypted = decipher.update(ciphertext, undefined, 'utf8')
    decrypted += decipher.final('utf8')

    return decrypted
  } catch {
    // If decryption fails (e.g. corrupted data or wrong key), return empty
    console.error('[crypto] Decryption failed — data may be corrupted or key mismatch')
    return ''
  }
}
