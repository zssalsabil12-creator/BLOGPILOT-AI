﻿import crypto from 'node:crypto';
import { timingSafeStringCompare } from '@/lib/crypto';

export interface PayeerConfig {
  merchantId: string;
  secret: string;
  enabled: boolean;
}

export function getPayeerConfig(): PayeerConfig {
  const merchantId = process.env.PAYEER_MERCHANT_ID || '';
  const secret = process.env.PAYEER_SECRET || '';
  return { merchantId, secret, enabled: !!(merchantId && secret) };
}

export function buildPayeerSign(
  shopId: string,
  orderId: string,
  amount: string,
  currency: string,
  description: string,
  secret: string,
): string {
  return crypto.createHash('md5')
    .update(`${shopId}:${orderId}:${amount}:${currency}:${description}:${secret}`)
    .digest('hex');
}

export function buildPayeerUrl(params: { orderId: string; amount: number; currency?: string; description: string }): string {
  const cfg = getPayeerConfig();
  if (!cfg.enabled) throw new Error('Payeer is not configured');
  const currency = params.currency || 'USD';
  const amount = params.amount.toFixed(2);
  const sign = buildPayeerSign(cfg.merchantId, params.orderId, amount, currency, params.description, cfg.secret);
  const query = new URLSearchParams({
    m_shop: cfg.merchantId,
    m_orderid: params.orderId,
    m_amount: amount,
    m_curr: currency,
    m_desc: params.description,
    m_sign: sign,
  });
  return `https://payeer.com/merchant/?${query.toString()}`;
}

export function verifyPayeerCallback(params: Record<string, string>): boolean {
  const cfg = getPayeerConfig();
  if (!cfg.enabled) return false;
  const { m_shop, m_orderid, m_amount, m_curr, m_desc, m_sign, m_status } = params;
  if (!m_shop || !m_orderid || !m_amount || !m_curr || !m_desc || !m_sign) return false;
  if (m_status !== 'success') return false;
  const expected = buildPayeerSign(m_shop, m_orderid, m_amount, m_curr, m_desc, cfg.secret);
  return timingSafeStringCompare(expected, m_sign);
}