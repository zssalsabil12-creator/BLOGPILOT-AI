import { NextResponse } from 'next/server';
import { z } from 'zod';
import { suggestLinksForArticle } from '../../../../lib/linkLibrary';
import { getCurrentUserId } from '../../../../lib/auth';
import { apiError } from '@/lib/utils';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { checkTextLength } from '@/lib/input-limits';
const bodySchema = z.object({
  text: z.string().min(10).max(50000),
  keywords: z.array(z.string().min(1).max(100)).min(1).max(10).optional(),
});

function detectIntent(query: string) {
  const q = query.toLowerCase();
  if (q.match(/\b(buy|price|coupon|discount|best price|compare|vs|sale)\b/)) return 'transactional';
  if (q.match(/\b(how to|what is|why|guide|tutorial|how do i|tips|ways to|examples|best practices)\b/)) return 'informational';
  if (q.match(/\b(login|facebook|twitter|reddit|site:)\b/)) return 'navigational';
  if (q.match(/\b(review|best|top|vs|comparison)\b/)) return 'commercial';
  return 'informational';
}

function extractTopics(text: string, keywords?: string[]): string[] {
  const words = text
    .toLowerCase()
    .replace(/["'".,:;()\[\]{}<>\/\\!?@#$%^&*+=|~`]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 4 && !STOP_WORDS.has(w));
  const freq = new Map<string, number>();
  for (const w of words) freq.set(w, (freq.get(w) || 0) + 1);
  const top = Array.from(freq.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 20)
    .map(([w]) => w);
  if (keywords && keywords.length > 0) {
    return [...new Set([...keywords.map((k) => k.toLowerCase()), ...top])];
  }
  return top;
}

const STOP_WORDS = new Set([
  'about', 'which', 'there', 'their', 'these', 'other', 'after', 'before',
  'where', 'under', 'while', 'with', 'from', 'some', 'than', 'that', 'this',
  'will', 'each', 'just', 'also', 'more', 'very', 'most', 'only', 'when',
  'then', 'what', 'when', 'your', 'into', 'over', 'such', 'make', 'like',
  'could', 'would', 'should', 'might', 'being', 'those', 'having', 'doing',
  'through', 'between', 'during', 'again', 'being', 'because', 'however',
]);

export async function POST(req: Request) {
  // Public endpoint — throttle per IP before any outbound work.
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`free-tool:${ip}`, RATE_LIMITS.publicApi);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait a moment and try again.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const parse = bodySchema.safeParse(body);
  if (!parse.success) {
    return NextResponse.json(
      { error: 'Invalid input', details: parse.error.flatten() },
      { status: 400 }
    );
  }

  const textSizeCheck = checkTextLength(parse.data.text);
  if (!textSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: textSizeCheck.error }, { status: 413 });
  }

  const userId = getCurrentUserId(req);
  const { text, keywords } = parse.data;
  const topics = extractTopics(text, keywords);
  const intent = detectIntent(text);

  try {
    const suggestions = await suggestLinksForArticle({
      query: text.slice(0, 200),
      searchIntent: intent,
      topics,
      topResultsUrls: [],
      userId: userId || null,
    });

    return NextResponse.json({
      ok: true,
      results: {
        suggestions,
        detectedTopics: topics.slice(0, 10),
        searchIntent: intent,
        totalLinksInLibrary: suggestions.length,
      },
    });
  } catch (err) {
    return apiError('free-tools/internal-link-finder', err);
  }
}
