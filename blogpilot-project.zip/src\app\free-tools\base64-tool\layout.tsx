﻿import type { Metadata } from 'next';
import { ToolSeo } from '@/components/free-tools/tool-seo';
import { toolPageMetadata } from '@/lib/free-tools/tool-page';

export const metadata: Metadata = toolPageMetadata('base64-tool');

export default function Layout({ children }: { children: React.ReactNode }) {
  return <ToolSeo slug="base64-tool">{children}</ToolSeo>;
}
