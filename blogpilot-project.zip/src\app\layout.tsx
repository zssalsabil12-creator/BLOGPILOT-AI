﻿import type { Metadata } from 'next';
import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { AppShell } from '@/components/app-shell';
import { SITE_NAME, SITE_TAGLINE, getSiteUrl } from '@/lib/site';

const siteUrl = getSiteUrl();

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: `${SITE_NAME} — ${SITE_TAGLINE} & AI Content for WordPress`,
    template: `%s | ${SITE_NAME}`,
  },
  description:
    'Connect your website, let the AI agent research competitors, write SEO-optimized articles with verified sources, and publish them directly to your WordPress or Blogger site.',
  applicationName: SITE_NAME,
  keywords: [
    'AI SEO agent',
    'AI article writer',
    'SEO content automation',
    'WordPress AI publishing',
    'affiliate content generator',
    'free SEO tools',
    'content optimization',
  ],
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    url: siteUrl,
    siteName: SITE_NAME,
    title: `${SITE_NAME} — ${SITE_TAGLINE} & AI Content for WordPress`,
    description:
      'Research → write → optimize → publish: an AI agent that grows organic traffic for your website with SEO-verified articles.',
    locale: 'en_US',
  },
  twitter: {
    card: 'summary_large_image',
    title: `${SITE_NAME} — ${SITE_TAGLINE}`,
    description:
      'An AI SEO growth agent that researches, writes, optimizes, and publishes ranking-ready articles to your website.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  icons: { icon: '/logo.svg' },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          themes={['light', 'dark']}
          disableTransitionOnChange
        >
          <AppShell>{children}</AppShell>
        </ThemeProvider>
      </body>
    </html>
  );
}
