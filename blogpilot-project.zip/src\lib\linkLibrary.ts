/*
  Prisma-backed Link Library
  Replaces file-based persistence with SQLite/Postgres via Prisma.

  Notes:
  - All functions that mutate or read user-specific data require a userId to enforce ownership.
  - URL validation is intentionally conservative; add a reputation service for stronger production checks.
*/

import prisma from './prisma';
import { z } from 'zod';

export type LinkType =
  | 'GENERAL'
  | 'ARTICLE'
  | 'TOOL'
  | 'SOFTWARE'
  | 'SERVICE'
  | 'PRODUCT'
  | 'AFFILIATE'
  | 'RESOURCE'
  | 'OTHER';

export type SafetyStatus = 'UNKNOWN' | 'SAFE' | 'UNSAFE' | 'REVIEW';

export type SavedLink = {
  id: string;
  userId: string;
  url: string;
  urlNormalized: string;
  title?: string;
  description?: string;
  category?: string;
  linkType?: LinkType;
  affiliate?: boolean;
  affiliateProvider?: string | null;
  anchorText?: string | null;
  targetKeyword?: string | null;
  preferredPlacement?: string | null;
  active?: boolean;
  safetyStatus?: SafetyStatus;
  safetyReason?: string | null;
  productInfo?: any | null;
  createdAt: string;
  updatedAt: string;
};

export const LINK_TYPES: LinkType[] = ['GENERAL', 'ARTICLE', 'TOOL', 'SOFTWARE', 'SERVICE', 'PRODUCT', 'AFFILIATE', 'RESOURCE', 'OTHER'];
const BLOCKLISTED_HOSTS = new Set(['example-malware.test', 'malicious.test', 'phishing.test']);

export function normalizeUrl(urlStr: string) {
  const u = new URL(urlStr);
  const protocol = u.protocol.toLowerCase();
  const hostname = u.hostname.toLowerCase();
  let pathname = u.pathname.replace(/\/+/g, '/');
  if (pathname !== '/' && pathname.endsWith('/')) pathname = pathname.slice(0, -1);
  const params = new URLSearchParams(u.searchParams);
  const sortedParams = new URLSearchParams();
  Array.from(params.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .forEach(([key, value]) => sortedParams.append(key, value));
  const search = sortedParams.toString();
  const port = u.port && !['80', '443'].includes(u.port) ? `:${u.port}` : '';
  return `${protocol}//${hostname}${port}${pathname}${search ? `?${search}` : ''}`;
}

export function evaluateUrlSafety(urlStr: string) {
  try {
    const u = new URL(urlStr);
    if (!['http:', 'https:'].includes(u.protocol)) return { status: 'UNSAFE' as const, reason: 'Only http(s) URLs are allowed.' };
    const host = u.hostname.toLowerCase();
    if (BLOCKLISTED_HOSTS.has(host)) return { status: 'UNSAFE' as const, reason: 'This domain is explicitly blocked.' };
    if (host === 'localhost' || host.endsWith('.local') || host === '127.0.0.1' || host === '::1') {
      return { status: 'UNSAFE' as const, reason: 'Localhost or internal addresses are not allowed.' };
    }
    if (/^10\.|^127\.|^192\.168\.|^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host)) {
      return { status: 'UNSAFE' as const, reason: 'Private network addresses are not allowed.' };
    }
    if (u.protocol === 'http:') {
      return { status: 'REVIEW' as const, reason: 'Non-HTTPS URLs are allowed but should be reviewed.' };
    }
    return { status: 'SAFE' as const, reason: 'URL is valid and uses HTTPS.' };
  } catch (error: any) {
    return { status: 'UNSAFE' as const, reason: 'Invalid URL format.' };
  }
}

export const createLinkBodySchema = z.object({
  url: z.string().url(),
  title: z.string().max(200).optional(),
  description: z.string().max(2000).optional(),
  category: z.string().max(100).optional(),
  linkType: z.enum(LINK_TYPES).optional(),
  affiliate: z.boolean().optional(),
  affiliateProvider: z.string().max(100).optional().nullable(),
  anchorText: z.string().max(100).optional().nullable(),
  targetKeyword: z.string().max(100).optional().nullable(),
  preferredPlacement: z.string().max(100).optional().nullable(),
  active: z.boolean().optional(),
  productInfo: z.any().optional().nullable(),
});

async function ensureUserExists(userId: string) {
  await prisma.user.upsert({
    where: { id: userId },
    update: {},
    create: { id: userId },
  });
}

async function findDuplicateLink(userId: string, url: string, excludingId?: string) {
  const normalized = normalizeUrl(url);
  const candidate = await prisma.link.findFirst({
    where: {
      userId,
      urlNormalized: normalized,
      ...(excludingId ? { NOT: { id: excludingId } } : {}),
    },
  });
  return candidate;
}

export async function addLink(userId: string, payload: unknown) {
  const parsed = createLinkBodySchema.parse(payload);
  await ensureUserExists(userId);
  const normalizedUrl = normalizeUrl(parsed.url);
  const duplicate = await findDuplicateLink(userId, parsed.url);
  if (duplicate) {
    throw new Error('You already added this URL to your Link Library.');
  }

  const safety = evaluateUrlSafety(parsed.url);
  const saved = await prisma.link.create({
    data: {
      userId,
      url: parsed.url,
      urlNormalized: normalizedUrl,
      title: parsed.title || null,
      description: parsed.description || null,
      category: parsed.category || null,
      linkType: parsed.linkType || 'GENERAL',
      affiliate: !!parsed.affiliate,
      affiliateProvider: parsed.affiliateProvider || null,
      anchorText: parsed.anchorText || null,
      targetKeyword: parsed.targetKeyword || null,
      preferredPlacement: parsed.preferredPlacement || null,
      active: typeof parsed.active === 'boolean' ? parsed.active : true,
      safetyStatus: safety.status,
      safetyReason: safety.reason,
      productInfo: parsed.productInfo || null,
    },
  });
  return saved as unknown as SavedLink;
}

export async function updateLink(userId: string, id: string, patch: Partial<SavedLink>) {
  const existing = await prisma.link.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) return null;

  const updateData: any = {};
  if (patch.url) {
    const normalizedUrl = normalizeUrl(patch.url);
    const duplicate = await findDuplicateLink(userId, patch.url, id);
    if (duplicate) {
      throw new Error('A link with this URL already exists in your library.');
    }
    const safety = evaluateUrlSafety(patch.url);
    updateData.url = patch.url;
    updateData.urlNormalized = normalizedUrl;
    updateData.safetyStatus = safety.status;
    updateData.safetyReason = safety.reason;
  }
  if (patch.title !== undefined) updateData.title = patch.title || null;
  if (patch.description !== undefined) updateData.description = patch.description || null;
  if (patch.category !== undefined) updateData.category = patch.category || null;
  if (patch.linkType !== undefined) updateData.linkType = patch.linkType;
  if (patch.affiliate !== undefined) updateData.affiliate = !!patch.affiliate;
  if (patch.affiliateProvider !== undefined) updateData.affiliateProvider = patch.affiliateProvider || null;
  if (patch.anchorText !== undefined) updateData.anchorText = patch.anchorText || null;
  if (patch.targetKeyword !== undefined) updateData.targetKeyword = patch.targetKeyword || null;
  if (patch.preferredPlacement !== undefined) updateData.preferredPlacement = patch.preferredPlacement || null;
  if (patch.active !== undefined) updateData.active = !!patch.active;
  if (patch.productInfo !== undefined) updateData.productInfo = patch.productInfo || null;

  const updated = await prisma.link.update({ where: { id }, data: updateData });
  return updated as unknown as SavedLink;
}

export async function deleteLink(userId: string, id: string) {
  const existing = await prisma.link.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) return false;
  await prisma.link.delete({ where: { id } });
  return true;
}

export async function getLinkById(userId: string, id: string) {
  const link = await prisma.link.findUnique({ where: { id } });
  if (!link || link.userId !== userId) return null;
  return link as unknown as SavedLink;
}

export async function listLinks(userId: string, opts?: {
  q?: string;
  category?: string;
  linkType?: LinkType;
  affiliate?: boolean | null;
  active?: boolean | null;
  safetyStatus?: SafetyStatus;
  limit?: number;
  offset?: number;
}) {
  const where: any = { userId };
  if (opts?.q) {
    const q = opts.q;
    where.OR = [
      { title: { contains: q } },
      { description: { contains: q } },
      { url: { contains: q } },
      { category: { contains: q } },
      { targetKeyword: { contains: q } },
      { affiliateProvider: { contains: q } },
    ];
  }
  if (opts?.category) where.category = opts.category;
  if (opts?.linkType) where.linkType = opts.linkType;
  if (typeof opts?.affiliate === 'boolean') where.affiliate = opts!.affiliate;
  if (typeof opts?.active === 'boolean') where.active = opts!.active;
  if (opts?.safetyStatus) where.safetyStatus = opts.safetyStatus;

  const links = await prisma.link.findMany({ where, orderBy: { updatedAt: 'desc' }, take: opts?.limit || 100, skip: opts?.offset || 0 });
  return links as unknown as SavedLink[];
}

export async function suggestLinksForArticle(params: {
  query: string;
  searchIntent: string;
  topics: string[];
  topResultsUrls: string[];
  userId?: string | null;
}) {
  const { query, searchIntent, topics, userId } = params;
  if (!userId) return [];

  const q = query.toLowerCase();
  const library = await prisma.link.findMany({
    where: {
      userId,
      active: true,
      NOT: { safetyStatus: 'UNSAFE' },
    },
  });

  const suggestions: Array<any> = [];
  for (const l of library) {
    const tk = (l.targetKeyword || '').toLowerCase();
    const matchesTarget = tk && (q.includes(tk) || topics.some((t) => t.includes(tk)));
    const titleLower = (l.title || '').toLowerCase();
    const descLower = (l.description || '').toLowerCase();
    const urlLower = (l.url || '').toLowerCase();
    const matchesTopic = topics.some((t) => titleLower.includes(t) || descLower.includes(t) || urlLower.includes(t));

    if (matchesTarget || matchesTopic || (l.category && topics.some((t) => (l.category || '').toLowerCase().includes(t)))) {
      let monetization: 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE' = 'NONE';
      if (l.affiliate && ['PRODUCT', 'SERVICE', 'TOOL', 'SOFTWARE', 'AFFILIATE'].includes(l.linkType || '')) monetization = 'HIGH';
      else if (l.affiliate) monetization = 'MEDIUM';

      const suggestedAnchor = l.anchorText || (l.title ? l.title.split(' ').slice(0, 5).join(' ') : l.url);
      const suggestedPlacement = l.preferredPlacement || (searchIntent === 'transactional' ? 'comparison-table' : 'relevant-section');

      suggestions.push({
        link: l,
        reason: matchesTarget ? `Matches target keyword '${l.targetKeyword}'` : `Relevant to topic keywords: ${topics.slice(0, 4).join(', ')}`,
        suggestedAnchor,
        suggestedPlacement,
        monetizationPotential: monetization,
      });
    }
  }

  suggestions.sort((a, b) => {
    const ma = a.monetizationPotential === 'HIGH' ? 1 : 0;
    const mb = b.monetizationPotential === 'HIGH' ? 1 : 0;
    if (ma !== mb) return mb - ma;
    const aq = (a.link.url || '').includes(q) ? 1 : 0;
    const bq = (b.link.url || '').includes(q) ? 1 : 0;
    return bq - aq;
  });

  return suggestions.slice(0, 10);
}
