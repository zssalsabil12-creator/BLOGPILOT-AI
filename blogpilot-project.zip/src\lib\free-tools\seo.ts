import type { Metadata } from 'next';
import { SITE_NAME, absoluteUrl } from '@/lib/site';

export function freeToolMetadata(opts: {
  title: string;
  description: string;
  path: string;
  openGraphTitle?: string;
  openGraphDescription?: string;
}): Metadata {
  const url = absoluteUrl(opts.path);
  return {
    // Root layout applies the "%s | BlogPilot AI" template — do not
    // include the brand name here or it will be duplicated.
    title: `${opts.title} — Free Tool`,
    description: opts.description,
    alternates: { canonical: url },
    openGraph: {
      title: opts.openGraphTitle || `${opts.title} — Free Tool`,
      description: opts.openGraphDescription || opts.description,
      type: 'website',
      url,
      siteName: SITE_NAME,
    },
    twitter: {
      card: 'summary_large_image',
      title: opts.openGraphTitle || opts.title,
      description: opts.openGraphDescription || opts.description,
    },
  };
}

export function toolJsonLd(tool: {
  name: string;
  description: string;
  url: string;
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: tool.name,
    description: tool.description,
    url: tool.url,
    applicationCategory: 'SEOApplication',
    operatingSystem: 'Web',
    browserRequirements: 'Requires JavaScript',
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
    },
    publisher: {
      '@type': 'Organization',
      name: SITE_NAME,
    },
  };
}

export function faqJsonLd(faqs: Array<{ question: string; answer: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer,
      },
    })),
  };
}

export function breadcrumbJsonLd(items: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  };
}
