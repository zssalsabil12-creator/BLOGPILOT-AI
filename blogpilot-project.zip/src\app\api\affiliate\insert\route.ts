import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { insertCampaignLink } from '@/lib/affiliate';

const insertSchema = z.object({
  campaignId: z.string().min(1).max(64),
  articleId: z.string().min(1).max(64),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = insertSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const limit = await checkRateLimit(`aff-insert:${userId}`, { windowMs: 60_000, maxRequests: 15 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests' }, { status: 429 });
  }

  try {
    const result = await insertCampaignLink(userId, parsed.data.campaignId, parsed.data.articleId);
    // Recompute SEO score after content change.
    const prisma = (await import('@/lib/prisma')).default;
    const { computeSeoScore } = await import('@/lib/seo-score');
    const article = await prisma.article.findFirst({
      where: { id: parsed.data.articleId, userId },
      select: { id: true, title: true, content: true, excerpt: true, targetKeyword: true },
    });
    if (article) {
      const seo = computeSeoScore(article);
      await prisma.article.update({ where: { id: article.id }, data: { seoScore: seo.score } });
    }
    return NextResponse.json({ ok: true, data: result });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 502;
    return NextResponse.json({ ok: false, error: error?.message || 'Insertion failed' }, { status });
  }
}
