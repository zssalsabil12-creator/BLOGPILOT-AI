﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId, getCurrentUser } from '@/lib/auth';

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      return NextResponse.json({ ok: false, error: 'User not found' }, { status: 404 });
    }

    const transactions = await prisma.creditTransaction.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    return NextResponse.json({
      ok: true,
      data: {
        credits: user.credits,
        totalCreditsUsed: user.totalCreditsUsed,
        freeCreditsUsed: user.freeCreditsUsed,
        plan: (await getCurrentUser(req))?.subscription?.plan || 'free',
        transactions: transactions.map(tx => ({
          id: tx.id,
          amount: tx.amount,
          reason: tx.reason,
          description: tx.description,
          balanceAfter: tx.balanceAfter,
          createdAt: tx.createdAt,
        })),
      },
    });
  } catch (error: any) {
    console.error('Get credits error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load credits' }, { status: 500 });
  }
}

const grantSchema = z.object({
  amount: z.number().int().min(1).max(100),
  reason: z.string().min(1).max(100).optional(),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = grantSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) {
    return NextResponse.json({ ok: false, error: 'User not found' }, { status: 404 });
  }

  // Case-insensitive admin check (User.role defaults to lowercase 'user').
  const isAdmin = String((user as any).role || '').toLowerCase() === 'admin';
  if (!isAdmin) {
    return NextResponse.json({ ok: false, error: 'Forbidden: admin access required' }, { status: 403 });
  }

  try {
    const { grantCredits } = await import('@/lib/billing');
    const updated = await grantCredits(
      userId,
      parsed.data.amount,
      parsed.data.reason || 'admin_grant',
      parsed.data.reason ? null : 'Credits granted by admin',
    );
    return NextResponse.json({ ok: true, data: { credits: updated.credits } });
  } catch (error: any) {
    console.error('Grant credits error:', error);
    return NextResponse.json({ ok: false, error: error?.message === 'User not found' ? 'User not found' : 'Unable to update credits' }, { status: error?.message === 'User not found' ? 404 : 500 });
  }
}
