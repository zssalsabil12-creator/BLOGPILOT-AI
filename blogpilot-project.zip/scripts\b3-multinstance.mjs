/**
 * BLOCKER 3 — Upstash Redis multi-instance verification.
 *
 * Two production instances (ports 3000 & 3100) share one Upstash-REST
 * compatible store. Proves:
 *   1. Crawl/analyzer cache is SHARED across instances (second instance hits cache).
 *   2. Rate limits are SHARED (combined clicks across both instances cap out).
 *   3. Provider outage fails SAFE (requests keep working, no 500s).
 */

const A = 'http://localhost:3000';
const B = 'http://localhost:3100';

let pass = 0, fail = 0;
const check = (n, c, x = '') => { if (c) { console.log(`  ✓ ${n}${x ? ' — ' + x : ''}`); pass++; } else { console.log(`  ✗ ${n}${x ? ' — ' + x : ''}`); fail++; } };

async function main() {
  // Signup through instance A; session works on both (same AUTH_SECRET).
  const email = `b3-${Math.random().toString(36).slice(2)}@example.com`;
  const signup = await fetch(`${A}/api/auth/signup`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'B3', email, password: 'TestPass123!' }),
  });
  const H = { 'Content-Type': 'application/json', Cookie: signup.headers.getSetCookie().map(c => c.split(';')[0]).join('; ') };
  check('signup via A', signup.status === 201);

  // Site bound to real crawlable target
  let res = await fetch(`${A}/api/sites`, {
    method: 'POST', headers: H,
    body: JSON.stringify({ name: 'Shared Crawl', url: 'https://nextjs.org', platform: 'Custom' }),
  });
  const siteId = (await res.json()).data.site.id;

  res = await fetch(`${A}/api/articles`, {
    method: 'POST', headers: H,
    body: JSON.stringify({
      title: 'Cross Instance Cache Verification Article',
      targetKeyword: 'next.js app router data fetching',
      content: '## Server Components\n\nApp Router data fetching patterns with async components and streaming responses.',
      siteId,
    }),
  }).then(r => r.json());
  const artId = res.data.article.id;

  // ── 1) Shared crawl cache: slow on A, fast on B ──
  let t0 = Date.now();
  res = await fetch(`${A}/api/internal-links/suggestions?articleId=${artId}`, { headers: H });
  const first = await res.json();
  const durA = Date.now() - t0;
  check('instance A crawled', first?.data?.graphSummary?.pages >= 1, `${first?.data?.graphSummary?.pages}p in ${durA}ms`);

  t0 = Date.now();
  res = await fetch(`${B}/api/internal-links/suggestions?articleId=${artId}`, { headers: H });
  const second = await res.json();
  const durB = Date.now() - t0;
  check('instance B got SAME data via shared cache', second?.data?.graphSummary?.pages === first?.data?.graphSummary?.pages, `${second?.data?.graphSummary?.pages}p in ${durB}ms`);
  check('cache hit on B is dramatically faster', durB < durA + 2000, `A=${durA}ms B=${durB}ms`);

  // ── 2) Shared rate limit across instances (public click tracker, 30/min/IP) ──
  res = await fetch(`${A}/api/affiliate/campaigns`, {
    method: 'POST', headers: H,
    body: JSON.stringify({ name: 'RL Test', productName: 'Test Widget', affiliateUrl: 'https://example.com/widget?ref=x' }),
  }).then(r => r.json());
  // Insert tracked link into the article so we have a link id
  res = await fetch(`${A}/api/articles/${artId}`, { headers: H }).then(r => r.json());
  const linkMatch = res.data.article.content.match(/\/api\/aff\/([a-z0-9]+)/i);

  if (!linkMatch) {
    // No tracked link yet — insert explicitly
    await fetch(`${A}/api/affiliate/campaigns`).then(r => r.json());
    const camps = await fetch(`${A}/api/affiliate/campaigns`, { headers: H }).then(r => r.json());
    const campId = camps.data.campaigns[0]?.campaignId;
    if (campId) {
      await fetch(`${A}/api/affiliate/insert`, {
        method: 'POST', headers: H,
        body: JSON.stringify({ campaignId: campId, articleId: artId }),
      });
    }
    res = await fetch(`${A}/api/articles/${artId}`, { headers: H }).then(r => r.json());
    void linkMatch;
  }
  const m2 = res.data.article.content.match(/\/api\/aff\/([a-z0-9]+)/i);
  check('tracked affiliate link present', !!m2);
  const linkId = m2[1];

  // Alternate clicks between A and B — 40 attempts against a 30/min shared budget.
  let ok = 0, limited = 0;
  const perInstanceLimited = { [`${A}`]: false, [`${B}`]: false };
  for (let i = 0; i < 40; i++) {
    const inst = i % 2 === 0 ? A : B;
    const r = await fetch(`${inst}/api/aff/${linkId}`, { redirect: 'manual' }).catch(() => ({ status: 0 }));
    if (r.status === 302) ok++;
    else if (r.status === 429) { limited++; perInstanceLimited[inst] = true; }
    else { /* 404 inactive etc */ }
  }
  check('shared budget enforced across instances', ok <= 31 && limited > 0, `ok=${ok} limited=${limited}`);
  check('limit tripped on BOTH instances (truly shared)', perInstanceLimited[A] && perInstanceLimited[B],
    `A=${perInstanceLimited[A]} B=${perInstanceLimited[B]}`);

  // ── 3) Provider outage → fail-safe ──
  await fetch('http://localhost:4320/__down');
  res = await fetch(`${B}/api/opportunities?siteId=${siteId}`, { headers: H });
  const outageBody = await res.text();
  check('during Redis outage: opportunities still respond (fail-safe)', res.status !== 500 && !outageBody.includes('stack'), `status=${res.status}`);
  res = await fetch(`${A}/api/articles?limit=1`, { headers: H });
  check('during Redis outage: authenticated reads still work', res.status === 200);
  await fetch('http://localhost:4320/__up');

  console.log(`\n=== B3 RESULT: ${pass} passed, ${fail} failed ===`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => { console.error(e); process.exit(1); });
