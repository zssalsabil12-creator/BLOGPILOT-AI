import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { applyLinks } from '@/lib/internal-links';
import { computeSeoScore } from '@/lib/seo-score';

const applySchema = z.object({
  articleId: z.string().min(1).max(64),
  targets: z.array(z.object({
    path: z.string().min(1).max(300),
    title: z.string().max(300),
  })).min(1).max(10),
});

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = applySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const limit = await checkRateLimit(`intlinks-apply:${userId}`, { windowMs: 60_000, maxRequests: 12 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  try {
    const { articleId } = parsed.data;
    const result = await applyLinks(userId, articleId, parsed.data.targets);

    // Recompute SEO score server-side after the content change.
    const article = await prisma.article.findFirst({
      where: { id: articleId, userId },
      select: { id: true, title: true, content: true, excerpt: true, targetKeyword: true },
    });
    if (article) {
      const seo = computeSeoScore(article);
      await prisma.article.update({ where: { id: article.id }, data: { seoScore: seo.score } });
    }

    return NextResponse.json({ ok: true, data: { applied: result.applied } });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 502;
    return NextResponse.json({ ok: false, error: error?.message || 'Failed to apply links' }, { status });
  }
}
