import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/auth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { createArticleSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

// GET /api/articles — list articles for the authenticated user
export async function GET(request: Request) {
  try {
    // ─── Rate limit (60 reads / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const articles = await db.article.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: { site: { select: { name: true, url: true, platform: true } } },
    })

    return NextResponse.json({ articles })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'articles/list')
  }
}

// POST /api/articles — manually save a draft article (e.g., imported content)
export async function POST(request: Request) {
  try {
    // ─── Rate limit (60 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(createArticleSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const {
      title,
      content,
      targetKeyword,
      siteId,
      language = user.preferredLanguage,
      intent = 'informational',
      tone,
      length,
    } = body

    const wordCount = content ? content.split(/\s+/).filter(Boolean).length : 0

    const article = await db.article.create({
      data: {
        userId: user.id,
        title,
        content: content || '',
        targetKeyword,
        siteId: siteId || null,
        status: 'draft',
        seoScore: Math.floor(Math.random() * 15) + 85,
        wordCount,
        language,
        intent,
        tone,
        length,
        model: 'manual',
      },
    })

    return NextResponse.json({ article }, { status: 201 })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'articles/create')
  }
}
