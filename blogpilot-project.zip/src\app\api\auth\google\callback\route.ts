import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import prisma from '@/lib/prisma';
import { createSessionToken, COOKIE_NAME } from '@/lib/auth';
import {
  exchangeSignInCode,
  GOOGLE_SIGNIN_STATE_COOKIE,
} from '@/lib/google-signin';

function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error('AUTH_SECRET is required');
  return secret;
}

function verifyStateSig(payload: string, sig: string): boolean {
  const hmac = crypto.createHmac('sha256', getAuthSecret());
  hmac.update(payload);
  const expected = hmac.digest('base64url');
  try {
    return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}

function parseCookie(req: Request, name: string): string | null {
  const cookieHeader = req.headers.get('cookie');
  if (!cookieHeader) return null;
  const match = cookieHeader.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

function loginRedirect(req: Request, error: string): NextResponse {
  const res = NextResponse.redirect(new URL(`/login?error=${encodeURIComponent(error)}`, req.url));
  res.cookies.set(GOOGLE_SIGNIN_STATE_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
  return res;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const oauthError = url.searchParams.get('error');

  if (oauthError) {
    return loginRedirect(req, oauthError === 'access_denied' ? 'google_denied' : 'google_error');
  }

  if (!code || !state) {
    return loginRedirect(req, 'google_invalid_response');
  }

  const cookieState = parseCookie(req, GOOGLE_SIGNIN_STATE_COOKIE);
  if (!cookieState || cookieState !== state) {
    return loginRedirect(req, 'google_state_mismatch');
  }

  try {
    const dotIdx = state.indexOf('.');
    if (dotIdx === -1) throw new Error('Missing signature');

    const payloadB64 = state.substring(0, dotIdx);
    const sig = state.substring(dotIdx + 1);
    const decoded = JSON.parse(Buffer.from(payloadB64, 'base64url').toString());

    if (!decoded.nonce || !decoded.ts || Date.now() - decoded.ts > 600_000) {
      throw new Error('Invalid or expired state');
    }
    if (!verifyStateSig(payloadB64, sig)) {
      throw new Error('Invalid state signature');
    }

    const profile = await exchangeSignInCode(code);

    if (!profile.emailVerified) {
      return loginRedirect(req, 'google_email_unverified');
    }

    let user = await prisma.user.findUnique({ where: { email: profile.email } });

    if (!user) {
      user = await prisma.user.create({
        data: {
          email: profile.email,
          name: profile.name || profile.email.split('@')[0],
          image: profile.picture,
          passwordHash: null,
        },
      });
    } else {
      const updates: { name?: string; image?: string } = {};
      if (!user.name && profile.name) updates.name = profile.name;
      if (!user.image && profile.picture) updates.image = profile.picture;
      if (Object.keys(updates).length > 0) {
        await prisma.user.update({ where: { id: user.id }, data: updates });
      }
    }

    const token = createSessionToken({
      userId: user.id,
      email: user.email,
      name: user.name,
    });

    const res = NextResponse.redirect(new URL('/dashboard', req.url));
    res.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60,
      path: '/',
    });
    res.cookies.set(GOOGLE_SIGNIN_STATE_COOKIE, '', { httpOnly: true, path: '/', maxAge: 0 });
    return res;
  } catch (err) {
    console.error('Google sign-in callback error:', err);
    return loginRedirect(req, 'google_signin_failed');
  }
}
