/**
 * Stripe integration library for BlogPilot AI.
 *
 * Responsibilities:
 *   - Expose a singleton Stripe client (lazy-initialized).
 *   - Map Stripe Price IDs → app plans (free / basic / pro / agency).
 *   - Map plans → monthly credit allotments.
 *   - Provide graceful "demo mode" when STRIPE_SECRET_KEY is not configured:
 *       getStripe() returns null
 *       callers should fall back to a simulated checkout / portal flow.
 *
 * Environment variables:
 *   STRIPE_SECRET_KEY        — sk_test_... / sk_live_...
 *   STRIPE_PUBLISHABLE_KEY   — pk_test_... / pk_live_... (used client-side)
 *   STRIPE_WEBHOOK_SECRET    — whsec_... (used by /api/stripe/webhook)
 *   STRIPE_PRICE_BASIC       — price_... for Basic plan
 *   STRIPE_PRICE_PRO         — price_... for Pro plan
 *   STRIPE_PRICE_AGENCY      — price_... for Agency plan
 *
 * If the price env vars are missing, we synthesize deterministic placeholder
 * IDs ("price_demo_basic", etc.) so the pricing UI still renders and the
 * checkout endpoint can return a "demo" checkout URL instead of crashing.
 */

import Stripe from 'stripe'
import { db } from '@/lib/db'
import { addCredits } from '@/lib/auth'

/* -------------------------------------------------------------------------- */
/*                              Plan → Credits map                            */
/* -------------------------------------------------------------------------- */

export type PlanTier = 'free' | 'basic' | 'pro' | 'agency'

interface PlanConfig {
  /** Display name */
  label: string
  /** Monthly credit allotment. `null` = unlimited. */
  credits: number | null
  /** Monthly price in USD cents (for display only — actual price comes from Stripe). */
  priceUsdCents: number
  /** Stripe Price ID env var name */
  priceEnvVar: string
  /** Fallback demo price ID */
  fallbackPriceId: string
  /** Hex accent color for badges / cards */
  accent: string
  /** Short marketing blurb */
  blurb: string
}

export const PLAN_CONFIG: Record<PlanTier, PlanConfig> = {
  free: {
    label: 'Free',
    credits: 10,
    priceUsdCents: 0,
    priceEnvVar: '',
    fallbackPriceId: '',
    accent: '#64748b',
    blurb: 'Try the platform with 10 free credits — no card required.',
  },
  basic: {
    label: 'Basic',
    credits: 20,
    priceUsdCents: 1900,
    priceEnvVar: 'STRIPE_PRICE_BASIC',
    fallbackPriceId: 'price_demo_basic',
    accent: '#3b82f6',
    blurb: '20 credits per month. Perfect for solo bloggers getting started.',
  },
  pro: {
    label: 'Pro',
    credits: 100,
    priceUsdCents: 4900,
    priceEnvVar: 'STRIPE_PRICE_PRO',
    fallbackPriceId: 'price_demo_pro',
    accent: '#8b5cf6',
    blurb: '100 credits per month. For agencies and power users scaling content.',
  },
  agency: {
    label: 'Agency',
    credits: null, // unlimited
    priceUsdCents: 19900,
    priceEnvVar: 'STRIPE_PRICE_AGENCY',
    fallbackPriceId: 'price_demo_agency',
    accent: '#f59e0b',
    blurb: 'Unlimited credits, priority AI, and multi-site publishing.',
  },
}

/** Order matters — used for upgrade picker UI. */
export const PAID_PLAN_TIERS: PlanTier[] = ['basic', 'pro', 'agency']

/** Reverse-lookup: Stripe Price ID → PlanTier. */
export function tierFromPriceId(priceId: string): PlanTier | null {
  for (const tier of PAID_PLAN_TIERS) {
    const configured = getConfiguredPriceId(tier)
    if (configured === priceId) return tier
  }
  // Also match fallback demo IDs
  for (const tier of PAID_PLAN_TIERS) {
    if (PLAN_CONFIG[tier].fallbackPriceId === priceId) return tier
  }
  return null
}

/** Get the configured Stripe Price ID for a tier (or fallback demo id). */
export function getConfiguredPriceId(tier: PlanTier): string {
  const cfg = PLAN_CONFIG[tier]
  if (!cfg.priceEnvVar) return cfg.fallbackPriceId
  return process.env[cfg.priceEnvVar] || cfg.fallbackPriceId
}

/** Whether Stripe is fully configured (secret key + webhook secret). */
export function isStripeConfigured(): boolean {
  return !!(
    process.env.STRIPE_SECRET_KEY &&
    process.env.STRIPE_WEBHOOK_SECRET &&
    process.env.STRIPE_PRICE_BASIC &&
    process.env.STRIPE_PRICE_PRO
  )
}

/* -------------------------------------------------------------------------- */
/*                              Stripe client                                 */
/* -------------------------------------------------------------------------- */

let stripeInstance: Stripe | null = null

/**
 * Lazy-init Stripe client. Returns null when STRIPE_SECRET_KEY is not set
 * (demo mode) — callers MUST null-check.
 */
export function getStripe(): Stripe | null {
  if (stripeInstance) return stripeInstance
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) return null
  stripeInstance = new Stripe(key, {
    apiVersion: '2025-08-27.basil' as Stripe.LatestApiVersion,
    typescript: true,
  })
  return stripeInstance
}

/** True when we're running in demo mode (no Stripe secret key). */
export function isDemoMode(): boolean {
  return !process.env.STRIPE_SECRET_KEY
}

/* -------------------------------------------------------------------------- */
/*                    Shared subscription activation helper                   */
/* -------------------------------------------------------------------------- */
/* Used by Stripe / PayPal / Payeer webhook handlers to flip a user's
 * subscription to "active" after a confirmed payment. Centralised so all
 * three gateways apply identical database side-effects.
 */

export interface ActivateSubscriptionResult {
  ok: boolean
  /** 'created' | 'updated' | 'no_change' */
  action: 'created' | 'updated' | 'no_change'
  creditsGranted: number | null
  /** New balance after granting the monthly allotment. */
  newBalance: number | null
  error?: string
}

/**
 * Activate a paid subscription for a user.
 *
 * Side-effects:
 *   - Upsert Subscription row with plan=tier, status='active'
 *   - Top up User.credits by the plan's monthly allotment (or set to 99999
 *     for Agency's "unlimited")
 *   - Log a CreditTransaction for audit
 *
 * Safe to call repeatedly (e.g., webhook retry) — if the user is already on
 * the same tier with status='active', we return `action: 'no_change'` and
 * skip the credit top-up to avoid double-granting.
 */
export async function activateSubscription(opts: {
  userId: string
  tier: PlanTier
  /** Payment gateway that triggered this activation. */
  gateway: 'stripe' | 'paypal' | 'payeer' | 'airtm' | 'demo' | 'admin'
  /** Optional gateway-specific IDs (Stripe subscription id, PayPal capture id, etc.) */
  externalId?: string
  /** Optional period-end timestamp (epoch ms). Defaults to +30 days. */
  currentPeriodEnd?: Date
}): Promise<ActivateSubscriptionResult> {
  const { userId, tier, gateway, externalId } = opts
  const cfg = PLAN_CONFIG[tier]
  const periodEnd = opts.currentPeriodEnd || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)

  try {
    // Check existing subscription to decide whether to grant credits
    const existing = await db.subscription.findUnique({ where: { userId } })
    if (existing && existing.plan === tier && existing.status === 'active') {
      return {
        ok: true,
        action: 'no_change',
        creditsGranted: null,
        newBalance: null,
      }
    }

    // Upsert subscription row
    await db.subscription.upsert({
      where: { userId },
      create: {
        userId,
        plan: tier,
        status: 'active',
        currentPeriodEnd: periodEnd,
        cancelAtPeriodEnd: false,
        // Save gateway-specific external ID in the existing columns. For
        // non-Stripe gateways we use stripeSubscriptionId as a generic
        // "externalSubscriptionId" — it's a free-text column.
        stripeSubscriptionId: externalId || null,
      },
      update: {
        plan: tier,
        status: 'active',
        currentPeriodEnd: periodEnd,
        cancelAtPeriodEnd: false,
        stripeSubscriptionId: externalId || existing?.stripeSubscriptionId || null,
      },
    })

    // Grant credits (or set unlimited for Agency)
    const credits = cfg.credits
    let newBalance: number | null = null

    if (credits === null) {
      // Agency — unlimited
      await db.user.update({
        where: { id: userId },
        data: { credits: 99999 },
      })
      newBalance = 99999
      await db.creditTransaction.create({
        data: {
          userId,
          amount: 99999,
          reason: 'subscription_created',
          description: `${cfg.label} subscription activated via ${gateway} — unlimited credits`,
          balanceAfter: 99999,
        },
      })
    } else {
      newBalance = await addCredits(
        userId,
        credits,
        'subscription_created',
        `${cfg.label} subscription activated via ${gateway} — ${credits} credits granted`
      )
    }

    return {
      ok: true,
      action: existing ? 'updated' : 'created',
      creditsGranted: credits,
      newBalance,
    }
  } catch (err) {
    return {
      ok: false,
      action: 'updated',
      creditsGranted: null,
      newBalance: null,
      error: err instanceof Error ? err.message : String(err),
    }
  }
}

/* -------------------------------------------------------------------------- */
/*                            Plan → credits helpers                          */
/* -------------------------------------------------------------------------- */

/**
 * Get the credit allotment for a plan tier.
 * Returns `null` for unlimited (Agency).
 */
export function getPlanCredits(tier: PlanTier): number | null {
  return PLAN_CONFIG[tier].credits
}

/**
 * Resolve a user's effective plan tier from their Subscription row.
 * Free / undefined / inactive subscriptions return 'free'.
 */
export function tierFromSubscription(sub: {
  plan: string
  status: string
} | null | undefined): PlanTier {
  if (!sub) return 'free'
  if (sub.status !== 'active' && sub.status !== 'trialing') return 'free'
  const tier = sub.plan as PlanTier
  if (tier in PLAN_CONFIG) return tier
  return 'free'
}

/**
 * Whether the user can generate articles.
 * Returns { ok: true } if allowed, otherwise an object describing why not.
 *
 * Paywall rules (evaluated in order):
 *   1. Agency tier (active) → unlimited, always allowed.
 *   2. If subscription.status is "inactive" (i.e., no paid plan):
 *        - Allow up to FREE_TRIAL_LIMIT (3) free articles via `freeCreditsUsed`.
 *        - Once freeCreditsUsed >= FREE_TRIAL_LIMIT, block generation and
 *          redirect to the payment page.
 *   3. Active paid subscription (basic / pro):
 *        - Block if credits balance is 0.
 */
export function checkGenerationEligibility(opts: {
  credits: number
  /** Number of free-trial articles the user has already consumed. */
  freeCreditsUsed?: number
  /** The free-trial ceiling (default 3, see auth.ts). */
  freeTrialLimit?: number
  subscription: { plan: string; status: string } | null
}): { ok: true } | {
  ok: false
  reason: 'no_credits' | 'inactive_subscription' | 'free_trial_exhausted'
  /** Recommended plan tier to suggest in the upgrade dialog. */
  suggestedTier: PlanTier
  message: string
  /** How many free-trial articles the user has left (only set for inactive subs). */
  freeCreditsRemaining?: number
} {
  const tier = tierFromSubscription(opts.subscription)

  // Agency tier (active) = unlimited, skip every check
  if (tier === 'agency') return { ok: true }

  // Determine if the subscription is "inactive" for paywall purposes.
  // A null subscription, or any status other than active/trialing, means
  // the user has not paid — they fall under the free-trial regime.
  const isActive = opts.subscription &&
    (opts.subscription.status === 'active' || opts.subscription.status === 'trialing') &&
    tier !== 'free'

  if (!isActive) {
    // Free-trial regime
    const used = opts.freeCreditsUsed ?? 0
    const limit = opts.freeTrialLimit ?? 3
    if (used >= limit) {
      return {
        ok: false,
        reason: 'free_trial_exhausted',
        suggestedTier: 'basic',
        message: `You've used all ${limit} free trial articles. Subscribe to a paid plan to keep generating content.`,
        freeCreditsRemaining: 0,
      }
    }
    // Still within the trial — allow generation; the caller will
    // increment `freeCreditsUsed` after the article is persisted.
    return { ok: true }
  }

  // Active paid subscription — enforce the credits balance
  if (opts.credits <= 0) {
    return {
      ok: false,
      reason: 'no_credits',
      // At this point `tier` is guaranteed to be a paid tier (basic / pro /
      // agency) because we already returned for inactive / free users.
      suggestedTier: tier as PlanTier,
      message: "You're out of credits. Upgrade your plan to keep generating articles.",
    }
  }

  return { ok: true }
}
