# BlogPilot AI

> AI-powered blog article generator with SEO optimization, competitor analysis, multi-language support, affiliate product injection, WordPress/Shopify auto-publishing, and Stripe subscription billing.

Built with **Next.js 16**, **TypeScript**, **Tailwind CSS 4**, **shadcn/ui**, **Prisma ORM**, Google **Gemini** (with OpenRouter failover).

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Architecture](#project-architecture)
- [Getting Started (Local Development)](#getting-started-local-development)
- [Environment Variables](#environment-variables)
- [Database Setup](#database-setup)
- [Available Scripts](#available-scripts)
- [API Reference](#api-reference)
- [Production Deployment](#production-deployment)
- [Security](#security)
- [License](#license)

---

## Overview

BlogPilot AI is a full-featured SaaS application that automates the entire blog content workflow: from keyword research and competitor analysis, through AI article generation with live fact-checking, to one-click publishing on WordPress or Shopify. The app supports 9 languages, integrates with affiliate networks (Amazon, eBay, CJ, ShareASale, Impact), and includes a built-in Stripe subscription system with credit-based metering.

The product is aimed at content marketers, SEO agencies, and solo bloggers who need to produce high-quality, SEO-optimized articles at scale without spending hours on research, writing, formatting, and publishing.

---

## Features

### Content Generation
- **AI article generation** powered by Google Gemini with automatic OpenRouter failover, timeout/retry/quota policies and a full usage ledger
- **Live fact-checking** with Google Search grounding — every claim is verified against current 2026 data
- **Competitor research** via Serper.dev (Google Search API) and Jina Reader (URL → markdown)
- **Outline-first workflow** — generate, review, edit the outline, then generate the full article
- **9 languages** — English, Arabic, Spanish, French, German, Chinese, Japanese, Portuguese, Russian
- **Multiple intents** — informational, commercial, transactional
- **Tone control** — professional, casual, persuasive, technical, conversational

### SEO & Analytics
- Auto-generated **meta descriptions** and **URL slugs**
- **SEO score** calculation (0–100) with actionable recommendations
- **Word count targeting** — short (500w), medium (1200w), long (2000w+)
- Internal linking suggestions between articles
- Real-time analytics dashboard with charts (Recharts)

### Affiliate & Monetization
- **Affiliate product injection** — auto-insert product comparison tables, pros/cons lists, and CTA buttons
- Supports **Amazon, eBay, CJ, ShareASale, Impact** affiliate networks
- **Auto image generation** — pulls relevant product photos and contextual images (Unsplash)
- Each affiliate key is encrypted at rest with AES-256-GCM

### Publishing & CMS
- **One-click publishing** to WordPress (REST API + Application Passwords)
- **One-click publishing** to Shopify (Admin REST API)
- Custom site publishing via webhook
- **Interlinking** — automatically inserts links to other articles on the same site
- Scheduled publishing support

### Editor & History
- **Full-screen TipTap rich text editor** — H1/H2/H3, bold/italic/underline, lists, links, images, alignment
- Custom **markdown ↔ HTML converter** (dependency-free)
- **History page** with grid/list views, search, and filters
- **Draft/published/scheduled** status management
- Auto-save on edit

### Billing & Subscriptions
- **4 tiers** (Free / Starter $29 / Pro $79 / Agency $199) with credit allocations
- **Credit-based metering** — 1 credit = 1 article generation, atomic reservation + refund
- **Paddle Billing** (default card gateway) — Visa/Mastercard via Paddle-hosted checkout,
  HMAC-verified webhooks (`Paddle-Signature`), transaction-scoped idempotent credit grants
- **Stripe** fully implemented as an alternative gateway (Checkout + Customer Portal +
  `invoice.paid`-scoped subscription credits)
- **PayPal / AirTM / Payeer** — wallet & regional gateways, all signature-verified
- **No demo mode in production paths** — unconfigured gateways return a clear 503; nothing is simulated

### Security & Reliability
- **Rate limiting** on every API endpoint (in-memory sliding window, per-user/per-IP)
  - AI endpoints: 8–12 requests/minute
  - Auth endpoints: 10 requests/minute (slow credential stuffing)
  - CRUD endpoints: 60 requests/minute
  - Payment endpoints: 10 requests/minute
- **Zod v4 input validation** on every route — strips control chars, caps lengths, rejects `javascript:` URLs
- **AES-256-GCM encryption** for all stored credentials (WordPress, Shopify, affiliate keys)
- **Centralized error handling** — no raw stack traces leak to clients; user-friendly messages with retry hints
- **Environment variable validation** at startup and via `/api/health`
- **Security headers** — HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy

---

## Tech Stack

| Category | Choice | Why |
|----------|--------|-----|
| **Framework** | Next.js 16 (App Router, Turbopack) | Latest React 19 features, server components, edge-ready |
| **Language** | TypeScript 5 (strict) | End-to-end type safety |
| **Styling** | Tailwind CSS 4 + shadcn/ui (New York) | Utility-first, accessible components |
| **Database** | Prisma ORM + SQLite (dev) / PostgreSQL (prod) | Type-safe queries, easy migrations |
| **AI** | Google Gemini (primary) + OpenRouter (automatic failover) | Real generation only — no mock mode; timeouts, retries, quota fail-fast |
| **Auth** | Custom session-based (with NextAuth available) | Simple, flexible |
| **Payments** | Paddle Billing + Stripe + PayPal/AirTM/Payeer | Card checkout via hosted pages; signature-verified, idempotent webhooks |
| **State** | Zustand (client) + TanStack Query (server) | Lightweight, predictable |
| **Editor** | TipTap (ProseMirror) | Battle-tested, extensible |
| **Charts** | Recharts | React-friendly, composable |
| **Validation** | Zod v4 | TypeScript-native schemas |
| **Crypto** | Node.js `crypto` (AES-256-GCM) | No external deps |
| **Icons** | lucide-react | Tree-shakeable, consistent |
| **Animations** | framer-motion | Declarative, performant |

---

## Project Architecture

```
blogpilot-ai/
├── prisma/
│   └── schema.prisma              # Database schema (User, Subscription, Article, etc.)
│
├── src/
│   ├── app/                       # Next.js App Router
│   │   ├── page.tsx               # Single-page app shell (Zustand-routed)
│   │   ├── layout.tsx             # Root layout with providers
│   │   ├── globals.css            # Tailwind base + theme tokens
│   │   │
│   │   └── api/                   # 24 API routes (all rate-limited + validated)
│   │       ├── auth/              # login, signup
│   │       ├── articles/          # CRUD + publish
│   │       ├── sites/             # WordPress/Shopify connections
│   │       ├── credentials/       # Affiliate key storage (encrypted)
│   │       ├── generate/          # AI article generation
│   │       ├── generate-outline/  # Outline-first workflow
│   │       ├── analyze/           # Competitor research
│   │       ├── fact-check/        # Live fact-check with Google Search
│   │       ├── products/          # Affiliate product lookup
│   │       ├── images/            # Contextual image generation
│   │       ├── credits/           # Credit balance + transactions
│   │       ├── stripe/            # checkout, portal, webhook, config
│   │       └── health/            # /api/health env + uptime report
│   │
│   ├── components/
│   │   ├── landing/               # Marketing landing page
│   │   ├── auth/                  # Login + signup pages
│   │   ├── dashboard/             # Main app shell + 9 sub-pages
│   │   │   ├── dashboard.tsx      # Sidebar + routing
│   │   │   ├── generate-article-page.tsx
│   │   │   ├── history-page.tsx
│   │   │   ├── editor-page.tsx    # Full-screen TipTap editor
│   │   │   ├── analytics-page.tsx
│   │   │   ├── connected-sites-page.tsx
│   │   │   ├── affiliate-credentials-page.tsx
│   │   │   ├── billing-page.tsx
│   │   │   └── upgrade-dialog.tsx
│   │   └── ui/                    # 40+ shadcn/ui components
│   │
│   ├── lib/                       # Server-side utilities
│   │   ├── db.ts                  # Prisma client singleton
│   │   ├── auth.ts                # requireUser(request) helper
│   │   ├── crypto.ts              # AES-256-GCM encrypt/decrypt
│   │   ├── gemini.ts              # Gemini API client (with mock mode)
│   │   ├── competitor-scraper.ts  # Serper + Jina integration
│   │   ├── stripe.ts              # Stripe client + plan → credit mapping
│   │   ├── rate-limit.ts          # Sliding-window rate limiter
│   │   ├── env.ts                 # Env var validation (12 accessors)
│   │   ├── validation.ts          # Zod schemas for every input
│   │   ├── api-errors.ts          # Centralized error classifier
│   │   ├── markdown-utils.ts      # markdown ↔ HTML converter
│   │   ├── store.ts               # Zustand store (SPA routing)
│   │   └── utils.ts               # cn(), formatters, etc.
│   │
│   └── hooks/                     # React hooks
│
├── supabase/
│   └── migrations/
│       └── 0001_init.sql          # PostgreSQL schema (for production)
│
├── docs/
│   └── DEPLOYMENT.md              # Vercel + Supabase deployment guide
│
├── scripts/                       # Utility scripts (not part of build)
│   ├── start-server.js
│   ├── test-prisma.js
│   ├── test-security.js
│   └── keepalive.sh
│
├── public/                        # Static assets
│   ├── logo.svg
│   └── robots.txt
│
├── .env.example                   # Template for env vars
├── vercel.json                    # Vercel deployment config
├── next.config.ts                 # Next.js production config
├── tsconfig.json                  # TypeScript strict mode
├── eslint.config.mjs              # ESLint config (Next.js + TypeScript)
├── tailwind.config.ts             # Tailwind theme
├── components.json                # shadcn/ui config
└── package.json
```

### Architecture Decisions

**Single-page app shell with Zustand routing.** Instead of using Next.js's file-based routing for the dashboard, the entire app lives at `/` and views are switched via a Zustand store. This gives smooth, instant transitions without page reloads — critical for the editor experience. The trade-off is no deep-linking to specific dashboard tabs; if you need that, refactor `page.tsx` to use `next/navigation` and split into routes.

**Server-only AI SDK.** The Gemini and OpenRouter clients are imported only in API routes, never in client components. This keeps the bundle small and the API keys server-side.

**Graceful degradation, never simulation.** Every paid integration (Gemini/OpenRouter, Paddle/Stripe, PayPal/AirTM/Payeer, SerpAPI) returns a clear "configuration required" error when its keys are absent. Nothing is mocked or simulated — a request either uses the real provider or fails honestly with a 503.

**Provider ladders for AI.** Generation walks the Gemini model ladder first; if every model is quota-blocked it fails over to OpenRouter automatically. Quota errors skip retries to fail fast; transient errors back off exponentially; truncation escalates the token budget before giving up.

**In-memory rate limiting.** A sliding-window counter per IP/user, no Redis dependency. Suitable for single-instance deployments (Vercel with a single region, or a VPS). For multi-region Vercel deployments, swap `src/lib/rate-limit.ts` with an Upstash Redis-backed limiter.

**SQLite for dev, PostgreSQL for prod.** The Prisma schema is database-agnostic; switching providers is a one-line change in `schema.prisma`. SQLite keeps local dev zero-config; Supabase Postgres gives you connection pooling, backups, and a dashboard.

---

## Getting Started (Local Development)

### Prerequisites

- **Node.js 20+** (or **Bun 1.3+**, which is faster and preferred)
- **Git**

### Install & Run

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/blogpilot-ai.git
cd blogpilot-ai

# 2. Install dependencies
bun install        # or: npm install

# 3. Set up environment variables
cp .env.example .env
# Edit .env — only DATABASE_URL is strictly required for the app to start.
# All other keys (Gemini/OpenRouter, Paddle/Stripe, etc.) degrade to clear
# "configuration required" errors if absent — nothing is simulated.

# 4. Generate the AES-256-GCM encryption key
openssl rand -base64 32
# Paste the output (44-char string) into .env as ENCRYPTION_KEY=...

# 5. Push the database schema
bun run db:push

# 6. Start the dev server
bun run dev
```

Open http://localhost:3000 — you should see the landing page.

### Default Login

For local development, the first user you sign up with becomes the admin. There's no seeded admin account by design — sign up with any email/password to start.

---

## Environment Variables

All variables are documented in [`.env.example`](./.env.example). Here's the summary:

### Required (server won't start without these)

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Prisma connection string | `file:./db/custom.db` (dev) or `postgresql://...` (prod) |

### AI Keys (real generation only — no mock fallback)

| Variable | Description |
|----------|-------------|
| `GEMINI_API_KEY` | Google Gemini API key from https://aistudio.google.com/app/apikey (primary provider) |
| `OPENROUTER_API_KEY` | OpenRouter key used automatically when every Gemini model is quota-blocked |

### Scraping Keys (optional — falls back to DuckDuckGo scraping if absent)

| Variable | Description |
|----------|-------------|
| `SERPAPI_API_KEY` | SerpAPI key for Google Search results |
| `JINA_API_KEY` | Jina Reader API key (URL → markdown) |

### Paddle (default card gateway — Visa/Mastercard)

| Variable | Description |
|----------|-------------|
| `PADDLE_API_KEY` | Paddle Billing API key (`pdl_live_...` or `pdl_sdbx_...`) |
| `PADDLE_WEBHOOK_SECRET` | Notification destination secret (`pdl_ntfset_...`) — verifies `Paddle-Signature` HMACs |
| `PADDLE_ENV` | Optional override: `live` or `sandbox` (inferred from key prefix by default) |
| `PADDLE_PRICE_ID_STARTER` / `_PRO` / `_AGENCY` | Recurring Price IDs from the Paddle Catalog; webhooks map the paid price back to the plan server-side |

### Stripe (alternative gateway)

| Variable | Description |
|----------|-------------|
| `STRIPE_SECRET_KEY` | Server-side Stripe key (`sk_test_...` or `sk_live_...`) |
| `STRIPE_PUBLISHABLE_KEY` | Client-side Stripe key (`pk_test_...` or `pk_live_...`) |
| `STRIPE_WEBHOOK_SECRET` | Webhook signing secret (`whsec_...`) |
| `STRIPE_PRICE_ID_STARTER` / `_PRO` / `_AGENCY` | Recurring Price IDs for each paid plan |

### OpenRouter (AI failover)

| Variable | Description |
|----------|-------------|
| `OPENROUTER_API_KEY` | Key from openrouter.ai/keys. Used automatically when every Gemini model is quota-blocked; requires credits at openrouter.ai/credits |

### Crypto (required for storing credentials)

| Variable | Description |
|----------|-------------|
| `ENCRYPTION_KEY` | 44-char base64 string from `openssl rand -base64 32` |

### Public

| Variable | Description |
|----------|-------------|
| `NEXT_PUBLIC_APP_URL` | App's public URL (used for Stripe redirects, etc.) |

---

## Database Setup

### Development (SQLite — zero config)

The default `DATABASE_URL` in `.env.example` is `file:./db/custom.db`. SQLite needs no separate server — Prisma creates the file automatically on first `db:push`.

```bash
bun run db:push    # creates tables
bun run db:generate  # regenerates the Prisma Client
```

### Production (PostgreSQL)

See [`docs/DEPLOYMENT.md`](./docs/DEPLOYMENT.md) for the full step-by-step guide. The short version:

1. Create a Postgres database (e.g. a Supabase project)
2. Apply the committed migration [`prisma/migrations/20240101000000_init/migration.sql`](./prisma/migrations/20240101000000_init/migration.sql) via the SQL editor or `psql -f`
3. Set `DATABASE_URL` to the Postgres connection string — the Prisma client auto-detects the provider, no code changes needed
4. Set `AUTH_SECRET` (required) and configure `UPSTASH_REDIS_REST_URL`/`_TOKEN` for shared rate limiting & caching when running multiple instances

The migration creates all tables with performance indexes on hot lookup paths
(`Subscription.stripeCustomerId`, `Article(userId, slug)`, `Article(userId, updatedAt)`,
`CreditTransaction(userId, createdAt)`), foreign keys, and the server-side
session revocation table (`RevokedSession`).

---

## Available Scripts

| Script | Description |
|--------|-------------|
| `bun run dev` | Start the dev server with hot reload (port 3000) |
| `bun run build` | Production build (compiles to `.next/standalone/`) |
| `bun run start` | Run the production build (requires `bun run build` first) |
| `bun run lint` | Run ESLint — must pass before deploy |
| `bun run db:push` | Push schema changes to the database |
| `bun run db:generate` | Regenerate the Prisma Client after schema changes |
| `bun run db:migrate` | Create a new migration (PostgreSQL only) |
| `bun run db:reset` | Drop and recreate all tables (⚠️ destructive) |

### Verification scripts (run against a live server)

| Script | Description |
|--------|-------------|
| `node scripts/e2e-test.mjs <url>` | 35 end-to-end checks: auth, session revocation, credits, refunds, webhooks, CSV, SSRF |
| `node scripts/paddle-webhook-test.mjs <url>` | Full Paddle flow with HMAC-signed webhooks — per-transaction credit idempotency, renewals, cancellation |
| `node scripts/stripe-webhook-test.mjs <url>` | Full Stripe subscription flow with signed webhooks — plan activation, per-invoice credit idempotency, refund handling |
| `node scripts/free-tools-smoke.mjs <url>` | Free Tools API smoke test incl. SSRF blocks and rate limiting |
| `node scripts/concurrent-credits.mjs` | Atomic credit primitives under concurrency (DB-level) |
| `node scripts/concurrent-generate-test.mjs <url>` | Concurrent generation vs. the credit gate over HTTP |
| `node scripts/live-generation-test.mjs <url>` | Real Gemini generation round-trip + usage ledger verification |

---

## API Reference

All 24 API routes are documented inline in their source files under `src/app/api/`. Here's the high-level map:

### Authentication
- `POST /api/auth/login` — login with email/password
- `POST /api/auth/signup` — create a new account (grants 10 free credits)

### Article Generation
- `POST /api/generate` — generate a full article from a keyword (1 credit)
- `POST /api/generate-outline` — generate an outline first (free), then call `/api/generate` with the outline
- `POST /api/analyze` — competitor research for a keyword
- `POST /api/fact-check` — fact-check claims with Google Search grounding
- `POST /api/products` — fetch affiliate products for a keyword
- `POST /api/images` — fetch contextual images (Unsplash + placeholders)

### Article CRUD
- `GET /api/articles` — list user's articles (supports filtering, pagination)
- `POST /api/articles` — create a new article (manual draft)
- `GET /api/articles/[id]` — get a single article
- `PATCH /api/articles/[id]` — update an article
- `DELETE /api/articles/[id]` — delete an article
- `POST /api/articles/[id]/publish` — publish to a connected site

### Connected Sites
- `GET /api/sites` — list user's connected sites
- `POST /api/sites` — connect a new site (WordPress/Shopify/custom)
- `PATCH /api/sites/[id]` — update a site connection
- `DELETE /api/sites/[id]` — disconnect a site

### Credentials
- `GET /api/credentials` — list user's affiliate keys (masked)
- `POST /api/credentials` — store a new affiliate key (encrypted)
- `PATCH /api/credentials/[id]` — update an affiliate key
- `DELETE /api/credentials/[id]` — delete an affiliate key

### Billing
- `GET /api/credits` — get current credit balance + recent transactions
- `POST /api/credits/topup` — manual credit top-up (demo only)
- `POST /api/paddle/checkout` — create a Paddle-hosted checkout transaction
- `POST /api/paddle/webhook` — receive Paddle webhook events (HMAC-verified)
- `GET /api/stripe/config` — get Stripe publishable key + plan prices
- `POST /api/stripe/checkout` — create a Stripe Checkout session
- `POST /api/stripe/portal` — create a Stripe Customer Portal session
- `POST /api/stripe/webhook` — receive Stripe webhook events

### Health
- `GET /api/health` — env var validation report + uptime + memory usage
- `GET /api/health/ai` — AI provider status (auth-gated): reports per-provider (`gemini`, `openrouter`) as `configured` | `not_configured` | `invalid` | `temporarily_unavailable`. Never exposes key material. See [docs/SECRET_ROTATION.md](./docs/SECRET_ROTATION.md) for the rotation runbook.

Every route returns JSON with this envelope:
- **Success**: `{ ...data }` (200)
- **Error**: `{ error: string, code: string, ...meta }` (4xx/5xx) — error messages are user-friendly, never contain stack traces

---

## Production Deployment

See [`docs/DEPLOYMENT.md`](./docs/DEPLOYMENT.md) for the complete guide. The summary:

1. **Database**: Create a Postgres database → apply `prisma/migrations/20240101000000_init/migration.sql` → copy the connection string
2. **Code**: Push to GitHub → import into Vercel
3. **Env vars**: Set `DATABASE_URL` + `AUTH_SECRET` (required) and the rest from `.env.example` in Vercel's project settings
4. **Paddle**: Create the 3 recurring prices in Paddle Catalog, add a webhook destination for `/api/paddle/webhook` and set `PADDLE_WEBHOOK_SECRET` + `PADDLE_PRICE_ID_*` (Stripe remains available as an alternative gateway)
5. **Deploy**: Vercel auto-builds with the configured build command and serves at `https://your-app.vercel.app`

The repo includes `vercel.json` pre-configured with build settings, security headers, and caching rules.

---

## Security

This app implements defense-in-depth:

1. **Rate limiting** — every API endpoint has a per-user/per-IP limit. AI endpoints are strictest (8–12 req/min) to prevent cost spikes from API abuse. Backed by memory (single instance) or any Upstash-REST-compatible Redis (multi-instance).
2. **Input validation** — every user input is validated with Zod v4 schemas that strip control characters, cap lengths, restrict URLs to `http`/`https` (rejects `javascript:`), and detect common XSS patterns.
3. **Encryption at rest** — all stored credentials (WordPress app passwords, Shopify API keys, affiliate keys) are encrypted with AES-256-GCM using `ENCRYPTION_KEY`.
4. **Centralized error handling** — no raw stack traces or internal details ever leak to clients. Every error is translated to a user-friendly message with retry hints.
5. **Environment validation** — `/api/health` returns the status of every env var; missing required vars return HTTP 503.
6. **Security headers** — HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy are set on every response (configured in `next.config.ts`).
7. **Atomic credit accounting** — credits are consumed via conditional atomic updates (`UPDATE ... WHERE credits >= n`), so concurrent requests can never overspend or produce negative balances; failed generations refund automatically.
8. **Idempotent webhooks** — payment webhooks (Paddle/Stripe/PayPal/Airtm/Payeer) claim events atomically before granting credits; redeliveries and replays grant nothing. Paddle additionally verifies the HMAC `Paddle-Signature` header with a replay window.
9. **Server-side session revocation** — logout inserts the token into `RevokedSession`; stolen cookies stop working immediately.
10. **SSRF protection** — server-side URL fetches validate scheme and resolve DNS to block loopback/metadata/private targets.

For a security audit, run the included test suites:
```bash
node scripts/test-security.js          # XSS, oversized input, SSRF, rate limits
node scripts/e2e-test.mjs              # 35 end-to-end checks (auth, credits, webhooks, CSV, SSRF)
node scripts/concurrent-credits.mjs    # atomic credit primitives under concurrency
node scripts/concurrent-generate-test.mjs  # concurrent generation vs. credit gate (needs running server)
```
The E2E suite runs against a live server: `node scripts/e2e-test.mjs http://localhost:3000`.

---

## License

Private / proprietary. All rights reserved.
