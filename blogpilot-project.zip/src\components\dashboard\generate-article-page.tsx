﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Copy, Save, Sparkles, Trash2, Wand2, FileText, Target, BarChart3 } from 'lucide-react';

type OpportunityReport = {
  query: string;
  opportunityScore: number;
  searchIntent: string;
  competitionLevel: string;
  contentGaps: string[];
  missingSubtopics: string[];
  faqOpportunities: string[];
  beatTop10Highlights: string[];
  aiRecommendations?: {
    recommended_h1?: string;
    recommended_h2?: string[];
    recommended_h3?: string[];
    suggested_faqs?: string[];
    top_improvements?: string[];
  };
  serpError?: string;
};

type GenerateArticleProps = {
  opportunityParam?: string | null;
};

export default function GenerateArticle({ opportunityParam }: GenerateArticleProps) {
  const [analysis, setAnalysis] = useState<OpportunityReport | null>(null);
  const [title, setTitle] = useState('');
  const [customBrief, setCustomBrief] = useState('Please write a well-structured, SEO-optimized article with headings, short paragraphs, and a strong conclusion.');
  const [article, setArticle] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (opportunityParam) {
      try {
        const decoded = decodeOpportunity(opportunityParam);
        setAnalysis(decoded);
        setTitle(decoded.query || 'New Article');
      } catch {
        setError('Unable to parse opportunity payload.');
      }
      return;
    }
    // Pending target from SEO Opportunities tab (session hand-off).
    try {
      const pending = sessionStorage.getItem('pendingOpportunity');
      if (pending) {
        sessionStorage.removeItem('pendingOpportunity');
        setTitle(pending);
      }
    } catch {
      // ignore storage errors
    }
  }, [opportunityParam]);

  const suggestedHeadings = useMemo(() => {
    if (analysis?.aiRecommendations?.recommended_h2?.length) return analysis.aiRecommendations.recommended_h2;
    return analysis?.missingSubtopics?.slice(0, 6) || [];
  }, [analysis]);

  async function handleGenerate() {
    if (!title) return setError('Please provide an article title.');
    setError(null);
    setLoading(true);
    setArticle('');
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, query: analysis?.query || title, analysis, instructions: customBrief }),
      });
      const payload = await res.json();
      if (!res.ok) {
        setError(payload?.error || 'Article generation failed.');
        toast.error(payload?.error || 'Failed');
      } else {
        setArticle(payload.article || '');
        toast.success('Article generated!');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error.');
      toast.error(err?.message || 'Network error');
    } finally {
      setLoading(false);
    }
  }

  async function handleCopy() {
    if (!article) return;
    await navigator.clipboard.writeText(article);
    toast.success('Copied to clipboard!');
  }

  async function handleSaveDraft() {
    if (!article) return;
    try {
      const res = await fetch('/api/articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content: article, slug: title.toLowerCase().replace(/\s+/g, '-'), excerpt: article.slice(0, 200), targetKeyword: analysis?.query || title }),
      });
      const payload = await res.json();
      if (!res.ok) toast.error(payload?.error || 'Failed to save.');
      else toast.success('Draft saved!');
    } catch (err: any) {
      toast.error(err?.message || 'Failed to save.');
    }
  }

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl border border-border bg-gradient-to-br from-cyan-500/[0.08] to-violet-500/[0.08] p-8">
        <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.3em] text-cyan-400">Article builder</p>
            <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Generate a stronger article</h1>
            <p className="mt-2 max-w-2xl text-slate-400">Use insights from the analyzer to create content optimized for search intent, topic coverage, and competitor gaps.</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-emerald-400/15 text-emerald-300 border-emerald-400/20">
              <Sparkles className="mr-1 h-3 w-3" /> AI Powered
            </Badge>
          </div>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[1.75fr_1fr]">
        <div className="space-y-6 rounded-3xl border border-border bg-card/50 p-6">
          <div>
            <label className="block text-sm font-medium text-slate-300">Article title</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} className="mt-2 w-full rounded-2xl border border-border bg-muted/50 px-4 py-3 text-foreground outline-none transition focus:border-primary focus:ring-1 focus:ring-primary/30" placeholder="Enter the article title" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300">Writer brief</label>
            <textarea value={customBrief} onChange={(e) => setCustomBrief(e.target.value)} rows={4} className="mt-2 w-full rounded-2xl border border-border bg-muted/50 px-4 py-3 text-foreground outline-none transition focus:border-primary focus:ring-1 focus:ring-primary/30" />
          </div>
          <div className="flex gap-3">
            <Button onClick={handleGenerate} disabled={loading} className="bg-gradient-to-r from-cyan-400 to-violet-500 text-slate-950 font-semibold shadow-lg shadow-cyan-500/25 hover:shadow-cyan-400/40">
              {loading ? 'Generating…' : 'Generate Article'}
              <Wand2 className="ml-2 h-4 w-4" />
            </Button>
            <Button variant="outline" onClick={() => setArticle('')} className="border-border bg-accent hover:bg-accent">
              <Trash2 className="mr-2 h-4 w-4" /> Clear
            </Button>
          </div>
          {error && <div className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">{error}</div>}
        </div>

        <div className="space-y-4 rounded-3xl border border-border bg-card/50 p-6">
          <h2 className="flex items-center gap-2 text-lg font-semibold text-white">
            <BarChart3 className="h-5 w-5 text-cyan-400" /> Analysis snapshot
          </h2>
          {analysis ? (
            <div className="mt-3 space-y-3">
              {[
                { label: 'Query', value: analysis.query, icon: Target },
                { label: 'Intent', value: analysis.searchIntent },
                { label: 'Score', value: `${analysis.opportunityScore}/100` },
                { label: 'Competition', value: analysis.competitionLevel },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between rounded-xl border border-border/50 bg-card/30 px-3 py-2.5">
                  <span className="text-xs text-muted-foreground">{item.label}</span>
                  <span className="text-sm font-medium text-foreground">{item.value}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-3 text-sm text-slate-500">Open the analyzer and click "Build a Better Article" to prefill this page.</p>
          )}
          {analysis?.aiRecommendations && (
            <div className="mt-4">
              <h3 className="text-xs font-semibold uppercase tracking-widest text-cyan-400">AI recommendations</h3>
              <div className="mt-3 space-y-2 text-sm text-slate-300">
                {analysis.aiRecommendations.recommended_h1 && <p><strong>H1:</strong> {analysis.aiRecommendations.recommended_h1}</p>}
                {analysis.aiRecommendations.recommended_h2?.length ? (
                  <div>
                    <strong>H2 ideas:</strong>
                    <ul className="mt-2 list-disc space-y-1 pl-5">
                      {analysis.aiRecommendations.recommended_h2.map((h, i) => <li key={i}>{h}</li>)}
                    </ul>
                  </div>
                ) : null}
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="rounded-3xl border border-border bg-card/50 p-6">
        <h2 className="flex items-center gap-2 text-lg font-semibold text-white">
          <FileText className="h-5 w-5 text-cyan-400" /> Suggested headings
        </h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {suggestedHeadings.length ? suggestedHeadings.map((h, i) => (
            <div key={i} className="rounded-2xl border border-border bg-muted/30 px-4 py-3 text-sm text-foreground">{h}</div>
          )) : (
            <p className="text-sm text-slate-500">No headings available yet.</p>
          )}
        </div>
      </section>

      {article && (
        <section className="rounded-3xl border border-border bg-card/50 p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Generated article</h2>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={handleSaveDraft} className="border-border bg-accent">
                <Save className="mr-1 h-4 w-4" /> Save
              </Button>
              <Button variant="outline" size="sm" onClick={handleCopy} className="border-border bg-accent">
                <Copy className="mr-1 h-4 w-4" /> Copy
              </Button>
            </div>
          </div>
          <pre className="mt-4 whitespace-pre-wrap break-words rounded-2xl border border-border bg-muted/50 p-6 text-sm leading-7 text-foreground">{article}</pre>
        </section>
      )}
    </div>
  );
}

function decodeOpportunity(value: string) {
  try { return JSON.parse(decodeURIComponent(value)); } catch {
    try { return JSON.parse(atob(value)); } catch { return JSON.parse(atob(decodeURIComponent(value))); }
  }
}
