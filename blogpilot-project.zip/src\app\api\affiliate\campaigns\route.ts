import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { createCampaign, listCampaignsWithStats } from '@/lib/affiliate';
import { checkBodySize } from '@/lib/input-limits';

const createSchema = z.object({
  name: z.string().min(1).max(120),
  productName: z.string().min(1).max(200),
  affiliateUrl: z
    .string()
    .url()
    .max(1000)
    .refine(v => /^https?:\/\//i.test(v), { message: 'Affiliate URL must be http(s)' }),
  merchantUrl: z.string().url().max(1000).optional().nullable(),
  network: z.string().max(60).optional().nullable(),
  commission: z.string().max(40).optional().nullable(),
  country: z.string().max(60).optional().nullable(),
  intent: z.string().max(40).optional().nullable(),
  targetAudience: z.string().max(300).optional().nullable(),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    const campaigns = await listCampaignsWithStats(userId);
    return NextResponse.json({ ok: true, data: { campaigns } });
  } catch (error: any) {
    console.error('List campaigns error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load campaigns' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const sizeCheck = await checkBodySize(req);
  if (!sizeCheck.ok) {
    return NextResponse.json({ ok: false, error: sizeCheck.error }, { status: 413 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const limit = await checkRateLimit(`campaigns:${userId}`, { windowMs: 60_000, maxRequests: 10 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests' }, { status: 429 });
  }

  try {
    const { campaign, trackedUrl } = await createCampaign(userId, parsed.data);
    return NextResponse.json({
      ok: true,
      data: { campaign, trackedUrl },
    }, { status: 201 });
  } catch (error: any) {
    console.error('Create campaign error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to create campaign' }, { status: 500 });
  }
}
