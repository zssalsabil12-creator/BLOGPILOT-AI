# BlogPilot AI

> AI-powered blog article generator with SEO optimization, competitor analysis, multi-language support, affiliate product injection, WordPress/Shopify auto-publishing, and Stripe subscription billing.

Built with **Next.js 16**, **TypeScript**, **Tailwind CSS 4**, **shadcn/ui**, **Prisma ORM**, and **Google Gemini 2.5 Flash**.

---

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Architecture](#project-architecture)
- [Getting Started (Local Development)](#getting-started-local-development)
- [Environment Variables](#environment-variables)
- [Database Setup](#database-setup)
- [Available Scripts](#available-scripts)
- [API Reference](#api-reference)
- [Production Deployment](#production-deployment)
- [Security](#security)
- [License](#license)

---

## Overview

BlogPilot AI is a full-featured SaaS application that automates the entire blog content workflow: from keyword research and competitor analysis, through AI article generation with live fact-checking, to one-click publishing on WordPress or Shopify. The app supports 9 languages, integrates with affiliate networks (Amazon, eBay, CJ, ShareASale, Impact), and includes a built-in Stripe subscription system with credit-based metering.

The product is aimed at content marketers, SEO agencies, and solo bloggers who need to produce high-quality, SEO-optimized articles at scale without spending hours on research, writing, formatting, and publishing.

---

## Features

### Content Generation
- **AI article generation** powered by Google Gemini 2.5 Flash (with `z-ai-web-dev-sdk` as automatic fallback)
- **Live fact-checking** with Google Search grounding — every claim is verified against current 2026 data
- **Competitor research** via Serper.dev (Google Search API) and Jina Reader (URL → markdown)
- **Outline-first workflow** — generate, review, edit the outline, then generate the full article
- **9 languages** — English, Arabic, Spanish, French, German, Chinese, Japanese, Portuguese, Russian
- **Multiple intents** — informational, commercial, transactional
- **Tone control** — professional, casual, persuasive, technical, conversational

### SEO & Analytics
- Auto-generated **meta descriptions** and **URL slugs**
- **SEO score** calculation (0–100) with actionable recommendations
- **Word count targeting** — short (500w), medium (1200w), long (2000w+)
- Internal linking suggestions between articles
- Real-time analytics dashboard with charts (Recharts)

### Affiliate & Monetization
- **Affiliate product injection** — auto-insert product comparison tables, pros/cons lists, and CTA buttons
- Supports **Amazon, eBay, CJ, ShareASale, Impact** affiliate networks
- **Auto image generation** — pulls relevant product photos and contextual images (Unsplash)
- Each affiliate key is encrypted at rest with AES-256-GCM

### Publishing & CMS
- **One-click publishing** to WordPress (REST API + Application Passwords)
- **One-click publishing** to Shopify (Admin REST API)
- Custom site publishing via webhook
- **Interlinking** — automatically inserts links to other articles on the same site
- Scheduled publishing support

### Editor & History
- **Full-screen TipTap rich text editor** — H1/H2/H3, bold/italic/underline, lists, links, images, alignment
- Custom **markdown ↔ HTML converter** (dependency-free)
- **History page** with grid/list views, search, and filters
- **Draft/published/scheduled** status management
- Auto-save on edit

### Billing & Subscriptions
- **Stripe-powered subscription system** with 4 tiers:
  - **Free** — 10 credits/month
  - **Basic** ($19/mo) — 20 credits/month
  - **Pro** ($49/mo) — 100 credits/month
  - **Agency** ($199/mo) — unlimited
- **Credit-based metering** — 1 credit = 1 article generation
- **Stripe Checkout** for new subscriptions
- **Stripe Customer Portal** for managing existing subscriptions
- **Webhook handling** for `checkout.session.completed`, `customer.subscription.*`, `invoice.payment_succeeded`
- **Demo mode** — when Stripe keys are absent, the entire flow is simulated locally for development

### Security & Reliability
- **Rate limiting** on every API endpoint (in-memory sliding window, per-user/per-IP)
  - AI endpoints: 8–12 requests/minute
  - Auth endpoints: 10 requests/minute (slow credential stuffing)
  - CRUD endpoints: 60 requests/minute
  - Stripe endpoints: 10 requests/minute
- **Zod v4 input validation** on every route — strips control chars, caps lengths, rejects `javascript:` URLs
- **AES-256-GCM encryption** for all stored credentials (WordPress, Shopify, affiliate keys)
- **Centralized error handling** — no raw stack traces leak to clients; user-friendly messages with retry hints
- **Environment variable validation** at startup and via `/api/health`
- **Security headers** — HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy

---

## Tech Stack

| Category | Choice | Why |
|----------|--------|-----|
| **Framework** | Next.js 16 (App Router, Turbopack) | Latest React 19 features, server components, edge-ready |
| **Language** | TypeScript 5 (strict) | End-to-end type safety |
| **Styling** | Tailwind CSS 4 + shadcn/ui (New York) | Utility-first, accessible components |
| **Database** | Prisma ORM + SQLite (dev) / PostgreSQL (prod) | Type-safe queries, easy migrations |
| **AI** | Google Gemini 2.5 Flash + `z-ai-web-dev-sdk` fallback | Search grounding, fast inference |
| **Auth** | Custom session-based (with NextAuth available) | Simple, flexible |
| **Payments** | Stripe (subscriptions + checkout + portal + webhooks) | Industry standard |
| **State** | Zustand (client) + TanStack Query (server) | Lightweight, predictable |
| **Editor** | TipTap (ProseMirror) | Battle-tested, extensible |
| **Charts** | Recharts | React-friendly, composable |
| **Validation** | Zod v4 | TypeScript-native schemas |
| **Crypto** | Node.js `crypto` (AES-256-GCM) | No external deps |
| **Icons** | lucide-react | Tree-shakeable, consistent |
| **Animations** | framer-motion | Declarative, performant |

---

## Project Architecture

```
blogpilot-ai/
├── prisma/
│   └── schema.prisma              # Database schema (User, Subscription, Article, etc.)
│
├── src/
│   ├── app/                       # Next.js App Router
│   │   ├── page.tsx               # Single-page app shell (Zustand-routed)
│   │   ├── layout.tsx             # Root layout with providers
│   │   ├── globals.css            # Tailwind base + theme tokens
│   │   │
│   │   └── api/                   # 24 API routes (all rate-limited + validated)
│   │       ├── auth/              # login, signup
│   │       ├── articles/          # CRUD + publish
│   │       ├── sites/             # WordPress/Shopify connections
│   │       ├── credentials/       # Affiliate key storage (encrypted)
│   │       ├── generate/          # AI article generation
│   │       ├── generate-outline/  # Outline-first workflow
│   │       ├── analyze/           # Competitor research
│   │       ├── fact-check/        # Live fact-check with Google Search
│   │       ├── products/          # Affiliate product lookup
│   │       ├── images/            # Contextual image generation
│   │       ├── credits/           # Credit balance + transactions
│   │       ├── stripe/            # checkout, portal, webhook, config
│   │       └── health/            # /api/health env + uptime report
│   │
│   ├── components/
│   │   ├── landing/               # Marketing landing page
│   │   ├── auth/                  # Login + signup pages
│   │   ├── dashboard/             # Main app shell + 9 sub-pages
│   │   │   ├── dashboard.tsx      # Sidebar + routing
│   │   │   ├── generate-article-page.tsx
│   │   │   ├── history-page.tsx
│   │   │   ├── editor-page.tsx    # Full-screen TipTap editor
│   │   │   ├── analytics-page.tsx
│   │   │   ├── connected-sites-page.tsx
│   │   │   ├── affiliate-credentials-page.tsx
│   │   │   ├── billing-page.tsx
│   │   │   └── upgrade-dialog.tsx
│   │   └── ui/                    # 40+ shadcn/ui components
│   │
│   ├── lib/                       # Server-side utilities
│   │   ├── db.ts                  # Prisma client singleton
│   │   ├── auth.ts                # requireUser(request) helper
│   │   ├── crypto.ts              # AES-256-GCM encrypt/decrypt
│   │   ├── gemini.ts              # Gemini API client (with mock mode)
│   │   ├── competitor-scraper.ts  # Serper + Jina integration
│   │   ├── stripe.ts              # Stripe client + plan → credit mapping
│   │   ├── rate-limit.ts          # Sliding-window rate limiter
│   │   ├── env.ts                 # Env var validation (12 accessors)
│   │   ├── validation.ts          # Zod schemas for every input
│   │   ├── api-errors.ts          # Centralized error classifier
│   │   ├── markdown-utils.ts      # markdown ↔ HTML converter
│   │   ├── store.ts               # Zustand store (SPA routing)
│   │   └── utils.ts               # cn(), formatters, etc.
│   │
│   └── hooks/                     # React hooks
│
├── supabase/
│   └── migrations/
│       └── 0001_init.sql          # PostgreSQL schema (for production)
│
├── docs/
│   └── DEPLOYMENT.md              # Vercel + Supabase deployment guide
│
├── scripts/                       # Utility scripts (not part of build)
│   ├── start-server.js
│   ├── test-prisma.js
│   ├── test-security.js
│   └── keepalive.sh
│
├── public/                        # Static assets
│   ├── logo.svg
│   └── robots.txt
│
├── .env.example                   # Template for env vars
├── vercel.json                    # Vercel deployment config
├── next.config.ts                 # Next.js production config
├── tsconfig.json                  # TypeScript strict mode
├── eslint.config.mjs              # ESLint config (Next.js + TypeScript)
├── tailwind.config.ts             # Tailwind theme
├── components.json                # shadcn/ui config
└── package.json
```

### Architecture Decisions

**Single-page app shell with Zustand routing.** Instead of using Next.js's file-based routing for the dashboard, the entire app lives at `/` and views are switched via a Zustand store. This gives smooth, instant transitions without page reloads — critical for the editor experience. The trade-off is no deep-linking to specific dashboard tabs; if you need that, refactor `page.tsx` to use `next/navigation` and split into routes.

**Server-only AI SDK.** `z-ai-web-dev-sdk` is imported only in API routes, never in client components. This keeps the bundle small and the API key server-side.

**Demo mode for every paid integration.** Stripe, Gemini, Serper, and Jina all gracefully degrade when their API keys are absent. This makes local development and first-deploy smoke testing painless — you don't need to set up billing with any provider just to see the app run.

**In-memory rate limiting.** A sliding-window counter per IP/user, no Redis dependency. Suitable for single-instance deployments (Vercel with a single region, or a VPS). For multi-region Vercel deployments, swap `src/lib/rate-limit.ts` with an Upstash Redis-backed limiter.

**SQLite for dev, PostgreSQL for prod.** The Prisma schema is database-agnostic; switching providers is a one-line change in `schema.prisma`. SQLite keeps local dev zero-config; Supabase Postgres gives you connection pooling, backups, and a dashboard.

---

## Getting Started (Local Development)

### Prerequisites

- **Node.js 20+** (or **Bun 1.3+**, which is faster and preferred)
- **Git**

### Install & Run

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/blogpilot-ai.git
cd blogpilot-ai

# 2. Install dependencies
bun install        # or: npm install

# 3. Set up environment variables
cp .env.example .env
# Edit .env — only DATABASE_URL is strictly required for the app to start.
# All other keys (Gemini, Stripe, etc.) default to demo mode if absent.

# 4. Generate the AES-256-GCM encryption key
openssl rand -base64 32
# Paste the output (44-char string) into .env as ENCRYPTION_KEY=...

# 5. Push the database schema
bun run db:push

# 6. Start the dev server
bun run dev
```

Open http://localhost:3000 — you should see the landing page.

### Default Login

For local development, the first user you sign up with becomes the admin. There's no seeded admin account by design — sign up with any email/password to start.

---

## Environment Variables

All variables are documented in [`.env.example`](./.env.example). Here's the summary:

### Required (server won't start without these)

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Prisma connection string | `file:./db/custom.db` (dev) or `postgresql://...` (prod) |

### AI Keys (optional — falls back to z-ai-web-dev-sdk if absent)

| Variable | Description |
|----------|-------------|
| `GEMINI_API_KEY` | Google Gemini API key from https://aistudio.google.com/app/apikey |

### Scraping Keys (optional — falls back to mock data if absent)

| Variable | Description |
|----------|-------------|
| `SERPER_API_KEY` | Serper.dev Google Search API key |
| `JINA_API_KEY` | Jina Reader API key (URL → markdown) |

### Stripe (optional — demo mode if absent)

| Variable | Description |
|----------|-------------|
| `STRIPE_SECRET_KEY` | Server-side Stripe key (`sk_test_...` or `sk_live_...`) |
| `STRIPE_PUBLISHABLE_KEY` | Client-side Stripe key (`pk_test_...` or `pk_live_...`) |
| `STRIPE_WEBHOOK_SECRET` | Webhook signing secret (`whsec_...`) |
| `STRIPE_PRICE_BASIC` | Price ID for the $19/mo Basic plan |
| `STRIPE_PRICE_PRO` | Price ID for the $49/mo Pro plan |
| `STRIPE_PRICE_AGENCY` | Price ID for the $199/mo Agency plan |

### Crypto (required for storing credentials)

| Variable | Description |
|----------|-------------|
| `ENCRYPTION_KEY` | 44-char base64 string from `openssl rand -base64 32` |

### Public

| Variable | Description |
|----------|-------------|
| `NEXT_PUBLIC_APP_URL` | App's public URL (used for Stripe redirects, etc.) |

---

## Database Setup

### Development (SQLite — zero config)

The default `DATABASE_URL` in `.env.example` is `file:./db/custom.db`. SQLite needs no separate server — Prisma creates the file automatically on first `db:push`.

```bash
bun run db:push    # creates tables
bun run db:generate  # regenerates the Prisma Client
```

### Production (Supabase PostgreSQL)

See [`docs/DEPLOYMENT.md`](./docs/DEPLOYMENT.md) for the full step-by-step guide. The short version:

1. Create a Supabase project at https://supabase.com/dashboard
2. Open the SQL Editor and run [`supabase/migrations/0001_init.sql`](./supabase/migrations/0001_init.sql)
3. Change `prisma/schema.prisma`'s datasource provider from `sqlite` to `postgresql`
4. Update `DATABASE_URL` in your `.env` (or Vercel env vars) to the Supabase connection string
5. Run `bun run db:push` to verify Prisma syncs cleanly with the new schema

The Supabase migration script creates all 6 tables, indexes, foreign keys, an `updatedAt` trigger (to replicate Prisma's `@updatedAt`), and enables Row-Level Security (RLS) on every table. RLS blocks direct access from the Supabase JS client — your Next.js app talks to Postgres via Prisma (server-side, service-role key) which bypasses RLS, which is the intended pattern.

---

## Available Scripts

| Script | Description |
|--------|-------------|
| `bun run dev` | Start the dev server with hot reload (port 3000) |
| `bun run build` | Production build (compiles to `.next/standalone/`) |
| `bun run start` | Run the production build (requires `bun run build` first) |
| `bun run lint` | Run ESLint — must pass before deploy |
| `bun run db:push` | Push schema changes to the database |
| `bun run db:generate` | Regenerate the Prisma Client after schema changes |
| `bun run db:migrate` | Create a new migration (PostgreSQL only) |
| `bun run db:reset` | Drop and recreate all tables (⚠️ destructive) |

---

## API Reference

All 24 API routes are documented inline in their source files under `src/app/api/`. Here's the high-level map:

### Authentication
- `POST /api/auth/login` — login with email/password
- `POST /api/auth/signup` — create a new account (grants 10 free credits)

### Article Generation
- `POST /api/generate` — generate a full article from a keyword (1 credit)
- `POST /api/generate-outline` — generate an outline first (free), then call `/api/generate` with the outline
- `POST /api/analyze` — competitor research for a keyword
- `POST /api/fact-check` — fact-check claims with Google Search grounding
- `POST /api/products` — fetch affiliate products for a keyword
- `POST /api/images` — fetch contextual images (Unsplash + placeholders)

### Article CRUD
- `GET /api/articles` — list user's articles (supports filtering, pagination)
- `POST /api/articles` — create a new article (manual draft)
- `GET /api/articles/[id]` — get a single article
- `PATCH /api/articles/[id]` — update an article
- `DELETE /api/articles/[id]` — delete an article
- `POST /api/articles/[id]/publish` — publish to a connected site

### Connected Sites
- `GET /api/sites` — list user's connected sites
- `POST /api/sites` — connect a new site (WordPress/Shopify/custom)
- `PATCH /api/sites/[id]` — update a site connection
- `DELETE /api/sites/[id]` — disconnect a site

### Credentials
- `GET /api/credentials` — list user's affiliate keys (masked)
- `POST /api/credentials` — store a new affiliate key (encrypted)
- `PATCH /api/credentials/[id]` — update an affiliate key
- `DELETE /api/credentials/[id]` — delete an affiliate key

### Billing
- `GET /api/credits` — get current credit balance + recent transactions
- `POST /api/credits/topup` — manual credit top-up (demo only)
- `GET /api/stripe/config` — get Stripe publishable key + plan prices
- `POST /api/stripe/checkout` — create a Stripe Checkout session
- `POST /api/stripe/portal` — create a Stripe Customer Portal session
- `POST /api/stripe/webhook` — receive Stripe webhook events

### Health
- `GET /api/health` — env var validation report + uptime + memory usage

Every route returns JSON with this envelope:
- **Success**: `{ ...data }` (200)
- **Error**: `{ error: string, code: string, ...meta }` (4xx/5xx) — error messages are user-friendly, never contain stack traces

---

## Production Deployment

See [`docs/DEPLOYMENT.md`](./docs/DEPLOYMENT.md) for the complete guide. The summary:

1. **Database**: Create a Supabase project → run `supabase/migrations/0001_init.sql` → copy the connection string
2. **Code**: Push to GitHub → import into Vercel
3. **Env vars**: Set all 12 vars in Vercel's project settings (see `.env.example`)
4. **Stripe**: Create 3 subscription products → register the webhook endpoint → set `STRIPE_WEBHOOK_SECRET`
5. **Deploy**: Vercel auto-builds with `bun run build` and serves at `https://your-app.vercel.app`

The repo includes `vercel.json` pre-configured with build settings, security headers, and caching rules.

---

## Security

This app implements defense-in-depth:

1. **Rate limiting** — every API endpoint has a per-user/per-IP limit. AI endpoints are strictest (8–12 req/min) to prevent cost spikes from API abuse.
2. **Input validation** — every user input is validated with Zod v4 schemas that strip control characters, cap lengths, restrict URLs to `http`/`https` (rejects `javascript:`), and detect common XSS patterns.
3. **Encryption at rest** — all stored credentials (WordPress app passwords, Shopify API keys, affiliate keys) are encrypted with AES-256-GCM using `ENCRYPTION_KEY`.
4. **Centralized error handling** — no raw stack traces or internal details ever leak to clients. Every error is translated to a user-friendly message with retry hints.
5. **Environment validation** — `/api/health` returns the status of every env var; missing required vars return HTTP 503.
6. **Security headers** — HSTS, X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy are set on every response (configured in `next.config.ts`).
7. **Row-Level Security** — Supabase RLS is enabled on every table, blocking direct access from the Supabase JS client.

For a security audit, run the included test suite:
```bash
node scripts/test-security.js
```
This exercises XSS rejection, oversized input handling, malformed JSON, `javascript:` URL rejection, weak password rejection, and rate-limit behavior.

---

## License

Private / proprietary. All rights reserved.
