'use client'

import { useState, useEffect, useCallback } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Loader2 } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Globe,
  Plus,
  Settings,
  ExternalLink,
  CheckCircle2,
  MoreVertical,
  Trash2,
  Eye,
  EyeOff,
  Zap,
  AlertTriangle,
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface ConnectedSite {
  id: string
  name: string
  url: string
  platform: string
  username?: string | null
  hasCredentials: boolean
  isActive: boolean
  articlesCount: number
  createdAt: string
  lastSyncAt?: string | null
}

const platformConfig: Record<string, {
  label: string
  icon: string
  color: string
  fields: string[]
}> = {
  wordpress: {
    label: 'WordPress',
    icon: 'WP',
    color: 'bg-blue-500/10 text-blue-500',
    fields: ['Site URL', 'Username/Email', 'Application Password'],
  },
  shopify: {
    label: 'Shopify',
    icon: 'SH',
    color: 'bg-green-500/10 text-green-500',
    fields: ['Store URL', 'API Key', 'Password'],
  },
  custom: {
    label: 'Custom Site',
    icon: 'CU',
    color: 'bg-purple-500/10 text-purple-500',
    fields: ['Site URL', 'Username/Email', 'API Key'],
  },
}

export function ConnectedSitesPage() {
  const [sites, setSites] = useState<ConnectedSite[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  // Form state
  const [newSiteName, setNewSiteName] = useState('')
  const [newSiteUrl, setNewSiteUrl] = useState('')
  const [newSitePlatform, setNewSitePlatform] = useState('wordpress')
  const [newUsername, setNewUsername] = useState('')
  const [newApiKey, setNewApiKey] = useState('')
  const [showPassword, setShowPassword] = useState(false)

  // Test connection state
  const [testingSiteId, setTestingSiteId] = useState<string | null>(null)

  // Fetch sites from API
  const fetchSites = useCallback(async () => {
    try {
      const res = await fetch('/api/sites')
      if (res.ok) {
        const data = await res.json()
        setSites(data.sites || [])
      }
    } catch (error) {
      console.error('Failed to fetch sites:', error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchSites()
  }, [fetchSites])

  // Add a new site
  const handleAddSite = async () => {
    if (!newSiteName.trim() || !newSiteUrl.trim()) {
      toast.error('Missing required fields', {
        description: 'Please enter a site name and URL.',
      })
      return
    }

    // Validate URL format
    try {
      new URL(newSiteUrl)
    } catch {
      toast.error('Invalid URL', {
        description: 'Please enter a valid URL starting with https://',
      })
      return
    }

    if (!newUsername.trim() || !newApiKey.trim()) {
      toast.error('Missing credentials', {
        description: 'Please enter both username and application password.',
      })
      return
    }

    setIsSaving(true)
    try {
      const res = await fetch('/api/sites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'demo-user',
          name: newSiteName,
          url: newSiteUrl,
          platform: newSitePlatform,
          username: newUsername,
          apiKey: newApiKey,
        }),
      })

      if (res.ok) {
        toast.success('Site connected successfully!', {
          description: `${newSiteName} has been added and credentials are encrypted.`,
        })
        resetForm()
        setIsAddDialogOpen(false)
        fetchSites()
      } else {
        const data = await res.json()
        toast.error('Failed to connect site', {
          description: data.error || 'An unexpected error occurred.',
        })
      }
    } catch {
      toast.error('Connection failed', {
        description: 'Could not reach the server. Please try again.',
      })
    } finally {
      setIsSaving(false)
    }
  }

  // Test connection to a site
  const handleTestConnection = async (siteId: string) => {
    setTestingSiteId(siteId)
    try {
      const res = await fetch(`/api/sites/${siteId}/test`, {
        method: 'POST',
      })
      const data = await res.json()

      if (data.success) {
        toast.success('Connection successful!', {
          description: data.message,
          duration: 5000,
        })
        fetchSites()
      } else {
        toast.error('Connection failed', {
          description: data.message,
          duration: 5000,
        })
      }
    } catch {
      toast.error('Test failed', {
        description: 'Could not reach the server. Please try again.',
      })
    } finally {
      setTestingSiteId(null)
    }
  }

  // Toggle site active status
  const handleToggleSite = async (siteId: string, currentState: boolean) => {
    try {
      const res = await fetch(`/api/sites/${siteId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !currentState }),
      })

      if (res.ok) {
        toast.success(currentState ? 'Site deactivated' : 'Site activated', {
          description: currentState
            ? 'BlogPilot AI will no longer publish to this site.'
            : 'BlogPilot AI can now publish to this site.',
        })
        fetchSites()
      }
    } catch {
      toast.error('Update failed', {
        description: 'Could not update site status.',
      })
    }
  }

  // Delete a site
  const handleDeleteSite = async (siteId: string, siteName: string) => {
    try {
      const res = await fetch(`/api/sites/${siteId}`, {
        method: 'DELETE',
      })

      if (res.ok) {
        toast.success('Site removed', {
          description: `${siteName} and its credentials have been permanently deleted.`,
        })
        fetchSites()
      }
    } catch {
      toast.error('Deletion failed', {
        description: 'Could not remove the site. Please try again.',
      })
    }
  }

  const resetForm = () => {
    setNewSiteName('')
    setNewSiteUrl('')
    setNewSitePlatform('wordpress')
    setNewUsername('')
    setNewApiKey('')
    setShowPassword(false)
  }

  const currentPlatform = platformConfig[newSitePlatform]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Globe className="h-6 w-6 text-primary" />
            Connected Sites
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage your WordPress, Shopify, and custom sites for direct publishing
          </p>
        </div>
        <Dialog
          open={isAddDialogOpen}
          onOpenChange={(open) => {
            setIsAddDialogOpen(open)
            if (!open) resetForm()
          }}
        >
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Add Site
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[520px]">
            <DialogHeader>
              <DialogTitle>Connect New Site</DialogTitle>
              <DialogDescription>
                Add a website where BlogPilot AI can publish articles directly. Your credentials are encrypted with AES-256 before storage.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-5 py-2">
              {/* Platform Selector */}
              <div className="space-y-2">
                <Label>Platform</Label>
                <div className="grid grid-cols-3 gap-3">
                  {Object.entries(platformConfig).map(([key, config]) => (
                    <button
                      key={key}
                      onClick={() => setNewSitePlatform(key)}
                      className={`p-3 rounded-lg border text-center transition-all ${
                        newSitePlatform === key
                          ? 'border-primary bg-primary/5 shadow-sm'
                          : 'border-border hover:border-border/80'
                      }`}
                    >
                      <div className={`h-7 w-7 rounded-md flex items-center justify-center text-xs font-bold mx-auto mb-1.5 ${config.color}`}>
                        {config.icon}
                      </div>
                      <span className="text-xs font-medium">{config.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Site Name */}
              <div className="space-y-2">
                <Label htmlFor="site-name">Site Name</Label>
                <Input
                  id="site-name"
                  placeholder="e.g., My Tech Blog"
                  value={newSiteName}
                  onChange={(e) => setNewSiteName(e.target.value)}
                />
              </div>

              {/* Site URL */}
              <div className="space-y-2">
                <Label htmlFor="site-url">Site URL</Label>
                <Input
                  id="site-url"
                  placeholder="https://yourblog.com"
                  value={newSiteUrl}
                  onChange={(e) => setNewSiteUrl(e.target.value)}
                />
                {newSiteUrl && !newSiteUrl.startsWith('https://') && (
                  <p className="text-xs text-yellow-500 flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    URL should start with https://
                  </p>
                )}
              </div>

              {/* Platform-specific auth fields */}
              <div className="space-y-2">
                <Label htmlFor="site-username">
                  {newSitePlatform === 'shopify' ? 'API Key' : 'Username / Email'}
                </Label>
                <Input
                  id="site-username"
                  placeholder={
                    newSitePlatform === 'wordpress'
                      ? 'admin'
                      : newSitePlatform === 'shopify'
                        ? 'shpat_xxxxxxxxxxxxx'
                        : 'your-email@example.com'
                  }
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                />
                {newSitePlatform === 'wordpress' && (
                  <p className="text-xs text-muted-foreground">
                    Generate an Application Password in WordPress under Profile → Applications
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="site-apikey">
                    {newSitePlatform === 'shopify' ? 'Password' : 'Application Password / API Key'}
                  </Label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                  >
                    {showPassword ? (
                      <>
                        <EyeOff className="h-3.5 w-3.5" /> Hide
                      </>
                    ) : (
                      <>
                        <Eye className="h-3.5 w-3.5" /> Show
                      </>
                    )}
                  </button>
                </div>
                <Input
                  id="site-apikey"
                  type={showPassword ? 'text' : 'password'}
                  placeholder={
                    newSitePlatform === 'wordpress'
                      ? 'xxxx xxxx xxxx xxxx xxxx xxxx'
                      : newSitePlatform === 'shopify'
                        ? 'Your Shopify admin password'
                        : 'Enter API key'
                  }
                  value={newApiKey}
                  onChange={(e) => setNewApiKey(e.target.value)}
                />
              </div>

              {/* Encryption notice */}
              <div className="flex items-start gap-2 rounded-lg border border-primary/20 bg-primary/5 p-3">
                <Zap className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-medium">AES-256-GCM Encryption</p>
                  <p className="text-[11px] text-muted-foreground">
                    Your credentials will be encrypted before storage and never exposed in API responses.
                  </p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setIsAddDialogOpen(false); resetForm() }}>
                Cancel
              </Button>
              <Button
                onClick={handleAddSite}
                disabled={isSaving || !newSiteName.trim() || !newSiteUrl.trim() || !newUsername.trim() || !newApiKey.trim()}
              >
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {isSaving ? 'Connecting...' : 'Connect Site'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Total Sites</p>
            <p className="text-2xl font-bold mt-1">{sites.length}</p>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Active Sites</p>
            <p className="text-2xl font-bold mt-1 text-green-500">
              {sites.filter((s) => s.isActive).length}
            </p>
          </CardContent>
        </Card>
        <Card className="border-border/50">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">Published Articles</p>
            <p className="text-2xl font-bold mt-1">
              {sites.reduce((acc, s) => acc + s.articlesCount, 0)}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Sites List */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : sites.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-16">
            <div className="flex flex-col items-center justify-center text-center gap-3">
              <div className="h-14 w-14 rounded-full bg-muted flex items-center justify-center">
                <Globe className="h-6 w-6 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium">No connected sites</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Add your first site to start publishing AI-generated articles directly
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {sites.map((site) => {
            const platform = platformConfig[site.platform] || platformConfig.custom
            return (
              <Card key={site.id} className="border-border/50">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* Platform icon */}
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center text-xs font-bold ${platform.color}`}>
                      {platform.icon}
                    </div>

                    {/* Site info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-sm truncate">{site.name}</p>
                        <Badge
                          variant={site.isActive ? 'secondary' : 'outline'}
                          className={`text-[10px] ${
                            site.isActive
                              ? 'bg-green-500/10 text-green-500 border-green-500/20'
                              : 'text-muted-foreground'
                          }`}
                        >
                          {site.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                        {site.hasCredentials && (
                          <Badge
                            variant="outline"
                            className="text-[10px] bg-blue-500/10 text-blue-500 border-blue-500/20"
                          >
                            <CheckCircle2 className="mr-1 h-3 w-3" />
                            Authenticated
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate mt-0.5">{site.url}</p>
                      {site.username && (
                        <p className="text-[11px] text-muted-foreground mt-0.5">
                          Auth as: <code className="bg-muted px-1 py-0.5 rounded font-mono">{site.username}</code>
                        </p>
                      )}
                    </div>

                    {/* Stats */}
                    <div className="hidden sm:flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="text-center">
                        <p className="font-medium text-foreground">{site.articlesCount}</p>
                        <p className="text-xs">Articles</p>
                      </div>
                      {site.lastSyncAt && (
                        <div className="text-center">
                          <p className="font-medium text-foreground text-xs">
                            {new Date(site.lastSyncAt).toLocaleDateString()}
                          </p>
                          <p className="text-xs">Last Sync</p>
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 text-xs"
                              onClick={() => handleTestConnection(site.id)}
                              disabled={testingSiteId === site.id}
                            >
                              {testingSiteId === site.id ? (
                                <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <Zap className="mr-1.5 h-3.5 w-3.5" />
                              )}
                              {testingSiteId === site.id ? 'Testing...' : 'Test'}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Test connection to this site</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>

                      <Switch
                        checked={site.isActive}
                        onCheckedChange={() => handleToggleSite(site.id, site.isActive)}
                        className="data-[state=checked]:bg-green-500"
                      />

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem className="text-xs">
                            <Settings className="mr-2 h-3.5 w-3.5" />
                            Settings
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-xs" onClick={() => window.open(site.url, '_blank')}>
                            <ExternalLink className="mr-2 h-3.5 w-3.5" />
                            Visit Site
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-xs text-destructive"
                            onClick={() => handleDeleteSite(site.id, site.name)}
                          >
                            <Trash2 className="mr-2 h-3.5 w-3.5" />
                            Remove
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
