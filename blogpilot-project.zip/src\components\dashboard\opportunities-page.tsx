'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Target,
  TrendingDown,
  MousePointerClick,
  FileQuestion,
  Loader2,
  AlertTriangle,
  CheckCircle,
  Link2,
  RefreshCw,
  Sparkles,
  PenTool,
  Eye,
  Search,
  ArrowRight,
  Bot,
  Layers,
  GitMerge,
  Megaphone,
  History,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'
import { useAppStore, type DashboardTab } from '@/lib/store'

interface GscProperty {
  siteUrl: string
  permissionLevel: string
}

interface Binding {
  id: string
  name: string
  url: string
  gscProperty: string | null
}

interface SitesResponse {
  connected: boolean
  needsReconnect?: boolean
  googleEmail?: string | null
  properties?: GscProperty[]
  bindings?: Binding[]
}

type CenterType =
  | 'quick-win' | 'ctr-opportunity' | 'refresh' | 'new-content'
  | 'topic-gap' | 'internal-link' | 'cannibalization' | 'affiliate'

interface OpportunityDto {
  id: string
  type: CenterType
  title: string
  target: string
  why: string[]
  impactScore: number
  factors: Array<{ name: string; value: number; max: number }>
  confidence: 'high' | 'medium' | 'low'
  difficulty: 'easy' | 'medium' | 'hard'
  action: string
  actionLabel: string
  source: string
}

interface OpportunitiesResponse {
  items: OpportunityDto[]
  countsByType: Partial<Record<CenterType, number>>
  sources: Record<string, 'connected' | 'not_connected'>
}

interface ActivityRow {
  id: string
  agent: string
  action: string
  targetLabel: string | null
  reason: string | null
  status: string
  error?: string | null
  createdAt: string
}

const TYPE_META: Record<CenterType, {
  label: string
  icon: React.ComponentType<{ className?: string }>
  color: string
}> = {
  'quick-win': { label: 'Quick Wins', icon: Target, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
  'ctr-opportunity': { label: 'Low CTR', icon: MousePointerClick, color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' },
  refresh: { label: 'Needs Refresh', icon: TrendingDown, color: 'text-red-400 bg-red-500/10 border-red-500/20' },
  'new-content': { label: 'Content Gaps', icon: FileQuestion, color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' },
  'topic-gap': { label: 'Topic Gaps', icon: Layers, color: 'text-violet-400 bg-violet-500/10 border-violet-500/20' },
  'internal-link': { label: 'Internal Links', icon: Link2, color: 'text-sky-400 bg-sky-500/10 border-sky-500/20' },
  cannibalization: { label: 'Cannibalization', icon: GitMerge, color: 'text-orange-400 bg-orange-500/10 border-orange-500/20' },
  affiliate: { label: 'Affiliate', icon: Megaphone, color: 'text-fuchsia-400 bg-fuchsia-500/10 border-fuchsia-500/20' },
}

function fmtPct(n: number): string {
  return `${(n * 100).toFixed(1)}%`
}

export default function OpportunitiesPage() {
  const setDashboardTab = useAppStore(s => s.setDashboardTab)
  const [phase, setPhase] = useState<'loading' | 'not-connected' | 'needs-reconnect' | 'select' | 'ready'>('loading')
  const [sitesData, setSitesData] = useState<SitesResponse | null>(null)
  const [userSites, setUserSites] = useState<Array<{ id: string; name: string }>>([])
  const [selectedProperty, setSelectedProperty] = useState<string>('')
  const [selectedSiteId, setSelectedSiteId] = useState<string>('')
  const [activeSiteId, setActiveSiteId] = useState<string | null>(null)
  const [opps, setOpps] = useState<OpportunitiesResponse | null>(null)
  const [oppsLoading, setOppsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [actionMsg, setActionMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [filter, setFilter] = useState<'all' | CenterType>('all')
  const [connecting, setConnecting] = useState(false)

  // Agent governance
  const [agentRunning, setAgentRunning] = useState(false)
  const [agentResult, setAgentResult] = useState<any>(null)
  const [pendingApprovals, setPendingApprovals] = useState<ActivityRow[]>([])
  const [recentActivity, setRecentActivity] = useState<ActivityRow[]>([])
  const [decidingId, setDecidingId] = useState<string | null>(null)

  async function loadOpportunities(siteId: string | null) {
    if (!siteId) return
    setOppsLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/opportunities?siteId=${encodeURIComponent(siteId)}`)
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to compute opportunities')
      setOpps(json.data)
      setActiveSiteId(siteId)
      setPhase('ready')
    } catch (err: any) {
      setError(err?.message || 'Failed to compute opportunities')
    } finally {
      setOppsLoading(false)
    }
  }

  function startLoad(_propertyUrl: string, siteId: string | null) {
    loadOpportunities(siteId)
  }

  const loadGovernance = useCallback(async () => {
    try {
      const res = await fetch('/api/activity?limit=25')
      if (!res.ok) return
      const json = await res.json()
      setPendingApprovals((json?.data?.activities || []).filter((a: ActivityRow) => a.status === 'pending_approval'))
      setRecentActivity((json?.data?.activities || []).slice(0, 12))
    } catch {}
  }, [])

  const loadSites = useCallback(async () => {
    try {
      setPhase(prev => (prev === 'ready' ? prev : 'loading'))
      const [gscRes, sitesRes] = await Promise.all([
        fetch('/api/gsc/sites'),
        fetch('/api/sites?limit=100'),
      ])
      const json = await gscRes.json()
      if (!gscRes.ok) throw new Error(json?.error || 'Failed to load Search Console status')
      const data: SitesResponse = json.data
      setSitesData(data)

      if (sitesRes.ok) {
        const sitesJson = await sitesRes.json()
        setUserSites(
          (sitesJson?.data?.sites || []).map((s: any) => ({ id: s.id as string, name: s.name as string }))
        )
      }

      if (!data.connected) {
        setPhase(data.needsReconnect ? 'needs-reconnect' : 'not-connected')
        return
      }

      // Prefer an existing binding so non-GSC opportunities still show fast.
      if ((data.bindings || []).length > 0) {
        startLoad(data.bindings![0].gscProperty!, data.bindings![0].id)
        return
      }
      setPhase('select')
    } catch (err: any) {
      setError(err?.message || 'Failed to load Search Console status')
      setPhase('select')
    }
  }, [])

  useEffect(() => { loadSites() }, [loadSites])
  useEffect(() => { loadGovernance() }, [loadGovernance])

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('google') === 'connected') {
      setActionMsg({ ok: true, text: 'Google account connected — Search Console access granted.' })
      window.history.replaceState(null, '', '/dashboard?tab=opportunities')
    } else if (params.get('google') === 'error') {
      setActionMsg({ ok: false, text: 'Google connection failed. Please try again.' })
      window.history.replaceState(null, '', '/dashboard?tab=opportunities')
    }
  }, [])

  const handleConnectGoogle = async () => {
    setConnecting(true)
    setError(null)
    try {
      const res = await fetch('/api/google/auth/url')
      const json = await res.json()
      if (!res.ok || !json?.data?.url) throw new Error(json?.error || 'Unable to start Google connection')
      window.location.href = json.data.url
    } catch (err: any) {
      setError(err?.message || 'Unable to start Google connection')
      setConnecting(false)
    }
  }

  const handleBindProperty = async () => {
    if (!selectedProperty) return
    setActionMsg(null)
    try {
      let boundSiteId = selectedSiteId || null
      const res = await fetch('/api/gsc/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ siteId: boundSiteId, propertyUrl: selectedProperty }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to link property')

      if (!boundSiteId) {
        const siteName = selectedProperty.replace(/^sc-https?:\/\//, '').replace(/^sc-domain:/, '')
        const created = await fetch('/api/sites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: siteName, url: selectedProperty.replace(/^sc-/, ''), platform: 'Webhook', isActive: false }),
        })
        const createdJson = await created.json()
        if (!created.ok) throw new Error(createdJson?.error || 'Failed to create site record for this property')
        boundSiteId = createdJson?.data?.site?.id
        await fetch('/api/gsc/connect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ siteId: boundSiteId, propertyUrl: selectedProperty }),
        })
      }

      setActionMsg({ ok: true, text: 'Property linked — loading your opportunities…' })
      startLoad(selectedProperty, boundSiteId)
    } catch (err: any) {
      setActionMsg({ ok: false, text: err?.message || 'Failed to link property' })
    }
  }

  const runAgent = async () => {
    if (!activeSiteId) return
    setAgentRunning(true)
    setAgentResult(null)
    try {
      const res = await fetch('/api/agent/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ siteId: activeSiteId }),
      })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Agent run failed')
      setAgentResult(json.data)
      await Promise.all([loadOpportunities(activeSiteId), loadGovernance()])
    } catch (err: any) {
      setError(err?.message || 'Agent run failed')
    } finally {
      setAgentRunning(false)
    }
  }

  const decideApproval = async (id: string, approve: boolean) => {
    setDecidingId(id)
    try {
      const res = await fetch(`/api/activity/${id}/${approve ? 'approve' : 'reject'}`, { method: 'POST' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Decision failed')
      setActionMsg({
        ok: true,
        text: approve ? `Approved — ${json?.data?.detail || 'executed'}.` : 'Rejected.',
      })
      await Promise.all([loadGovernance(), activeSiteId && loadOpportunities(activeSiteId)])
    } catch (err: any) {
      setMessageSafe(err?.message || 'Decision failed')
    } finally {
      setDecidingId(null)
    }
  }

  function setMessageSafe(text: string) {
    setActionMsg({ ok: false, text })
  }

  const handleAction = (o: OpportunityDto) => {
    switch (o.action) {
      case 'apply-internal-links':
        setDashboardTab('content-strategy' as DashboardTab)
        return
      case 'generate-affiliate-cluster':
        setDashboardTab('affiliate-campaigns' as DashboardTab)
        return
      case 'review-cannibalization':
        setDashboardTab('content-strategy' as DashboardTab)
        return
      default:
        try { sessionStorage.setItem('pendingOpportunity', o.target || o.title) } catch {}
        setDashboardTab('generate-article' as DashboardTab)
    }
  }

  const filtered = useMemo(() => {
    if (!opps) return []
    return filter === 'all' ? opps.items : opps.items.filter(o => o.type === filter)
  }, [opps, filter])

  // ── Render helpers ──

  function ConnectCard({ reconnect }: { reconnect: boolean }) {
    return (
      <Card className="bg-card/50 border border-border backdrop-blur-xl max-w-xl mx-auto">
        <CardContent className="p-8 text-center">
          <div className={cn(
            'w-14 h-14 rounded-2xl mx-auto flex items-center justify-center border mb-5',
            reconnect ? 'bg-amber-500/15 border-amber-500/20' : 'bg-cyan-500/15 border-cyan-500/20'
          )}>
            <Link2 className={cn('w-7 h-7', reconnect ? 'text-amber-400' : 'text-cyan-400')} />
          </div>
          <h2 className="text-lg font-semibold text-foreground mb-2">
            {reconnect ? 'Reconnect your Google account' : 'Connect Google Search Console'}
          </h2>
          <p className="text-sm text-muted-foreground leading-relaxed mb-6 max-w-md mx-auto">
            {reconnect
              ? 'Your Google connection predates Search Console access. Reconnect once to grant read-only permission.'
              : 'Grant read-only access to see real search data. Content-based opportunities are available right now even without it.'}
          </p>
          <Button
            onClick={handleConnectGoogle}
            disabled={connecting}
            className="rounded-xl px-6 bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
          >
            {connecting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Link2 className="w-4 h-4 mr-2" />}
            {reconnect ? 'Reconnect Google Account' : 'Connect Google Account'}
          </Button>
        </CardContent>
      </Card>
    )
  }

  function PropertySelector() {
    return (
      <Card className="bg-card/50 border border-border backdrop-blur-xl max-w-xl mx-auto">
        <CardContent className="p-8">
          <h2 className="text-lg font-semibold text-foreground mb-1">Choose a Search Console property</h2>
          <p className="text-sm text-muted-foreground mb-6">
            Pick the property to analyze. Optionally map it to one of your connected sites.
          </p>

          {(sitesData?.properties?.length ?? 0) === 0 ? (
            <div className="flex items-start gap-3 p-4 rounded-xl border border-border bg-muted/30">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                No verified properties found in this Search Console account. Verify your domain at{' '}
                <a href="https://search.google.com/search-console" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">search.google.com/search-console</a>{' '}
                then come back.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Search Console property</label>
                <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                  <SelectTrigger className="w-full bg-muted/40 border-border">
                    <SelectValue placeholder="Select a property…" />
                  </SelectTrigger>
                  <SelectContent>
                    {(sitesData?.properties || []).map(p => (
                      <SelectItem key={p.siteUrl} value={p.siteUrl}>
                        {p.siteUrl.replace(/^sc-https?:\/\//, '').replace(/^sc-domain:/, '')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                  Map to connected site <span className="opacity-60">(optional)</span>
                </label>
                <Select value={selectedSiteId} onValueChange={setSelectedSiteId}>
                  <SelectTrigger className="w-full bg-muted/40 border-border">
                    <SelectValue placeholder="None — track standalone" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None — track standalone</SelectItem>
                    {userSites.map(site => (
                      <SelectItem key={site.id} value={site.id}>{site.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleBindProperty}
                disabled={!selectedProperty}
                className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
              >
                Analyze this property
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  function ApprovalsAndActivity() {
    return (
      <>
        {pendingApprovals.length > 0 && (
          <Card className="bg-card/50 border border-amber-500/30 backdrop-blur-xl mb-6">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <Bot className="w-4 h-4 text-amber-400" />
                <span className="text-sm font-semibold text-foreground">
                  {pendingApprovals.length} recommended action{pendingApprovals.length > 1 ? 's' : ''} waiting for approval
                </span>
              </div>
              <div className="space-y-3">
                {pendingApprovals.map(a => (
                  <div key={a.id} className="flex flex-col sm:flex-row sm:items-center gap-3 p-3 rounded-xl border border-border bg-muted/20">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground">{a.targetLabel}</p>
                      <p className="text-[11px] text-muted-foreground">{a.reason} · {new Date(a.createdAt).toLocaleString()}</p>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button size="sm" variant="outline" className="rounded-xl" disabled={decidingId === a.id}
                        onClick={() => decideApproval(a.id, true)}>
                        Approve
                      </Button>
                      <Button size="sm" variant="ghost" className="rounded-xl text-muted-foreground" disabled={decidingId === a.id}
                        onClick={() => decideApproval(a.id, false)}>
                        Reject
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {recentActivity.length > 0 && (
          <Card className="bg-card/50 border border-border backdrop-blur-xl mb-6">
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <History className="w-4 h-4 text-violet-400" />
                <span className="text-sm font-semibold text-foreground">What is the AI doing?</span>
              </div>
              <ul className="space-y-2">
                {recentActivity.map(a => (
                  <li key={a.id} className="flex items-start gap-3 text-xs">
                    <Badge variant="secondary" className={cn('text-[9px] shrink-0 capitalize border',
                      a.status === 'success' && 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
                      a.status === 'failed' && 'bg-red-500/10 text-red-400 border-red-500/20',
                      a.status === 'pending_approval' && 'bg-amber-500/10 text-amber-400 border-amber-500/20',
                      a.status === 'rejected' && 'bg-muted text-muted-foreground border-transparent',
                    )}>
                      {a.agent}
                    </Badge>
                    <div className="min-w-0 flex-1">
                      <span className="text-foreground/80">{a.action.replace(/-/g, ' ')}</span>
                      {a.targetLabel && <span className="text-muted-foreground"> · {a.targetLabel.slice(0, 70)}</span>}
                      {a.reason && <span className="block text-[10px] text-muted-foreground/60 truncate">{a.reason}</span>}
                      {a.error && <span className="block text-[10px] text-red-400/80">{a.error}</span>}
                    </div>
                    <span className="shrink-0 text-[10px] text-muted-foreground/50">
                      {new Date(a.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </>
    )
  }

  function OpportunityList() {
    if (!opps) return null

    const allTypes = Object.keys(TYPE_META) as CenterType[]
    const presentTypes = allTypes.filter(t => (opps.countsByType[t] || 0) > 0)

    return (
      <>
        {/* Sources status */}
        <div className="flex flex-wrap items-center gap-3 mb-4 text-[11px] text-muted-foreground">
          <span>Data sources:</span>
          <span className="flex items-center gap-1">
            <span className={cn('w-1.5 h-1.5 rounded-full', opps.sources.gsc === 'connected' ? 'bg-emerald-400' : 'bg-muted-foreground/40')} />
            Search Console {opps.sources.gsc === 'connected' ? '' : '(not connected)'}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            Content analysis
          </span>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 mb-5">
          <button
            onClick={() => setFilter('all')}
            className={cn(
              'px-3 py-1.5 rounded-full text-xs font-medium border transition-colors',
              filter === 'all' ? 'border-cyan-400/40 bg-cyan-500/10 text-cyan-300' : 'border-border text-muted-foreground hover:text-foreground hover:bg-accent'
            )}
          >
            All ({opps.items.length})
          </button>
          {presentTypes.map(type => {
            const meta = TYPE_META[type]
            const count = opps.countsByType[type] || 0
            return (
              <button
                key={type}
                onClick={() => setFilter(type)}
                className={cn(
                  'px-3 py-1.5 rounded-full text-xs font-medium border transition-colors flex items-center gap-1.5',
                  filter === type ? meta.color : 'border-border text-muted-foreground hover:text-foreground hover:bg-accent'
                )}
              >
                <meta.icon className="w-3.5 h-3.5" />
                {meta.label} ({count})
              </button>
            )
          })}
        </div>

        {filtered.length === 0 ? (
          <Card className="bg-card/50 border border-border backdrop-blur-xl">
            <CardContent className="py-16 text-center">
              <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto mb-4" />
              <h3 className="text-base font-semibold text-foreground mb-1">No opportunities detected right now</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Generate more articles or wait for Search Console data to accumulate.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filtered.map((o, i) => {
              const meta = TYPE_META[o.type]
              return (
                <motion.div
                  key={o.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.04, 0.3), duration: 0.3 }}
                >
                  <Card className="bg-card/50 border border-border backdrop-blur-xl hover:border-border transition-all">
                    <CardContent className="p-5 flex flex-col sm:flex-row gap-5">
                      {/* Impact score */}
                      <div className="flex sm:flex-col items-center gap-2 shrink-0 sm:w-16">
                        <div className="relative w-14 h-14">
                          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                            <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" strokeWidth="10" className="text-border/40" />
                            <circle
                              cx="50" cy="50" r="42" fill="none" strokeWidth="10" strokeLinecap="round"
                              strokeDasharray={`${(o.impactScore / 100) * 264} 264`}
                              className={cn(
                                o.impactScore >= 70 ? 'stroke-emerald-400' :
                                o.impactScore >= 45 ? 'stroke-cyan-400' : 'stroke-amber-400'
                              )}
                            />
                          </svg>
                          <span className="absolute inset-0 flex items-center justify-center text-sm font-bold text-foreground">
                            {o.impactScore}
                          </span>
                        </div>
                        <span className="text-[9px] uppercase tracking-wide text-muted-foreground">Impact</span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1.5">
                          <h3 className="text-sm font-semibold text-foreground">{o.title}</h3>
                          <Badge variant="secondary" className={cn('text-[10px] border capitalize', meta.color)}>
                            {meta.label}
                          </Badge>
                          <Badge variant="secondary" className={cn(
                            'text-[10px] border-0',
                            o.confidence === 'high' && 'bg-emerald-500/15 text-emerald-400',
                            o.confidence === 'medium' && 'bg-amber-500/15 text-amber-400',
                            o.confidence === 'low' && 'bg-muted text-muted-foreground',
                          )}>
                            {o.confidence} confidence
                          </Badge>
                          <Badge variant="secondary" className="bg-muted text-muted-foreground border-0 text-[10px] capitalize">
                            {o.difficulty}
                          </Badge>
                        </div>
                        <ul className="space-y-1 mb-2">
                          {o.why.map((w, j) => (
                            <li key={j} className="text-xs text-muted-foreground flex items-start gap-1.5">
                              <span className="opacity-40 mt-0.5">•</span> {w}
                            </li>
                          ))}
                        </ul>
                        {/* Factor breakdown */}
                        <details className="group">
                          <summary className="text-[11px] text-muted-foreground/60 cursor-pointer hover:text-muted-foreground">
                            Why this score?
                          </summary>
                          <div className="mt-1.5 space-y-1 pl-3 border-l border-border/60">
                            {o.factors.map(f => (
                              <div key={f.name} className="flex items-center justify-between gap-3 text-[10px]">
                                <span className="text-muted-foreground">{f.name}</span>
                                <span className="tabular-nums text-foreground/70">{f.value}/{f.max}</span>
                              </div>
                            ))}
                          </div>
                        </details>
                      </div>

                      <Button
                        size="sm"
                        onClick={() => handleAction(o)}
                        className="shrink-0 self-start rounded-xl text-xs bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-white"
                      >
                        <PenTool className="w-3.5 h-3.5 mr-1.5" />
                        {o.actionLabel}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        )}
      </>
    )
  }

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">SEO Opportunities</h1>
            <p className="text-muted-foreground">What should I do next — ranked by potential impact, from real data</p>
          </div>
          {phase === 'ready' && activeSiteId && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={runAgent}
                disabled={agentRunning || oppsLoading}
                className="rounded-xl border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/10"
              >
                {agentRunning ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Bot className="w-4 h-4 mr-2" />}
                Run agent now
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => activeSiteId && loadOpportunities(activeSiteId)}
                disabled={oppsLoading}
                className="rounded-xl"
              >
                {oppsLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                Refresh
              </Button>
            </div>
          )}
        </div>

        {actionMsg && (
          <div className={cn(
            'mb-6 flex items-center gap-3 px-4 py-3 rounded-xl border text-sm break-all',
            actionMsg.ok ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
          )}>
            {actionMsg.ok ? <CheckCircle className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
            {actionMsg.text}
          </div>
        )}

        {error && phase !== 'select' && (
          <div className="mb-6 flex items-center gap-3 px-4 py-3 rounded-xl border border-red-500/20 bg-red-500/10 text-sm text-red-400">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        {phase === 'loading' || (oppsLoading && !opps) ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 rounded-2xl bg-card/40 border border-border animate-pulse" style={{ animationDelay: `${i * 120}ms` }} />
            ))}
          </div>
        ) : phase === 'not-connected' ? (
          <>
            {/* Content-based opportunities work even before GSC connection. */}
            <ConnectCard reconnect={false} />
            <div className="mt-8">
              {opps && opps.items.length > 0 ? (
                <>
                  <ApprovalsAndActivity />
                  <OpportunityList />
                </>
              ) : null}
            </div>
          </>
        ) : phase === 'needs-reconnect' ? (
          <ConnectCard reconnect={true} />
        ) : phase === 'select' ? (
          <PropertySelector />
        ) : (
          <>
            <ApprovalsAndActivity />
            {oppsLoading && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                <Loader2 className="w-4 h-4 animate-spin" /> Recomputing opportunities…
              </div>
            )}
            <OpportunityList />
          </>
        )}

        <div className="mt-10 flex items-start gap-3 text-xs text-muted-foreground/70">
          <Sparkles className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <p>
            Impact scores are estimated from transparent factors (traffic potential, ranking distance, urgency,
            business value). They indicate opportunity — not guaranteed results.
          </p>
        </div>
      </div>
    </div>
  )
}
