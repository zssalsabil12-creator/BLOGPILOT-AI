/**
 * Minimal Upstash-REST-compatible Redis mock for multi-instance integration
 * testing. Supports exactly what BlogPilot's providers call:
 *   POST /pipeline   body: [["INCR",k],["EXPIRE",k,sec,"NX"],["GET",k],["SET",k,v],["PEXPIRE",k,ms]]
 *   GET  /get/{key}                -> {result: value|null}
 *   GET  /set/{key}/{value}/EX/{s} -> {result: "OK"}
 *
 * Control endpoints:
 *   GET /__down            -> respond 503 (simulate provider outage)
 *   GET /__up              -> restore
 *   GET /__dump            -> current kv snapshot
 */

import http from 'node:http';
import fs from 'node:fs';

const PORT = Number(process.env.UPSTASH_MOCK_PORT || 4320);
const kv = new Map(); // string -> { value: string, expiresAt?: number }
let down = false;

const now = () => Date.now();
const alive = (e) => e && (!e.expiresAt || e.expiresAt > now());
const get = (k) => (alive(kv.get(k)) ? kv.get(k).value : null);

function exec(cmd) {
  const op = String(cmd[0] || '').toUpperCase();
  const key = cmd[1];
  switch (op) {
    case 'INCR': {
      const cur = Number(get(key) ?? 0) + 1;
      const entry = kv.get(key);
      if (alive(entry)) entry.value = String(cur);
      else kv.set(key, { value: String(cur), expiresAt: entry?.expiresAt });
      return cur;
    }
    case 'EXPIRE': {
      const entry = kv.get(key);
      if (!alive(entry)) return 0;
      if (cmd[3] === 'NX' && entry.expiresAt) return 1;
      entry.expiresAt = now() + Number(cmd[2]) * 1000;
      return 1;
    }
    case 'PEXPIRE': {
      const entry = kv.get(key);
      if (!alive(entry)) return 0;
      entry.expiresAt = now() + Number(cmd[2]);
      return 1;
    }
    case 'SET': {
      kv.set(key, { value: String(cmd[2] ?? '') });
      return 'OK';
    }
    case 'GET':
      return get(key);
    default:
      return null;
  }
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);

  if (url.pathname === '/__down') { down = true; res.writeHead(200); return res.end('down'); }
  if (url.pathname === '/__up') { down = false; res.writeHead(200); return res.end('up'); }
  if (url.pathname === '/__dump') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(Object.fromEntries([...kv.entries()].filter(([, v]) => alive(v)).map(([k, v]) => [k, v.value]))));
  }

  if (down) { res.writeHead(503); return res.end('provider down'); }

  if (req.method === 'POST' && url.pathname === '/pipeline') {
    let body = '';
    req.on('data', c => (body += c));
    req.on('end', () => {
      let cmds = [];
      try { cmds = JSON.parse(body || '[]'); } catch {}
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(cmds.map(c => ({ result: exec(c) }))));
    });
    return;
  }

  // Path-style: /get/{key} | /set/{key}/{value}/EX/{seconds}
  const parts = url.pathname.slice(1).split('/').map(decodeURIComponent);
  const op = (parts[0] || '').toUpperCase();

  if (op === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ result: get(parts[1]) }));
  }
  if (op === 'SET') {
    const key = parts[1];
    let value = parts[2] ?? '';
    let expiresAt;
    if ((parts[3] || '').toUpperCase() === 'EX') expiresAt = now() + Number(parts[4]) * 1000;
    kv.set(key, { value, expiresAt });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ result: 'OK' }));
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'unknown command' }));
});

// Optional auto-shutdown flag for failover tests
setInterval(() => {
  if (fs.existsSync('scripts/redis-down-flag')) down = true;
  else down = false && down ? false : down;
  // flag presence forces down; absence does NOT auto-recover (use /__up)
  if (!fs.existsSync('scripts/redis-down-flag') && !down) return;
}, 1000);

server.listen(PORT, () => console.log(`[upstash-mock] REST Redis on :${PORT}`));
