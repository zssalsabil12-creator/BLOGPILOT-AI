import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { scanAffiliateLinks } from '@/lib/affiliate';

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const limit = await checkRateLimit(`aff-scan:${userId}`, { windowMs: 60_000, maxRequests: 3 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Scan limit reached — try again in a minute.' }, { status: 429 });
  }

  try {
    const reports = await scanAffiliateLinks(userId);
    const broken = reports.filter(r => r.status === 'error').length;
    return NextResponse.json({
      ok: true,
      data: {
        scanned: reports.length,
        broken,
        deactivated: reports.filter(r => r.status === 'error').length,
        reports: reports.slice(0, 50),
      },
    });
  } catch (error: any) {
    console.error('Broken links scan error:', error);
    return NextResponse.json({ ok: false, error: 'Scan failed' }, { status: 502 });
  }
}
