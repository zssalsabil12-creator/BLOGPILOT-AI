/**
 * Topical Authority Engine.
 *
 * Clusters the user's existing articles into topic clusters, identifies
 * pillar candidates, detects cannibalization (two pages targeting the same
 * intent), flags orphan/weak content, and produces a prioritized roadmap of
 * missing supporting articles.
 *
 * Primary strategy: ONE cheap Gemini clustering call over the user's own
 * keyword/title list, cached per article-set digest. Deterministic token-
 * overlap fallback when AI is unavailable — never fabricated.
 */

import prisma from '@/lib/prisma';
import { generateText, isGeminiConfigured } from './gemini';
import { cacheGet, cacheSet, hashKeyParts } from './cache';

export interface TopicCluster {
  name: string;
  pillar: { title: string; keyword: string | null; articleId: string | null } | null;
  members: Array<{ articleId: string; title: string; keyword: string | null; status: string; seoScore: number | null }>;
  missingSubtopics: string[];
  coverage: 'strong' | 'partial' | 'thin';
}

export interface CannibalizationIssue {
  keywords: string[];
  articles: Array<{ articleId: string; title: string; status: string }>;
  recommendation: 'merge' | 're-target' | 'differentiate';
  detail: string;
}

export interface RoadmapItem {
  title: string;
  clusterName: string;
  intent: 'informational' | 'commercial' | 'comparison' | 'unknown';
  priority: 'high' | 'medium' | 'low';
  reason: string;
}

export interface TopicalMapResult {
  clusters: TopicCluster[];
  cannibalization: CannibalizationIssue[];
  roadmap: RoadmapItem[];
  stats: {
    totalArticles: number;
    clustersFound: number;
    orphanCandidates: number;
    aiPowered: boolean;
  };
}

interface AiClusterOutput {
  clusters: Array<{
    name: string;
    pillarKeyword?: string;
    memberKeywords?: string[];
    missingSubtopics?: string[];
  }>;
  roadmap?: Array<{
    title: string;
    cluster?: string;
    intent?: string;
    priority?: string;
    reason?: string;
  }>;
}

function tokenize(text: string): Set<string> {
  return new Set(
    text.toLowerCase().replace(/[^a-z\u0600-\u06FF\s]/g, ' ').split(/\s+/).filter(w => w.length > 3)
  );
}

function jaccard(a: Set<string>, b: Set<string>): number {
  const inter = [...a].filter(x => b.has(x)).length;
  const union = new Set([...a, ...b]).size;
  return union === 0 ? 0 : inter / union;
}

/** Deterministic fallback clustering via greedy token-overlap agglomeration. */
function deterministicClusters(articles: ArticleLite[]): TopicCluster[] {
  const used = new Set<string>();
  const clusters: TopicCluster[] = [];

  for (const a of articles) {
    if (used.has(a.id)) continue;
    const seedTokens = tokenize(`${a.targetKeyword || ''} ${a.title}`);
    const members = articles.filter(b => {
      if (used.has(b.id)) return false;
      const sim = jaccard(seedTokens, tokenize(`${b.targetKeyword || ''} ${b.title}`));
      return sim >= 0.28 || b.id === a.id;
    });
    for (const m of members) used.add(m.id);

    // Pillar = longest content / most "hub-like" (shortest keyword, highest score).
    const sorted = [...members].sort((x, y) => (y.seoScore ?? 0) - (x.seoScore ?? 0));
    const pillar = sorted[0] || a;

    clusters.push({
      name: pillar.targetKeyword || pillar.title.slice(0, 50),
      pillar: { title: pillar.title, keyword: pillar.targetKeyword, articleId: pillar.id },
      members: members.map(m => ({
        articleId: m.id,
        title: m.title,
        keyword: m.targetKeyword,
        status: m.status,
        seoScore: m.seoScore,
      })),
      missingSubtopics: [],
      coverage: members.length >= 4 ? 'strong' : members.length >= 2 ? 'partial' : 'thin',
    });
  }

  return clusters.sort((a, b) => b.members.length - a.members.length);
}

interface ArticleLite {
  id: string;
  title: string;
  slug: string | null;
  targetKeyword: string | null;
  status: string;
  seoScore: number | null;
  wordCount: number | null;
  siteId: string | null;
}

async function aiClusters(userId: string, articles: ArticleLite[]): Promise<AiClusterOutput | null> {
  if (!isGeminiConfigured() || articles.length < 3) return null;

  const digest = hashKeyParts(...articles.flatMap(a => [a.id, a.targetKeyword || '', a.title]));
  // userId-scoped: clustering output derives from a user's private titles,
  // so it must never be served from a global cache key.
  const key = `topical:v1:${userId}:${digest}`;
  const cached = await cacheGet<AiClusterOutput>(key);
  if (cached) return cached;

  const prompt = `You are a topical authority strategist. Given this list of the site's articles (keyword + title), group them into topic clusters.

Return ONLY raw JSON:
{
  "clusters": [
    { "name": "<cluster topic>", "pillarKeyword": "<keyword of the best pillar page or null>",
      "memberKeywords": ["<exact targetKeyword values from list that belong>"],
      "missingSubtopics": ["<2-5 specific subtopics/articles this cluster lacks>"] }
  ],
  "roadmap": [
    { "title": "<specific article to create>", "cluster": "<cluster name>",
      "intent": "informational|commercial|comparison", "priority": "high|medium|low",
      "reason": "<one short sentence>" }
  ]
}
Rules: every article's keyword must appear in exactly one cluster. Max 8 clusters. Max 8 roadmap items. Be specific.

ARTICLES:
${articles.map((a, i) => `${i + 1}. keyword="${a.targetKeyword || '-'}" title="${a.title}" (${a.status}, ${a.wordCount ?? 0}w)`).join('\n')}`;

  try {
    const out = await generateText(prompt, 1400);
    const cleaned = out.replace(/^```(?:json)?/m, '').replace(/```\s*$/m, '').trim();
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    const parsed = JSON.parse(cleaned.slice(start, end + 1));
    const result: AiClusterOutput = { clusters: parsed.clusters || [], roadmap: parsed.roadmap || [] };
    await cacheSet(key, result, 6 * 3600);
    return result;
  } catch (err: any) {
    console.warn('[topical-map] AI clustering failed:', err?.message || err);
    return null;
  }
}

export async function buildTopicalMap(userId: string, siteId?: string | null): Promise<TopicalMapResult> {
  const articles: ArticleLite[] = await prisma.article.findMany({
    where: { userId, ...(siteId ? { siteId } : {}) },
    orderBy: { updatedAt: 'desc' },
    take: 300,
    select: { id: true, title: true, slug: true, targetKeyword: true, status: true, seoScore: true, wordCount: true, siteId: true },
  });

  if (articles.length === 0) {
    return {
      clusters: [],
      cannibalization: [],
      roadmap: [],
      stats: { totalArticles: 0, clustersFound: 0, orphanCandidates: 0, aiPowered: false },
    };
  }

  // ── Cannibalization: near-identical keywords or highly overlapping titles ──
  const cannibalization: CannibalizationIssue[] = [];
  const kwGroups = new Map<string, ArticleLite[]>();
  for (const a of articles) {
    const kw = (a.targetKeyword || '').toLowerCase().trim();
    if (!kw) continue;
    const norm = kw.split(/\s+/).sort().join(' ');
    kwGroups.set(norm, [...(kwGroups.get(norm) || []), a]);
  }
  for (const [, group] of kwGroups.entries()) {
    if (group.length >= 2) {
      cannibalization.push({
        keywords: [...new Set(group.map(g => g.targetKeyword || ''))],
        articles: group.map(g => ({ articleId: g.id, title: g.title, status: g.status })),
        recommendation: group.some(g => g.status === 'PUBLISHED') ? 'merge' : 're-target',
        detail: `${group.length} articles target effectively the same keyword. Merge into one stronger page or re-target one toward a distinct sub-intent.`,
      });
    }
  }
  // Title overlap pass (catches different keywords, same intent).
  for (let i = 0; i < articles.length && cannibalization.length < 10; i++) {
    for (let j = i + 1; j < articles.length; j++) {
      const sim = jaccard(tokenize(articles[i].title), tokenize(articles[j].title));
      if (sim >= 0.65 && !cannibalization.some(c => c.articles.some(a => a.articleId === articles[j].id))) {
        cannibalization.push({
          keywords: [articles[i].targetKeyword || '-', articles[j].targetKeyword || '-'],
          articles: [
            { articleId: articles[i].id, title: articles[i].title, status: articles[i].status },
            { articleId: articles[j].id, title: articles[j].title, status: articles[j].status },
          ],
          recommendation: 'differentiate',
          detail: `Titles are ${(sim * 100).toFixed(0)}% similar — search engines may struggle to pick which page ranks.`,
        });
      }
    }
  }

  // ── Clustering: AI primary, deterministic fallback ──
  const ai = await aiClusters(userId, articles);
  let clusters: TopicCluster[] = [];

  if (ai && ai.clusters.length > 0) {
    const byKw = new Map<string, ArticleLite[]>();
    for (const a of articles) {
      const kw = (a.targetKeyword || '').toLowerCase().trim();
      if (!kw) continue;
      byKw.set(kw, [...(byKw.get(kw) || []), a]);
    }

    const assigned = new Set<string>();
    for (const c of ai.clusters) {
      const members: TopicCluster['members'] = [];
      for (const kwRaw of c.memberKeywords || []) {
        const matches = byKw.get(kwRaw.toLowerCase().trim()) || [];
        for (const m of matches) {
          if (!assigned.has(m.id)) {
            assigned.add(m.id);
            members.push({ articleId: m.id, title: m.title, keyword: m.targetKeyword, status: m.status, seoScore: m.seoScore });
          }
        }
      }
      if (members.length === 0) continue;

      const pillarMember =
        members.find(m => m.keyword && c.pillarKeyword && m.keyword.toLowerCase() === c.pillarKeyword.toLowerCase()) ||
        [...members].sort((x, y) => (y.seoScore ?? 0) - (x.seoScore ?? 0))[0];

      clusters.push({
        name: c.name,
        pillar: pillarMember ? { title: pillarMember.title, keyword: pillarMember.keyword, articleId: pillarMember.articleId } : null,
        members,
        missingSubtopics: (c.missingSubtopics || []).slice(0, 6),
        coverage: members.length >= 4 ? 'strong' : members.length >= 2 ? 'partial' : 'thin',
      });
    }

    // Sweep unassigned into a residual cluster so nothing disappears.
    const unassigned = articles.filter(a => !assigned.has(a.id));
    if (unassigned.length > 0) {
      clusters.push({
        name: 'Unsorted',
        pillar: null,
        members: unassigned.map(m => ({
          articleId: m.id, title: m.title, keyword: m.targetKeyword, status: m.status, seoScore: m.seoScore,
        })),
        missingSubtopics: [],
        coverage: 'thin',
      });
    }

    clusters.sort((a, b) => b.members.length - a.members.length);

    const roadmap: RoadmapItem[] = (ai.roadmap || []).slice(0, 8).map(r => ({
      title: String(r.title),
      clusterName: String(r.cluster || ''),
      intent: (['informational', 'commercial', 'comparison'].includes(String(r.intent))
        ? String(r.intent)
        : 'unknown') as RoadmapItem['intent'],
      priority: (['high', 'medium', 'low'].includes(String(r.priority)) ? String(r.priority) : 'medium') as RoadmapItem['priority'],
      reason: String(r.reason || ''),
    }));

    const orphanCount = articles.filter(a => {
      // Orphan candidate: belongs to no cluster with ≥2 members.
      return !clusters.some(c => c.members.length >= 2 && c.members.some(m => m.articleId === a.id));
    }).length;

    return {
      clusters,
      cannibalization,
      roadmap,
      stats: {
        totalArticles: articles.length,
        clustersFound: clusters.filter(c => c.name !== 'Unsorted').length,
        orphanCandidates: orphanCount,
        aiPowered: true,
      },
    };
  }

  clusters = deterministicClusters(articles);
  const roadmap: RoadmapItem[] = [];
  for (const c of clusters.filter(x => x.coverage !== 'strong').slice(0, 4)) {
    roadmap.push({
      title: `${c.name} — complete guide`,
      clusterName: c.name,
      intent: 'informational',
      priority: c.members.length >= 3 ? 'high' : 'medium',
      reason: `Cluster has only ${c.members.length} article(s); a pillar guide would anchor it.`,
    });
  }

  const orphanCount = articles.filter(a =>
    !clusters.some(c => c.members.length >= 2 && c.members.some(m => m.articleId === a.id))
  ).length;

  return {
    clusters,
    cannibalization,
    roadmap,
    stats: {
      totalArticles: articles.length,
      clustersFound: clusters.length,
      orphanCandidates: orphanCount,
      aiPowered: false,
    },
  };
}
