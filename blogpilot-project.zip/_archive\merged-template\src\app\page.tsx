'use client'

import { useAppStore } from '@/lib/store'
import { LandingPage } from '@/components/landing/landing-page'
import { LoginPage, SignupPage } from '@/components/auth/auth-pages'
import { Dashboard } from '@/components/dashboard/dashboard'

export default function Home() {
  const { currentView } = useAppStore()

  switch (currentView) {
    case 'landing':
      return <LandingPage />
    case 'login':
      return <LoginPage />
    case 'signup':
      return <SignupPage />
    case 'dashboard':
    case 'analytics':
    case 'generate-article':
    case 'connected-sites':
    case 'affiliate-credentials':
    case 'history':
      return <Dashboard />
    default:
      return <LandingPage />
  }
}
