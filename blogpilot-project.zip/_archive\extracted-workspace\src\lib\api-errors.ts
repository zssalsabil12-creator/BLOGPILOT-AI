/**
 * Centralized API Error Handling
 *
 * Provides a single `handleApiError` helper that every route handler
 * can call from its `catch` block. Translates known error types into
 * user-friendly messages so the API never leaks raw stack traces or
 * internal upstream error text.
 *
 * User-friendly message philosophy:
 *   - The end-user does not care that "GoogleGenerativeAI threw
 *     RequestFailedError: 429 ResourceExhausted" — they just need to
 *     know the AI service is busy and they should retry shortly.
 *   - Internal diagnostics go to server logs (console.error), NOT to
 *     the response body.
 *
 * Error categories handled:
 *   - AuthError (from @/lib/auth) → user-friendly auth message + status
 *   - ZodError (validation) → already handled before this layer
 *   - AbortError (timeout) → "service timed out" message
 *   - Network errors (fetch failed) → "service unreachable"
 *   - AI provider errors (Gemini / z-ai) → "AI service busy"
 *   - Prisma errors (database) → "database error, please retry"
 *   - Generic Error → stripped, generic message
 */

import { NextResponse } from 'next/server'
import { ZodError } from 'zod'
import { AuthError } from '@/lib/auth'

/* -------------------------------------------------------------------------- */
/*                            Error classification                            */
/* -------------------------------------------------------------------------- */

export type ErrorCategory =
  | 'auth'
  | 'validation'
  | 'rate_limit'
  | 'timeout'
  | 'ai_unreachable'
  | 'scrape_unreachable'
  | 'database'
  | 'upstream'
  | 'payment'
  | 'not_found'
  | 'internal'

export interface ApiErrorShape {
  error: string
  code: ErrorCategory
  /** Optional — when true, the client should retry after a short delay. */
  retryable?: boolean
  /** Optional — seconds to wait before retrying. */
  retryAfter?: number
  /** Optional — opaque correlation id for support (NOT a raw stack). */
  traceId?: string
}

/* -------------------------------------------------------------------------- */
/*                         User-friendly message map                          */
/* -------------------------------------------------------------------------- */

const MESSAGES: Record<ErrorCategory, string> = {
  auth: 'You must be signed in to perform this action.',
  validation: 'The request contained invalid data. Please check your input and try again.',
  rate_limit: 'Too many requests. Please slow down and try again shortly.',
  timeout: 'The request took too long to complete. Please try again.',
  ai_unreachable: 'The AI service is busy right now. Please try again in a moment.',
  scrape_unreachable: 'We could not reach the web scraping service. Please try again later.',
  database: 'A database error occurred. Your data is safe — please try again.',
  upstream: 'An upstream service is unavailable. Please try again shortly.',
  payment: 'Payment could not be processed. Please check your payment method and retry.',
  not_found: 'The requested resource was not found.',
  internal: 'Something went wrong on our end. Please try again.',
}

/* -------------------------------------------------------------------------- */
/*                          Error → category resolver                         */
/* -------------------------------------------------------------------------- */

interface ResolvedError {
  category: ErrorCategory
  status: number
  /** Detailed message for server logs (NOT for client). */
  internalMessage: string
  retryable?: boolean
  retryAfter?: number
}

/**
 * Classify an unknown error caught in a route handler.
 *
 * We rely on:
 *   - instanceof checks for our own error types
 *   - name / message pattern matching for third-party errors (Prisma,
 *     fetch, AbortController, Stripe, GoogleGenerativeAI)
 */
function classifyError(error: unknown): ResolvedError {
  // ─── Our own typed errors ───
  if (error instanceof AuthError) {
    return {
      category: 'auth',
      status: error.statusCode || 401,
      internalMessage: error.message,
    }
  }

  if (error instanceof ZodError) {
    return {
      category: 'validation',
      status: 400,
      internalMessage: error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; '),
    }
  }

  // ─── Native error wrappers ───
  if (error instanceof Error) {
    const name = error.name
    const msg = error.message || ''

    // AbortController / fetch timeout
    if (name === 'AbortError' || name === 'TimeoutError' || /timed?\s*out/i.test(msg)) {
      return {
        category: 'timeout',
        status: 504,
        internalMessage: `Timeout: ${msg}`,
        retryable: true,
        retryAfter: 5,
      }
    }

    // Network errors (fetch failed, ECONNRESET, ENOTFOUND, etc.)
    if (
      name === 'TypeError' && /fetch failed/i.test(msg) ||
      /ECONNRESET|ENOTFOUND|ECONNREFUSED|EAI_AGAIN|networkerror/i.test(msg)
    ) {
      // Guess based on which API the route is calling — we can't know
      // for sure here, so use the generic "upstream" category. The
      // route can override this by wrapping the call in
      // `withCategory('ai_unreachable', () => ...)`.
      return {
        category: 'upstream',
        status: 502,
        internalMessage: `Network error: ${msg}`,
        retryable: true,
        retryAfter: 10,
      }
    }

    // Prisma errors
    if (name === 'PrismaClientKnownRequestError' || name.startsWith('Prisma')) {
      // P2025 = record not found
      const code = (error as any).code
      if (code === 'P2025') {
        return {
          category: 'not_found',
          status: 404,
          internalMessage: `Prisma P2025: ${msg}`,
        }
      }
      // P2002 = unique constraint violation
      if (code === 'P2002') {
        return {
          category: 'validation',
          status: 409,
          internalMessage: `Prisma P2002: ${msg}`,
        }
      }
      return {
        category: 'database',
        status: 500,
        internalMessage: `Prisma ${code || name}: ${msg}`,
        retryable: true,
      }
    }

    // Google Generative AI errors
    if (
      name === 'GoogleGenerativeAIError' ||
      name === 'GoogleGenerativeAIRequestError' ||
      name === 'GoogleGenerativeAIFetchError' ||
      /generative-ai|gemini/i.test(name) ||
      /RESOURCE_EXHAUSTED|429|quota|rate.?limit/i.test(msg)
    ) {
      return {
        category: 'ai_unreachable',
        status: 503,
        internalMessage: `AI provider error (${name}): ${msg}`,
        retryable: true,
        retryAfter: 15,
      }
    }

    // Stripe errors
    if (name.startsWith('Stripe') || /stripe/i.test(name)) {
      const stripeErr = error as any
      // StripeAuthenticationError, StripeCardError, etc.
      if (stripeErr.type === 'StripeCardError' || /card_declined/i.test(stripeErr.code || '')) {
        return {
          category: 'payment',
          status: 402,
          internalMessage: `Stripe card error: ${msg} (code=${stripeErr.code})`,
        }
      }
      return {
        category: 'upstream',
        status: 502,
        internalMessage: `Stripe error (${name}): ${msg}`,
        retryable: true,
      }
    }

    // Generic Error fallback — never expose raw message to client
    return {
      category: 'internal',
      status: 500,
      internalMessage: `${name}: ${msg}`,
    }
  }

  // ─── Non-Error throwables (strings, plain objects) ───
  return {
    category: 'internal',
    status: 500,
    internalMessage: typeof error === 'string' ? error : JSON.stringify(error),
  }
}

/* -------------------------------------------------------------------------- */
/*                              Public helper                                 */
/* -------------------------------------------------------------------------- */

/**
 * Handle an error caught in a route handler.
 *
 *   try {
 *     // ... route logic
 *   } catch (error) {
 *     return handleApiError(error, 'generate-article')
 *   }
 *
 * The `routeName` is logged for debugging but never sent to the client.
 */
export function handleApiError(
  error: unknown,
  routeName: string
): NextResponse<ApiErrorShape> {
  const resolved = classifyError(error)
  const userMessage = MESSAGES[resolved.category]

  // Server-side log with full detail for debugging
  console.error(`[api:${routeName}] ${resolved.category} — ${resolved.internalMessage}`)

  const body: ApiErrorShape = {
    error: userMessage,
    code: resolved.category,
    ...(resolved.retryable ? { retryable: true } : {}),
    ...(resolved.retryAfter ? { retryAfter: resolved.retryAfter } : {}),
  }

  const headers: Record<string, string> = {}
  if (resolved.retryAfter) {
    headers['Retry-After'] = String(resolved.retryAfter)
  }

  return NextResponse.json(body, { status: resolved.status, headers })
}

/**
 * Wrap an async route handler with try/catch + centralized error handling.
 *
 *   export const POST = withErrorHandler('generate', async (request) => {
 *     // ... route logic — throw freely, errors get translated
 *     return NextResponse.json({ ok: true })
 *   })
 *
 * Use this when you want cleaner route bodies and don't need custom
 * error branching.
 */
export function withErrorHandler(
  routeName: string,
  handler: (request: Request, ctx?: any) => Promise<NextResponse>
): (request: Request, ctx?: any) => Promise<NextResponse> {
  return async (request, ctx) => {
    try {
      return await handler(request, ctx)
    } catch (error) {
      return handleApiError(error, routeName)
    }
  }
}

/**
 * Tagged error — lets a route handler explicitly classify an error
 * before throwing, so classifyError() respects the override.
 *
 * Example:
 *   throw taggedError('ai_unreachable', 'Gemini 429 quota exceeded', 503)
 */
export class TaggedError extends Error {
  category: ErrorCategory
  status: number
  retryable?: boolean
  retryAfter?: number

  constructor(
    category: ErrorCategory,
    message: string,
    status: number = 500,
    opts?: { retryable?: boolean; retryAfter?: number }
  ) {
    super(message)
    this.name = 'TaggedError'
    this.category = category
    this.status = status
    if (opts?.retryable !== undefined) this.retryable = opts.retryable
    if (opts?.retryAfter !== undefined) this.retryAfter = opts.retryAfter
  }
}

// Re-export the typed classification so route handlers can use TaggedError
// without importing classifyError directly.
export { classifyError }
