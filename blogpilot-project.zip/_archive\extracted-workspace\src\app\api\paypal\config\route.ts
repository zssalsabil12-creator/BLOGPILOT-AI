import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { isPaypalConfigured } from '@/lib/paypal'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * GET /api/paypal/config
 *
 * Returns the public PayPal config + whether PayPal is configured.
 *
 * Used by the Billing page to decide whether to render the PayPal button
 * and what client ID to pass to the PayPal JS SDK.
 *
 * Response:
 *   200 {
 *     clientId: string | null,
 *     configured: boolean,
 *     mode: 'sandbox' | 'live',
 *   }
 */
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    // Require auth so unauthenticated callers can't probe the config
    await requireUser(request)

    return NextResponse.json({
      clientId: process.env.PAYPAL_CLIENT_ID || null,
      configured: isPaypalConfigured(),
      mode: (process.env.PAYPAL_MODE || 'sandbox').toLowerCase(),
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'paypal/config')
  }
}
