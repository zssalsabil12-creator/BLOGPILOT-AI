import type { MetadataRoute } from 'next';
import { getSiteUrl } from '@/lib/site';
import { ALL_TOOLS } from '@/lib/free-tools/tool-registry';

const TOOL_SUB_PAGES = [
  '/free-tools/content-opportunity-analyzer/keyword-research',
  '/free-tools/content-opportunity-analyzer/competitor-analysis',
  '/free-tools/content-opportunity-analyzer/beat-top-10',
];

export default function sitemap(): MetadataRoute.Sitemap {
  const base = getSiteUrl();
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${base}/`, lastModified: now, changeFrequency: 'weekly', priority: 1 },
    { url: `${base}/free-tools`, lastModified: now, changeFrequency: 'weekly', priority: 0.9 },
    { url: `${base}/signup`, lastModified: now, changeFrequency: 'monthly', priority: 0.5 },
  ];

  const toolRoutes: MetadataRoute.Sitemap = ALL_TOOLS.map((tool) => ({
    url: `${base}${tool.href}`,
    lastModified: now,
    changeFrequency: 'monthly' as const,
    priority: tool.featured ? 0.8 : 0.7,
  }));

  const subRoutes: MetadataRoute.Sitemap = TOOL_SUB_PAGES.map((path) => ({
    url: `${base}${path}`,
    lastModified: now,
    changeFrequency: 'monthly' as const,
    priority: 0.6,
  }));

  return [...staticRoutes, ...toolRoutes, ...subRoutes];
}
