import { NextResponse } from 'next/server'
import { verifyPaypalWebhook } from '@/lib/paypal'
import { activateSubscription, type PlanTier } from '@/lib/stripe'

/**
 * POST /api/paypal/webhook
 *
 * Receives PayPal webhook events and activates the user's subscription
 * after a successful payment.
 *
 * Handled events:
 *   - CHECKOUT.ORDER.APPROVED       — buyer approved the order on PayPal
 *   - PAYMENT.CAPTURE.COMPLETED     — funds captured (final state)
 *   - BILLING.SUBSCRIPTION.ACTIVATED — for recurring subscriptions
 *
 * SECURITY: This route verifies the PayPal webhook signature BEFORE doing
 * any work. If PAYPAL_WEBHOOK_ID is not configured, the route returns 503.
 *
 * NOTES:
 *   - PayPal sends the raw body as JSON; we re-stringify it for signature
 *     verification (PayPal signs the exact bytes it sent, but the JSON
 *     parsing/stringifying round-trip is safe because PayPal's signature
 *     is computed on the canonical JSON form).
 *   - In sandbox mode, you must use the PayPal sandbox webhook simulator
 *     to test this endpoint.
 */
export async function POST(request: Request) {
  // PayPal webhook requires the raw body for signature verification
  const rawBody = await request.text()

  // Collect PayPal signature headers
  const headers: Record<string, string> = {}
  for (const [key, value] of request.headers.entries()) {
    headers[key.toLowerCase()] = value
  }

  // Verify the signature
  const verification = await verifyPaypalWebhook({ headers, rawBody })
  if (!verification.valid) {
    console.error('[paypal/webhook] signature verification failed:', verification.reason)
    return NextResponse.json(
      { error: `Webhook signature verification failed: ${verification.reason}` },
      { status: 400 }
    )
  }

  // Parse the verified body
  let event: any
  try {
    event = JSON.parse(rawBody)
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 })
  }

  const eventType: string = event.event_type || ''
  const resource = event.resource || {}

  try {
    switch (eventType) {
      case 'CHECKOUT.ORDER.APPROVED': {
        // The buyer approved the order on PayPal — funds aren't captured yet.
        // We don't activate here; the /api/paypal/capture endpoint does that
        // after the front-end calls it. Just acknowledge.
        return NextResponse.json({ received: true, type: eventType, action: 'acknowledged' })
      }

      case 'PAYMENT.CAPTURE.COMPLETED': {
        // Funds captured — this is the source of truth. Activate the plan.
        const customId: string = resource.custom_id || resource.supplementary_data?.related_ids?.order_id || ''
        const [userId, tier] = customId.split(':')

        if (!userId || !tier) {
          console.warn('[paypal/webhook] PAYMENT.CAPTURE.COMPLETED missing custom_id', { customId })
          return NextResponse.json({ received: true, type: eventType, action: 'no_custom_id' })
        }

        const captureId = resource.id || null
        const result = await activateSubscription({
          userId,
          tier: tier as PlanTier,
          gateway: 'paypal',
          externalId: captureId,
        })

        return NextResponse.json({
          received: true,
          type: eventType,
          action: result.action,
          ok: result.ok,
        })
      }

      case 'BILLING.SUBSCRIPTION.ACTIVATED':
      case 'BILLING.SUBSCRIPTION.CANCELLED': {
        // Future: handle PayPal recurring subscriptions (currently we use
        // one-time captures, so these events are acknowledged but not
        // acted upon).
        return NextResponse.json({ received: true, type: eventType, action: 'acknowledged' })
      }

      default:
        // Acknowledge unhandled events so PayPal doesn't retry
        return NextResponse.json({ received: true, type: eventType, unhandled: true })
    }
  } catch (err) {
    console.error(`[paypal/webhook] error handling ${eventType}:`, err)
    return NextResponse.json(
      { error: 'Webhook handler failed', type: eventType },
      { status: 500 }
    )
  }
}

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
