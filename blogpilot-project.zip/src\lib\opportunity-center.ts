/**
 * Unified SEO Opportunity Center.
 *
 * Merges every intelligence source into ONE prioritized "What should I do
 * next" feed: GSC quick-wins/declines/CTR, topical gaps, cannibalization,
 * internal-link orphans, and dormant affiliate campaigns. Each item carries a
 * transparent impact score with the factors that produced it. Sources that
 * need no external connection (content/site-derived) are always available;
 * GSC-sourced items appear only when a property is bound and returns data.
 */

import prisma from '@/lib/prisma';
import { computeOpportunities, type Opportunity } from './opportunities';
import { buildTopicalMap } from './topical-map';
import {
  getGscAccessToken,
  querySearchAnalytics,
  buildPeriodRange,
} from './gsc';

export type CenterType =
  | 'quick-win' | 'ctr-opportunity' | 'refresh' | 'new-content'
  | 'topic-gap' | 'internal-link' | 'cannibalization' | 'affiliate';

export interface CenterItem {
  id: string;
  type: CenterType;
  title: string;
  target: string;
  why: string[];
  impactScore: number; // 0-100, explained via factors
  factors: Array<{ name: string; value: number; max: number }>;
  confidence: 'high' | 'medium' | 'low';
  difficulty: 'easy' | 'medium' | 'hard';
  action: string;
  actionLabel: string;
  source: 'gsc' | 'content-analysis' | 'site-crawl' | 'affiliate';
}

const TYPE_LABELS: Record<CenterType, string> = {
  'quick-win': 'Quick win',
  'ctr-opportunity': 'Low CTR',
  refresh: 'Needs refresh',
  'new-content': 'Content gap',
  'topic-gap': 'Topic gap',
  'internal-link': 'Internal linking',
  cannibalization: 'Cannibalization',
  affiliate: 'Affiliate opportunity',
};

function mapLegacyType(t: Opportunity['type']): CenterType {
  switch (t) {
    case 'quick-win': return 'quick-win';
    case 'low-ctr': return 'ctr-opportunity';
    case 'declining': return 'refresh';
    case 'content-gap': return 'new-content';
  }
}

/** Transparent scoring: impressions-weighted potential + intent multipliers.
 *  Difficulty acts as a percentage discount on the earned base (not absolute),
 *  so hard opportunities still rank proportionally to their upside. */
function scoreFactors(opts: {
  impressions?: number;
  positionBoost?: boolean;
  isDecline?: boolean;
  businessValue?: number; // 0..1
  difficultyPenalty?: number; // 0..0.5
}): { score: number; factors: Array<{ name: string; value: number; max: number }> } {
  const factors: Array<{ name: string; value: number; max: number }> = [];
  const imp = opts.impressions ?? 0;

  const trafficPotential = Math.min(1, Math.log10(Math.max(imp, 10)) / Math.log10(10000));
  const trafficPts = Math.round(trafficPotential * 35);
  factors.push({ name: 'Traffic potential', value: trafficPts, max: 35 });

  const posPts = opts.positionBoost ? 20 : 0;
  if (opts.positionBoost) factors.push({ name: 'Close to ranking (top-20)', value: posPts, max: 20 });
  else factors.push({ name: 'Ranking distance', value: 0, max: 20 });

  const urgencyPts = opts.isDecline ? 15 : 0;
  factors.push({ name: 'Urgency', value: urgencyPts, max: 15 });

  const bizPts = Math.round((opts.businessValue ?? 0.3) * 30);
  factors.push({ name: 'Business value', value: bizPts, max: 30 });

  const base = trafficPts + posPts + urgencyPts + bizPts;
  const penaltyPct = Math.min(0.5, Math.max(0, opts.difficultyPenalty ?? 0.2));
  const score = Math.max(8, Math.min(100, Math.round(base * (1 - penaltyPct))));
  factors.push({ name: 'Difficulty adjustment', value: -Math.round(base * penaltyPct), max: 0 });
  return { score, factors };
}

export async function buildOpportunityCenter(
  userId: string,
  siteId: string | null,
): Promise<{
  items: CenterItem[];
  sources: Record<string, 'connected' | 'not_connected'>;
  countsByType: Partial<Record<CenterType, number>>;
}> {
  const items: CenterItem[] = [];
  const sources: Record<string, 'connected' | 'not_connected'> = {};

  // ── Source 1: GSC (only when bound + token valid) ──
  let gscSite: { id: string; gscProperty: string } | null = null;
  if (siteId) {
    const s = await prisma.connectedSite.findFirst({
      where: { id: siteId, userId },
      select: { id: true, gscProperty: true },
    });
    if (s?.gscProperty) {
      gscSite = { id: s.id, gscProperty: s.gscProperty };
    }
  }

  if (gscSite) {
    const access = await getGscAccessToken(userId);
    if (access.ok) {
      sources.gsc = 'connected';
      try {
        const range = buildPeriodRange(28);
        const [byPage, byQuery, byPagePrev] = await Promise.all([
          querySearchAnalytics(access.accessToken, gscSite.gscProperty, { ...range.current, dimensions: ['page'], rowLimit: 1000 }),
          querySearchAnalytics(access.accessToken, gscSite.gscProperty, { ...range.current, dimensions: ['query'], rowLimit: 2000 }),
          querySearchAnalytics(access.accessToken, gscSite.gscProperty, { ...range.previous, dimensions: ['page'], rowLimit: 1000 }),
        ]);

        for (const opp of computeOpportunities({ byQuery, byPage, byPagePrev })) {
          const type = mapLegacyType(opp.type);
          const scored = scoreFactors({
            impressions: opp.metrics.impressions ?? 0,
            positionBoost: type === 'quick-win',
            isDecline: type === 'refresh',
            businessValue: type === 'quick-win' ? 0.6 : 0.35,
            difficultyPenalty: type === 'new-content' ? 0.5 : 0.15,
          });
          items.push({
            id: `gsc:${opp.id}`,
            type,
            title: opp.title,
            target: opp.target,
            why: [opp.why, opp.impact],
            impactScore: scored.score,
            factors: scored.factors,
            confidence: opp.confidence,
            difficulty: type === 'new-content' ? 'hard' : type === 'quick-win' ? 'easy' : 'medium',
            action: opp.action,
            actionLabel: opp.actionLabel,
            source: 'gsc',
          });
        }
      } catch (err: any) {
        console.warn('[opportunity-center] GSC query failed:', err?.message || err);
        sources.gsc = 'not_connected';
      }
    } else {
      sources.gsc = 'not_connected';
    }
  } else {
    sources.gsc = 'not_connected';
  }

  // ── Source 2: Topical gaps + cannibalization (always available) ──
  try {
    const map = await buildTopicalMap(userId, siteId);
    if (map.stats.totalArticles > 0) {
      sources.content_analysis = 'connected';

      for (const cluster of map.clusters.filter(c => c.coverage !== 'strong').slice(0, 3)) {
        const subtopics = cluster.missingSubtopics.length > 0
          ? cluster.missingSubtopics.slice(0, 3).join(', ')
          : null;
        const scored = scoreFactors({ impressions: cluster.members.length * 60, businessValue: 0.4, difficultyPenalty: 0.4 });
        items.push({
          id: `topic-gap:${cluster.name}`,
          type: 'topic-gap',
          title: `Strengthen the “${cluster.name}” cluster`,
          target: cluster.name,
          why: [
            `${cluster.members.length} article(s) only — clusters this thin rarely earn topical authority.`,
            subtopics ? `Missing: ${subtopics}.` : 'No pillar guide anchoring the cluster yet.',
          ],
          impactScore: scored.score,
          factors: scored.factors,
          confidence: 'medium',
          difficulty: 'hard',
          action: 'write-article',
          actionLabel: `Write ${subtopics ? 'missing pieces' : 'the pillar guide'}`,
          source: 'content-analysis',
        });
      }

      for (const c of map.cannibalization.slice(0, 3)) {
        const scored = scoreFactors({ impressions: 120, isDecline: false, businessValue: 0.3, difficultyPenalty: 0.2 });
        items.push({
          id: `cannibalization:${c.articles.map(a => a.articleId).join('-').slice(0, 60)}`,
          type: 'cannibalization',
          title: `${c.articles.length} pages compete for "${c.keywords[0]}"`,
          target: c.keywords.join(' / '),
          why: [c.detail],
          impactScore: scored.score,
          factors: scored.factors,
          confidence: c.recommendation === 'merge' ? 'high' : 'medium',
          difficulty: 'easy',
          action: 'review-cannibalization',
          actionLabel: c.recommendation === 'merge' ? 'Review merge option' : 'Re-target one page',
          source: 'content-analysis',
        });
      }

      // Roadmap top item as new-content opportunity
      const roadmapTop = map.roadmap.find(r => r.priority === 'high') || map.roadmap[0];
      if (roadmapTop) {
        const scored = scoreFactors({ impressions: 150, businessValue: roadmapTop.intent === 'commercial' ? 0.7 : 0.4, difficultyPenalty: 0.5 });
        items.push({
          id: `new-content:${hashStr(roadmapTop.title)}`,
          type: 'new-content',
          title: roadmapTop.title,
          target: roadmapTop.clusterName || '',
          why: [roadmapTop.reason || 'Recommended by topical analysis.', `Intent: ${roadmapTop.intent}.`],
          impactScore: scored.score,
          factors: scored.factors,
          confidence: 'medium',
          difficulty: 'hard',
          action: 'write-article',
          actionLabel: 'Create article',
          source: 'content-analysis',
        });
      }
    }
  } catch (err: any) {
    console.warn('[opportunity-center] topical analysis failed:', err?.message || err);
  }

  // ── Source 3: Internal-link graph (needs a site to crawl) ──
  const crawlTarget = siteId
    ? await prisma.connectedSite.findFirst({ where: { id: siteId, userId }, select: { url: true, isActive: true } })
    : await prisma.connectedSite.findFirst({ where: { userId, isActive: true }, select: { url: true }, orderBy: { createdAt: 'desc' } });

  if (crawlTarget) {
    try {
      const { getSuggestions } = await import('./internal-links');
      const firstArticle = await prisma.article.findFirst({
        where: { userId, ...(siteId ? { siteId } : {}) },
        orderBy: { updatedAt: 'desc' },
        select: { id: true },
      });
      if (firstArticle) {
        const res = await getSuggestions(userId, firstArticle.id);
        const totalOpps = res.suggestions.length;
        if (totalOpps >= 3) {
          const orphansNote = res.graphSummary.orphans > 0
            ? `${res.graphSummary.orphans} orphan page(s) have no internal links at all.`
            : undefined;
          const scored = scoreFactors({ impressions: totalOpps * 80, businessValue: 0.4, difficultyPenalty: 0.05 });
          items.push({
            id: `internal-link:${firstArticle.id}`,
            type: 'internal-link',
            title: `${totalOpps} internal linking opportunities on “${firstArticle.id === res.articleId ? 'your latest article' : 'recent content'}”`,
            target: firstArticle.id,
            why: [
              `${totalOpps} high-relevance targets found across ${res.graphSummary.pages} crawled pages.`,
              orphansNote || 'Internal links distribute authority to pages that need it.',
            ].filter(Boolean) as string[],
            impactScore: scored.score,
            factors: scored.factors,
            confidence: 'high',
            difficulty: 'easy',
            action: 'apply-internal-links',
            actionLabel: 'Review & apply links',
            source: 'site-crawl',
          });
        }
      }
    } catch (err: any) {
      console.warn('[opportunity-center] link suggestions failed:', err?.message || err);
    }
  }

  // ── Source 4: Dormant affiliate campaigns ──
  try {
    const activeCampaigns = await prisma.affiliateCampaign.findMany({
      where: { userId, isActive: true },
      select: { id: true, productName: true, name: true },
      take: 10,
    });
    if (activeCampaigns.length > 0 && items.some(i => i.type !== 'affiliate')) {
      // If no article mentions the product, suggest building its cluster.
      const products = activeCampaigns.map(c => c.productName.toLowerCase());
      const articlesSample = await prisma.article.findMany({
        where: { userId },
        select: { title: true, targetKeyword: true },
        take: 300,
      });
      const dormant = activeCampaigns.filter(c => {
        const p = c.productName.toLowerCase();
        return !articlesSample.some(a =>
          (a.targetKeyword || '').toLowerCase().includes(p) || a.title.toLowerCase().includes(p)
        );
      });

      for (const camp of dormant.slice(0, 2)) {
        const scored = scoreFactors({ impressions: 90, businessValue: 0.9, difficultyPenalty: 0.45 });
        items.push({
          id: `affiliate:${camp.id}`,
          type: 'affiliate',
          title: `“${camp.productName}” campaign has no supporting content`,
          target: camp.name,
          why: [
            'No article in your workspace targets this product yet.',
            'Commercial clusters convert best when review + comparison + supporting guides exist together.',
          ],
          impactScore: scored.score,
          factors: scored.factors,
          confidence: 'medium',
          difficulty: 'hard',
          action: 'generate-affiliate-cluster',
          actionLabel: 'Generate commercial cluster',
          source: 'affiliate',
        });
      }
    }
  } catch (err: any) {
    console.warn('[opportunity-center] affiliate scan failed:', err?.message || err);
  }

  items.sort((a, b) => b.impactScore - a.impactScore);

  const countsByType: Partial<Record<CenterType, number>> = {};
  for (const i of items) countsByType[i.type] = (countsByType[i.type] || 0) + 1;

  return { items: items.slice(0, 50), sources, countsByType };
}

function hashStr(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(16);
}
