﻿import { NextResponse } from 'next/server';
import { getPayeerConfig } from '@/lib/payeer';

export async function GET() {
  const cfg = getPayeerConfig();
  return NextResponse.json({
    ok: true,
    data: { provider: 'payeer', enabled: cfg.enabled },
  });
}