'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Sparkles, ArrowLeft, Mail, Lock, User, Gift, CheckCircle2 } from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { GoogleSignInButton, AuthDivider } from '@/components/auth/google-signin-button';

export default function SignupPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const login = useAppStore(s => s.login);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Signup failed.');
      } else {
        if (data?.user) {
          login(data.user);
        }
        window.location.href = '/dashboard';
      }
    } catch (err: any) {
      setError(err?.message || 'Network error.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen bg-background">
      <div className="aurora opacity-70" />

      {/* Back link */}
      <div className="absolute left-4 top-4 z-20">
        <Button variant="ghost" size="sm" asChild className="text-muted-foreground hover:text-foreground">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Link>
        </Button>
      </div>

      {/* Brand panel (desktop) */}
      <div className="relative hidden w-[46%] flex-col justify-between overflow-hidden border-r border-border/60 p-10 lg:flex">
        <div className="pointer-events-none absolute inset-0 dot-texture opacity-40" />
        <div className="pointer-events-none absolute -left-24 bottom-1/4 h-96 w-96 rounded-full bg-violet-600/12 blur-[120px]" />
        <div className="pointer-events-none absolute -right-16 top-0 h-80 w-80 rounded-full bg-cyan-500/14 blur-[110px]" />

        <Link href="/" className="relative z-10 flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30 ring-1 ring-inset ring-white/25">
            <Sparkles className="h-4.5 w-4.5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight">
            BlogPilot <span className="text-gradient">AI</span>
          </span>
        </Link>

        <div className="relative z-10 max-w-md">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-400/25 bg-gradient-to-r from-cyan-400/10 to-violet-500/10 px-4 py-1.5 text-xs font-medium text-cyan-200 shimmer-badge">
            <Gift className="h-3.5 w-3.5" />
            10 free credits included — no card required
          </div>
          <h2 className="tracking-display text-4xl font-extrabold leading-[1.12] text-balance">
            Start creating content that <span className="text-gradient">ranks</span> today.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Join creators and agencies using BlogPilot AI to research, write and publish
            SEO articles in minutes instead of hours.
          </p>

          <ul className="mt-8 space-y-3">
            {[
              'Full SEO articles with meta, headings & links',
              'Competitor analysis built into every brief',
              'Publish directly to WordPress or Blogger',
              'Upgrade, downgrade or cancel anytime',
            ].map((point) => (
              <li key={point} className="flex items-start gap-3 text-sm">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-cyan-400" />
                <span className="text-muted-foreground">{point}</span>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative z-10 text-xs text-muted-foreground/70">
          © {new Date().getFullYear()} BlogPilot AI — All rights reserved.
        </p>
      </div>

      {/* Form panel */}
      <div className="relative z-10 flex flex-1 items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8 flex flex-col items-center lg:hidden">
            <Link href="/" className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30 ring-1 ring-inset ring-white/25">
              <Sparkles className="h-6 w-6 text-white" />
            </Link>
            <h1 className="tracking-display text-2xl font-bold">Create your account</h1>
            <p className="mt-1 text-sm text-muted-foreground">Start with 10 free credits</p>
          </div>

          <div className="hidden mb-8 lg:block">
            <h1 className="tracking-display text-3xl font-bold">Create your account</h1>
            <p className="mt-1 text-sm text-muted-foreground">Free to start — no credit card required</p>
          </div>

          <Card className="card-premium overflow-hidden rounded-2xl">
            <CardContent className="p-7 pt-7">
              <GoogleSignInButton label="Sign up with Google" />
              <AuthDivider />
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="Your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="h-11 rounded-xl pl-10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-11 rounded-xl pl-10"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="At least 8 characters"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-11 rounded-xl pl-10"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                    {error}
                  </p>
                )}

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="h-11 w-full rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/25 transition hover:shadow-cyan-400/40"
                >
                  {isLoading ? (
                    <span className="inline-flex items-center gap-2">
                      <span className="size-4 animate-spin rounded-full border-2 border-slate-900/40 border-t-slate-900" />
                      Creating account...
                    </span>
                  ) : (
                    'Create free account'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" className="font-medium text-primary hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
