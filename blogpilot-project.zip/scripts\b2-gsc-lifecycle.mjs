/**
 * BLOCKER 2 — GSC credential lifecycle verification (offline-verifiable half).
 * Real Google credentials are unavailable in this environment; this proves:
 *   - expired access token + invalid refresh -> honest needs_reconnect,
 *     token marked inactive, NO fabricated data returned
 *   - OAuth callback rejects tampered state signatures
 *   - unauthenticated /api/google/auth/url is rejected
 */

import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const BASE = process.env.BASE_URL || 'http://localhost:3000';

let pass = 0, fail = 0;
const check = (n, c, x = '') => { if (c) { console.log(`  ✓ ${n}${x ? ' — ' + x : ''}`); pass++; } else { console.log(`  ✗ ${n}${x ? ' — ' + x : ''}`); fail++; } };

async function main() {
  const email = `b2-${Math.random().toString(36).slice(2)}@example.com`;
  const signup = await fetch(`${BASE}/api/auth/signup`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'B2', email, password: 'TestPass123!' }),
  });
  const cookie = signup.headers.getSetCookie().map(c => c.split(';')[0]).join('; ');
  const H = { 'Content-Type': 'application/json', Cookie: cookie };
  check('signup', signup.status === 201);

  const user = await prisma.user.findUnique({ where: { email } });

  // ── Craft an EXPIRED grant that claims searchconsole scope ──
  await prisma.googleToken.create({
    data: {
      userId: user.id,
      accessToken: 'expired-access-token',
      refreshToken: 'invalid-revoked-refresh-token',
      googleEmail: 'tester@example.com',
      expiresAt: new Date(Date.now() - 3600_000), // expired 1h ago
      scope: 'blogger,searchconsole',
      services: 'blogger,searchconsole',
      status: 'connected',
    },
  });

  // Bind property directly (bypasses ownership probe since no real GSC acct).
  const siteRes = await fetch(`${BASE}/api/sites`, {
    method: 'POST', headers: H,
    body: JSON.stringify({ name: 'GSC Bound', url: 'https://real-site.example', platform: 'Custom' }),
  }).then(r => r.json());
  const siteId = siteRes.data.site.id;
  await prisma.connectedSite.update({ where: { id: siteId }, data: { gscProperty: 'sc-https://real-site.example' } });

  // ── Expired/revoked flow: must return needs_reconnect honestly ──
  let res = await fetch(`${BASE}/api/gsc/sites`, { headers: H });
  let j = (await res.json()).data;
  check('expired+revoked grant -> connected:false', res.status === 200 && j.connected === false);
  check('honest needsReconnect flag (no fabricated data)', j.needsReconnect === true);

  const tokenRow = await prisma.googleToken.findFirst({ where: { userId: user.id } });
  check('refresh failure marked token inactive', tokenRow.isActive === false && tokenRow.status === 'expired',
    `status=${tokenRow.status}`);

  // Opportunities endpoint surfaces gsc not_connected instead of fake metrics
  res = await fetch(`${BASE}/api/opportunities?siteId=${siteId}`, { headers: H });
  j = (await res.json()).data;
  check('opportunity center reports gsc not_connected', j?.sources?.gsc === 'not_connected');

  // ── OAuth state protection ──
  // undici manual redirect reports opaqueredirect as status 200/307 variably;
  // assert on Location header presence instead.
  res = await fetch(`${BASE}/api/google/auth/callback?code=x&state=tampered.state`, { redirect: 'manual' });
  const loc = res.headers.get('location') || '';
  check('tampered state rejected -> error redirect', loc.includes('google=error'), decodeURIComponent(loc).slice(0, 80));

  await new Promise(r => setTimeout(r, 1500));
  let okUrl = false, urlSample = '';
  for (let attempt = 0; attempt < 3 && !okUrl; attempt++) {
    res = await fetch(`${BASE}/api/google/auth/url`, { headers: H });
    j = await res.json().catch(() => ({}));
    okUrl = res.status === 200 && !!j?.url?.includes('state=');
    urlSample = `${res.status} ${String(j?.url || j?.error || '').slice(0, 60)}`;
    if (!okUrl) await new Promise(r => setTimeout(r, 2000));
  }
  check('auth url issues signed state for authenticated user', okUrl, urlSample);

  // Unauthenticated request must be refused
  res = await fetch(`${BASE}/api/google/auth/url`);
  check('unauthenticated auth-url refused', res.status === 401);

  console.log(`\n=== B2 (offline-verifiable) RESULT: ${pass} passed, ${fail} failed ===`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
