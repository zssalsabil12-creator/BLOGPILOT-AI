import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { encrypt, decrypt } from '@/lib/crypto'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { createSiteSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

// GET /api/sites — list all sites for a user (decrypted fields masked)
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    const sites = await db.connectedSite.findMany({
      where: userId ? { userId } : undefined,
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { articles: true } },
      },
    })

    // Return sites with masked API keys (never expose decrypted keys in GET)
    const safeSites = sites.map((site) => {
      const { apiKey: _encryptedKey, username, ...rest } = site
      return {
        ...rest,
        hasCredentials: !!_encryptedKey,
        username: username || null,
        articlesCount: site._count.articles,
      }
    })

    return NextResponse.json({ sites: safeSites })
  } catch (error) {
    return handleApiError(error, 'sites/list')
  }
}

// POST /api/sites — create a new connected site with encrypted credentials
export async function POST(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(createSiteSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { userId, name, url, platform, username, apiKey } = body

    // Encrypt the API key before storage
    const encryptedApiKey = apiKey ? encrypt(apiKey) : null

    const site = await db.connectedSite.create({
      data: {
        userId,
        name,
        url,
        platform,
        username: username || null,
        apiKey: encryptedApiKey,
      },
    })

    // Return safe data (no decrypted keys)
    const { apiKey: _, ...safeSite } = site
    return NextResponse.json(
      { site: { ...safeSite, hasCredentials: !!encryptedApiKey, articlesCount: 0 } },
      { status: 201 }
    )
  } catch (error) {
    return handleApiError(error, 'sites/create')
  }
}
