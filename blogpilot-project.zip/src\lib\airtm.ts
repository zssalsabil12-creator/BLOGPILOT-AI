﻿import crypto from 'node:crypto';
import { timingSafeStringCompare } from '@/lib/crypto';

export interface AirtmConfig {
  merchantId: string;
  secret: string;
  enabled: boolean;
  baseUrl: string;
}

export function getAirtmConfig(): AirtmConfig {
  const merchantId = process.env.AIRTM_MERCHANT_ID || '';
  const secret = process.env.AIRTM_SECRET || '';
  return {
    merchantId,
    secret,
    enabled: !!(merchantId && secret),
    baseUrl: process.env.AIRTM_MERCHANT_URL || 'https://www.airtm.com/payment/request',
  };
}

export function signAirtmPayload(payload: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

export function buildAirtmUrl(params: { orderId: string; amount: number; currency?: string; description: string }): string {
  const cfg = getAirtmConfig();
  if (!cfg.enabled) throw new Error('Airtm is not configured');
  const currency = params.currency || 'USD';
  const amount = params.amount.toFixed(2);
  const sign = signAirtmPayload(`${params.orderId}:${amount}:${currency}`, cfg.secret);
  const query = new URLSearchParams({
    merchant_id: cfg.merchantId,
    order_id: params.orderId,
    amount,
    currency,
    description: params.description,
    sign,
  });
  return `${cfg.baseUrl}?${query.toString()}`;
}

export function verifyAirtmCallback(params: Record<string, string>): boolean {
  const cfg = getAirtmConfig();
  if (!cfg.enabled) return false;
  const { order_id, amount, currency, status, sign } = params;
  if (!order_id || !amount || !currency || !status || !sign) return false;
  if (status !== 'success' && status !== 'completed' && status !== 'paid') return false;
  const expected = signAirtmPayload(`${order_id}:${amount}:${currency}`, cfg.secret);
  return timingSafeStringCompare(expected, sign);
}