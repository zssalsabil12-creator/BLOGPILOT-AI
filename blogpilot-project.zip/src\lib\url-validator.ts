import dns from 'node:dns';

const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  '127.0.0.1',
  '0.0.0.0',
  '::1',
  'metadata.google.internal',
  '169.254.169.254',
]);

/**
 * Admin-configured allowlist (SSRF_ALLOWLIST="cms.internal,10.0.0.5").
 * Hosts on this list bypass private-range blocking so self-hosted CMS
 * targets on private networks work. Empty by default — the guard stays
 * fully closed unless an operator explicitly opens specific hosts.
 */
function getAllowlistedHosts(): Set<string> {
  return new Set(
    (process.env.SSRF_ALLOWLIST || '')
      .split(',')
      .map(s => s.trim().toLowerCase())
      .filter(Boolean)
  );
}

function isPrivateIp(ip: string): boolean {
  if (ip === '127.0.0.1' || ip === '::1' || ip === '::ffff:127.0.0.1') return true;
  if (ip.startsWith('10.')) return true;
  if (ip.startsWith('172.')) {
    const second = parseInt(ip.split('.')[1], 10);
    if (second >= 16 && second <= 31) return true;
  }
  if (ip.startsWith('192.168.')) return true;
  if (ip === '169.254.169.254') return true;
  return false;
}

export async function validateFetchUrl(urlString: string): Promise<{ ok: boolean; error?: string }> {
  let parsed: URL;
  try {
    parsed = new URL(urlString);
  } catch {
    return { ok: false, error: 'Invalid URL format' };
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return { ok: false, error: 'Only HTTP and HTTPS URLs are allowed' };
  }

  const hostname = parsed.hostname.toLowerCase();

  // Operator-approved hosts skip all private-range checks.
  if (getAllowlistedHosts().has(hostname)) {
    return { ok: true };
  }

  if (BLOCKED_HOSTNAMES.has(hostname)) {
    return { ok: false, error: 'Fetching internal/private URLs is not allowed' };
  }

  if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname)) {
    if (isPrivateIp(hostname)) {
      return { ok: false, error: 'Fetching private IP addresses is not allowed' };
    }
  }

  try {
    const addresses = await dns.promises.resolve4(hostname);
    for (const addr of addresses) {
      if (isPrivateIp(addr)) {
        return { ok: false, error: 'URL resolves to a private/internal IP address' };
      }
    }
  } catch {
    const addresses6 = await dns.promises.resolve6(hostname).catch(() => []);
    for (const addr of addresses6) {
      if (addr === '::1' || addr.startsWith('fe80:') || addr.startsWith('fc00:') || addr.startsWith('fd00:')) {
        return { ok: false, error: 'URL resolves to a private/internal IP address' };
      }
    }
  }

  return { ok: true };
}
