import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { buildOpportunityCenter } from '@/lib/opportunity-center';

const querySchema = z.object({
  siteId: z.string().max(64).optional(),
  days: z.coerce.number().int().min(7).max(90).optional().default(28),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters', details: parsed.error.flatten() }, { status: 400 });
  }

  const limit = await checkRateLimit(`opportunities:${userId}`, { windowMs: 60_000, maxRequests: 10 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  try {
    // Unified center merges GSC + topical/cannibalization/internal-links/affiliate.
    const center = await buildOpportunityCenter(userId, parsed.data.siteId || null);

    return NextResponse.json({
      ok: true,
      data: {
        items: center.items,
        countsByType: center.countsByType,
        sources: center.sources,
      },
    });
  } catch (error: any) {
    console.error('Opportunity center error:', error);
    return NextResponse.json(
      { ok: false, error: error?.message || 'Failed to compute opportunities' },
      { status: 502 },
    );
  }
}
