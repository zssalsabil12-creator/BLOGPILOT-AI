﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId, getCurrentUser } from '@/lib/auth';
import { testWordPressConnection } from '@/lib/wordpress';
import { getPlanConfig } from '@/lib/billing';
import { encrypt } from '@/lib/encryption';

const createSiteSchema = z.object({
  name: z.string().min(1, 'Name is required').max(120),
  url: z.string().min(1, 'URL is required').max(500),
  platform: z.enum(['WordPress', 'Webhook', 'Custom', 'Blogger']),
  apiKey: z.string().max(500).optional().nullable(),
  username: z.string().max(200).optional().nullable(),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  try {
    const sites = await prisma.connectedSite.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      ok: true,
      data: {
        sites: sites.map(site => ({
          id: site.id,
          name: site.name,
          url: site.url,
          platform: site.platform,
          username: site.username,
          hasApiKey: !!site.apiKey,
          isActive: site.isActive,
          lastSyncAt: site.lastSyncAt,
          createdAt: site.createdAt,
        })),
      },
    });
  } catch (error: any) {
    console.error('List sites error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load sites' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = createSiteSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  const data = parsed.data;

  try {
    const user = await getCurrentUser(req);
    const planConfig = getPlanConfig(user?.subscription?.plan || 'free');
    const siteCount = await prisma.connectedSite.count({ where: { userId } });

    if (siteCount >= planConfig.maxSites) {
      return NextResponse.json({
        ok: false,
        error: `Your ${planConfig.name} plan allows up to ${planConfig.maxSites} sites. Upgrade to add more.`,
        code: 'plan_limit',
      }, { status: 402 });
    }

    let isActive = data.platform === 'Webhook' || data.platform === 'Custom';
    let connectionMessage: string | null = null;

    if (data.platform === 'WordPress') {
      const result = await testWordPressConnection({
        url: data.url,
        username: data.username,
        apiKey: data.apiKey,
      });
      isActive = result.ok;
      connectionMessage = result.message;
    }

    const site = await prisma.connectedSite.create({
      data: {
        userId,
        name: data.name,
        url: data.url,
        platform: data.platform,
        apiKey: data.apiKey ? encrypt(data.apiKey) : null,
        username: data.username || null,
        isActive,
      },
    });

    return NextResponse.json({
      ok: true,
      data: {
        site: {
          id: site.id,
          name: site.name,
          url: site.url,
          platform: site.platform,
          username: site.username,
          hasApiKey: !!site.apiKey,
          isActive: site.isActive,
          lastSyncAt: site.lastSyncAt,
          createdAt: site.createdAt,
        },
        connection: connectionMessage ? { ok: isActive, message: connectionMessage } : null,
      },
    }, { status: 201 });
  } catch (error: any) {
    console.error('Create site error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to create site' }, { status: 500 });
  }
}