/**
 * Smart Internal Linking.
 *
 * Uses the crawled site graph + the user's articles to suggest internal
 * links for a given article, then applies them into the markdown content at
 * the most relevant paragraph. Deterministic scoring; no fabricated targets.
 */

import prisma from '@/lib/prisma';
import { crawlSite, type CrawlGraph } from './site-crawler';

export interface LinkSuggestion {
  targetPath: string;
  targetTitle: string;
  anchor: string;
  relevance: number; // 0-100
  reason: string;
  placementParagraph: number; // index of paragraph to insert near
  alreadyLinked: boolean;
}

export interface SuggestionsResult {
  graphSummary: { pages: number; orphans: number; source: string };
  suggestions: LinkSuggestion[];
}

const STOP = new Set(['this', 'that', 'with', 'from', 'have', 'will', 'your', 'more', 'when', 'them', 'they', 'their', 'there', 'these', 'those', 'than', 'then', 'were', 'been', 'also', 'into', 'just', 'only', 'very', 'and', 'for', 'the', 'are', 'you', 'how', 'what', 'why', 'best', 'top']);

function tokens(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z\u0600-\u06FF\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 3 && !STOP.has(w))
  );
}

function overlap(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  const inter = [...a].filter(x => b.has(x)).length;
  return inter / Math.min(a.size, b.size);
}

function contentParagraphs(content: string): string[] {
  return content.split(/\n{2,}/).map(p => p.trim()).filter(Boolean);
}

function existingLinkedPaths(content: string, origin: string): Set<string> {
  const paths = new Set<string>();
  const re = /\]\(([^)]+)\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(content))) {
    const link = m[1];
    try {
      const u = new URL(link, origin);
      paths.add(u.pathname.replace(/\/$/, '') || '/');
    } catch {
      if (link.startsWith('/')) paths.add(link.replace(/\/$/, '') || '/');
    }
  }
  return paths;
}

function bestPlacement(paragraphs: string[], targetTokens: Set<string>): number {
  let bestIdx = -1;
  let bestScore = 0;
  paragraphs.forEach((p, i) => {
    // Skip headings-only blocks.
    if (p.startsWith('#')) return;
    const score = overlap(tokens(p), targetTokens);
    if (score > bestScore) {
      bestScore = score;
      bestIdx = i;
    }
  });
  return bestIdx >= 0 ? bestIdx : Math.max(0, Math.min(1, paragraphs.length - 1));
}

export async function getSuggestions(userId: string, articleId: string): Promise<SuggestionsResult & { articleId: string }> {
  const article = await prisma.article.findFirst({
    where: { id: articleId, userId },
    select: { id: true, title: true, content: true, targetKeyword: true, siteId: true },
  });
  if (!article) throw Object.assign(new Error('Article not found'), { statusCode: 404 });

  const site = article.siteId
    ? await prisma.connectedSite.findFirst({ where: { id: article.siteId, userId }, select: { url: true } })
    : await prisma.connectedSite.findFirst({ where: { userId, isActive: true }, select: { url: true }, orderBy: { createdAt: 'desc' } });
  if (!site) throw Object.assign(new Error('Connect a website first — internal links need a real site to link to.'), { statusCode: 409 });

  const graph: CrawlGraph = await crawlSite(site.url);

  const sourceTokens = tokens(`${article.targetKeyword || ''} ${article.title} ${article.content.slice(0, 4000)}`);
  const linkedPaths = existingLinkedPaths(article.content || '', graph.root);

  // Candidate targets from other workspace articles mapped onto crawled paths
  // (article.slug matches crawled path), plus crawled pages themselves.
  const siblings = await prisma.article.findMany({
    where: { userId, id: { not: article.id } },
    select: { id: true, title: true, slug: true, targetKeyword: true },
    take: 200,
  });

  type Candidate = { path: string; title: string; tokens: Set<string>; orphan: boolean; kind: 'page' | 'article' };
  const candidates: Candidate[] = [];

  for (const s of siblings) {
    if (!s.slug) continue;
    const path = `/${s.slug}`;
    const page = graph.pages.find(p => p.path === path || p.path.endsWith(path));
    candidates.push({
      path,
      title: s.title,
      tokens: tokens(`${s.targetKeyword || ''} ${s.title}`),
      orphan: page ? graph.orphanPaths.includes(page.path) : false,
      kind: 'article',
    });
  }
  for (const p of graph.pages) {
    if (p.path === '/') continue;
    candidates.push({
      path: p.path,
      title: p.title || p.path,
      tokens: tokens(`${p.title || ''} ${p.path.replace(/[-/]/g, ' ')}`),
      orphan: graph.orphanPaths.includes(p.path),
      kind: 'page',
    });
  }

  const paragraphs = contentParagraphs(article.content || '');
  const suggestions: LinkSuggestion[] = [];

  const seen = new Set<string>();
  for (const c of candidates) {
    if (seen.has(c.path)) continue;
    seen.add(c.path);
    if (linkedPaths.has(c.path)) continue;

    const rel = overlap(sourceTokens, c.tokens);
    if (rel < 0.12) continue;

    // Anchor: trimmed title (first 6 words), keyword preferred when available.
    const anchorBase = c.kind === 'article' && siblings.length > 0 ? c.title : c.title;
    const anchor = anchorBase.split(/\s+/).slice(0, 6).join(' ').replace(/[.,:]$/, '');

    const placementParagraph = bestPlacement(paragraphs, c.tokens);

    suggestions.push({
      targetPath: c.path,
      targetTitle: c.title,
      anchor,
      relevance: Math.round(Math.min(rel / 0.6, 1) * 100),
      reason: c.orphan
        ? 'Target page is currently an orphan — linking here gives it its first internal link.'
        : `Topically related (${Math.round(rel * 100)}% keyword overlap).`,
      placementParagraph,
      alreadyLinked: false,
    });
  }

  suggestions.sort((a, b) => b.relevance - a.relevance || (a.targetPath < b.targetPath ? -1 : 1));

  return {
    articleId: article.id,
    graphSummary: {
      pages: graph.pages.length,
      orphans: graph.orphanPaths.length,
      source: graph.source,
    },
    suggestions: suggestions.slice(0, 15),
  };
}

/**
 * Applies selected links into article content. Insertion strategy:
 * append a contextual sentence to the highest-relevance paragraph, or add a
 * "Related reading" section when no good paragraph exists.
 */
export async function applyLinks(
  userId: string,
  articleId: string,
  targets: Array<{ path: string; title: string }>
): Promise<{ applied: number; content: string }> {
  const article = await prisma.article.findFirst({
    where: { id: articleId, userId },
    select: { id: true, content: true, siteId: true },
  });
  if (!article) throw Object.assign(new Error('Article not found'), { statusCode: 404 });

  const site = article.siteId
    ? await prisma.connectedSite.findFirst({ where: { id: article.siteId, userId }, select: { url: true } })
    : await prisma.connectedSite.findFirst({ where: { userId, isActive: true }, select: { url: true }, orderBy: { createdAt: 'desc' } });
  if (!site) throw Object.assign(new Error('No connected site'), { statusCode: 409 });

  const origin = new URL(site.url).origin;
  const result = await getSuggestions(userId, articleId);
  const byPath = new Map(result.suggestions.map(s => [s.targetPath, s]));

  let content = article.content || '';
  const paragraphs = contentParagraphs(content);
  let applied = 0;
  const fallbackLinks: string[] = [];

  for (const t of targets.slice(0, 10)) {
    const suggestion = byPath.get(t.path);
    const anchor = suggestion?.anchor || t.title.split(/\s+/).slice(0, 6).join(' ');
    const url = `${origin}${t.path}`;
    const sentence = ` For a deeper dive, see our related guide on [${anchor}](${url}).`;

    const idx = suggestion?.placementParagraph ?? -1;
    if (idx >= 0 && idx < paragraphs.length && !paragraphs[idx].startsWith('#') && !paragraphs[idx].startsWith('|')) {
      paragraphs[idx] = `${paragraphs[idx].replace(/\s+$/, '')}${sentence}`;
      applied++;
    } else {
      fallbackLinks.push(`[${anchor}](${url})`);
    }
  }

  if (fallbackLinks.length > 0) {
    const section = `\n\n## Related reading\n\n${fallbackLinks.map(l => `- ${l}`).join('\n')}\n`;
    content = paragraphs.join('\n\n') + section;
  } else {
    content = paragraphs.join('\n\n');
  }

  if (applied > 0 || fallbackLinks.length > 0) {
    await prisma.article.update({
      where: { id: articleId },
      data: { content },
    });
  }

  return { applied: applied + fallbackLinks.length, content };
}
