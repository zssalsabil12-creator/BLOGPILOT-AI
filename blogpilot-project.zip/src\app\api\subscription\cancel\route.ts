import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { cancelSubscription } from '@/lib/billing';
import { apiError } from '@/lib/utils';

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await cancelSubscription(userId);
    return NextResponse.json({ ok: true, message: 'Subscription cancelled.' });
  } catch (err: any) {
    return apiError('subscription/cancel', err);
  }
}
