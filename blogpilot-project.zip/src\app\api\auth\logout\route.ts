import { NextResponse } from 'next/server';
import { COOKIE_NAME, revokeSessionToken } from '@/lib/auth';

export async function POST(req: Request) {
  // Revoke the presented session server-side so a copied token (cookie or
  // bearer) is rejected everywhere, then clear the cookie.
  const auth = req.headers.get('authorization');
  let token: string | null = null;
  if (auth && auth.startsWith('Bearer ')) {
    token = auth.slice(7).trim();
  } else {
    const cookieHeader = req.headers.get('cookie');
    if (cookieHeader) {
      const match = cookieHeader.match(new RegExp(`(?:^|;\\s*)${COOKIE_NAME}=([^;]*)`));
      if (match) token = decodeURIComponent(match[1]);
    }
  }

  if (token) {
    await revokeSessionToken(token).catch((err) =>
      console.error('Session revocation failed:', err?.message || err),
    );
  }

  const res = NextResponse.json({ ok: true, message: 'Logged out successfully' });
  res.cookies.set(COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 0,
    path: '/',
  });
  return res;
}
