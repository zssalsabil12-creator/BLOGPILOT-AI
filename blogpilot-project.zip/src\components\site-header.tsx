'use client';

import { usePathname } from 'next/navigation';
import { Sparkles } from 'lucide-react';
import { ThemeToggle } from '@/components/theme-toggle';

export function SiteHeader() {
  const pathname = usePathname();

  if (pathname === '/') return null;

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-4">
        <a href="/" className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30">
            <Sparkles className="h-4 w-4 text-slate-950" />
          </div>
          <span className="text-lg font-bold tracking-tight text-foreground">
            BlogPilot <span className="text-gradient">AI</span>
          </span>
        </a>
        <nav className="flex flex-wrap items-center gap-1 text-sm text-muted-foreground">
          <a href="/free-tools" className="rounded-lg px-3 py-2 transition-colors hover:bg-accent hover:text-foreground">
            Free Tools
          </a>
          <a href="/dashboard/generate" className="rounded-lg px-3 py-2 transition-colors hover:bg-accent hover:text-foreground">
            Generate Article
          </a>
          <a href="/dashboard/link-library" className="rounded-lg px-3 py-2 transition-colors hover:bg-accent hover:text-foreground">
            Link Library
          </a>
        </nav>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <a
            href="/dashboard/generate"
            className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-cyan-400 to-violet-500 px-5 py-2.5 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/25 transition hover:shadow-cyan-400/40"
          >
            Start Article Builder
          </a>
        </div>
      </div>
    </header>
  );
}
