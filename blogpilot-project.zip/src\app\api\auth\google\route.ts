import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import {
  isGoogleSignInConfigured,
  getGoogleSignInUrl,
  GOOGLE_SIGNIN_STATE_COOKIE,
} from '@/lib/google-signin';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';

function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error('AUTH_SECRET is required');
  return secret;
}

function signState(payload: string): string {
  const hmac = crypto.createHmac('sha256', getAuthSecret());
  hmac.update(payload);
  return hmac.digest('base64url');
}

export async function GET(req: Request) {
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`google-login:${ip}`, RATE_LIMITS.login);
  if (!rl.allowed) {
    return NextResponse.redirect(new URL('/login?error=google_rate_limited', req.url));
  }

  if (!isGoogleSignInConfigured()) {
    return NextResponse.redirect(new URL('/login?error=google_not_configured', req.url));
  }

  const nonce = crypto.randomBytes(16).toString('base64url');
  const payload = JSON.stringify({ nonce, ts: Date.now() });
  const sig = signState(payload);
  const state = Buffer.from(payload).toString('base64url') + '.' + sig;

  const authUrl = getGoogleSignInUrl(state);

  const res = NextResponse.redirect(authUrl);
  res.cookies.set(GOOGLE_SIGNIN_STATE_COOKIE, state, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 600,
    path: '/',
  });
  return res;
}
