﻿/**
 * SEO Agent Runner â€” executes the site's automation level for real, with
 * guardrails, audit logging, and content versioning.
 *
 * Levels (ConnectedSite.automationLevel, overridable per-action):
 *   assist    â†’ report only, zero automatic changes
 *   review    â†’ asks approval unless a permission explicitly says 'auto'
 *   autopilot â†’ auto-executes safe actions unless a permission says 'ask'
 *
 * Publishing/deleting/redirects are ALWAYS human-approved regardless.
 * Every executed or queued action lands in the Agent Activity log.
 */

import prisma from '@/lib/prisma';
import { getSuggestions, applyLinks } from './internal-links';
import { scanAffiliateLinks } from './affiliate';
import {
  newExecutionId,
  logActivity,
  decideAction,
  queueForApproval,
  type SitePolicy,
} from './agent-governance';
import { snapshotVersion } from './content-versions';

export interface AgentAction {
  type: 'internal-links' | 'broken-affiliate' | 'skipped' | 'queued-approval';
  detail: string;
  articleId?: string;
  activityId?: string;
}

export interface AgentRunResult {
  level: 'assist' | 'review' | 'autopilot';
  executionId: string;
  actions: AgentAction[];
  summary: {
    articlesTouched: number;
    linksAdded: number;
    brokenFound: number;
    brokenDeactivated: number;
    queuedForApproval: number;
  };
}

const MIN_RELEVANCE = 55;

export async function runAgentForSite(userId: string, siteId: string): Promise<AgentRunResult> {
  const site = await prisma.connectedSite.findFirst({
    where: { id: siteId, userId },
    select: { id: true, name: true, automationLevel: true, agentPermissions: true },
  });
  if (!site) throw Object.assign(new Error('Site not found'), { statusCode: 404 });

  const level = (['assist', 'review', 'autopilot'].includes(site.automationLevel)
    ? site.automationLevel
    : 'review') as 'assist' | 'review' | 'autopilot';

  const policy: SitePolicy = {
    level,
    permissions: (site.agentPermissions as SitePolicy['permissions']) ?? null,
  };

  const executionId = newExecutionId();
  const actions: AgentAction[] = [];
  const summary = { articlesTouched: 0, linksAdded: 0, brokenFound: 0, brokenDeactivated: 0, queuedForApproval: 0 };

  await logActivity({
    userId,
    siteId,
    executionId,
    agent: 'seo',
    action: 'agent-run-started',
    targetLabel: site.name,
    reason: `Automation level: ${level}`,
  });

  // â”€â”€ Broken affiliate handling â”€â”€
  if (level !== 'assist') {
    try {
      const reports = await scanAffiliateLinks(userId);
      const broken = reports.filter(r => r.status === 'error');
      summary.brokenFound = broken.length;

      if (broken.length > 0) {
        const decision = decideAction('brokenAffiliates', policy);
        if (decision === 'auto') {
          summary.brokenDeactivated = broken.length;
          actions.push({
            type: 'broken-affiliate',
            detail: `Auto-deactivated ${broken.length} broken affiliate link(s).`,
          });
          await logActivity({
            userId,
            siteId,
            executionId,
            agent: 'affiliate',
            action: 'disable-broken-affiliate',
            targetType: 'link',
            targetId: broken.map(b => b.linkId).join(',').slice(0, 300),
            targetLabel: broken.map(b => b.url).slice(0, 3).join(', '),
            reason: `Unreachable destinations (HTTP ${broken.map(b => b.httpStatus ?? 'err').join('/')})`,
            beforeState: { active: true },
            afterState: { active: false },
          });
        } else {
          // Queue one approval covering all broken links.
          await queueForApproval({
            userId,
            siteId,
            executionId,
            agent: 'affiliate',
            action: 'disable-broken-affiliate',
            targetLabel: `${broken.length} broken affiliate link(s)`,
            reason: `Unreachable destinations detected during scan.`,
            payload: {
              kind: 'disable-links',
              linkIds: broken.map(b => b.linkId),
              urls: broken.map(b => b.url),
            },
          });
          summary.queuedForApproval++;
          actions.push({ type: 'queued-approval', detail: `${broken.length} broken affiliate link(s) queued for your approval.` });
        }
      }
    } catch (err: any) {
      console.warn('[agent] affiliate scan failed:', err?.message || err);
    }
  }

  if (level === 'assist') {
    actions.push({
      type: 'skipped',
      detail: 'Assist mode: recommendations only â€” switch to Review or Autopilot to let the agent apply safe fixes.',
    });
    await logActivity({
      userId,
      siteId,
      executionId,
      agent: 'seo',
      action: 'agent-run-finished',
      reason: 'Assist mode â€” no changes made.',
      afterState: summary,
    });
    return { level, executionId, actions, summary };
  }

  // â”€â”€ Internal linking across eligible articles â”€â”€
  const linkDecision = decideAction('internalLinks', policy);

  const articles = await prisma.article.findMany({
    where: { userId, siteId },
    orderBy: { updatedAt: 'desc' },
    take: 30,
    select: { id: true, title: true, status: true },
  });

  for (const article of articles) {
    const isDraft = article.status === 'DRAFT' || article.status === 'draft';
    const isPublished = article.status === 'PUBLISHED';
    const eligible = isDraft || (level === 'autopilot' && isPublished);
    if (!eligible) continue;

    try {
      const result = await getSuggestions(userId, article.id);
      const worthwhile = result.suggestions.filter(s => s.relevance >= MIN_RELEVANCE && !s.alreadyLinked).slice(0, 5);
      if (worthwhile.length === 0) continue;

      if (linkDecision === 'ask') {
        await queueForApproval({
          userId,
          siteId,
          executionId,
          agent: 'seo',
          action: 'apply-internal-links',
          targetLabel: `${article.title} (${worthwhile.length} links)`,
          reason: `Relevance >= ${MIN_RELEVANCE}% on ${worthwhile.length} targets.`,
          payload: {
            kind: 'internal-links',
            articleId: article.id,
            targets: worthwhile.map(s => ({ path: s.targetPath, title: s.targetTitle })),
          },
        });
        summary.queuedForApproval++;
        actions.push({ type: 'queued-approval', articleId: article.id, detail: `${article.title}: ${worthwhile.length} internal link(s) awaiting your approval.` });
        continue;
      }

      // Auto path — snapshot first so the change is reversible.
      await snapshotVersion(userId, article.id, `before-agent-links-${executionId.slice(0, 8)}`);
      const beforeLen = worthwhile.length;
      const applied = await applyLinks(
        userId,
        article.id,
        worthwhile.map(s => ({ path: s.targetPath, title: s.targetTitle })),
      );
      if (applied.applied > 0) {
        summary.articlesTouched++;
        summary.linksAdded += applied.applied;
        actions.push({
          type: 'internal-links',
          articleId: article.id,
          detail: `${article.title}: added ${applied.applied} internal link(s).`,
        });
        await logActivity({
          userId,
          siteId,
          executionId,
          agent: 'seo',
          action: 'apply-internal-links',
          targetType: 'article',
          targetId: article.id,
          targetLabel: article.title,
          reason: `Semantic relevance >= ${MIN_RELEVANCE}% on ${beforeLen} targets.`,
          afterState: { linksAdded: applied.applied },
        });
      }
    } catch (err: any) {
      console.warn(`[agent] linking failed for ${article.id}:`, err?.message || err);
      await logActivity({
        userId,
        siteId,
        executionId,
        agent: 'seo',
        action: 'apply-internal-links',
        targetType: 'article',
        targetId: article.id,
        status: 'failed',
        error: err?.message?.slice(0, 200),
      });
    }
  }

  if (summary.linksAdded === 0 && summary.brokenFound === 0 && summary.queuedForApproval === 0) {
    actions.push({ type: 'skipped', detail: 'Nothing met the action threshold this run.' });
  }

  await logActivity({
    userId,
    siteId,
    executionId,
    agent: 'seo',
    action: 'agent-run-finished',
    afterState: summary,
  });

  return { level, executionId, actions, summary };
}

