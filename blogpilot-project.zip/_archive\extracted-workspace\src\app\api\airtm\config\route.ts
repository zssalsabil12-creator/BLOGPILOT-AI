import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { isAirtmConfigured } from '@/lib/airtm'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * GET /api/airtm/config
 *
 * Returns the public Airtm config + whether Airtm is configured.
 *
 * Used by the Billing page to decide whether to render the Airtm button.
 * The admin's email is NEVER exposed in this response — only a boolean
 * indicating whether ADMIN_AIRTM_EMAIL is set.
 *
 * Response:
 *   200 {
 *     configured: boolean,
 *   }
 */
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    await requireUser(request)

    return NextResponse.json({
      configured: isAirtmConfigured(),
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'airtm/config')
  }
}
