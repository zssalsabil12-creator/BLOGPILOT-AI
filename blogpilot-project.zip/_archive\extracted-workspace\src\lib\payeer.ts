/**
 * Payeer payment integration for BlogPilot AI.
 *
 * Payeer's flow is form-based (not REST):
 *   1. Merchant builds a signed form with amount, order_id, user, etc.
 *   2. Buyer is redirected to https://payeer.com/merchant/?m_shop=...
 *   3. After payment, Payeer POSTs back to the merchant's status_url with
 *      a signed `m_sign` parameter — we verify the signature server-side
 *      and activate the user's plan.
 *
 * Routing of funds:
 *   Payeer pays out to the wallet that owns PAYEER_MERCHANT_ID. The
 *   "admin's merchant wallet" is the Payeer account that owns those
 *   credentials — no separate payout config needed.
 *
 * Environment variables (validated by /src/lib/env.ts):
 *   PAYEER_MERCHANT_ID — shop ID from Payeer merchant settings
 *   PAYEER_SECRET_KEY  — secret key from Payeer merchant settings (signs m_sign)
 *   PAYEER_API_KEY     — optional, used for status queries (not currently used)
 *
 * Demo mode: when PAYEER_MERCHANT_ID or PAYEER_SECRET_KEY is missing,
 * `buildPayeerPaymentUrl` returns null and the route handler falls back
 * to a simulated checkout.
 */

import { createHmac, timingSafeEqual } from 'crypto'
import { PLAN_CONFIG, type PlanTier } from '@/lib/stripe'

/** Whether Payeer is fully configured for live mode. */
export function isPayeerConfigured(): boolean {
  return !!(process.env.PAYEER_MERCHANT_ID && process.env.PAYEER_SECRET_KEY)
}

/** Payeer merchant gateway URL (form POST target). */
export const PAYEER_MERCHANT_URL = 'https://payeer.com/merchant/'

/* -------------------------------------------------------------------------- */
/*                          Payment URL builder                               */
/* -------------------------------------------------------------------------- */

export interface PayeerPaymentParams {
  /** Payeer shop ID (m_shop). */
  shop: string
  /** Unique order ID we generate (m_orderid). */
  orderId: string
  /** Amount in USD (m_amount). Format: "19.00" (2 decimals). */
  amount: string
  /** Currency code (m_curr). */
  currency: string
  /** Description (m_desc) — base64-encoded. */
  desc: string
  /** HMAC-SHA256 signature (m_sign). */
  sign: string
}

/**
 * Build the signed form parameters for a Payeer redirect.
 *
 * The signature is `HMAC-SHA256(shop:order:amount:curr:desc:key)` where
 * `key` is PAYEER_SECRET_KEY. Payeer verifies this signature on receipt
 * and rejects the request if it doesn't match.
 *
 * Returns null in demo mode (no credentials configured).
 */
export function buildPayeerPaymentParams(opts: {
  tier: PlanTier
  userId: string
  orderId: string
}): PayeerPaymentParams | null {
  if (!isPayeerConfigured()) return null

  const { tier, userId, orderId } = opts
  const cfg = PLAN_CONFIG[tier]
  const amount = (cfg.priceUsdCents / 100).toFixed(2)
  const currency = 'USD'
  const desc = Buffer.from(
    `BlogPilot AI ${cfg.label} plan (monthly subscription) — user ${userId}`,
    'utf-8'
  ).toString('base64')

  const shop = process.env.PAYEER_MERCHANT_ID!
  const key = process.env.PAYEER_SECRET_KEY!

  // Payeer signature recipe: HMAC-SHA256(shop:order:amount:curr:desc:key)
  // output as uppercase hex.
  const signString = [shop, orderId, amount, currency, desc, key].join(':')
  const sign = createHmac('sha256', key)
    .update(signString)
    .digest('hex')
    .toUpperCase()

  return {
    shop,
    orderId,
    amount,
    currency,
    desc,
    sign,
  }
}

/**
 * Build the full Payeer redirect URL (GET with query params).
 *
 * Some merchants use a form POST instead — both are accepted by Payeer.
 * We use a GET URL so the front-end can simply `window.location.href = url`.
 */
export function buildPayeerPaymentUrl(opts: {
  tier: PlanTier
  userId: string
  orderId: string
  successUrl: string
  failUrl: string
  statusUrl: string
}): string | null {
  const params = buildPayeerPaymentParams(opts)
  if (!params) return null

  const { shop, orderId, amount, currency, desc, sign } = params
  const { successUrl, failUrl, statusUrl } = opts

  const query = new URLSearchParams({
    m_shop: shop,
    m_orderid: orderId,
    m_amount: amount,
    m_curr: currency,
    m_desc: desc,
    m_sign: sign,
    m_process: 'success',
    m_success_url: successUrl,
    m_fail_url: failUrl,
    m_status_url: statusUrl,
  })

  return `${PAYEER_MERCHANT_URL}?${query.toString()}`
}

/* -------------------------------------------------------------------------- */
/*                          Webhook signature check                           */
/* -------------------------------------------------------------------------- */

/**
 * Verify the m_sign parameter on an inbound Payeer status callback.
 *
 * Payeer POSTs form-encoded data to m_status_url after every payment
 * attempt (success or failure). The POST includes `m_sign`, which we
 * must recompute and compare to trust the callback.
 *
 * The signature recipe is `HMAC-SHA256(shop:order:amount:curr:desc:status:key)`.
 */
export function verifyPayeerCallback(form: {
  m_shop?: string
  m_orderid?: string
  m_amount?: string
  m_curr?: string
  m_desc?: string
  m_status?: string
  m_sign?: string
}): { valid: boolean; reason?: string } {
  if (!isPayeerConfigured()) {
    return { valid: false, reason: 'PAYEER_MERCHANT_ID or PAYEER_SECRET_KEY not configured' }
  }

  const { m_shop, m_orderid, m_amount, m_curr, m_desc, m_status, m_sign } = form

  if (!m_shop || !m_orderid || !m_amount || !m_curr || !m_desc || !m_status || !m_sign) {
    return { valid: false, reason: 'Missing required Payeer callback fields' }
  }

  const key = process.env.PAYEER_SECRET_KEY!
  const expectedSignString = [m_shop, m_orderid, m_amount, m_curr, m_desc, m_status, key].join(':')
  const expectedSign = createHmac('sha256', key)
    .update(expectedSignString)
    .digest('hex')
    .toUpperCase()

  // Constant-time-ish comparison to avoid timing attacks (Payeer signs are
  // uppercase hex of fixed length so a simple === is also acceptable, but
  // we use timingSafeEqual as defense-in-depth).
  if (expectedSign.length !== m_sign.length) {
    return { valid: false, reason: 'Signature length mismatch' }
  }

  try {
    const a = Buffer.from(expectedSign)
    const b = Buffer.from(m_sign)
    if (a.length !== b.length) return { valid: false, reason: 'Signature buffer length mismatch' }
    if (!timingSafeEqual(a, b)) {
      return { valid: false, reason: 'Signature mismatch' }
    }
  } catch {
    return { valid: false, reason: 'Signature comparison failed' }
  }

  return { valid: true }
}

/**
 * Parse a Payeer m_orderid back into { userId, tier }.
 *
 * We encode the user id and tier into the order id at creation time so
 * the callback can locate the user without relying on a separate DB
 * table for pending Payeer orders.
 *
 * Format: `<userId>__<tier>__<timestamp>__<random>`
 */
export function parsePayeerOrderId(orderId: string): {
  userId: string | null
  tier: PlanTier | null
} {
  const parts = orderId.split('__')
  if (parts.length < 2) return { userId: null, tier: null }
  return {
    userId: parts[0] || null,
    tier: (parts[1] as PlanTier) || null,
  }
}

/**
 * Build a unique Payeer order ID encoding the user id and tier.
 */
export function buildPayeerOrderId(userId: string, tier: PlanTier): string {
  const ts = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `${userId}__${tier}__${ts}__${rand}`
}
