export const SITE_NAME = 'BlogPilot AI';
export const SITE_TAGLINE = 'AI SEO Growth Agent';

export function getSiteUrl(): string {
  const raw =
    process.env.NEXT_PUBLIC_SITE_URL ||
    (process.env.APP_URL as string | undefined) ||
    'https://blogpilot.ai';
  return raw.replace(/\/+$/, '');
}

export function absoluteUrl(path: string): string {
  return `${getSiteUrl()}${path.startsWith('/') ? path : `/${path}`}`;
}
