'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Image from '@tiptap/extension-image'
import Link from '@tiptap/extension-link'
import Placeholder from '@tiptap/extension-placeholder'
import TextAlign from '@tiptap/extension-text-align'
import Underline from '@tiptap/extension-underline'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'
import { useAppStore } from '@/lib/store'
import { toast } from 'sonner'
import { markdownToHtml, htmlToMarkdown } from '@/lib/markdown-utils'
import {
  ArrowLeft,
  Save,
  Send,
  Bold,
  Italic,
  Underline as UnderlineIcon,
  Strikethrough,
  Code,
  Heading1,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Quote,
  Minus,
  Link as LinkIcon,
  Image as ImageIcon,
  Undo,
  Redo,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Table as TableIcon,
  Eye,
  Code as CodeIcon,
  Loader2,
  Check,
  ExternalLink,
  Globe,
  ShoppingCart,
  Info,
} from 'lucide-react'

interface ArticleData {
  id: string
  title: string
  content: string
  excerpt: string | null
  status: 'draft' | 'published' | 'scheduled'
  targetKeyword: string | null
  seoScore: number | null
  wordCount: number | null
  language: string
  intent: string
  tone: string | null
  length: string | null
  siteId: string | null
  site: { id: string; name: string; url: string; platform: string } | null
  publishedAt: string | null
  createdAt: string
  updatedAt: string
}

interface ConnectedSite {
  id: string
  name: string
  url: string
  platform: string
  isActive: boolean
}

const statusConfig: Record<string, { label: string; className: string }> = {
  published: {
    label: 'Published',
    className: 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20',
  },
  draft: {
    label: 'Draft',
    className: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20',
  },
  scheduled: {
    label: 'Scheduled',
    className: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
  },
}

export function EditorPage() {
  const { currentArticleId, closeEditor } = useAppStore()
  const [article, setArticle] = useState<ArticleData | null>(null)
  const [sites, setSites] = useState<ConnectedSite[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isPublishing, setIsPublishing] = useState(false)
  const [lastSaved, setLastSaved] = useState<string | null>(null)
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false)
  const [publishDialogOpen, setPublishDialogOpen] = useState(false)
  const [publishSiteId, setPublishSiteId] = useState<string>('')
  const [linkDialogOpen, setLinkDialogOpen] = useState(false)
  const [linkUrl, setLinkUrl] = useState('')
  const [imageDialogOpen, setImageDialogOpen] = useState(false)
  const [imageUrl, setImageUrl] = useState('')
  const [imageAlt, setImageAlt] = useState('')
  const [previewMode, setPreviewMode] = useState(false)

  // Title and metadata editable fields
  const [titleDraft, setTitleDraft] = useState('')
  const [excerptDraft, setExcerptDraft] = useState('')
  const [targetKeywordDraft, setTargetKeywordDraft] = useState('')

  // Track initial load to prevent false "dirty" state
  const initialLoadRef = useRef(false)

  /* ------------------------------------------------------------------------ */
  /*                              TipTap editor                               */
  /* ------------------------------------------------------------------------ */
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3, 4] },
      }),
      Underline,
      Link.configure({
        openOnClick: false,
        HTMLAttributes: { class: 'text-primary underline underline-offset-2' },
      }),
      Image.configure({
        inline: false,
        HTMLAttributes: { class: 'rounded-lg max-w-full h-auto' },
      }),
      Placeholder.configure({
        placeholder: 'Start writing or edit the AI-generated content…',
      }),
      TextAlign.configure({ types: ['heading', 'paragraph'] }),
    ],
    content: '',
    onUpdate: () => {
      if (initialLoadRef.current) {
        setHasUnsavedChanges(true)
      }
    },
    editorProps: {
      attributes: {
        class:
          'prose prose-sm dark:prose-invert max-w-none focus:outline-none min-h-[400px] px-8 py-6 leading-relaxed',
      },
    },
  })

  /* ------------------------------------------------------------------------ */
  /*                          Load article + sites                            */
  /* ------------------------------------------------------------------------ */
  useEffect(() => {
    if (!currentArticleId) {
      setIsLoading(false)
      return
    }
    let cancelled = false
    setIsLoading(true)
    initialLoadRef.current = false

    Promise.all([
      fetch(`/api/articles/${currentArticleId}`).then((r) => r.json()),
      fetch('/api/sites').then((r) => r.json()),
    ])
      .then(([articleData, sitesData]) => {
        if (cancelled) return
        if (articleData.article) {
          const a = articleData.article
          setArticle(a)
          setTitleDraft(a.title)
          setExcerptDraft(a.excerpt || '')
          setTargetKeywordDraft(a.targetKeyword || '')
          setPublishSiteId(a.siteId || '')
          // Convert markdown to HTML for TipTap
          const html = markdownToHtml(a.content || '')
          editor?.commands.setContent(html)
        }
        if (sitesData.sites) {
          setSites(sitesData.sites.filter((s: ConnectedSite) => s.isActive))
        }
      })
      .catch((e) => {
        console.error('Failed to load article:', e)
        toast.error('Failed to load article', {
          description: e instanceof Error ? e.message : 'Unknown error',
        })
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoading(false)
          // Defer enabling dirty tracking until after content is set
          setTimeout(() => {
            initialLoadRef.current = true
          }, 50)
        }
      })

    return () => {
      cancelled = true
    }
  }, [currentArticleId, editor])

  /* ------------------------------------------------------------------------ */
  /*                              Beforeunload                               */
  /* ------------------------------------------------------------------------ */
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault()
        e.returnValue = ''
      }
    }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [hasUnsavedChanges])

  /* ------------------------------------------------------------------------ */
  /*                                 Save                                     */
  /* ------------------------------------------------------------------------ */
  const handleSave = useCallback(async () => {
    if (!article || !editor) return
    setIsSaving(true)
    try {
      const html = editor.getHTML()
      const markdown = htmlToMarkdown(html)
      const wordCount = markdown.split(/\s+/).filter(Boolean).length

      const res = await fetch(`/api/articles/${article.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: titleDraft,
          content: markdown,
          excerpt: excerptDraft,
          targetKeyword: targetKeywordDraft,
          wordCount,
        }),
      })

      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || `HTTP ${res.status}`)
      }

      const data = await res.json()
      setArticle(data.article)
      setHasUnsavedChanges(false)
      setLastSaved(new Date().toLocaleTimeString())
      toast.success('Changes saved', {
        description: `${wordCount} words • ${data.article.title.slice(0, 60)}`,
      })
    } catch (e) {
      toast.error('Failed to save', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setIsSaving(false)
    }
  }, [article, editor, titleDraft, excerptDraft, targetKeywordDraft])

  /* ------------------------------------------------------------------------ */
  /*                                Publish                                   */
  /* ------------------------------------------------------------------------ */
  const handlePublish = useCallback(async () => {
    if (!article) return
    setIsPublishing(true)
    try {
      // Auto-save before publishing to ensure latest content is on the server
      if (hasUnsavedChanges) {
        await handleSave()
      }

      const res = await fetch(`/api/articles/${article.id}/publish`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ siteId: publishSiteId || undefined }),
      })

      const data = await res.json()
      if (!res.ok) {
        throw new Error(data.error || `HTTP ${res.status}`)
      }

      setArticle((prev) =>
        prev
          ? {
              ...prev,
              status: 'published',
              publishedAt: data.publishedAt,
              siteId: publishSiteId || prev.siteId,
            }
          : prev
      )
      setPublishDialogOpen(false)
      setHasUnsavedChanges(false)

      const isSimulated = data.method === 'simulated' || data.method === 'manual'
      toast.success(
        isSimulated ? 'Published (demo mode)' : 'Published to site',
        {
          description: data.postUrl
            ? `${data.platform} • ${data.postUrl}`
            : `${data.platform} • ${article.title.slice(0, 60)}`,
          action: data.postUrl
            ? {
                label: 'View',
                onClick: () => window.open(data.postUrl, '_blank'),
              }
            : undefined,
        }
      )
    } catch (e) {
      toast.error('Failed to publish', {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setIsPublishing(false)
    }
  }, [article, publishSiteId, hasUnsavedChanges, handleSave])

  /* ------------------------------------------------------------------------ */
  /*                          Editor toolbar helpers                          */
  /* ------------------------------------------------------------------------ */
  const setLink = () => {
    const previous = editor?.getAttributes('link').href || ''
    setLinkUrl(previous)
    setLinkDialogOpen(true)
  }

  const confirmLink = () => {
    if (!editor) return
    const url = linkUrl.trim()
    if (!url) {
      editor.chain().focus().extendMarkRange('link').unsetLink().run()
    } else {
      // Basic URL normalization
      const normalized = /^https?:\/\//.test(url) ? url : `https://${url}`
      editor
        .chain()
        .focus()
        .extendMarkRange('link')
        .setLink({ href: normalized, target: '_blank', rel: 'noopener noreferrer' })
        .run()
    }
    setLinkDialogOpen(false)
    setLinkUrl('')
  }

  const addImage = () => {
    setImageUrl('')
    setImageAlt('')
    setImageDialogOpen(true)
  }

  const confirmImage = () => {
    if (!editor || !imageUrl.trim()) return
    editor.chain().focus().setImage({ src: imageUrl.trim(), alt: imageAlt.trim() }).run()
    setImageDialogOpen(false)
    setImageUrl('')
    setImageAlt('')
  }

  if (!currentArticleId) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">No article selected.</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={() => closeEditor('history')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to History
          </Button>
        </div>
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-sm text-muted-foreground mt-3">Loading article…</p>
        </div>
      </div>
    )
  }

  if (!article) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">Article not found.</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={() => closeEditor('history')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to History
          </Button>
        </div>
      </div>
    )
  }

  const status = statusConfig[article.status] || statusConfig.draft
  const IntentIcon = article.intent === 'commercial' ? ShoppingCart : Info
  const wordCount = editor?.getText().split(/\s+/).filter(Boolean).length || 0

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)] -m-4 lg:-m-6">
      {/* Top Bar */}
      <div className="border-b border-border/50 bg-card/50 backdrop-blur-sm px-4 lg:px-6 py-3 flex flex-wrap items-center gap-3 shrink-0">
        <Button variant="ghost" size="sm" onClick={() => closeEditor('history')}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <Separator orientation="vertical" className="h-6" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={`text-[10px] ${status.className}`}>
              {status.label}
            </Badge>
            <Badge variant="secondary" className="text-[10px]">
              <IntentIcon className="h-3 w-3 mr-1" />
              {article.intent}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {article.language.toUpperCase()} • {wordCount.toLocaleString()} words
            </span>
          </div>
        </div>

        {/* Save indicator */}
        {lastSaved && !hasUnsavedChanges && (
          <span className="text-xs text-muted-foreground hidden sm:flex items-center gap-1">
            <Check className="h-3 w-3 text-green-500" />
            Saved at {lastSaved}
          </span>
        )}
        {hasUnsavedChanges && (
          <span className="text-xs text-yellow-600 dark:text-yellow-400 hidden sm:flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-yellow-500" />
            Unsaved changes
          </span>
        )}

        {/* Action buttons */}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setPreviewMode((v) => !v)}
        >
          <Eye className="h-4 w-4 mr-2" />
          {previewMode ? 'Edit' : 'Preview'}
        </Button>
        <Button
          variant="default"
          size="sm"
          onClick={handleSave}
          disabled={isSaving || !hasUnsavedChanges}
        >
          {isSaving ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          Save
        </Button>
        <Button
          variant="default"
          size="sm"
          className="bg-gradient-to-r from-primary to-primary/80"
          onClick={() => setPublishDialogOpen(true)}
          disabled={isPublishing}
        >
          {isPublishing ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Send className="h-4 w-4 mr-2" />
          )}
          Push to Site
        </Button>
      </div>

      {/* Toolbar */}
      {!previewMode && editor && (
        <div className="border-b border-border/40 bg-muted/20 px-4 lg:px-6 py-2 flex flex-wrap items-center gap-1 shrink-0 overflow-x-auto">
          <ToolbarButton onClick={() => editor.chain().focus().undo().run()} disabled={!editor.can().undo()} title="Undo">
            <Undo className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().redo().run()} disabled={!editor.can().redo()} title="Redo">
            <Redo className="h-4 w-4" />
          </ToolbarButton>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <ToolbarButton onClick={() => editor.chain().focus().toggleBold().run()} active={editor.isActive('bold')} title="Bold">
            <Bold className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleItalic().run()} active={editor.isActive('italic')} title="Italic">
            <Italic className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleUnderline().run()} active={editor.isActive('underline')} title="Underline">
            <UnderlineIcon className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleStrike().run()} active={editor.isActive('strike')} title="Strikethrough">
            <Strikethrough className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleCode().run()} active={editor.isActive('code')} title="Inline code">
            <Code className="h-4 w-4" />
          </ToolbarButton>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} active={editor.isActive('heading', { level: 1 })} title="H1">
            <Heading1 className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} active={editor.isActive('heading', { level: 2 })} title="H2">
            <Heading2 className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} active={editor.isActive('heading', { level: 3 })} title="H3">
            <Heading3 className="h-4 w-4" />
          </ToolbarButton>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <ToolbarButton onClick={() => editor.chain().focus().toggleBulletList().run()} active={editor.isActive('bulletList')} title="Bullet list">
            <List className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editor.isActive('orderedList')} title="Numbered list">
            <ListOrdered className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleBlockquote().run()} active={editor.isActive('blockquote')} title="Quote">
            <Quote className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().toggleCodeBlock().run()} active={editor.isActive('codeBlock')} title="Code block">
            <CodeIcon className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().setHorizontalRule().run()} title="Divider">
            <Minus className="h-4 w-4" />
          </ToolbarButton>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('left').run()} active={editor.isActive({ textAlign: 'left' })} title="Align left">
            <AlignLeft className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('center').run()} active={editor.isActive({ textAlign: 'center' })} title="Align center">
            <AlignCenter className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('right').run()} active={editor.isActive({ textAlign: 'right' })} title="Align right">
            <AlignRight className="h-4 w-4" />
          </ToolbarButton>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <ToolbarButton onClick={setLink} active={editor.isActive('link')} title="Add link">
            <LinkIcon className="h-4 w-4" />
          </ToolbarButton>
          <ToolbarButton onClick={addImage} title="Insert image">
            <ImageIcon className="h-4 w-4" />
          </ToolbarButton>
        </div>
      )}

      {/* Editor + Sidebar */}
      <div className="flex-1 overflow-hidden flex">
        {/* Main editor area */}
        <div className="flex-1 overflow-y-auto bg-background">
          {previewMode ? (
            <article className="prose prose-lg dark:prose-invert max-w-3xl mx-auto px-8 py-8">
              <h1>{titleDraft}</h1>
              <div
                dangerouslySetInnerHTML={{ __html: editor?.getHTML() || '' }}
              />
            </article>
          ) : (
            <div className="max-w-3xl mx-auto px-4 lg:px-8 py-6">
              {/* Title input — large, like a document title */}
              <input
                value={titleDraft}
                onChange={(e) => {
                  setTitleDraft(e.target.value)
                  setHasUnsavedChanges(true)
                }}
                placeholder="Article title"
                className="w-full text-3xl font-bold tracking-tight bg-transparent border-none outline-none mb-4 placeholder:text-muted-foreground/50"
              />
              {/* Editor content */}
              <div className="border border-border/40 rounded-lg bg-card min-h-[500px]">
                <EditorContent editor={editor} />
              </div>
            </div>
          )}
        </div>

        {/* Sidebar — article metadata */}
        {!previewMode && (
          <aside className="hidden lg:block w-80 border-l border-border/50 bg-card/30 overflow-y-auto shrink-0">
            <div className="p-4 space-y-4">
              <div>
                <h3 className="text-xs font-semibold uppercase text-muted-foreground tracking-wide mb-3">
                  Article Details
                </h3>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="excerpt" className="text-xs">Excerpt</Label>
                    <Textarea
                      id="excerpt"
                      value={excerptDraft}
                      onChange={(e) => {
                        setExcerptDraft(e.target.value)
                        setHasUnsavedChanges(true)
                      }}
                      placeholder="Short summary for SEO and previews…"
                      rows={3}
                      className="mt-1 text-sm resize-none"
                    />
                  </div>
                  <div>
                    <Label htmlFor="keyword" className="text-xs">Target Keyword</Label>
                    <Input
                      id="keyword"
                      value={targetKeywordDraft}
                      onChange={(e) => {
                        setTargetKeywordDraft(e.target.value)
                        setHasUnsavedChanges(true)
                      }}
                      placeholder="best wireless headphones"
                      className="mt-1 text-sm"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              {/* Stats */}
              <div>
                <h3 className="text-xs font-semibold uppercase text-muted-foreground tracking-wide mb-3">
                  Stats
                </h3>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="p-2 rounded-md bg-muted/30">
                    <p className="text-[10px] text-muted-foreground uppercase">Words</p>
                    <p className="font-mono font-bold">{wordCount.toLocaleString()}</p>
                  </div>
                  <div className="p-2 rounded-md bg-muted/30">
                    <p className="text-[10px] text-muted-foreground uppercase">SEO Score</p>
                    <p className={`font-mono font-bold ${
                      (article.seoScore || 0) >= 90 ? 'text-green-500' : (article.seoScore || 0) >= 80 ? 'text-yellow-500' : 'text-red-500'
                    }`}>
                      {article.seoScore ?? '—'}
                    </p>
                  </div>
                  <div className="p-2 rounded-md bg-muted/30 col-span-2">
                    <p className="text-[10px] text-muted-foreground uppercase">Last updated</p>
                    <p className="text-xs font-medium">
                      {new Date(article.updatedAt).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Publishing info */}
              <div>
                <h3 className="text-xs font-semibold uppercase text-muted-foreground tracking-wide mb-3">
                  Publishing
                </h3>
                {article.publishedAt && (
                  <div className="mb-3 p-2 rounded-md bg-green-500/5 border border-green-500/20">
                    <p className="text-[10px] text-green-600 dark:text-green-400 uppercase">Published on</p>
                    <p className="text-xs font-medium">
                      {new Date(article.publishedAt).toLocaleString()}
                    </p>
                  </div>
                )}
                {article.site ? (
                  <div className="p-2 rounded-md bg-muted/30">
                    <p className="text-[10px] text-muted-foreground uppercase">Connected site</p>
                    <p className="text-sm font-medium flex items-center gap-1.5 mt-0.5">
                      <Globe className="h-3 w-3" />
                      {article.site.name}
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5 capitalize">
                      {article.site.platform}
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    No site connected. Use &ldquo;Push to Site&rdquo; to publish.
                  </p>
                )}
              </div>
            </div>
          </aside>
        )}
      </div>

      {/* Publish Dialog */}
      <Dialog open={publishDialogOpen} onOpenChange={setPublishDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Push to Site</DialogTitle>
            <DialogDescription>
              Choose a connected site to publish this article. The article will be saved with your latest edits before publishing.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs">Target site</Label>
              {sites.length === 0 ? (
                <div className="mt-2 p-3 rounded-md bg-yellow-500/5 border border-yellow-500/20 text-xs text-yellow-700 dark:text-yellow-400">
                  No active sites connected. The article will be marked as published locally (demo mode).
                  Connect a WordPress or Shopify site in <strong>Connected Sites</strong> to enable live publishing.
                </div>
              ) : (
                <Select value={publishSiteId} onValueChange={setPublishSiteId}>
                  <SelectTrigger className="mt-1.5">
                    <SelectValue placeholder="Select a site" />
                  </SelectTrigger>
                  <SelectContent>
                    {sites.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        <span className="flex items-center gap-2">
                          <Globe className="h-3 w-3" />
                          {s.name}
                          <span className="text-[10px] text-muted-foreground capitalize">({s.platform})</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="p-3 rounded-md bg-muted/30 border border-border/50">
              <p className="text-xs font-medium mb-1">{titleDraft}</p>
              <p className="text-[11px] text-muted-foreground">
                {wordCount.toLocaleString()} words • {article.language.toUpperCase()} • {article.intent}
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPublishDialogOpen(false)} disabled={isPublishing}>
              Cancel
            </Button>
            <Button
              onClick={handlePublish}
              disabled={isPublishing}
              className="bg-gradient-to-r from-primary to-primary/80"
            >
              {isPublishing ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Publishing...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Publish Now
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Link Dialog */}
      <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Insert Link</DialogTitle>
            <DialogDescription>
              Add a hyperlink to the selected text. Leave blank to remove an existing link.
            </DialogDescription>
          </DialogHeader>
          <div className="py-2">
            <Input
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              placeholder="https://example.com"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault()
                  confirmLink()
                }
              }}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLinkDialogOpen(false)}>Cancel</Button>
            <Button onClick={confirmLink}>Apply</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Image Dialog */}
      <Dialog open={imageDialogOpen} onOpenChange={setImageDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Insert Image</DialogTitle>
            <DialogDescription>
              Paste an image URL. Use Unsplash, your CDN, or any publicly accessible image.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <Label className="text-xs">Image URL</Label>
              <Input
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                autoFocus
              />
            </div>
            <div>
              <Label className="text-xs">Alt text (for SEO)</Label>
              <Input
                value={imageAlt}
                onChange={(e) => setImageAlt(e.target.value)}
                placeholder="Wireless headphones on a wooden desk"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImageDialogOpen(false)}>Cancel</Button>
            <Button onClick={confirmImage} disabled={!imageUrl.trim()}>Insert</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/* -------------------------------------------------------------------------- */
/*                              Toolbar button                               */
/* -------------------------------------------------------------------------- */
function ToolbarButton({
  children,
  onClick,
  active,
  disabled,
  title,
}: {
  children: React.ReactNode
  onClick: () => void
  active?: boolean
  disabled?: boolean
  title?: string
}) {
  return (
    <Button
      variant="ghost"
      size="icon"
      className={`h-8 w-8 shrink-0 ${active ? 'bg-secondary text-secondary-foreground' : ''}`}
      onClick={onClick}
      disabled={disabled}
      title={title}
      type="button"
    >
      {children}
    </Button>
  )
}
