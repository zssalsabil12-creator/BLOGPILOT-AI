'use client'
import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, Legend
} from 'recharts'
import { TrendingUp, Globe, BarChart3, Coins, Loader2, Sparkles } from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'
import { useAppStore } from '@/lib/store'

interface ApiArticle {
  id: string
  title: string
  status: string
  language: string
  wordCount: number
  seoScore: number
  createdAt: string
}

const COLORS = ['#22d3ee', '#8b5cf6', '#d946ef', '#f59e0b', '#10b981']
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
}

export default function AnalyticsPage() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [articles, setArticles] = useState<ApiArticle[]>([])
  const [credits, setCredits] = useState<{ credits: number; totalCreditsUsed: number } | null>(null)
  const setDashboardTab = useAppStore(s => s.setDashboardTab)

  const loadData = useCallback(async () => {
    try {
      setLoading(true)
      const [articlesRes, creditsRes] = await Promise.all([
        fetch('/api/articles?limit=500'),
        fetch('/api/credits'),
      ])
      const articlesJson = await articlesRes.json()
      if (!articlesRes.ok) throw new Error(articlesJson?.error || 'Failed to load data')
      const creditsJson = creditsRes.ok ? await creditsRes.json() : null

      setArticles(articlesJson?.data?.articles || [])
      setCredits(creditsJson?.data
        ? { credits: creditsJson.data.credits ?? 0, totalCreditsUsed: creditsJson.data.totalCreditsUsed ?? 0 }
        : null)
      setError(null)
    } catch (err: any) {
      console.error('Load analytics error:', err)
      setError(err?.message || 'Failed to load analytics')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadData()
  }, [loadData])

  const monthlyData = MONTHS.map((month, i) => {
    const monthArticles = articles.filter(a => {
      const d = new Date(a.createdAt)
      return d.getMonth() === i
    })
    return {
      month,
      articles: monthArticles.length,
      published: monthArticles.filter(a => a.status === 'PUBLISHED').length,
    }
  })

  const statusData = [
    { name: 'Published', value: articles.filter(a => a.status === 'PUBLISHED').length },
    { name: 'Draft', value: articles.filter(a => a.status === 'DRAFT').length },
    { name: 'Scheduled', value: articles.filter(a => a.status === 'SCHEDULED').length },
  ].filter(d => d.value > 0)

  const langMap = new Map<string, number>()
  for (const a of articles) {
    const lang = a.language || 'Unknown'
    langMap.set(lang, (langMap.get(lang) || 0) + 1)
  }
  const langData = Array.from(langMap.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5)

  const wordData = MONTHS.map((month, i) => {
    const monthArticles = articles.filter(a => new Date(a.createdAt).getMonth() === i)
    const total = monthArticles.reduce((sum, a) => sum + (a.wordCount || 0), 0)
    return {
      month,
      words: monthArticles.length > 0 ? Math.round(total / monthArticles.length) : 0,
    }
  })

  const totalArticles = articles.length
  const publishedCount = articles.filter(a => a.status === 'PUBLISHED').length

  // Real SEO scores only. Articles saved before server-side scoring have 0
  // ("not scored yet") and are excluded rather than shown as fake zeros.
  const scoredArticles = articles.filter(a => (a.seoScore || 0) > 0)
  const avgSeo = scoredArticles.length > 0
    ? Math.round(scoredArticles.reduce((sum, a) => sum + (a.seoScore || 0), 0) / scoredArticles.length)
    : null

  const seoBuckets = [
    { range: '0-39', label: 'Needs work', min: 0, max: 39 },
    { range: '40-59', label: 'Fair', min: 40, max: 59 },
    { range: '60-79', label: 'Good', min: 60, max: 79 },
    { range: '80-100', label: 'Strong', min: 80, max: 100 },
  ].map(b => ({
    name: b.range,
    count: scoredArticles.filter(a => (a.seoScore || 0) >= b.min && (a.seoScore || 0) <= b.max).length,
  })).filter(b => b.count > 0)

  const hasAnyData = totalArticles > 0

  const stats = [
    {
      title: 'Total Articles',
      value: String(totalArticles),
      change: `${credits?.totalCreditsUsed || 0} credits used`,
      icon: TrendingUp,
      color: 'from-cyan-400 to-blue-500',
    },
    {
      title: 'Published',
      value: String(publishedCount),
      change: totalArticles > 0 ? `${Math.round((publishedCount / totalArticles) * 100)}% publish rate` : 'No data yet',
      icon: Globe,
      color: 'from-emerald-400 to-teal-500',
    },
    {
      title: 'Avg SEO Score',
      value: avgSeo !== null ? `${avgSeo}/100` : '—',
      change: avgSeo !== null
        ? `across ${scoredArticles.length} scored`
        : totalArticles > 0 ? 're-save an article to score it' : 'No data yet',
      icon: BarChart3,
      color: 'from-violet-400 to-purple-500',
    },
    {
      title: 'Credits Left',
      value: String(credits?.credits ?? '—'),
      change: 'available for generation',
      icon: Coins,
      color: 'from-fuchsia-400 to-pink-500',
    },
  ]

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-foreground mb-2">Analytics</h1>
          <p className="text-muted-foreground">Track your content library and on-page SEO quality</p>
        </motion.div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
        ) : error ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-20"
          >
            <p className="text-muted-foreground mb-4">{error}</p>
            <button
              onClick={loadData}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-violet-500 text-foreground text-sm"
            >
              Retry
            </button>
          </motion.div>
        ) : !hasAnyData ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-24 text-center"
          >
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500/20 to-violet-500/20 flex items-center justify-center border border-border mb-6">
              <Sparkles className="w-8 h-8 text-cyan-400" />
            </div>
            <h2 className="text-xl font-semibold text-foreground mb-2">No data yet</h2>
            <p className="text-muted-foreground max-w-md mb-6">
              Generate your first article to see content metrics and SEO quality analysis here.
            </p>
            <Button
              onClick={() => setDashboardTab('generate-article')}
              className="bg-gradient-to-r from-cyan-500 to-violet-500 hover:opacity-90 text-foreground rounded-xl px-6"
            >
              Generate your first article
            </Button>
          </motion.div>
        ) : (
          <>
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
            >
              {stats.map((stat) => (
                <motion.div key={stat.title} variants={itemVariants}>
                  <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl hover:bg-accent transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className={cn(
                          "w-12 h-12 rounded-full flex items-center justify-center bg-gradient-to-br",
                          stat.color
                        )}>
                          <stat.icon className="w-6 h-6 text-foreground" />
                        </div>
                        <Badge variant="secondary" className="bg-emerald-500/20 text-emerald-400 border-0">
                          {stat.change}
                        </Badge>
                      </div>
                      <div className="text-3xl font-bold text-foreground mb-1">{stat.value}</div>
                      <div className="text-muted-foreground text-sm">{stat.title}</div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>

            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-1 lg:grid-cols-2 gap-6"
            >
              <motion.div variants={itemVariants}>
                <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-foreground">Articles Over Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={monthlyData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(var(--border))" />
                          <XAxis dataKey="month" stroke="rgba(var(--muted-foreground))" />
                          <YAxis stroke="rgba(var(--muted-foreground))" allowDecimals={false} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '12px',
                              color: 'hsl(var(--popover-foreground))',
                            }}
                          />
                          <Area
                            type="monotone"
                            dataKey="articles"
                            stroke="#22d3ee"
                            fill="url(#colorArticles)"
                            strokeWidth={2}
                          />
                          <Area
                            type="monotone"
                            dataKey="published"
                            stroke="#8b5cf6"
                            fill="url(#colorPublished)"
                            strokeWidth={2}
                          />
                          <defs>
                            <linearGradient id="colorArticles" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                            </linearGradient>
                            <linearGradient id="colorPublished" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <Legend wrapperStyle={{ color: 'hsl(var(--foreground))' }} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-foreground">Articles by Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={statusData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(var(--border))" />
                          <XAxis dataKey="name" stroke="rgba(var(--muted-foreground))" />
                          <YAxis stroke="rgba(var(--muted-foreground))" allowDecimals={false} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '12px',
                              color: 'hsl(var(--popover-foreground))',
                            }}
                          />
                          <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                            {statusData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-foreground">Languages Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={langData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {langData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '12px',
                              color: 'hsl(var(--popover-foreground))',
                            }}
                          />
                          <Legend wrapperStyle={{ color: 'hsl(var(--foreground))' }} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-foreground">Avg Word Count Trend</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={wordData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(var(--border))" />
                          <XAxis dataKey="month" stroke="rgba(var(--muted-foreground))" />
                          <YAxis stroke="rgba(var(--muted-foreground))" allowDecimals={false} />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '12px',
                              color: 'hsl(var(--popover-foreground))',
                            }}
                          />
                          <Line
                            type="monotone"
                            dataKey="words"
                            stroke="#10b981"
                            strokeWidth={3}
                            dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                            activeDot={{ r: 6 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants} className="lg:col-span-2">
                <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl">
                  <CardHeader>
                    <CardTitle className="text-foreground">SEO Score Distribution</CardTitle>
                    <p className="text-sm text-muted-foreground">
                      On-page quality computed when articles are saved (title, structure, depth, readability).
                      {scoredArticles.length === 0 && ' No scored articles yet — re-save an article to compute its score.'}
                    </p>
                  </CardHeader>
                  <CardContent>
                    {seoBuckets.length > 0 ? (
                      <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={seoBuckets}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(var(--border))" />
                            <XAxis dataKey="name" stroke="rgba(var(--muted-foreground))" />
                            <YAxis stroke="rgba(var(--muted-foreground))" allowDecimals={false} />
                            <Tooltip
                              contentStyle={{
                                backgroundColor: 'hsl(var(--popover))',
                                border: '1px solid hsl(var(--border))',
                                borderRadius: '12px',
                                color: 'hsl(var(--popover-foreground))',
                              }}
                            />
                            <Bar dataKey="count" radius={[8, 8, 0, 0]} fill="#22d3ee" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-[300px] text-center">
                        <BarChart3 className="w-10 h-10 text-muted-foreground/40 mb-3" />
                        <p className="text-muted-foreground">No scored articles yet</p>
                        <p className="text-xs text-muted-foreground/60 mt-1">
                          Scores are computed automatically the next time you save or edit an article.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </>
        )}
      </div>
    </div>
  )
}
