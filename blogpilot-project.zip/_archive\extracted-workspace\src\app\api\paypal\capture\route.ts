import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { PLAN_CONFIG, activateSubscription, type PlanTier } from '@/lib/stripe'
import { capturePaypalOrder, isPaypalConfigured } from '@/lib/paypal'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { parseBody } from '@/lib/validation'
import { paypalCaptureSchema } from '../_validation'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/paypal/capture
 *
 * Called by the front-end after the buyer returns from the PayPal
 * approval page. Captures the approved order — funds are debited from
 * the buyer and deposited to the merchant's PayPal wallet.
 *
 * Body:
 *   { orderId: string }
 *
 * On success, flips the user's subscription to status='active' and
 * grants the plan's monthly credit allotment.
 *
 * Response:
 *   200 { ok: true, tier, creditsGranted, newBalance }
 *   400 if the capture failed or the order doesn't belong to the user
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(paypalCaptureSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    // ─── Demo mode — short-circuit with a fake success ───────────────────
    if (!isPaypalConfigured()) {
      return NextResponse.json({
        ok: false,
        error: 'PayPal is not configured. Cannot capture a live order.',
        code: 'paypal_not_configured',
      }, { status: 503 })
    }

    const capture = await capturePaypalOrder(body.orderId)

    if (!capture.ok) {
      return NextResponse.json(
        {
          ok: false,
          error: 'PayPal capture failed',
          code: 'paypal_capture_failed',
          detail: capture.raw,
        },
        { status: 400 }
      )
    }

    // Security: verify the capture belongs to the authenticated user.
    // The custom_id we set at order creation is "<userId>:<tier>".
    if (capture.userId && capture.userId !== user.id) {
      console.error(
        `[paypal/capture] user ${user.id} attempted to capture order ${body.orderId} ` +
        `belonging to user ${capture.userId}`
      )
      return NextResponse.json(
        { ok: false, error: 'This order does not belong to your account', code: 'auth' },
        { status: 403 }
      )
    }

    if (!capture.tier || !(capture.tier in PLAN_CONFIG) || capture.tier === 'free') {
      return NextResponse.json(
        { ok: false, error: 'Could not determine plan tier from PayPal order', code: 'paypal_invalid_tier' },
        { status: 400 }
      )
    }

    // Activate the subscription (flips status='active' + grants credits)
    const activation = await activateSubscription({
      userId: user.id,
      tier: capture.tier,
      gateway: 'paypal',
      externalId: capture.captureId || body.orderId,
    })

    if (!activation.ok) {
      return NextResponse.json(
        {
          ok: false,
          error: 'Capture succeeded but subscription activation failed',
          code: 'activation_failed',
          detail: activation.error,
        },
        { status: 500 }
      )
    }

    return NextResponse.json({
      ok: true,
      tier: capture.tier as PlanTier,
      captureId: capture.captureId,
      amount: capture.amount,
      currency: capture.currency,
      creditsGranted: activation.creditsGranted,
      newBalance: activation.newBalance,
      action: activation.action,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'paypal/capture')
  }
}
