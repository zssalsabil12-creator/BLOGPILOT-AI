'use client';

import React, { useState, useMemo } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  Image as ImageIcon,
  Globe,
  AlertTriangle,
} from 'lucide-react';

interface OgFields {
  siteName: string;
  title: string;
  description: string;
  imageUrl: string;
  url: string;
  type: string;
  locale: string;
}

function CharCounter({ count, recommended }: { count: number; recommended: number }) {
  if (count === 0) return null;
  const color =
    count <= recommended ? 'text-emerald-400' : count <= recommended + 30 ? 'text-amber-400' : 'text-rose-400';
  return (
    <span className={`text-xs ${color}`}>
      {count} chars {count <= recommended ? '(good)' : count <= recommended + 30 ? '(getting long)' : '(too long)'}
    </span>
  );
}

function extractDomain(url: string): string {
  if (!url.trim()) return 'example.com';
  try {
    const normalized = url.startsWith('http') ? url : 'https://' + url;
    return new URL(normalized).hostname;
  } catch {
    return url.replace(/^https?:\/\//, '').split('/')[0] || 'example.com';
  }
}

export default function OpenGraphPreviewPage() {
  const [fields, setFields] = useState<OgFields>({
    siteName: '',
    title: '',
    description: '',
    imageUrl: '',
    url: '',
    type: 'website',
    locale: 'en_US',
  });

  const domain = useMemo(() => extractDomain(fields.url), [fields.url]);
  const displayTitle = fields.title || 'Page Title';
  const displayDescription = fields.description || 'Add a description to see how it will appear when shared on social media.';
  const displaySiteName = fields.siteName || domain;

  function handleChange(field: keyof OgFields, value: string) {
    setFields((prev) => ({ ...prev, [field]: value }));
  }

  const inputClass =
    'w-full rounded-xl border border-border bg-muted/50 py-2.5 px-4 text-sm text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30';
  const labelClass = 'text-xs font-medium text-muted-foreground';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        {/* Hero */}
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Open Graph <span className="text-gradient">Preview</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Preview how your page will look when shared on Facebook, LinkedIn, and Twitter/X.
            Customize all Open Graph fields in real time.
          </p>
        </section>

        {/* Input */}
        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className={labelClass}>Site Name</label>
                <input
                  value={fields.siteName}
                  onChange={(e) => handleChange('siteName', e.target.value)}
                  placeholder="My Website"
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>URL</label>
                <div className="relative">
                  <Globe className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    value={fields.url}
                    onChange={(e) => handleChange('url', e.target.value)}
                    placeholder="https://example.com/page"
                    className={`${inputClass} pl-11`}
                  />
                </div>
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className={labelClass}>Page Title</label>
                <CharCounter count={fields.title.length} recommended={70} />
              </div>
              <input
                value={fields.title}
                onChange={(e) => handleChange('title', e.target.value)}
                placeholder="Your Page Title"
                className={inputClass}
                maxLength={100}
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className={labelClass}>Description</label>
                <CharCounter count={fields.description.length} recommended={200} />
              </div>
              <textarea
                value={fields.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="A brief description of your page content..."
                rows={3}
                className={`${inputClass} resize-none`}
                maxLength={400}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label className={labelClass}>Image URL</label>
                <input
                  value={fields.imageUrl}
                  onChange={(e) => handleChange('imageUrl', e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>Type</label>
                <select
                  value={fields.type}
                  onChange={(e) => handleChange('type', e.target.value)}
                  className={inputClass}
                >
                  <option value="website">website</option>
                  <option value="article">article</option>
                  <option value="video">video</option>
                  <option value="mission">mission</option>
                </select>
              </div>
              <div>
                <label className={labelClass}>Locale</label>
                <select
                  value={fields.locale}
                  onChange={(e) => handleChange('locale', e.target.value)}
                  className={inputClass}
                >
                  <option value="en_US">English (US)</option>
                  <option value="en_GB">English (UK)</option>
                  <option value="ar_AR">Arabic</option>
                  <option value="fr_FR">French</option>
                  <option value="de_DE">German</option>
                  <option value="es_ES">Spanish</option>
                  <option value="ja_JP">Japanese</option>
                  <option value="zh_CN">Chinese (Simplified)</option>
                </select>
              </div>
            </div>
          </div>
        </section>

        {/* Previews */}
        <div className="grid gap-6 lg:grid-cols-2">
          {/* Facebook / LinkedIn Preview */}
          <section className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center gap-3">
              <div className="h-5 w-5 rounded-full bg-[#1877f2] flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">f</span>
              </div>
              <h2 className="text-lg font-semibold text-foreground">Facebook / LinkedIn Preview</h2>
            </div>

            <div className="mt-4 overflow-hidden rounded-xl border border-[#ddd] bg-white">
              {/* Image Area */}
              {fields.imageUrl ? (
                <div className="relative aspect-[1200/630] w-full bg-muted/30">
                  <img
                    src={fields.imageUrl}
                    alt="OG Preview"
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              ) : (
                <div className="flex aspect-[1200/630] w-full flex-col items-center justify-center bg-[#f0f0f0]">
                  <ImageIcon aria-hidden="true" className="h-12 w-12 text-[#999]" />
                  <p className="mt-2 text-sm text-[#999]">No image set</p>
                </div>
              )}

              {/* Text Area */}
              <div className="border-t border-[#ddd] bg-[#f0f2f5] p-3">
                <p className="text-[12px] uppercase text-[#8d949e]">
                  {domain}
                </p>
                <p className="mt-0.5 text-[16px] font-semibold leading-tight text-[#1c1e21]">
                  {displayTitle}
                </p>
                <p className="mt-1 text-[14px] leading-snug text-[#606770]">
                  {displayDescription.length > 110
                    ? displayDescription.slice(0, 107) + '...'
                    : displayDescription}
                </p>
              </div>
            </div>
          </section>

          {/* Twitter/X Preview */}
          <section className="rounded-2xl border border-border bg-card/50 p-6">
            <div className="flex items-center gap-3">
              <div className="h-5 w-5 rounded-full bg-black flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">X</span>
              </div>
              <h2 className="text-lg font-semibold text-foreground">Twitter / X Preview</h2>
            </div>

            <div className="mt-4 overflow-hidden rounded-xl border border-[#2f333c] bg-[#15202b]">
              {/* Image Area */}
              {fields.imageUrl ? (
                <div className="relative aspect-[1200/628] w-full bg-muted/30">
                  <img
                    src={fields.imageUrl}
                    alt="Twitter Card Preview"
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>
              ) : (
                <div className="flex aspect-[1200/628] w-full flex-col items-center justify-center bg-[#253341]">
                  <ImageIcon aria-hidden="true" className="h-12 w-12 text-[#8899a6]" />
                  <p className="mt-2 text-sm text-[#8899a6]">No image set</p>
                </div>
              )}

              {/* Text Area */}
              <div className="border-t border-[#2f333c] p-3">
                <p className="text-[14px] font-bold text-[#e7e9ea]">
                  {displayTitle}
                </p>
                <p className="mt-1 text-[14px] leading-snug text-[#71767b]">
                  {displayDescription.length > 130
                    ? displayDescription.slice(0, 127) + '...'
                    : displayDescription}
                </p>
                <div className="mt-2 flex items-center gap-1 text-[14px] text-[#71767b]">
                  <Globe className="h-3.5 w-3.5" />
                  <span>{domain}</span>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* OG Meta Tags */}
        <section className="rounded-2xl border border-border bg-card/50 p-6">
          <div className="flex items-center gap-3">
            <Globe className="h-5 w-5 text-cyan-300" />
            <h2 className="text-lg font-semibold text-foreground">Generated OG Tags</h2>
          </div>
          <pre className="mt-4 overflow-x-auto rounded-xl border border-border bg-muted/50 p-4 text-sm leading-relaxed text-foreground">
            <code>
{`<meta property="og:type" content="${fields.type}" />
<meta property="og:url" content="${fields.url || 'https://example.com/page'}" />
<meta property="og:title" content="${fields.title || 'Page Title'}" />
<meta property="og:description" content="${fields.description || 'Add a description...'}" />
<meta property="og:image" content="${fields.imageUrl || 'https://example.com/image.jpg'}" />
<meta property="og:site_name" content="${displaySiteName}" />
<meta property="og:locale" content="${fields.locale}" />

<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${fields.title || 'Page Title'}" />
<meta name="twitter:description" content="${fields.description || 'Add a description...'}" />
<meta name="twitter:image" content="${fields.imageUrl || 'https://example.com/image.jpg'}" />`}
            </code>
          </pre>
        </section>
      </div>
    </FreeToolLayout>
  );
}
