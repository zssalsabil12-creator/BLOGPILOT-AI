'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { toast } from 'sonner'
import {
  Sparkles,
  Zap,
  Infinity as InfinityIcon,
  Check,
  Loader2,
  Coins,
  AlertCircle,
  CreditCard,
  ExternalLink,
} from 'lucide-react'

type Gateway = 'stripe' | 'paypal' | 'payeer'

interface PlanInfo {
  tier: 'basic' | 'pro' | 'agency'
  label: string
  priceUsd: number
  credits: number | null
  blurb: string
  accent: string
}

interface UpgradeDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Pre-selected tier to highlight (e.g., when /api/generate returns 403 with suggestedTier). */
  suggestedTier?: 'basic' | 'pro' | 'agency' | null
  /** Message to show at the top of the dialog (e.g., the 403 error message). */
  reasonMessage?: string
  /** Called after a successful upgrade in demo mode so the caller can refetch state. */
  onUpgraded?: () => void
}

const tierIcons: Record<string, React.ElementType> = {
  basic: Zap,
  pro: Sparkles,
  agency: InfinityIcon,
}

export function UpgradeDialog({
  open,
  onOpenChange,
  suggestedTier,
  reasonMessage,
  onUpgraded,
}: UpgradeDialogProps) {
  const [plans, setPlans] = useState<PlanInfo[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [checkoutTier, setCheckoutTier] = useState<string | null>(null)
  const [checkoutGateway, setCheckoutGateway] = useState<Gateway | null>(null)
  const [demoMode, setDemoMode] = useState(false)
  const [paypalConfigured, setPaypalConfigured] = useState(false)
  const [payeerConfigured, setPayeerConfigured] = useState(false)

  useEffect(() => {
    if (!open) return
    let cancelled = false
    setIsLoading(true)
    Promise.all([
      fetch('/api/stripe/config', { cache: 'no-store' }).then((r) => r.json()),
      fetch('/api/paypal/config', { cache: 'no-store' }).then((r) => r.json()).catch(() => ({ configured: false })),
      fetch('/api/payeer/config', { cache: 'no-store' }).then((r) => r.json()).catch(() => ({ configured: false })),
    ])
      .then(([stripeData, paypalData, payeerData]) => {
        if (cancelled) return
        setPlans(stripeData.plans || [])
        setDemoMode(!!stripeData.demoMode)
        setPaypalConfigured(!!paypalData.configured)
        setPayeerConfigured(!!payeerData.configured)
      })
      .catch((e) => {
        console.error('Failed to load plan config:', e)
        toast.error('Failed to load plans')
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [open])

  const handleCheckout = async (tier: string, gateway: Gateway = 'stripe') => {
    setCheckoutTier(tier)
    setCheckoutGateway(gateway)
    try {
      const endpoint =
        gateway === 'stripe' ? '/api/stripe/checkout' :
        gateway === 'paypal' ? '/api/paypal/checkout' :
        '/api/payeer/checkout'

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tier }),
      })
      const data = await res.json()
      if (!res.ok) {
        throw new Error(data.error || `HTTP ${res.status}`)
      }

      if (data.demo) {
        toast.success('Demo upgrade complete', {
          description: data.message || `Upgraded to ${tier} via ${gateway}.`,
        })
        onUpgraded?.()
        onOpenChange(false)
        return
      }

      if (gateway === 'paypal' && data.approvalUrl) {
        try {
          sessionStorage.setItem('pendingPaypalOrder', JSON.stringify({ orderId: data.orderId, tier }))
        } catch { /* sessionStorage may be unavailable */ }
        window.location.href = data.approvalUrl
        return
      }

      if (data.url) {
        // Stripe Checkout or Payeer redirect
        window.location.href = data.url
      }
    } catch (e) {
      toast.error(`${gateway} checkout failed`, {
        description: e instanceof Error ? e.message : 'Unknown error',
      })
    } finally {
      setCheckoutTier(null)
      setCheckoutGateway(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Upgrade Your Plan
          </DialogTitle>
          <DialogDescription>
            {reasonMessage ||
              'Choose a plan that fits your content needs. Pay with Stripe, PayPal, or Payeer.'}
          </DialogDescription>
        </DialogHeader>

        {demoMode && (
          <div className="p-3 rounded-md bg-amber-500/5 border border-amber-500/20 flex items-start gap-2">
            <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 dark:text-amber-300">
              Demo mode: at least one gateway is not configured. Upgrading will grant credits locally.
              Configure <code className="font-mono">STRIPE_SECRET_KEY</code>,
              <code className="font-mono ml-1">PAYPAL_CLIENT_ID</code> /
              <code className="font-mono ml-1">PAYPAL_CLIENT_SECRET</code>, or
              <code className="font-mono ml-1">PAYEER_MERCHANT_ID</code> /
              <code className="font-mono ml-1">PAYEER_SECRET_KEY</code> in <code className="font-mono ml-1">.env</code> for live payments.
            </p>
          </div>
        )}

        {/* Plans grid */}
        {isLoading ? (
          <div className="grid sm:grid-cols-3 gap-3 py-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-64 rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid sm:grid-cols-3 gap-3 py-2">
            {plans.map((plan) => {
              const isSuggested = suggestedTier === plan.tier
              const Icon = tierIcons[plan.tier] || Zap
              const isBusy = checkoutTier === plan.tier
              return (
                <Card
                  key={plan.tier}
                  className={`relative transition-all ${
                    isSuggested
                      ? 'border-primary border-2 shadow-sm'
                      : 'border-border/50 hover:border-primary/30'
                  }`}
                >
                  <CardContent className="p-4 flex flex-col h-full">
                    {isSuggested && (
                      <div className="absolute -top-2 left-1/2 -translate-x-1/2">
                        <Badge className="text-[10px] bg-primary text-primary-foreground">
                          Recommended
                        </Badge>
                      </div>
                    )}

                    <div
                      className="h-9 w-9 rounded-lg flex items-center justify-center mb-2"
                      style={{ backgroundColor: `${plan.accent}15`, color: plan.accent }}
                    >
                      <Icon className="h-5 w-5" />
                    </div>

                    <h3 className="text-base font-bold">{plan.label}</h3>
                    <div className="flex items-baseline gap-1 mt-0.5">
                      <span className="text-xl font-bold">${plan.priceUsd}</span>
                      <span className="text-[10px] text-muted-foreground">/mo</span>
                    </div>

                    <div className="mt-2 flex items-center gap-1.5 text-xs">
                      <Coins className="h-3 w-3 text-primary" />
                      <span className="font-medium">
                        {plan.credits === null ? (
                          <span className="flex items-center gap-1">
                            <InfinityIcon className="h-3 w-3" />
                            Unlimited
                          </span>
                        ) : (
                          `${plan.credits} credits/mo`
                        )}
                      </span>
                    </div>

                    <p className="text-[11px] text-muted-foreground mt-2 flex-1">{plan.blurb}</p>

                    {/* Primary Stripe button */}
                    <Button
                      size="sm"
                      className="w-full mt-3"
                      variant={isSuggested ? 'default' : 'outline'}
                      disabled={isBusy}
                      onClick={() => handleCheckout(plan.tier, 'stripe')}
                    >
                      {isBusy && checkoutGateway === 'stripe' ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <CreditCard className="h-3.5 w-3.5 mr-1.5" />
                          Pay with Stripe
                        </>
                      )}
                    </Button>

                    {/* PayPal + Payeer — secondary */}
                    <div className="grid grid-cols-2 gap-1.5 mt-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={isBusy}
                        onClick={() => handleCheckout(plan.tier, 'paypal')}
                        className="text-[11px] h-7"
                        title={paypalConfigured ? 'Pay with PayPal' : 'PayPal in demo mode'}
                      >
                        {isBusy && checkoutGateway === 'paypal' ? (
                          <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                        ) : null}
                        PayPal
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={isBusy}
                        onClick={() => handleCheckout(plan.tier, 'payeer')}
                        className="text-[11px] h-7"
                        title={payeerConfigured ? 'Pay with Payeer' : 'Payeer in demo mode'}
                      >
                        {isBusy && checkoutGateway === 'payeer' ? (
                          <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                        ) : (
                          <ExternalLink className="h-3 w-3 mr-1" />
                        )}
                        Payeer
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}

        <DialogFooter className="flex flex-col sm:flex-row gap-2">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mr-auto">
            <Check className="h-3 w-3 text-green-500" />
            Secure payment via Stripe · PayPal · Payeer
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Maybe later
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
