import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  parsePayeerOrderId,
  verifyPayeerCallback,
  isPayeerConfigured,
} from '@/lib/payeer'
import { activateSubscription, type PlanTier } from '@/lib/stripe'

/**
 * POST /api/payeer/callback
 *
 * Payeer's status_url — receives a server-to-server POST after every
 * payment attempt (success or failure).
 *
 * The POST is form-encoded with these fields:
 *   m_shop, m_orderid, m_amount, m_curr, m_desc, m_status, m_sign
 *
 * We verify the m_sign signature, then activate the user's subscription
 * if m_status === 'success'.
 *
 * Security:
 *   - The signature is HMAC-SHA256 of "shop:order:amount:curr:desc:status:key"
 *     with the server-side PAYEER_SECRET_KEY. Without the key, an attacker
 *     cannot forge a valid callback.
 *   - We also look up the user from the m_orderid (which encodes userId +
 *     tier at creation time) so we don't trust any user-supplied user id.
 *
 * Response:
 *   Payeer expects a literal "OK" response body (without quotes) on success.
 *   Any other response triggers Payeer to retry the callback.
 */
export async function POST(request: Request) {
  // Parse form-encoded body
  const formText = await request.text()
  const params = new URLSearchParams(formText)
  const form = {
    m_shop: params.get('m_shop') || undefined,
    m_orderid: params.get('m_orderid') || undefined,
    m_amount: params.get('m_amount') || undefined,
    m_curr: params.get('m_curr') || undefined,
    m_desc: params.get('m_desc') || undefined,
    m_status: params.get('m_status') || undefined,
    m_sign: params.get('m_sign') || undefined,
  }

  // ─── Demo mode ──────────────────────────────────────────────────────
  // Without Payeer credentials, we can't verify the signature — return
  // a non-OK response so Payeer retries (or in tests, returns an error).
  if (!isPayeerConfigured()) {
    console.warn('[payeer/callback] received callback but Payeer is not configured')
    return new NextResponse('Payeer not configured', { status: 503 })
  }

  // ─── Verify signature ───────────────────────────────────────────────
  const verification = verifyPayeerCallback(form)
  if (!verification.valid) {
    console.error('[payeer/callback] signature verification failed:', verification.reason, { form })
    return new NextResponse('BAD SIGNATURE', { status: 400 })
  }

  // ─── Parse order id → { userId, tier } ──────────────────────────────
  const { userId, tier } = parsePayeerOrderId(form.m_orderid!)
  if (!userId || !tier) {
    console.error('[payeer/callback] could not parse orderId', { orderId: form.m_orderid })
    return new NextResponse('BAD ORDER ID', { status: 400 })
  }

  // ─── Idempotency: skip if subscription is already active ────────────
  // Payeer retries callbacks up to 16 times if we don't return OK. We
  // need to make sure we don't double-grant credits on retries.
  const existing = await db.subscription.findUnique({ where: { userId } })
  if (existing && existing.plan === tier && existing.status === 'active') {
    return new NextResponse('OK', { status: 200 })
  }

  // ─── Activate subscription ──────────────────────────────────────────
  if (form.m_status === 'success') {
    const result = await activateSubscription({
      userId,
      tier: tier as PlanTier,
      gateway: 'payeer',
      externalId: form.m_orderid,
    })

    if (!result.ok) {
      console.error('[payeer/callback] activation failed:', result.error)
      // Return non-OK so Payeer retries — but only for transient errors
      return new NextResponse('ACTIVATION FAILED', { status: 500 })
    }

    console.info(`[payeer/callback] activated ${tier} for user ${userId} (order ${form.m_orderid})`)
    return new NextResponse('OK', { status: 200 })
  }

  // m_status !== 'success' — payment failed. Acknowledge so Payeer
  // doesn't retry, but don't activate the subscription.
  console.warn(`[payeer/callback] payment status '${form.m_status}' for order ${form.m_orderid}`)
  return new NextResponse('OK', { status: 200 })
}

// Payeer sends form-encoded data, not JSON — disable body parsing
export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
