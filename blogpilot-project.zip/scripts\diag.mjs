// Diagnostics for WP E2E connectivity
(async () => {
  const auth = 'Basic ' + Buffer.from('blogpilot-tester:abcd efgh ijkl mnop').toString('base64');

  // 1) Mock alive?
  const root = await fetch('http://localhost:4310/wp-json').then(r => ({ s: r.status, j: r.json() }));
  console.log('mock /wp-json:', root.s);

  // 2) Direct auth against mock
  const me = await fetch('http://localhost:4310/wp-json/wp/v2/users/me', { headers: { Authorization: auth } });
  console.log('direct users/me:', me.status);

  // 3) Validator behavior with allowlist
  process.env.SSRF_ALLOWLIST = 'localhost,127.0.0.1';
  const { validateFetchUrl } = await import('../src/lib/url-validator.ts');
  const v = await validateFetchUrl('http://localhost:4310');
  console.log('validateFetchUrl(allowlisted localhost):', JSON.stringify(v));
})().catch(e => console.error('DIAG ERR:', e.message));
