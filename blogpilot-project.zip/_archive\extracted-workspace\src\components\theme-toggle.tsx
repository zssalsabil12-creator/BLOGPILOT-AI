'use client';

import { useTheme } from 'next-themes';
import { Moon, Sun } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ThemeToggle() {
  const { theme, setTheme, resolvedTheme, systemTheme } = useTheme();
  const current = theme === 'system' ? (systemTheme || 'dark') : theme;

  const toggle = () => {
    if (current === 'dark') {
      setTheme('light');
    } else {
      setTheme('dark');
    }
  };

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label="Toggle dark mode"
      className={cn(
        'inline-flex h-9 w-9 items-center justify-center rounded-2xl border border-slate-700 bg-slate-950 text-slate-100 transition hover:border-cyan-400 hover:text-cyan-400',
      )}
    >
      {current === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </button>
  );
}
