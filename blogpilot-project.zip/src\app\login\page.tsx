'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Sparkles, ArrowLeft, Mail, Lock, Zap, Globe, ShieldCheck, TrendingUp } from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { GoogleSignInButton, AuthDivider } from '@/components/auth/google-signin-button';

const GOOGLE_ERRORS: Record<string, string> = {
  google_denied: 'Google sign-in was cancelled.',
  google_not_configured: 'Google sign-in is not configured yet.',
  google_rate_limited: 'Too many attempts. Please try again later.',
  google_state_mismatch: 'Sign-in session expired. Please try again.',
  google_email_unverified: 'Your Google email is not verified.',
  google_invalid_response: 'Invalid response from Google.',
  google_error: 'Google sign-in failed.',
  google_signin_failed: 'Could not sign in with Google. Please try again.',
};

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const login = useAppStore(s => s.login);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const googleError = params.get('error');
    if (googleError) {
      setError(GOOGLE_ERRORS[googleError] || 'Sign-in failed. Please try again.');
      window.history.replaceState({}, '', '/login');
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Login failed.');
      } else {
        if (data?.user) {
          login(data.user);
        }
        window.location.href = '/dashboard';
      }
    } catch (err: any) {
      setError(err?.message || 'Network error.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen bg-background">
      <div className="aurora opacity-70" />

      {/* Back link */}
      <div className="absolute left-4 top-4 z-20">
        <Button variant="ghost" size="sm" asChild className="text-muted-foreground hover:text-foreground">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Link>
        </Button>
      </div>

      {/* Brand panel (desktop) */}
      <div className="relative hidden w-[46%] flex-col justify-between overflow-hidden border-r border-border/60 p-10 lg:flex">
        <div className="pointer-events-none absolute inset-0 dot-texture opacity-40" />
        <div className="pointer-events-none absolute -left-24 top-1/4 h-96 w-96 rounded-full bg-cyan-500/12 blur-[120px]" />
        <div className="pointer-events-none absolute -right-16 bottom-0 h-80 w-80 rounded-full bg-violet-600/14 blur-[110px]" />

        <Link href="/" className="relative z-10 flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30 ring-1 ring-inset ring-white/25">
            <Sparkles className="h-4.5 w-4.5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight">
            BlogPilot <span className="text-gradient">AI</span>
          </span>
        </Link>

        <div className="relative z-10 max-w-md">
          <h2 className="tracking-display text-4xl font-extrabold leading-[1.12] text-balance">
            Write content that <span className="text-gradient">outranks</span> the competition.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            Research competitors, generate long-form SEO articles, and publish straight
            to your blog — all from one powerful dashboard.
          </p>

          <ul className="mt-8 space-y-4">
            {[
              { icon: Zap, title: 'One-click generation', desc: 'Full articles with headings, meta and internal links' },
              { icon: Globe, title: 'Direct publishing', desc: 'WordPress & Blogger integrations built-in' },
              { icon: TrendingUp, title: 'Competitor insights', desc: 'See what ranks and write something better' },
              { icon: ShieldCheck, title: 'Bank-grade security', desc: 'Encrypted credentials, verified sessions' },
            ].map((f) => (
              <li key={f.title} className="flex items-start gap-3">
                <span className="icon-tile mt-0.5 size-9 shrink-0">
                  <f.icon className="size-4" />
                </span>
                <div>
                  <p className="text-sm font-semibold">{f.title}</p>
                  <p className="text-xs text-muted-foreground">{f.desc}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative z-10 text-xs text-muted-foreground/70">
          © {new Date().getFullYear()} BlogPilot AI — All rights reserved.
        </p>
      </div>

      {/* Form panel */}
      <div className="relative z-10 flex flex-1 items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          <div className="mb-8 flex flex-col items-center lg:hidden">
            <Link href="/" className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30 ring-1 ring-inset ring-white/25">
              <Sparkles className="h-6 w-6 text-white" />
            </Link>
            <h1 className="tracking-display text-2xl font-bold">Welcome back</h1>
            <p className="mt-1 text-sm text-muted-foreground">Sign in to your BlogPilot AI account</p>
          </div>

          <div className="hidden mb-8 lg:block">
            <h1 className="tracking-display text-3xl font-bold">Welcome back</h1>
            <p className="mt-1 text-sm text-muted-foreground">Sign in to continue to your workspace</p>
          </div>

          <Card className="card-premium overflow-hidden rounded-2xl">
            <CardContent className="p-7 pt-7">
              <GoogleSignInButton label="Continue with Google" />
              <AuthDivider />
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="you@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-11 rounded-xl pl-10"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-11 rounded-xl pl-10"
                      required
                    />
                  </div>
                </div>

                {error && (
                  <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                    {error}
                  </p>
                )}

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="h-11 w-full rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/25 transition hover:shadow-cyan-400/40"
                >
                  {isLoading ? (
                    <span className="inline-flex items-center gap-2">
                      <span className="size-4 animate-spin rounded-full border-2 border-slate-900/40 border-t-slate-900" />
                      Signing in...
                    </span>
                  ) : (
                    'Sign in'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Don&apos;t have an account?{' '}
            <Link href="/signup" className="font-medium text-primary hover:underline">
              Create one free
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
