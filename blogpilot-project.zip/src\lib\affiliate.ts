/**
 * Affiliate Growth Engine.
 *
 * Campaign management, tracked-link generation (real click counting via a
 * redirect endpoint), contextual insertion into articles with anchor
 * variation, and broken-link scanning. Conversions/revenue are NOT
 * fabricated — they appear only when a network API is wired in later.
 */

import prisma from '@/lib/prisma';
import { APP_URL } from '@/lib/env';
import { validateFetchUrl } from './url-validator';

export interface CampaignStats {
  campaignId: string;
  name: string;
  productName: string;
  isActive: boolean;
  linkCount: number;
  clicks30d: number;
  clicksTotal: number;
  lastClickAt: string | null;
}

function normalizeUrl(urlStr: string): string {
  try {
    const u = new URL(urlStr);
    u.hash = '';
    return u.toString();
  } catch {
    return urlStr.trim();
  }
}

/** The tracking redirect URL that counts real clicks before hopping to the merchant. */
export function trackedUrlFor(linkId: string): string {
  return `${APP_URL.replace(/\/+$/, '')}/api/aff/${linkId}`;
}

export async function createCampaign(userId: string, data: {
  name: string;
  productName: string;
  affiliateUrl: string;
  merchantUrl?: string | null;
  network?: string | null;
  commission?: string | null;
  country?: string | null;
  intent?: string | null;
  targetAudience?: string | null;
}): Promise<{ campaign: any; linkId: string; trackedUrl: string }> {
  // Upsert a Link record for the affiliate URL so tracking + safety checks
  // integrate with the existing link infrastructure.
  const normalized = normalizeUrl(data.affiliateUrl);
  let link = await prisma.link.findUnique({
    where: { userId_urlNormalized: { userId, urlNormalized: normalized } },
  });

  if (!link) {
    link = await prisma.link.create({
      data: {
        userId,
        url: data.affiliateUrl,
        urlNormalized: normalized,
        title: data.productName,
        linkType: 'AFFILIATE',
        affiliate: true,
        targetKeyword: data.productName.toLowerCase(),
      },
    });
  }

  const campaign = await prisma.affiliateCampaign.create({
    data: {
      userId,
      name: data.name,
      productName: data.productName,
      affiliateUrl: data.affiliateUrl,
      merchantUrl: data.merchantUrl || null,
      network: data.network || null,
      commission: data.commission || null,
      country: data.country || null,
      intent: data.intent || 'commercial',
      targetAudience: data.targetAudience || null,
      links: { connect: [{ id: link.id }] },
    },
  });

  await prisma.link.update({ where: { id: link.id }, data: { campaignId: campaign.id } });

  return { campaign, linkId: link.id, trackedUrl: trackedUrlFor(link.id) };
}

export async function listCampaignsWithStats(userId: string): Promise<CampaignStats[]> {
  const since = new Date(Date.now() - 30 * 24 * 3600 * 1000);
  const campaigns = await prisma.affiliateCampaign.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    include: {
      _count: { select: { links: true } },
      clicks: { select: { createdAt: true } },
    },
  });

  return campaigns.map(c => {
    const total = c.clicks.length;
    const last30 = c.clicks.filter(k => k.createdAt >= since).length;
    const lastClick = c.clicks.reduce<Date | null>(
      (acc, k) => (!acc || k.createdAt > acc ? k.createdAt : acc), null,
    );
    return {
      campaignId: c.id,
      name: c.name,
      productName: c.productName,
      isActive: c.isActive,
      linkCount: c._count.links,
      clicks30d: last30,
      clicksTotal: total,
      lastClickAt: lastClick ? lastClick.toISOString() : null,
    };
  });
}

/**
 * Contextual insertion of the tracked affiliate link into an article.
 * Anchor variation rotates across natural CTA patterns to avoid footprint.
 */
const ANCHOR_PATTERNS = [
  (p: string) => `Check price of ${p}`,
  (p: string) => `See ${p} details`,
  (p: string) => `${p} — current deal`,
  (p: string) => `View ${p} availability`,
];

export async function insertCampaignLink(
  userId: string,
  campaignId: string,
  articleId: string,
): Promise<{ applied: boolean; anchor: string; placementParagraph: number }> {
  const campaign = await prisma.affiliateCampaign.findFirst({
    where: { id: campaignId, userId },
    include: { links: true },
  });
  if (!campaign) throw Object.assign(new Error('Campaign not found'), { statusCode: 404 });
  if (!campaign.isActive) throw Object.assign(new Error('Campaign is inactive'), { statusCode: 409 });

  const article = await prisma.article.findFirst({
    where: { id: articleId, userId },
    select: { id: true, title: true, content: true, siteId: true },
  });
  if (!article) throw Object.assign(new Error('Article not found'), { statusCode: 404 });

  const link = campaign.links[0];
  if (!link) throw Object.assign(new Error('Campaign has no tracking link'), { statusCode: 409 });
  const trackedHref = trackedUrlFor(link.id);

  // Skip if this tracked URL is already in the content.
  if ((article.content || '').includes(trackedHref)) {
    return { applied: false, anchor: '', placementParagraph: -1 };
  }

  // Snapshot before mutating so the insertion is reversible.
  await import('./content-versions').then(v =>
    v.snapshotVersion(userId, article.id, 'before-affiliate-insert')
  );

  const productLower = campaign.productName.toLowerCase();
  const paragraphs = (article.content || '').split(/\n{2,}/);

  // Best paragraph = most overlap with product name tokens.
  const prodTokens = productLower.split(/\s+/).filter(w => w.length > 3);
  let bestIdx = Math.min(1, paragraphs.length - 1);
  let bestScore = 0;
  paragraphs.forEach((p, i) => {
    if (p.startsWith('#') || p.startsWith('|')) return;
    const lower = p.toLowerCase();
    const score = prodTokens.reduce((s, t) => s + (lower.includes(t) ? 1 : 0), 0);
    if (score > bestScore) { bestScore = score; bestIdx = i; }
  });

  // Anchor variation based on existing insertion count for this campaign.
  const priorInsertions = (article.content || '').split(trackedHref).length - 1;
  const pattern = ANCHOR_PATTERNS[priorInsertions % ANCHOR_PATTERNS.length];
  const anchor = pattern(campaign.productName);

  const sentence = `\n\n**${anchor}:** [${trackedHref}](${trackedHref})`;
  if (bestScore > 0 && bestIdx < paragraphs.length) {
    paragraphs[bestIdx] += sentence;
  } else {
    paragraphs.push(sentence.trim());
  }

  await prisma.article.update({
    where: { id: article.id },
    data: { content: paragraphs.join('\n\n') },
  });

  await import('./agent-governance').then(g =>
    g.logActivity({
      userId,
      agent: 'affiliate',
      action: 'insert-affiliate-link',
      targetType: 'article',
      targetId: article.id,
      targetLabel: article.title,
      reason: `Campaign "${campaign.name}" — contextual match at paragraph ${bestIdx + 1}.`,
      afterState: { anchor, campaignId },
    }),
  );

  return { applied: true, anchor, placementParagraph: bestIdx };
}

export interface BrokenLinkReport {
  linkId: string;
  url: string;
  status: 'ok' | 'error' | 'blocked' | 'skipped';
  httpStatus?: number;
  detail?: string;
}

/** Scans active affiliate links and updates safety/active state honestly. */
export async function scanAffiliateLinks(userId: string): Promise<BrokenLinkReport[]> {
  const links = await prisma.link.findMany({
    where: { userId, affiliate: true, active: true },
    select: { id: true, url: true, active: true },
    take: 50,
  });

  const reports: BrokenLinkReport[] = [];

  for (const link of links) {
    const check = await validateFetchUrl(link.url);
    if (!check.ok) {
      reports.push({ linkId: link.id, url: link.url, status: 'skipped', detail: check.error });
      continue;
    }
    try {
      const res = await fetch(link.url, {
        method: 'HEAD',
        redirect: 'follow',
        signal: AbortSignal.timeout(10_000),
        headers: { 'User-Agent': 'Mozilla/5.0 (compatible; BlogPilotBot/1.0)' },
      });
      const ok = res.status < 400;
      reports.push({ linkId: link.id, url: link.url, status: ok ? 'ok' : 'error', httpStatus: res.status });
      await prisma.link.update({
        where: { id: link.id },
        data: {
          safetyStatus: ok ? 'SAFE' : 'UNSAFE',
          safetyReason: ok ? null : `HTTP ${res.status} on ${new Date().toISOString()}`,
          active: ok ? link.active : false,
        },
      });
    } catch (err: any) {
      reports.push({ linkId: link.id, url: link.url, status: 'error', detail: err?.message?.slice(0, 120) });
      await prisma.link.update({
        where: { id: link.id },
        data: { safetyStatus: 'REVIEW', safetyReason: `Unreachable: ${err?.message?.slice(0, 80)}` },
      });
    }
  }

  return reports;
}
