﻿import { NextResponse } from 'next/server';
import { exchangeCode } from '@/lib/google-oauth';
import prisma from '@/lib/prisma';
import crypto from 'node:crypto';
import { apiError } from '@/lib/utils';
import { encrypt } from '@/lib/encryption';

function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error('AUTH_SECRET is required');
  return secret;
}

function verifyStateSig(payload: string, sig: string): boolean {
  const hmac = crypto.createHmac('sha256', getAuthSecret());
  hmac.update(payload);
  const expected = hmac.digest('base64url');
  try {
    return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  const error = url.searchParams.get('error');

  if (error) {
    return NextResponse.redirect(new URL(`/dashboard?tab=opportunities&google=error&msg=${encodeURIComponent('oauth_error')}`, req.url));
  }

  if (!code || !state) {
    return NextResponse.redirect(new URL('/dashboard?tab=opportunities&google=error&msg=missing_params', req.url));
  }

  let userId: string;
  try {
    const dotIdx = state.indexOf('.');
    if (dotIdx === -1) throw new Error('Missing signature');

    const payload = state.substring(0, dotIdx);
    const sig = state.substring(dotIdx + 1);
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString());

    if (!decoded.userId || !decoded.ts || Date.now() - decoded.ts > 600_000) {
      throw new Error('Invalid or expired state');
    }
    if (!verifyStateSig(payload, sig)) {
      throw new Error('Invalid state signature');
    }

    userId = decoded.userId;
  } catch {
    return NextResponse.redirect(new URL('/dashboard?tab=opportunities&google=error&msg=invalid_state', req.url));
  }

  try {
    const tokens = await exchangeCode(code);

    const existing = await prisma.googleToken.findFirst({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });

    if (existing) {
      await prisma.googleToken.update({
        where: { id: existing.id },
        data: {
          accessToken: encrypt(tokens.accessToken),
          refreshToken: encrypt(tokens.refreshToken),
          googleEmail: tokens.email,
          expiresAt: new Date(Date.now() + tokens.expiresIn * 1000),
          scope: 'blogger,searchconsole',
          services: 'blogger,searchconsole',
          status: 'connected',
          isActive: true,
          lastRefreshedAt: new Date(),
        },
      });
    } else {
      await prisma.googleToken.create({
        data: {
          userId,
          accessToken: encrypt(tokens.accessToken),
          refreshToken: encrypt(tokens.refreshToken),
          googleEmail: tokens.email,
          expiresAt: new Date(Date.now() + tokens.expiresIn * 1000),
          scope: 'blogger,searchconsole',
          services: 'blogger,searchconsole',
          status: 'connected',
          lastRefreshedAt: new Date(),
        },
      });
    }

    return NextResponse.redirect(new URL('/dashboard?tab=opportunities&google=connected', req.url));
  } catch (err) {
    console.error('Google OAuth callback error:', err);
    return NextResponse.redirect(new URL(`/dashboard?tab=opportunities&google=error&msg=${encodeURIComponent('oauth_exchange_failed')}`, req.url));
  }
}
