import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { checkRateLimit } from '@/lib/rate-limit';
import { generateCampaignIdeas } from '@/lib/affiliate-ideas';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  const limit = await checkRateLimit(`camp-ideas:${userId}`, { windowMs: 60_000, maxRequests: 6 });
  if (!limit.allowed) {
    return NextResponse.json({ ok: false, error: 'Too many requests — try again in a minute.' }, { status: 429 });
  }

  try {
    const campaign = await prisma.affiliateCampaign.findFirst({
      where: { id, userId },
      select: { productName: true, targetAudience: true, country: true, intent: true },
    });
    if (!campaign) return NextResponse.json({ ok: false, error: 'Campaign not found' }, { status: 404 });

    const ideas = await generateCampaignIdeas(campaign);
    return NextResponse.json({ ok: true, data: ideas });
  } catch (error: any) {
    console.error('Campaign ideas error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to generate content cluster' }, { status: 502 });
  }
}
