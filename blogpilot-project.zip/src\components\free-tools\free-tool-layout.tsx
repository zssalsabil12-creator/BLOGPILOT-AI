import React from 'react';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

interface FreeToolLayoutProps {
  children: React.ReactNode;
  backHref?: string;
  backLabel?: string;
}

export function FreeToolLayout({
  children,
  backHref = '/free-tools',
  backLabel = 'All Free Tools',
}: FreeToolLayoutProps) {
  return (
    <div className="-mx-4 px-4 py-4 md:-mx-8 md:px-8 md:py-6">
      <Link
        href={backHref}
        className="group mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/50 px-4 py-2 text-sm text-muted-foreground transition hover:bg-card hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4 transition group-hover:-translate-x-0.5" />
        {backLabel}
      </Link>
      {children}
    </div>
  );
}
