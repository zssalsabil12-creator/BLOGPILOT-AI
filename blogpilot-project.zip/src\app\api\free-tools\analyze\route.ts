﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import { analyzeQuery } from '../../../../lib/analyzer';
import { getCurrentUserId } from '../../../../lib/auth';
import { validateFetchUrl } from '@/lib/url-validator';
import { apiError } from '@/lib/utils';
import { checkTextLength, checkUrlLength } from '@/lib/input-limits';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';

const bodySchema = z.object({
  input: z.string().min(2),
  type: z.enum(['keyword', 'article', 'website']).default('keyword'),
  numResults: z.number().min(3).max(20).optional(),
});

export async function POST(req: Request) {
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`analyzer:${ip}`, RATE_LIMITS.publicAnalyzer);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Rate limit exceeded', retryAfter: Math.ceil((rl.resetAt - Date.now()) / 1000) },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch (err) {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const parse = bodySchema.safeParse(body);
  if (!parse.success) return NextResponse.json({ error: 'Invalid input', details: parse.error.flatten() }, { status: 400 });

  const { input, numResults, type } = parse.data;

  const inputSizeCheck = type === 'keyword' ? checkTextLength(input, 5000) : checkUrlLength(input);
  if (!inputSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: inputSizeCheck.error }, { status: 413 });
  }

  try {
    const userId = getCurrentUserId(req);
    const opts: any = { numResults, userId };
    if (type && type !== 'keyword') {
      const urlCheck = await validateFetchUrl(input);
      if (!urlCheck.ok) {
        return NextResponse.json({ error: urlCheck.error }, { status: 400 });
      }
      opts.userUrl = input;
    }
    const report = await analyzeQuery(input, opts);
    return NextResponse.json({ ok: true, report });
  } catch (err) {
    return apiError('free-tools/analyze', err);
  }
}

