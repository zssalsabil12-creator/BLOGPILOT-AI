'use client'

import { useAppStore } from '@/lib/store'
import { LandingPage } from '@/components/landing/landing-page'

export default function Home() {
  return <LandingPage />
}
