import { NextResponse } from 'next/server';
import { z } from 'zod';
import { validateFetchUrl } from '@/lib/url-validator';
import { apiError } from '@/lib/utils';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { checkUrlLength } from '@/lib/input-limits';

const bodySchema = z.object({
  url: z.string().url().max(2048),
});

const MAX_HOPS = 10;

function statusType(status: number): string {
  if (status === 301) return '301 Moved Permanently';
  if (status === 302) return '302 Found';
  if (status === 303) return '303 See Other';
  if (status === 307) return '307 Temporary Redirect';
  if (status === 308) return '308 Permanent Redirect';
  return `${status}`;
}

function detectMetaRefresh(html: string): string | null {
  const match = html.match(
    /<meta[^>]+http-equiv\s*=\s*["']?refresh["']?[^>]*content\s*=\s*["']?\d+\s*;\s*url\s*=\s*([^"'\s>]+)/i
  );
  return match ? match[1] : null;
}

export async function POST(req: Request) {
  // Public endpoint — throttle per IP before any outbound work.
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`free-tool:${ip}`, RATE_LIMITS.publicApi);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait a moment and try again.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const parse = bodySchema.safeParse(body);
  if (!parse.success) {
    return NextResponse.json(
      { error: 'Invalid input', details: parse.error.flatten() },
      { status: 400 }
    );
  }

  const urlSizeCheck = checkUrlLength(parse.data.url);
  if (!urlSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: urlSizeCheck.error }, { status: 413 });
  }

  const chain: { url: string; status: number; location?: string; type: string }[] = [];
  let currentUrl = parse.data.url;
  let hops = 0;

  try {
    const urlCheck = await validateFetchUrl(currentUrl);
    if (!urlCheck.ok) {
      return NextResponse.json({ error: urlCheck.error }, { status: 400 });
    }
    while (hops < MAX_HOPS) {
      const hopCheck = await validateFetchUrl(currentUrl);
      if (!hopCheck.ok) {
        chain.push({ url: currentUrl, status: 0, type: `Blocked: ${hopCheck.error}` });
        break;
      }
      const res = await fetch(currentUrl, {
        redirect: 'manual',
        headers: {
          'User-Agent':
            'Mozilla/5.0 (compatible; RedirectChecker/1.0)',
          Accept: 'text/html,application/xhtml+xml,*/*',
        },
        signal: AbortSignal.timeout(10000),
      });

      const status = res.status;
      const location = res.headers.get('location') || undefined;

      if (status >= 300 && status < 400 && location) {
        chain.push({
          url: currentUrl,
          status,
          location,
          type: statusType(status),
        });

        const nextUrl = new URL(location, currentUrl);
        currentUrl = nextUrl.href;
        hops++;
        continue;
      }

      if (status >= 200 && status < 400) {
        const contentType = res.headers.get('content-type') || '';
        if (contentType.includes('text/html') || contentType.includes('xhtml')) {
          const text = await res.text();
          const metaRefreshUrl = detectMetaRefresh(text);
          if (metaRefreshUrl) {
            chain.push({
              url: currentUrl,
              status,
              location: metaRefreshUrl,
              type: 'Meta Refresh',
            });
            try {
              currentUrl = new URL(metaRefreshUrl, currentUrl).href;
              hops++;
              continue;
            } catch {
              break;
            }
          }
        }
      }

      chain.push({ url: currentUrl, status, type: statusType(status) });
      break;
    }

    return NextResponse.json({
      ok: true,
      chain,
      finalUrl: currentUrl,
      totalHops: chain.length - 1,
      hasRedirect: chain.length > 1 && chain[0].status >= 300 && chain[0].status < 400,
    });
  } catch (err) {
    if (chain.length === 0) {
      return apiError('free-tools/redirect-checker', err);
    }
    chain.push({ url: currentUrl, status: 0, type: 'Error — Could not follow redirect' });
    return NextResponse.json({
      ok: true,
      chain,
      finalUrl: currentUrl,
      totalHops: chain.length - 1,
      hasRedirect: true,
    });
  }
}
