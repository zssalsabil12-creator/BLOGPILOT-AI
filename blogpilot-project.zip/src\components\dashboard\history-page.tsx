'use client'
import { useEffect, useState, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Search, Grid3X3, List, Edit3, Trash2, Copy, FileText, Clock, CheckCircle, Calendar, Eye, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '@/lib/store'

interface HistoryArticle {
  id: string
  title: string
  status: 'published' | 'draft' | 'scheduled'
  wordCount: number
  seoScore: number
  createdAt: string
  slug: string
  content: string
}

const statusConfig: Record<string, { color: string; icon: typeof CheckCircle }> = {
  published: { color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30', icon: CheckCircle },
  draft: { color: 'bg-amber-500/20 text-amber-400 border-amber-500/30', icon: FileText },
  scheduled: { color: 'bg-blue-500/20 text-blue-400 border-blue-500/30', icon: Clock },
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.3 } },
  exit: { opacity: 0, scale: 0.95, transition: { duration: 0.2 } },
}

function mapStatus(status: string): HistoryArticle['status'] {
  if (status === 'PUBLISHED') return 'published'
  if (status === 'SCHEDULED') return 'scheduled'
  return 'draft'
}

export default function HistoryPage() {
  const [articles, setArticles] = useState<HistoryArticle[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [activeFilter, setActiveFilter] = useState<'all' | 'published' | 'draft' | 'scheduled'>('all')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [visibleCount, setVisibleCount] = useState(6)

  const openEditor = useAppStore(s => s.openEditor)

  const loadArticles = useCallback(async () => {
    try {
      setLoading(true)
      const res = await fetch('/api/articles')
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to load articles')
      const list: any[] = json?.data?.articles || []
      setArticles(list.map(a => ({
        id: a.id,
        title: a.title,
        status: mapStatus(a.status),
        wordCount: a.wordCount || 0,
        seoScore: a.seoScore ?? 0,
        createdAt: a.createdAt ? a.createdAt.slice(0, 10) : '',
        slug: a.slug || '',
        content: a.content || '',
      })))
      setError(null)
    } catch (err: any) {
      console.error('Load history error:', err)
      setError(err?.message || 'Failed to load articles')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadArticles()
  }, [loadArticles])

  const deleteArticle = async (id: string) => {
    setDeletingId(id)
    try {
      const res = await fetch(`/api/articles/${id}`, { method: 'DELETE' })
      const json = await res.json()
      if (!res.ok) throw new Error(json?.error || 'Failed to delete article')
      setArticles(prev => prev.filter(a => a.id !== id))
    } catch (err: any) {
      console.error('Delete article error:', err)
      alert(err?.message || 'Failed to delete article')
    } finally {
      setDeletingId(null)
    }
  }

  const copyArticle = (article: HistoryArticle) => {
    navigator.clipboard.writeText(article.content || article.title).catch(() => {})
  }

  const filteredArticles = articles.filter((article) => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesFilter = activeFilter === 'all' || article.status === activeFilter
    return matchesSearch && matchesFilter
  })

  const displayedArticles = filteredArticles.slice(0, visibleCount)
  const hasMore = visibleCount < filteredArticles.length

  return (
    <div className="min-h-screen p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-foreground mb-2">Article History</h1>
          <p className="text-muted-foreground">Manage and review your published articles</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mb-6 space-y-4"
        >
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 border border-border bg-card/50 text-foreground placeholder:text-muted-foreground rounded-xl h-12 focus:border-primary/50 focus:ring-primary/20"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('grid')}
                className={cn(
                  "h-12 w-12 rounded-xl",
                  viewMode === 'grid'
                    ? "bg-cyan-500 hover:bg-cyan-600"
                    : "border border-border bg-card/50 hover:bg-accent text-foreground"
                )}
              >
                <Grid3X3 className="w-5 h-5" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="icon"
                onClick={() => setViewMode('list')}
                className={cn(
                  "h-12 w-12 rounded-xl",
                  viewMode === 'list'
                    ? "bg-cyan-500 hover:bg-cyan-600"
                    : "border border-border bg-card/50 hover:bg-accent text-foreground"
                )}
              >
                <List className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap">
            {(['all', 'published', 'draft', 'scheduled'] as const).map((filter) => (
              <Button
                key={filter}
                variant={activeFilter === filter ? 'default' : 'outline'}
                onClick={() => setActiveFilter(filter)}
                className={cn(
                  "rounded-xl h-10 px-4 capitalize",
                  activeFilter === filter
                    ? "bg-cyan-500 hover:bg-cyan-600"
                    : "border border-border bg-card/50 hover:bg-accent text-foreground"
                )}
              >
                {filter}
              </Button>
            ))}
          </div>
        </motion.div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
          </div>
        ) : error ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-20"
          >
            <div className="w-20 h-20 rounded-full bg-card/50 border border-border flex items-center justify-center mb-6">
              <FileText className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">Could not load articles</h3>
            <p className="text-muted-foreground mb-4">{error}</p>
            <Button
              onClick={loadArticles}
              className="bg-gradient-to-r from-cyan-500 to-violet-500 text-foreground rounded-xl"
            >
              Retry
            </Button>
          </motion.div>
        ) : displayedArticles.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-20"
          >
            <div className="w-20 h-20 rounded-full bg-card/50 border border-border flex items-center justify-center mb-6">
              <FileText className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">No articles found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
          </motion.div>
        ) : viewMode === 'grid' ? (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {displayedArticles.map((article) => {
                const statusInfo = statusConfig[article.status]
                const StatusIcon = statusInfo.icon
                return (
                  <motion.div
                    key={article.id}
                    variants={itemVariants}
                    layout
                    exit="exit"
                  >
                    <Card className="border border-border bg-card/50 rounded-3xl backdrop-blur-xl hover:bg-accent transition-all group h-full">
                      <CardContent className="p-6 flex flex-col h-full">
                        <div className="flex items-start justify-between mb-4">
                          <Badge variant="secondary" className={cn("border", statusInfo.color)}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {article.status}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{article.createdAt}</span>
                        </div>
                        <h3 className="text-lg font-semibold text-foreground mb-4 line-clamp-2 flex-grow">{article.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                          <div className="flex items-center gap-1">
                            <FileText className="w-4 h-4" />
                            <span>{article.wordCount.toLocaleString()} words</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {article.seoScore > 0
                              ? <span>SEO: {article.seoScore}/100</span>
                              : <span className="italic">Not scored yet</span>}
                          </div>
                        </div>
                        <div className="flex gap-2 pt-4 border-t border-border">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditor(article.id)}
                            className="text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl"
                          >
                            <Edit3 className="w-4 h-4 mr-1" />
                            Edit
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => copyArticle(article)}
                            className="text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl"
                          >
                            <Copy className="w-4 h-4 mr-1" />
                            Copy
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteArticle(article.id)}
                            disabled={deletingId === article.id}
                            className="text-muted-foreground hover:text-red-400 hover:bg-red-500/10 rounded-xl ml-auto"
                          >
                            {deletingId === article.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Trash2 className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </motion.div>
        ) : (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-3"
          >
            <AnimatePresence mode="popLayout">
              {displayedArticles.map((article) => {
                const statusInfo = statusConfig[article.status]
                const StatusIcon = statusInfo.icon
                return (
                  <motion.div
                    key={article.id}
                    variants={itemVariants}
                    layout
                    exit="exit"
                  >
                    <Card className="border border-border bg-card/50 rounded-2xl backdrop-blur-xl hover:bg-accent transition-all">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className="hidden sm:block">
                            <Badge variant="secondary" className={cn("border", statusInfo.color)}>
                              <StatusIcon className="w-3 h-3 mr-1" />
                              {article.status}
                            </Badge>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-sm font-semibold text-foreground truncate">{article.title}</h3>
                            <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                              <span className="flex items-center gap-1 sm:hidden">
                                <StatusIcon className="w-3 h-3" />
                                {article.status}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {article.createdAt}
                              </span>
                              <span className="hidden sm:flex items-center gap-1">
                                <FileText className="w-3 h-3" />
                                {article.wordCount.toLocaleString()} words
                              </span>
                              <span className="hidden sm:flex items-center gap-1">
                                <Eye className="w-3 h-3" />
                                {article.seoScore > 0 ? `SEO: ${article.seoScore}/100` : 'Not scored yet'}
                              </span>
                            </div>
                          </div>
                          <div className="hidden md:flex items-center gap-2 text-sm text-muted-foreground">
                            <span>{article.wordCount.toLocaleString()} words</span>
                            <span className="text-muted-foreground">|</span>
                            <span>{article.seoScore > 0 ? `SEO: ${article.seoScore}/100` : 'Not scored yet'}</span>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditor(article.id)}
                              className="h-9 w-9 text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl"
                            >
                              <Edit3 className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => copyArticle(article)}
                              className="h-9 w-9 text-muted-foreground hover:text-foreground hover:bg-accent rounded-xl"
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteArticle(article.id)}
                              disabled={deletingId === article.id}
                              className="h-9 w-9 text-muted-foreground hover:text-red-400 hover:bg-red-500/10 rounded-xl"
                            >
                              {deletingId === article.id ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Trash2 className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </AnimatePresence>
          </motion.div>
        )}

        {hasMore && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-center mt-8"
          >
            <Button
              variant="outline"
              onClick={() => setVisibleCount((prev) => prev + 6)}
              className="border border-border bg-card/50 hover:bg-accent text-foreground rounded-xl px-8"
            >
              Load More
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  )
}
