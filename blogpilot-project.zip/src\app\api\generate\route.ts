﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { generateArticleChunked } from '@/lib/article-generator';
import { getCurrentUserId } from '@/lib/auth';
import { consumeCredits, grantCreditsAtomic, InsufficientCreditsError } from '@/lib/credits';
import { checkRateLimit, RATE_LIMITS, getClientIp } from '@/lib/rate-limit';
import { apiError } from '@/lib/utils';
import { checkBodySize, checkTextLength } from '@/lib/input-limits';

const bodySchema = z.object({
  title: z.string().min(5).max(250),
  query: z.string().min(3).max(250),
  analysis: z.any().optional(),
  instructions: z.string().min(10).max(5000).optional(),
});

// Best-effort usage ledger write — never blocks or fails the request.
function recordAiUsage(
  userId: string,
  data: {
    operation: string;
    model?: string;
    requestedChars?: number;
    outputChars?: number;
    success: boolean;
    creditsCharged: number;
    durationMs: number;
    errorCode?: string;
  },
) {
  return prisma.aiUsage.create({
    data: {
      userId,
      operation: data.operation,
      model: data.model ?? null,
      requestedChars: data.requestedChars ?? null,
      outputChars: data.outputChars ?? null,
      success: data.success,
      creditsCharged: data.creditsCharged,
      durationMs: data.durationMs,
      errorCode: data.errorCode ?? null,
    },
  }).catch((e) => console.error('[generate] Failed to record AI usage:', e));
}

export async function POST(req: Request) {
  const bodySizeCheck = await checkBodySize(req, 2_097_152);
  if (!bodySizeCheck.ok) {
    return NextResponse.json({ ok: false, error: bodySizeCheck.error }, { status: 413 });
  }

  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const ip = getClientIp(req);
  const rl = await checkRateLimit(`generate:${userId}:${ip}`, RATE_LIMITS.generate);
  if (!rl.allowed) {
    return NextResponse.json(
      { ok: false, error: 'Too many requests. Please wait before generating again.' },
      { status: 429, headers: { 'Retry-After': String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } },
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch (err) {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 });
  }

  const parse = bodySchema.safeParse(body);
  if (!parse.success) {
    return NextResponse.json({ error: 'Invalid input', details: parse.error.flatten() }, { status: 400 });
  }

  const titleSizeCheck = checkTextLength(parse.data.title, 500);
  if (!titleSizeCheck.ok) {
    return NextResponse.json({ ok: false, error: titleSizeCheck.error }, { status: 413 });
  }

  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, credits: true, freeCreditsUsed: true, subscription: { select: { plan: true } } },
    });
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }
    if (user.credits <= 0) {
      return NextResponse.json({
        error: 'You have no credits left. Upgrade your plan to keep generating articles.',
        code: 'insufficient_credits',
      }, { status: 402 });
    }

    // Reserve the credit BEFORE any AI call. The conditional decrement is
    // atomic (`credits >= 1` is part of the UPDATE WHERE), so two concurrent
    // requests can never spend the same last credit and the balance can never
    // go negative.
    const isFreePlan = (user.subscription?.plan || 'free') === 'free';
    await consumeCredits(userId, 1, 'generation', {
      description: 'Article generated',
      freeUse: isFreePlan,
    });

    const startedAt = Date.now();
    let article;
    try {
      article = await generateArticleChunked({
        query: parse.data.query,
        title: parse.data.title,
        instructions: parse.data.instructions,
        analysis: parse.data.analysis ?? null,
      });
    } catch (genErr) {
      // Generation failed — give the reserved credit back so the user is not
      // charged for an incomplete operation.
      await grantCreditsAtomic(userId, 1, 'generation_refund', 'Refund: article generation failed').catch((e) =>
        console.error('[generate] Credit refund failed:', e),
      );
      await recordAiUsage(userId, {
        operation: 'article_generation',
        requestedChars: parse.data.title.length + parse.data.query.length + (parse.data.instructions?.length || 0),
        success: false,
        creditsCharged: 0,
        durationMs: Date.now() - startedAt,
        errorCode: genErr instanceof Error ? genErr.name : 'unknown',
      });
      throw genErr;
    }

    await recordAiUsage(userId, {
      operation: 'article_generation',
      model: article.model,
      requestedChars: parse.data.title.length + parse.data.query.length + (parse.data.instructions?.length || 0),
      outputChars: article.markdown.length,
      success: true,
      creditsCharged: 1,
      durationMs: Date.now() - startedAt,
    });

    return NextResponse.json({
      ok: true,
      article: article.markdown,
      meta: {
        sections: article.sections.length,
        truncated: article.truncated,
        ...(article.truncated ? { warning: 'One or more sections could not be completed within the AI output budget.' } : {}),
      },
    });
  } catch (err) {
    if (err instanceof InsufficientCreditsError) {
      return NextResponse.json({
        error: 'You have no credits left. Upgrade your plan to keep generating articles.',
        code: 'insufficient_credits',
      }, { status: 402 });
    }
    return apiError('generate', err);
  }
}
