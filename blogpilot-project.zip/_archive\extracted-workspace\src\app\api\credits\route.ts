import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, addCredits, AuthError, getPlanCreditCap, FREE_TRIAL_LIMIT } from '@/lib/auth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { topupCreditsSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

// GET /api/credits — fetch the current user's credit balance and recent transactions
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const [recentTransactions, totalUsed] = await Promise.all([
      db.creditTransaction.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
        take: 20,
      }),
      db.creditTransaction.aggregate({
        where: { userId: user.id, amount: { lt: 0 } },
        _sum: { amount: true },
      }),
    ])

    const planCap = getPlanCreditCap(user.subscription?.plan)
    const totalUsedCount = Math.abs(totalUsed._sum.amount || 0)

    return NextResponse.json({
      balance: user.credits,
      totalUsed: totalUsedCount,
      plan: user.subscription?.plan || 'free',
      planCap,
      remainingPercentage: planCap > 0 ? Math.round((user.credits / planCap) * 100) : 0,
      // Free-trial info — drives the client-side paywall UI
      freeTrial: {
        used: user.freeCreditsUsed,
        limit: FREE_TRIAL_LIMIT,
        remaining: Math.max(0, FREE_TRIAL_LIMIT - user.freeCreditsUsed),
        // True when the paywall will block the next generation. Front-end
        // uses this to switch the Generate button to "Upgrade to continue".
        exhausted: user.freeCreditsUsed >= FREE_TRIAL_LIMIT,
      },
      // True when the user has an active paid subscription — front-end uses
      // this to decide whether to show the free-trial banner at all.
      hasActiveSubscription:
        !!user.subscription &&
        (user.subscription.status === 'active' || user.subscription.status === 'trialing') &&
        user.subscription.plan !== 'free',
      subscriptionStatus: user.subscription?.status || 'inactive',
      transactions: recentTransactions.map((t) => ({
        id: t.id,
        amount: t.amount,
        reason: t.reason,
        description: t.description,
        articleId: t.articleId,
        balanceAfter: t.balanceAfter,
        createdAt: t.createdAt.toISOString(),
      })),
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'credits/list')
  }
}

// POST /api/credits — top up credits (in production this would be called after a Stripe payment)
export async function POST(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(topupCreditsSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { amount, reason = 'topup', description } = body

    const newBalance = await addCredits(
      user.id,
      amount,
      reason,
      description || `Manual top-up of ${amount} credits`
    )

    return NextResponse.json({
      balance: newBalance,
      added: amount,
      message: `Successfully added ${amount} credits`,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'credits/topup')
  }
}
