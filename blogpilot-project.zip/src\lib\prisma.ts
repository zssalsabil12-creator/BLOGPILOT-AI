import { PrismaClient } from '@prisma/client';

declare global {
  var __prisma_client: PrismaClient | undefined;
}

const prisma = global.__prisma_client || new PrismaClient();
if (process.env.NODE_ENV !== 'production') global.__prisma_client = prisma;

export default prisma;
