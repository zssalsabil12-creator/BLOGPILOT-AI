import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import { isPayeerConfigured } from '@/lib/payeer'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * GET /api/payeer/config
 *
 * Returns the public Payeer config + whether Payeer is configured.
 *
 * Response:
 *   200 {
 *     merchantId: string | null,
 *     configured: boolean,
 *     merchantUrl: string,
 *   }
 */
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    await requireUser(request)

    return NextResponse.json({
      merchantId: process.env.PAYEER_MERCHANT_ID || null,
      configured: isPayeerConfigured(),
      merchantUrl: 'https://payeer.com/merchant/',
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'payeer/config')
  }
}
