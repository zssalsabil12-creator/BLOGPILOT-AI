'use client';

import React, { useState, useCallback, useRef } from 'react';
import { FreeToolLayout } from '@/components/free-tools/free-tool-layout';
import {
  BookOpen,
  BarChart3,
  RotateCcw,
  Copy,
  Check,
  Info,
} from 'lucide-react';

interface ReadabilityResult {
  fleschReadingEase: number;
  fleschKincaidGrade: number;
  avgSentenceLength: number;
  avgWordLength: number;
  totalSentences: number;
  totalWords: number;
  totalSyllables: number;
  gradeLevel: string;
  easeDescription: string;
}

function countSyllables(word: string): number {
  const cleaned = word.toLowerCase().replace(/[^a-z]/g, '');
  if (cleaned.length === 0) return 0;
  if (cleaned.length <= 2) return 1;

  let count = 0;
  const vowels = 'aeiouy';
  let prevVowel = false;

  for (let i = 0; i < cleaned.length; i++) {
    const isVowel = vowels.includes(cleaned[i]);
    if (isVowel && !prevVowel) {
      count++;
    }
    prevVowel = isVowel;
  }

  if (cleaned.endsWith('e') && count > 1) {
    count--;
  }

  if (cleaned.endsWith('le') && cleaned.length > 2 && !vowels.includes(cleaned[cleaned.length - 3])) {
    count++;
  }

  if (count === 0) count = 1;

  return count;
}

function analyzeReadability(text: string): ReadabilityResult | null {
  const trimmed = text.trim();
  if (!trimmed) return null;

  const sentences = trimmed.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const totalSentences = sentences.length;

  const words = trimmed.split(/\s+/).filter(w => w.replace(/[^a-zA-Z]/g, '').length > 0);
  const totalWords = words.length;

  if (totalWords === 0 || totalSentences === 0) return null;

  let totalSyllables = 0;
  for (const word of words) {
    totalSyllables += countSyllables(word);
  }

  const avgSentenceLength = totalWords / totalSentences;
  const totalChars = words.reduce((sum, w) => sum + w.replace(/[^a-zA-Z]/g, '').length, 0);
  const avgWordLength = totalChars / totalWords;

  const fleschReadingEase = 206.835 - 1.015 * avgSentenceLength - 84.6 * (totalSyllables / totalWords);
  const fleschKincaidGrade = 0.39 * avgSentenceLength + 11.8 * (totalSyllables / totalWords) - 15.59;

  const clampedEase = Math.max(0, Math.min(100, Math.round(fleschReadingEase * 10) / 10));
  const clampedGrade = Math.max(0, Math.round(fleschKincaidGrade * 10) / 10);

  let easeDescription: string;
  if (clampedEase >= 90) easeDescription = 'Very Easy — Easily understood by 11-year-olds';
  else if (clampedEase >= 80) easeDescription = 'Easy — Easily understood by 12-year-olds';
  else if (clampedEase >= 70) easeDescription = 'Fairly Easy — Easily understood by 13-year-olds';
  else if (clampedEase >= 60) easeDescription = 'Standard — Easily understood by 14-15 year-olds';
  else if (clampedEase >= 50) easeDescription = 'Fairly Difficult — Easily understood by 16-17 year-olds';
  else if (clampedEase >= 30) easeDescription = 'Difficult — Easily understood by college graduates';
  else easeDescription = 'Very Difficult — Best understood by university graduates';

  let gradeLevel: string;
  if (clampedGrade <= 6) gradeLevel = 'Elementary';
  else if (clampedGrade <= 8) gradeLevel = 'Middle School';
  else if (clampedGrade <= 10) gradeLevel = 'High School';
  else if (clampedGrade <= 12) gradeLevel = 'High School Senior';
  else if (clampedGrade <= 16) gradeLevel = 'College';
  else gradeLevel = 'Post-Graduate';

  return {
    fleschReadingEase: clampedEase,
    fleschKincaidGrade: clampedGrade,
    avgSentenceLength: Math.round(avgSentenceLength * 10) / 10,
    avgWordLength: Math.round(avgWordLength * 10) / 10,
    totalSentences,
    totalWords,
    totalSyllables,
    gradeLevel,
    easeDescription,
  };
}

function ScoreCard({ label, score, color }: { label: string; score: number; color: string }) {
  return (
    <div className="rounded-xl border border-border bg-muted/50 p-4">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <div className="mt-1 flex items-baseline gap-2">
        <p className={`text-3xl font-bold ${color}`}>{score}</p>
      </div>
    </div>
  );
}

function getEaseColor(score: number): string {
  if (score > 60) return 'text-emerald-400';
  if (score >= 40) return 'text-amber-400';
  return 'text-rose-400';
}

function getEaseBg(score: number): string {
  if (score > 60) return 'bg-emerald-400/10';
  if (score >= 40) return 'bg-amber-400/10';
  return 'bg-rose-400/10';
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/50 px-3 py-1.5 text-xs text-muted-foreground transition hover:bg-card hover:text-foreground"
    >
      {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

export default function ReadabilityAnalyzerPage() {
  const [text, setText] = useState('');
  const [results, setResults] = useState<ReadabilityResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleAnalyze = useCallback(() => {
    setError(null);
    if (!text.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    const result = analyzeReadability(text);
    if (!result) {
      setError('Could not analyze the text. Make sure it contains valid sentences and words.');
      return;
    }
    setResults(result);
  }, [text]);

  const handleReset = useCallback(() => {
    setText('');
    setResults(null);
    setError(null);
    textareaRef.current?.focus();
  }, []);

  const charCount = text.length;
  const wordCountApprox = text.trim() ? text.trim().split(/\s+/).length : 0;

  const resultsText = results
    ? [
        `Flesch Reading Ease: ${results.fleschReadingEase}`,
        `Flesch-Kincaid Grade Level: ${results.fleschKincaidGrade}`,
        `Grade Level Assessment: ${results.gradeLevel}`,
        `Ease Description: ${results.easeDescription}`,
        '',
        `Average Sentence Length: ${results.avgSentenceLength} words/sentence`,
        `Average Word Length: ${results.avgWordLength} characters/word`,
        `Total Sentences: ${results.totalSentences}`,
        `Total Words: ${results.totalWords}`,
        `Total Syllables: ${results.totalSyllables}`,
      ].join('\n')
    : '';

  return (
    <FreeToolLayout>
      <div className="space-y-8">
        <section className="text-center">
          <p className="text-xs font-medium uppercase tracking-widest text-cyan-400">Free Tool</p>
          <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Readability <span className="text-gradient">Analyzer</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground">
            Analyze your text readability using the Flesch Reading Ease and Flesch-Kincaid Grade Level formulas. Understand how easy your content is to read.
          </p>
        </section>

        <section className="rounded-2xl border border-border bg-card/50 p-6 backdrop-blur-sm">
          <div className="space-y-4">
            <textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste or type your text here..."
              rows={10}
              className="w-full rounded-xl border border-border bg-muted/50 p-4 text-foreground placeholder:text-muted-foreground outline-none transition focus:border-primary/50 focus:ring-1 focus:ring-primary/30 resize-y"
            />
            <div className="flex items-center justify-between">
              <div className="text-xs text-muted-foreground">
                {charCount.toLocaleString()} chars &middot; {wordCountApprox.toLocaleString()} words
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={handleAnalyze}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-6 py-3 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:shadow-cyan-400/40 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <BookOpen className="h-4 w-4" />
                  Analyze Readability
                </button>
                {results && (
                  <button
                    onClick={handleReset}
                    className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    Reset
                  </button>
                )}
              </div>
            </div>
          </div>
          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-4 py-3 text-sm text-rose-300">
              <span>{error}</span>
            </div>
          )}
        </section>

        {results && (
          <div className="space-y-6">
            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BarChart3 className="h-5 w-5 text-cyan-300" />
                  <h2 className="text-lg font-semibold text-foreground">Readability Scores</h2>
                </div>
                <CopyButton text={resultsText} />
              </div>

              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <div className={`rounded-xl border border-border p-5 ${getEaseBg(results.fleschReadingEase)}`}>
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Flesch Reading Ease</p>
                  <div className="mt-2 flex items-baseline gap-3">
                    <p className={`text-4xl font-bold ${getEaseColor(results.fleschReadingEase)}`}>
                      {results.fleschReadingEase}
                    </p>
                    <span className="text-xs text-muted-foreground">/100</span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{results.easeDescription}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-5">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Flesch-Kincaid Grade Level</p>
                  <div className="mt-2 flex items-baseline gap-3">
                    <p className="text-4xl font-bold text-foreground">{results.fleschKincaidGrade}</p>
                    <span className="text-xs text-muted-foreground">grade level</span>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Reading level: <span className="font-medium text-foreground">{results.gradeLevel}</span>
                  </p>
                </div>
              </div>

              <div className="mt-5 grid gap-4 sm:grid-cols-3">
                <ScoreCard label="Avg Sentence Length" score={results.avgSentenceLength} color="text-foreground" />
                <ScoreCard label="Avg Word Length (chars)" score={results.avgWordLength} color="text-foreground" />
                <ScoreCard label="Total Syllables" score={results.totalSyllables} color="text-foreground" />
              </div>
            </section>

            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center gap-3">
                <Info className="h-5 w-5 text-violet-300" />
                <h2 className="text-lg font-semibold text-foreground">Text Statistics</h2>
              </div>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                <div className="rounded-xl border border-border bg-muted/50 p-4 text-center">
                  <p className="text-xs font-medium text-muted-foreground">Total Sentences</p>
                  <p className="mt-1 text-2xl font-bold text-foreground">{results.totalSentences}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4 text-center">
                  <p className="text-xs font-medium text-muted-foreground">Total Words</p>
                  <p className="mt-1 text-2xl font-bold text-foreground">{results.totalWords}</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/50 p-4 text-center">
                  <p className="text-xs font-medium text-muted-foreground">Total Syllables</p>
                  <p className="mt-1 text-2xl font-bold text-foreground">{results.totalSyllables}</p>
                </div>
              </div>
            </section>

            <section className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="flex items-center gap-3">
                <BookOpen className="h-5 w-5 text-emerald-300" />
                <h2 className="text-lg font-semibold text-foreground">Interpretation Guide</h2>
              </div>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-emerald-400">90 - 100</span>
                  <span className="text-muted-foreground">Very Easy — Easily understood by an average 11-year-old student</span>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-emerald-400">80 - 89</span>
                  <span className="text-muted-foreground">Easy — Conversational English for average 12-year-olds</span>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-emerald-400">70 - 79</span>
                  <span className="text-muted-foreground">Fairly Easy — Easily understood by 13- to 15-year-olds</span>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-amber-400">60 - 69</span>
                  <span className="text-muted-foreground">Standard — Easily understood by 14- to 15-year-olds</span>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-amber-400">50 - 59</span>
                  <span className="text-muted-foreground">Fairly Difficult — Easily understood by 16- to 17-year-olds</span>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-rose-400">30 - 49</span>
                  <span className="text-muted-foreground">Difficult — Easily understood by college graduates</span>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/50 px-4 py-2.5">
                  <span className="w-20 text-right font-mono text-xs text-rose-400">0 - 29</span>
                  <span className="text-muted-foreground">Very Confusing — Best understood by university graduates</span>
                </div>
              </div>
            </section>
          </div>
        )}
      </div>
    </FreeToolLayout>
  );
}
