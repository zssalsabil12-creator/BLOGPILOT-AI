import { NextResponse } from 'next/server'
import { geminiFactCheck, isGeminiConfigured, geminiGenerate } from '@/lib/gemini'
import ZAI from 'z-ai-web-dev-sdk'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { factCheckSchema, parseBody } from '@/lib/validation'
import { handleApiError, TaggedError } from '@/lib/api-errors'

let _zai: any = null
async function getZAI() {
  if (!_zai) _zai = await ZAI.create()
  return _zai as any
}

/**
 * POST /api/fact-check
 *
 * Uses Gemini's Google Search grounding to verify facts and fetch real-time data.
 * Can be used standalone or as part of the article generation flow.
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit (12 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.factCheck)
    if (blocked) return blocked

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(factCheckSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const { query, context, statements } = body

    // Build the fact-check prompt
    let factCheckPrompt: string
    let itemsToCheck: string[]

    if (statements?.length) {
      // Fact-check specific statements
      itemsToCheck = statements
      factCheckPrompt = `Fact-check the following claims and statements. For each one:
1. Verify if it is accurate, partially accurate, or inaccurate
2. Provide the correct information with current data
3. Include specific numbers, dates, or statistics where applicable
4. Cite sources when possible

Statements to verify:
${statements.map((s: string, i: number) => `${i + 1}. "${s}"`).join('\n')}

For each statement, respond with:
- Statement: (repeat the claim)
- Verdict: ACCURATE / PARTIALLY ACCURATE / INACCURATE / UNVERIFIABLE
- Corrected Information: (current, verified facts)
- Source: (where you found the information, if available)
- Confidence: HIGH / MEDIUM / LOW`
    } else {
      // General fact-finding query — query is guaranteed by the schema refine
      const q = (query ?? '').trim()
      itemsToCheck = [q]
      factCheckPrompt = q
    }

    // Use Gemini with Google Search grounding
    let result

    try {
      if (isGeminiConfigured()) {
        result = await geminiFactCheck(
          factCheckPrompt,
          context || undefined
        )
      } else {
        // Fallback: use z-ai-web-dev-sdk without grounding
        const zai = await getZAI()
        const fallbackPrompt = `You are a research fact-checker. Provide accurate, factual information.

${factCheckPrompt}

Note: Real-time search grounding is not available. Provide the best information you can based on your training data, but clearly note that data may not reflect the very latest updates.

Format your response clearly with sections for each item checked.`
        const aiResult = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content:
                'You are a meticulous fact-checker. Always verify claims and provide specific data. If you are uncertain, say so clearly.',
            },
            { role: 'user', content: fallbackPrompt },
          ],
        })

        result = { text: aiResult.content || aiResult.choices?.[0]?.message?.content || '' }
      }
    } catch (aiError) {
      throw new TaggedError(
        'ai_unreachable',
        aiError instanceof Error ? aiError.message : 'AI provider error',
        503,
        { retryable: true, retryAfter: 15 }
      )
    }

    // Parse structured response if we have statements
    let structuredResults
    if (statements?.length && isGeminiConfigured()) {
      structuredResults = parseFactCheckResults(result.text, statements)
    }

    // Extract search grounding metadata if available
    const groundingInfo = result.groundingMetadata
      ? {
          webSearchQueries: result.groundingMetadata.webSearchQueries || [],
          sources:
            result.groundingMetadata.groundingChunks
              ?.map((chunk: any) => chunk.web?.title || chunk.web?.uri)
              .filter(Boolean) || [],
        }
      : null

    return NextResponse.json({
      success: true,
      query: query || 'Fact-check batch',
      results: structuredResults || null,
      fullResponse: result.text,
      groundingInfo,
      groundedWithGoogleSearch: isGeminiConfigured() && !!result.groundingMetadata,
      usage: result.usageMetadata,
      timestamp: new Date().toISOString(),
    })
  } catch (error: unknown) {
    if (error instanceof TaggedError) {
      return handleApiError(error, 'fact-check')
    }
    return handleApiError(error, 'fact-check')
  }
}

/**
 * Parse fact-check results from AI response into structured format.
 */
function parseFactCheckResults(
  text: string,
  originalStatements: string[]
): Array<{
  statement: string
  verdict: string
  correctedInfo: string
  confidence: string
}> {
  const results: Array<{
    statement: string
    verdict: string
    correctedInfo: string
    confidence: string
  }> = []

  // Try to extract structured data from the response
  for (const statement of originalStatements) {
    const lowerText = text.toLowerCase()
    const stmtLower = statement.toLowerCase()

    // Find the relevant section in the response
    const idx = lowerText.indexOf(stmtLower.slice(0, 50))
    if (idx !== -1) {
      const section = text.slice(idx, idx + 500)

      let verdict = 'UNVERIFIABLE'
      if (section.toLowerCase().includes('accurate') && !section.toLowerCase().includes('inaccurate') && !section.toLowerCase().includes('partially')) {
        verdict = 'ACCURATE'
      } else if (section.toLowerCase().includes('inaccurate') || section.toLowerCase().includes('incorrect')) {
        verdict = 'INACCURATE'
      } else if (section.toLowerCase().includes('partially')) {
        verdict = 'PARTIALLY ACCURATE'
      }

      let confidence = 'MEDIUM'
      if (section.toLowerCase().includes('confidence: high') || section.toLowerCase().includes('high confidence')) {
        confidence = 'HIGH'
      } else if (section.toLowerCase().includes('confidence: low') || section.toLowerCase().includes('low confidence')) {
        confidence = 'LOW'
      }

      results.push({
        statement,
        verdict,
        correctedInfo: section.slice(0, 300),
        confidence,
      })
    } else {
      results.push({
        statement,
        verdict: 'UNVERIFIABLE',
        correctedInfo: 'Could not find verification data for this claim.',
        confidence: 'LOW',
      })
    }
  }

  return results
}
