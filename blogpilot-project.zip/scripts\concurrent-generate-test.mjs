/**
 * Fires two truly concurrent /api/generate requests from a user holding a
 * single credit. Exactly one may consume it; the other must be rejected with
 * 402. If the winner's generation fails, its credit must be refunded — the
 * final balance must always be internally consistent.
 *
 * Run: node scripts/concurrent-generate-test.mjs [baseUrl]
 */
import { PrismaClient } from '@prisma/client';

const BASE = process.argv[2] || 'http://localhost:3000';
const prisma = new PrismaClient();

async function api(path, { method = 'GET', body, cookie } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      ...(cookie ? { Cookie: cookie } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let json = null;
  try { json = await res.json(); } catch {}
  return { status: res.status, json };
}

async function main() {
  const email = `concurrent-gen-${Date.now()}@test.com`;
  await fetch(`${BASE}/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'Sup3rSecurePass!', name: 'Concurrent Gen' }),
  });
  const login = await api('/api/auth/login', { method: 'POST', body: { email, password: 'Sup3rSecurePass!' } });
  if (login.status !== 200) throw new Error(`login failed: ${login.status}`);
  // Re-fetch set-cookie via raw fetch:
  const loginRes = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'Sup3rSecurePass!' }),
  });
  const setCookie = loginRes.headers.get('set-cookie') || '';
  const authCookie = setCookie.split(';')[0];

  const user = await prisma.user.findUnique({ where: { email } });
  await prisma.user.update({ where: { id: user.id }, data: { credits: 1 } });
  console.log(`User ${user.id} set to 1 credit. Firing 2 concurrent generations...`);

  const payload = { title: 'Concurrent spend race article', query: 'concurrent credit race condition', instructions: 'Write briefly for a test.' };
  const [r1, r2] = await Promise.all([
    api('/api/generate', { method: 'POST', cookie: authCookie, body: payload }),
    api('/api/generate', { method: 'POST', cookie: authCookie, body: payload }),
  ]);

  const statuses = [r1.status, r2.status].sort();
  const finalUser = await prisma.user.findUnique({ where: { id: user.id } });
  const txs = await prisma.creditTransaction.count({ where: { userId: user.id } });

  console.log(`Responses: ${r1.status}, ${r2.status}`);
  console.log(`Final balance: ${finalUser.credits}, ledger entries: ${txs}`);

  let ok = true;
  // Exactly one request may pass the credit gate; the loser gets 402.
  if (!(statuses[0] === 402 || statuses[1] === 402)) {
    console.log('FAIL: no 402 among responses — both requests passed the credit gate');
    ok = false;
  }
  if (finalUser.credits < 0) {
    console.log('FAIL: negative balance');
    ok = false;
  }
  // Winner either succeeded (balance 0) or failed+refunded (balance 1).
  if (![0, 1].includes(finalUser.credits)) {
    console.log('FAIL: inconsistent final balance');
    ok = false;
  }
  const winnerOk = r1.status !== 402 ? r1 : r2.status !== 402 ? r2 : null;
  if (winnerOk) {
    if (winnerOk.status === 200 && finalUser.credits !== 0) { console.log('FAIL: successful generation did not keep the charge'); ok = false; }
    if (winnerOk.status === 500 && finalUser.credits !== 1) { console.log('FAIL: failed generation was not refunded'); ok = false; }
  }

  await prisma.user.delete({ where: { id: user.id } }).catch(() => {});
  console.log(ok ? '\nCONCURRENT GENERATE TEST PASSED' : '\nCONCURRENT GENERATE TEST FAILED');
  process.exit(ok ? 0 : 1);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => prisma.$disconnect());
