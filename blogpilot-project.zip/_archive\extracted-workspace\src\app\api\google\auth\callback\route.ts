import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import {
  exchangeCodeForTokens,
  fetchGoogleUserInfo,
  storeGoogleTokens,
  isGoogleOAuthConfigured,
} from '@/lib/google-oauth'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/google/auth/callback
 *
 * Handles the OAuth callback after the user consents on Google's page.
 *
 * Body:
 *   { code: string, state?: string }
 *
 * This route is called by the frontend (not directly by Google's redirect,
 * since we use access_type=offline which returns the code as a query param).
 * The frontend reads the code from the URL and posts it here.
 *
 * Flow:
 *   1. Exchange the authorization code for access + refresh tokens
 *   2. Fetch the user's Google profile (email, name, id) using the access token
 *   3. Encrypt both tokens and store in the database
 *   4. Return success with the Google account info
 *
 * Response:
 *   200 { success: true, email: string, connected: true }
 *   400 if code is missing
 *   503 if Google OAuth not configured
 */
export async function POST(request: Request) {
  try {
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => ({}))
    const code = raw.code as string | undefined

    if (!code || typeof code !== 'string' || code.trim().length === 0) {
      return NextResponse.json(
        { error: 'Authorization code is required', code: 'validation' },
        { status: 400 }
      )
    }

    // ─── Demo mode ──────────────────────────────────────────────────────
    if (!isGoogleOAuthConfigured()) {
      return NextResponse.json({
        success: true,
        demo: true,
        email: 'user@example.com (demo)',
        connected: true,
        message: 'Demo mode: Google account connected (simulated). Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env for real OAuth.',
      })
    }

    // ─── Exchange code for tokens ────────────────────────────────────────
    const tokenResult = await exchangeCodeForTokens({ code: code.trim() })

    if (!tokenResult || !tokenResult.success) {
      return NextResponse.json(
        {
          error: `Failed to exchange authorization code: ${tokenResult?.error || 'unknown error'}`,
          code: 'oauth_error',
        },
        { status: 502 }
      )
    }

    // ─── Fetch Google user info ──────────────────────────────────────────
    const userInfo = await fetchGoogleUserInfo(tokenResult.accessToken)
    const googleEmail = userInfo?.email || 'unknown@example.com'
    const googleUserId = userInfo?.id || 'unknown'
    const googleName = userInfo?.name || googleEmail

    // ─── Store encrypted tokens in database ──────────────────────────────
    const tokenId = await storeGoogleTokens({
      userId: user.id,
      googleEmail,
      googleUserId,
      accessToken: tokenResult.accessToken,
      refreshToken: tokenResult.refreshToken,
      expiresIn: tokenResult.expiresIn,
      scope: tokenResult.scope,
      tokenType: tokenResult.tokenType,
    })

    console.info(
      `[google:auth] User ${user.id} connected Google account: ${googleEmail} ` +
      `(token ${tokenId}, expires in ${tokenResult.expiresIn}s)`
    )

    return NextResponse.json({
      success: true,
      tokenId,
      email: googleEmail,
      name: googleName,
      picture: userInfo?.picture || null,
      scopes: tokenResult.scope.split(' '),
      expiresIn: tokenResult.expiresIn,
      connected: true,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'google/auth/callback')
  }
}
