import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/auth'
import { getStripe, isDemoMode } from '@/lib/stripe'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/stripe/portal
 * Creates a Stripe Billing Portal session so the user can manage their
 * subscription (update payment method, switch plans, cancel, view invoices).
 *
 * In demo mode (no STRIPE_SECRET_KEY), returns a fake portal URL pointing
 * back to /billing so the front-end can render a simulated management view.
 *
 * Response:
 *   200 { url: string, demo: boolean }
 *   400 if user has no Stripe customer id
 *   401 if not authenticated
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const subscription = await db.subscription.findUnique({
      where: { userId: user.id },
    })

    // ─── Demo mode ──────────────────────────────────────────────────────
    if (isDemoMode() || !getStripe()) {
      return NextResponse.json({
        url: '/dashboard?demo_portal=opened',
        demo: true,
        message: 'Demo mode: subscription management is simulated. Configure STRIPE_SECRET_KEY to enable the real Stripe portal.',
      })
    }

    if (!subscription?.stripeCustomerId) {
      return NextResponse.json(
        {
          error: 'No Stripe customer found. Please upgrade to a paid plan first.',
          demo: false,
        },
        { status: 400 }
      )
    }

    const stripe = getStripe()!
    const origin =
      request.headers.get('origin') ||
      process.env.NEXT_PUBLIC_APP_URL ||
      'http://localhost:3000'

    const session = await stripe.billingPortal.sessions.create({
      customer: subscription.stripeCustomerId,
      return_url: `${origin}/dashboard?portal=returned`,
    })

    return NextResponse.json({
      url: session.url,
      demo: false,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'stripe/portal')
  }
}
