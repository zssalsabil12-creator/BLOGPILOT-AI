/**
 * Google OAuth 2.0 — Auto-Renewing Token Management
 *
 * Provides a complete, production-ready integration with Google's OAuth 2.0
 * system for automated publishing and indexing workflows.
 *
 * Architecture:
 *   1. Users connect their Google Account via standard OAuth 2.0 consent flow
 *      with `access_type: 'offline'` to obtain a permanent Refresh Token.
 *   2. The Refresh Token is encrypted (AES-256-GCM) and stored in the database.
 *   3. Before any automation run, callers use `getValidGoogleAccessToken()` which:
 *      - Checks if the current access token is expired (typically after 1 hour)
 *      - If expired, automatically uses the stored Refresh Token to request
 *        a brand new Access Token from Google's token endpoint
 *      - Updates the database with the new access token + expiry
 *   4. If a user revokes access manually, the refresh fails and the token
 *      is marked as "revoked" — error logs are emitted and callers are notified.
 *
 * Security:
 *   - Access tokens and refresh tokens are ALWAYS encrypted at rest
 *     using AES-256-GCM (via /src/lib/crypto.ts)
 *   - The Google Client Secret is only used server-side for token exchange
 *   - The refresh token is never exposed to the client
 *
 * Environment variables (validated by /src/lib/env.ts):
 *   GOOGLE_CLIENT_ID     — public OAuth client ID
 *   GOOGLE_CLIENT_SECRET — server-side secret for token exchange + refresh
 *   GOOGLE_REDIRECT_URI   — must match Google Cloud Console config
 *
 * Demo mode: when GOOGLE_CLIENT_ID or GOOGLE_CLIENT_SECRET is missing,
 * the library falls back to simulated token management so the UI can
 * render the connect/disconnect flow without a real Google project.
 */

import { encrypt, decrypt } from '@/lib/crypto'
import { db } from '@/lib/db'

/* -------------------------------------------------------------------------- */
/*                              Configuration                                  */
/* -------------------------------------------------------------------------- */

/** Google OAuth 2.0 token endpoint. */
const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token'

/** Google OAuth 2.0 authorization endpoint. */
const GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'

/** Google UserInfo endpoint (for fetching email + ID after consent). */
const GOOGLE_USERINFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo'

/**
 * Default OAuth scopes for automated publishing and indexing.
 *
 *   - userinfo.email, userinfo.profile — identify the user
 *   - www.googleapis.com/auth/indexing — submit URLs to Google Search Console
 *   - www.googleapis.com/auth/webmasters.readonly — read Search Console data
 *   - www.googleapis.com/auth/blogger — publish to Blogger
 *   - www.googleapis.com/auth/analytics.readonly — read Analytics data
 */
export const GOOGLE_DEFAULT_SCOPES = [
  'openid',
  'email',
  'profile',
  'https://www.googleapis.com/auth/indexing',
  'https://www.googleapis.com/auth/webmasters.readonly',
  'https://www.googleapis.com/auth/blogger',
  'https://www.googleapis.com/auth/analytics.readonly',
]

/** Whether Google OAuth is configured for live mode. */
export function isGoogleOAuthConfigured(): boolean {
  return !!(
    process.env.GOOGLE_CLIENT_ID &&
    process.env.GOOGLE_CLIENT_SECRET
  )
}

/** Get the Google Client ID (safe to expose to the browser). */
export function getGoogleClientId(): string | null {
  return process.env.GOOGLE_CLIENT_ID || null
}

/* -------------------------------------------------------------------------- */
/*                          In-memory token cache                              */
/* -------------------------------------------------------------------------- */

interface CachedToken {
  accessToken: string
  expiresAt: number // epoch-ms
}

/** Per-userId cache of access tokens (avoids hitting Google on every check). */
const tokenCache = new Map<string, CachedToken>()

/**
 * Clear a user's cached access token (e.g., after disconnect or revocation).
 */
export function clearTokenCache(userId: string): void {
  tokenCache.delete(userId)
}

/**
 * Clear ALL cached tokens (useful for testing or after a mass rotation).
 */
export function clearAllTokenCaches(): void {
  tokenCache.clear()
}

/* -------------------------------------------------------------------------- */
/*                     OAuth Authorization URL generation                      */
/* -------------------------------------------------------------------------- */

/**
 * Generate a Google OAuth 2.0 authorization URL.
 *
 * This URL should be opened in the user's browser to start the consent flow.
 * Key parameters:
 *   - access_type=offline — ensures a refresh token is returned
 *   - prompt=consent      — forces Google to always return a refresh token
 *   - state=<cuid>         — CSRF protection, stored in the DB for verification
 *
 * Returns null in demo mode (no Google credentials configured).
 */
export function generateAuthUrl(opts: {
  state: string
  scopes?: string[]
  redirectUri?: string
}): string | null {
  if (!isGoogleOAuthConfigured()) return null

  const clientId = process.env.GOOGLE_CLIENT_ID!
  const redirectUri = opts.redirectUri ||
    process.env.GOOGLE_REDIRECT_URI ||
    'http://localhost:3000/api/google/auth/callback'
  const scopes = (opts.scopes || GOOGLE_DEFAULT_SCOPES).join(' ')

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: scopes,
    access_type: 'offline',
    prompt: 'consent',
    state: opts.state,
  })

  return `${GOOGLE_AUTH_URL}?${params.toString()}`
}

/* -------------------------------------------------------------------------- */
/*                      Token exchange (code → tokens)                          */
/* -------------------------------------------------------------------------- */

export interface GoogleTokenExchangeResult {
  success: boolean
  accessToken: string
  refreshToken: string
  expiresIn: number // seconds
  scope: string
  tokenType: string
  error?: string
}

/**
 * Exchange an authorization code for access + refresh tokens.
 *
 * Called by /api/google/auth/callback after the user consents.
 * Returns null in demo mode.
 */
export async function exchangeCodeForTokens(opts: {
  code: string
  redirectUri?: string
}): Promise<GoogleTokenExchangeResult | null> {
  if (!isGoogleOAuthConfigured()) return null

  const redirectUri = opts.redirectUri ||
    process.env.GOOGLE_REDIRECT_URI ||
    'http://localhost:3000/api/google/auth/callback'

  const params = new URLSearchParams({
    code: opts.code,
    client_id: process.env.GOOGLE_CLIENT_ID!,
    client_secret: process.env.GOOGLE_CLIENT_SECRET!,
    redirect_uri: redirectUri,
    grant_type: 'authorization_code',
  })

  const res = await fetch(GOOGLE_TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params.toString(),
    cache: 'no-store',
  })

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}))
    console.error(
      `[google-oauth] Token exchange failed (${res.status}):`,
      errorBody
    )
    return {
      success: false,
      accessToken: '',
      refreshToken: '',
      expiresIn: 0,
      scope: '',
      tokenType: '',
      error: `HTTP ${res.status}: ${(errorBody as any).error_description || 'unknown'}`,
    }
  }

  const data = await res.json() as {
    access_token: string
    refresh_token: string
    expires_in: number
    scope: string
    token_type: string
  }

  return {
    success: true,
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    expiresIn: data.expires_in,
    scope: data.scope,
    tokenType: data.token_type,
  }
}

/* -------------------------------------------------------------------------- */
/*                      Token refresh (refresh_token → access_token)            */
/* -------------------------------------------------------------------------- */

export interface GoogleTokenRefreshResult {
  success: boolean
  accessToken: string
  expiresIn: number
  error?: string
  /** If true, the refresh token itself is invalid/expired — user must re-auth. */
  revoked: boolean
}

/**
 * Use a refresh token to obtain a new access token.
 *
 * This is the core of the auto-renewal mechanism. When the access token
 * expires (typically after 1 hour), this function silently exchanges the
 * stored refresh token for a new access token — no user intervention required.
 *
 * Error handling:
 *   - invalid_grant → the refresh token is revoked/expired → marks the token
 *     as "revoked" in the database and logs the error
 *   - Network errors → returns success=false but does NOT mark as revoked
 *     (caller can retry later)
 */
export async function refreshAccessToken(refreshToken: string): Promise<GoogleTokenRefreshResult> {
  if (!isGoogleOAuthConfigured()) {
    return { success: false, accessToken: '', expiresIn: 0, error: 'Google OAuth not configured', revoked: false }
  }

  const params = new URLSearchParams({
    grant_type: 'refresh_token',
    client_id: process.env.GOOGLE_CLIENT_ID!,
    client_secret: process.env.GOOGLE_CLIENT_SECRET!,
    refresh_token: refreshToken,
  })

  try {
    const res = await fetch(GOOGLE_TOKEN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString(),
      cache: 'no-store',
    })

    if (!res.ok) {
      const errorBody = await res.json().catch(() => ({})) as any
      const errorCode = errorBody.error || ''
      const errorDesc = errorBody.error_description || 'unknown'

      // Google returns "invalid_grant" when the refresh token is revoked
      // or expired — this is NOT recoverable; the user must re-authenticate.
      const isRevoked = errorCode === 'invalid_grant' ||
        errorCode === 'invalid_token' ||
        res.status === 400

      console.error(
        `[google-oauth] Token refresh failed (${res.status}): ${errorCode} — ${errorDesc}`,
        isRevoked ? '→ token likely revoked by user' : '→ transient error, will retry'
      )

      return {
        success: false,
        accessToken: '',
        expiresIn: 0,
        error: `${errorCode}: ${errorDesc}`,
        revoked: isRevoked,
      }
    }

    const data = await res.json() as {
      access_token: string
      expires_in: number
      scope?: string
      token_type: string
    }

    return {
      success: true,
      accessToken: data.access_token,
      expiresIn: data.expires_in,
      revoked: false,
    }
  } catch (err) {
    console.error('[google-oauth] Token refresh network error:', err)
    return {
      success: false,
      accessToken: '',
      expiresIn: 0,
      error: err instanceof Error ? err.message : 'Network error',
      revoked: false,
    }
  }
}

/* -------------------------------------------------------------------------- */
/*                Store & retrieve tokens in the database                       */
/* -------------------------------------------------------------------------- */

/**
 * Store token data in the database after a successful OAuth exchange.
 *
 * Both access_token and refresh_token are encrypted at rest.
 * The stored row includes the Google user's email + ID for display purposes.
 */
export async function storeGoogleTokens(opts: {
  userId: string
  googleEmail: string
  googleUserId: string
  accessToken: string
  refreshToken: string
  expiresIn: number
  scope: string
  tokenType: string
}): Promise<string> {
  const expiresAt = new Date(Date.now() + opts.expiresIn * 1000)

  // Upsert: if the user already has a token for this Google account, update it.
  // Otherwise create a new row.
  const existing = await db.googleToken.findFirst({
    where: {
      userId: opts.userId,
      googleEmail: opts.googleEmail,
    },
  })

  if (existing) {
    await db.googleToken.update({
      where: { id: existing.id },
      data: {
        accessToken: encrypt(opts.accessToken),
        refreshToken: encrypt(opts.refreshToken),
        scope: opts.scope,
        tokenType: opts.tokenType,
        expiresAt,
        isActive: true,
        status: 'connected',
        lastRefreshedAt: new Date(),
      },
    })
    // Update cache
    tokenCache.set(opts.userId, {
      accessToken: opts.accessToken,
      expiresAt: expiresAt.getTime(),
    })
    return existing.id
  }

  const token = await db.googleToken.create({
    data: {
      userId: opts.userId,
      googleEmail: opts.googleEmail,
      googleUserId: opts.googleUserId,
      accessToken: encrypt(opts.accessToken),
      refreshToken: encrypt(opts.refreshToken),
      scope: opts.scope,
      tokenType: opts.tokenType,
      expiresAt,
      isActive: true,
      status: 'connected',
      lastRefreshedAt: new Date(),
    },
  })

  // Update cache
  tokenCache.set(opts.userId, {
    accessToken: opts.accessToken,
    expiresAt: expiresAt.getTime(),
  })

  return token.id
}

/**
 * Fetch the user's Google tokens from the database.
 * Returns the raw encrypted rows — callers should decrypt.
 */
export async function getGoogleTokensForUser(userId: string) {
  return db.googleToken.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
  })
}

/**
 * Delete (disconnect) a Google token.
 */
export async function deleteGoogleToken(id: string, userId: string): Promise<boolean> {
  const token = await db.googleToken.findFirst({ where: { id, userId } })
  if (!token) return false

  await db.googleToken.delete({ where: { id } })
  // Also clear from cache
  clearTokenCache(userId)
  return true
}

/* -------------------------------------------------------------------------- */
/*          ★ getValidGoogleAccessToken() — Auto-renewal middleware ★          */
/* -------------------------------------------------------------------------- */

export interface ValidTokenResult {
  /** A valid (non-expired) access token ready for API calls. */
  accessToken: string
  /** The GoogleToken record id in the database. */
  tokenId: string
  /** Whether the token was auto-refreshed during this call. */
  refreshed: boolean
}

export type TokenErrorResult = {
  accessToken: null
  tokenId: string | null
  /** User-friendly error code. */
  code: 'not_configured' | 'no_token' | 'revoked' | 'refresh_failed'
  /** Human-readable message. */
  message: string
}

/**
 * Get a valid Google access token for a user, auto-renewing if expired.
 *
 * This is the core middleware function that should be called before ANY
 * automation run (publishing, indexing, analytics fetching, etc.).
 *
 * Logic:
 *   1. Check Google OAuth is configured → if not, return 'not_configured'
 *   2. Fetch the user's active GoogleToken from the DB
 *   3. Check the in-memory cache for a valid, non-expired access token
 *   4. If cached token is still valid (expiresAt > now + 60s buffer), return it
 *   5. If expired (or no cache):
 *      a. Decrypt the stored refresh token
 *      b. Call Google's token endpoint to get a new access token
 *      c. If refresh fails with invalid_grant → mark as 'revoked', log error
 *      d. If refresh succeeds → update DB + cache with new access token
 *   6. Return the valid access token
 *
 * Usage in an automation route:
 *   ```ts
 *   const token = await getValidGoogleAccessToken(user.id)
 *   if (!token.accessToken) {
 *     // token.code === 'revoked' → redirect user to reconnect
 *     // token.code === 'not_configured' → admin must set up Google OAuth
 *     // token.code === 'no_token' → user hasn't connected Google yet
 *   }
 *   // Use token.accessToken for Google API calls
 *   const res = await fetch('https://indexing.googleapis.com/v3/urlNotifications:publish', {
 *     headers: { Authorization: `Bearer ${token.accessToken}` },
 *     ...
 *   })
 *   ```
 */
export async function getValidGoogleAccessToken(
  userId: string,
  tokenId?: string
): Promise<ValidTokenResult | TokenErrorResult> {
  // 1. Check configured
  if (!isGoogleOAuthConfigured()) {
    return {
      accessToken: null,
      tokenId: null,
      code: 'not_configured',
      message: 'Google OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env',
    }
  }

  // 2. Fetch the user's token from DB
  const tokenRecord = tokenId
    ? await db.googleToken.findFirst({ where: { id: tokenId, userId } })
    : await db.googleToken.findFirst({ where: { userId, isActive: true } })

  if (!tokenRecord) {
    return {
      accessToken: null,
      tokenId: null,
      code: 'no_token',
      message: 'No Google account connected. Connect a Google account first.',
    }
  }

  // If the token is marked as revoked/invalid, don't even try to refresh
  if (!tokenRecord.isActive || tokenRecord.status === 'revoked' || tokenRecord.status === 'invalid') {
    return {
      accessToken: null,
      tokenId: tokenRecord.id,
      code: 'revoked',
      message: `Google account disconnected or access revoked. Status: ${tokenRecord.status}. Please reconnect.`,
    }
  }

  // 3. Check in-memory cache
  const cached = tokenCache.get(userId)
  if (cached && cached.expiresAt > Date.now() + 60_000) {
    // Token still valid (with 60s safety buffer) — update lastUsedAt
    await db.googleToken.update({
      where: { id: tokenRecord.id },
      data: { lastUsedAt: new Date() },
    }).catch(() => { /* fire-and-forget */ })
    return { accessToken: cached.accessToken, tokenId: tokenRecord.id, refreshed: false }
  }

  // 4. Access token is expired or not cached — need to refresh
  const refreshTokenPlaintext = decrypt(tokenRecord.refreshToken)
  if (!refreshTokenPlaintext) {
    console.error(`[google-oauth] Failed to decrypt refresh token for user ${userId}`)
    // Mark as invalid
    await db.googleToken.update({
      where: { id: tokenRecord.id },
      data: { status: 'invalid', isActive: false },
    })
    clearTokenCache(userId)
    return {
      accessToken: null,
      tokenId: tokenRecord.id,
      code: 'revoked',
      message: 'Stored refresh token could not be decrypted. Please reconnect your Google account.',
    }
  }

  // 5. Refresh the access token
  const refreshResult = await refreshAccessToken(refreshTokenPlaintext)

  if (!refreshResult.success) {
    // If the refresh token itself is revoked, update the DB
    if (refreshResult.revoked) {
      console.error(
        `[google-oauth] Refresh token revoked for user ${userId} (Google email: ${tokenRecord.googleEmail}). ` +
        'User must re-authenticate. This usually happens when the user manually revoked ' +
        'access in their Google Account settings.'
      )
      await db.googleToken.update({
        where: { id: tokenRecord.id },
        data: { status: 'revoked', isActive: false },
      })
      clearTokenCache(userId)
      return {
        accessToken: null,
        tokenId: tokenRecord.id,
        code: 'revoked',
        message: `Google access was revoked. Error: ${refreshResult.error}. Please reconnect your Google account.`,
      }
    }

    // Transient error (network, rate limit, etc.) — don't mark as revoked
    return {
      accessToken: null,
      tokenId: tokenRecord.id,
      code: 'refresh_failed',
      message: `Failed to refresh Google access token: ${refreshResult.error}. Will retry on next attempt.`,
    }
  }

  // 6. Update DB and cache with the new access token
  const newExpiresAt = new Date(Date.now() + refreshResult.expiresIn * 1000)

  await db.googleToken.update({
    where: { id: tokenRecord.id },
    data: {
      accessToken: encrypt(refreshResult.accessToken),
      expiresAt: newExpiresAt,
      lastRefreshedAt: new Date(),
      lastUsedAt: new Date(),
      status: 'connected',
      isActive: true,
    },
  })

  // Update cache
  tokenCache.set(userId, {
    accessToken: refreshResult.accessToken,
    expiresAt: newExpiresAt.getTime(),
  })

  return {
    accessToken: refreshResult.accessToken,
    tokenId: tokenRecord.id,
    refreshed: true,
  }
}

/* -------------------------------------------------------------------------- */
/*                          Fetch user info from Google                        */
/* -------------------------------------------------------------------------- */

export interface GoogleUserInfo {
  id: string
  email: string
  name: string
  picture?: string
  verifiedEmail?: boolean
}

/**
 * Fetch the user's Google profile info using an access token.
 */
export async function fetchGoogleUserInfo(accessToken: string): Promise<GoogleUserInfo | null> {
  try {
    const res = await fetch(GOOGLE_USERINFO_URL, {
      headers: { Authorization: `Bearer ${accessToken}` },
      cache: 'no-store',
    })
    if (!res.ok) return null

    const data = await res.json() as {
      id: string
      email: string
      name: string
      picture?: string
      email_verified?: boolean
    }

    return {
      id: data.id,
      email: data.email,
      name: data.name,
      picture: data.picture,
      verifiedEmail: data.email_verified,
    }
  } catch (err) {
    console.error('[google-oauth] Failed to fetch user info:', err)
    return null
  }
}
