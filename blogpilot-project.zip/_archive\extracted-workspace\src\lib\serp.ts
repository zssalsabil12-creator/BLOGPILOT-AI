
export type SerpResult = {
  position: number;
  title?: string;
  link?: string;
  snippet?: string;
  displayed_link?: string;
  favicon?: string;
  rich_snippet?: any;
};

function normalizeOrganicResults(organic: any[], num: number): SerpResult[] {
  return (organic || [])
    .slice(0, num)
    .map((r: any, i: number) => ({
      position: i + 1,
      title: r.title || r.position || '',
      link: r.link || r.url || r.position || '',
      snippet: r.snippet || r.snippet_from_result || r.description || '',
      displayed_link: r.displayed_link || r.domain || undefined,
      favicon: r.favicon || undefined,
      rich_snippet: r.rich_snippet || r.rich_snippet || undefined,
    }));
}

export async function searchSerpApi(query: string, num = 10) {
  const key = process.env.SERPAPI_API_KEY;
  if (!key) {
    throw new Error('SERPAPI_API_KEY not configured in env');
  }

  const params = new URLSearchParams({
    q: query,
    engine: 'google',
    num: String(num),
    api_key: key,
  });

  const url = `https://serpapi.com/search.json?${params.toString()}`;
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36' } });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`SerpAPI error ${res.status}: ${text}`);
  }
  const data = await res.json();

  const organic = (data.organic_results || data.orgicals || data.orgic_results || []) as any[];
  const results = normalizeOrganicResults(organic, num);
  return { raw: data, results };
}

export async function searchDuckDuckGoHtml(query: string, num = 10) {
  const params = new URLSearchParams({ q: query, kl: 'us-en' });
  const url = `https://html.duckduckgo.com/html/?${params.toString()}`;
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
    },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`DuckDuckGo HTML search error ${res.status}: ${text}`);
  }

  const html = await res.text();
  const results: SerpResult[] = [];
  const resultPattern = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let match: RegExpExecArray | null;

  while (results.length < num && (match = resultPattern.exec(html))) {
    let link = match[1];
    const title = match[2].replace(/<[^>]+>/g, '').trim();
    if (link.startsWith('//duckduckgo.com/l/?uddg=')) {
      const decoded = decodeURIComponent(link.split('uddg=')[1].split('&')[0]);
      link = decoded;
    }
    const snippetStart = html.indexOf(match[0], match.index);
    let snippet = '';
    if (snippetStart !== -1) {
      const snippetBlock = html.slice(snippetStart, snippetStart + 600);
      const snippetMatch = snippetBlock.match(/<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/i);
      if (snippetMatch) snippet = snippetMatch[1].replace(/<[^>]+>/g, '').trim();
    }
    if (link && title) {
      results.push({ position: results.length + 1, title, link: link.startsWith('http') ? link : `https:${link}`, snippet });
    }
  }

  return { raw: html, results: results.slice(0, num) };
}
