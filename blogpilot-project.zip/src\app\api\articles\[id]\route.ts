﻿import { NextResponse } from 'next/server';
import { z } from 'zod';
import prisma from '@/lib/prisma';
import { getCurrentUserId } from '@/lib/auth';
import { computeSeoScore } from '@/lib/seo-score';

const updateArticleSchema = z.object({
  title: z.string().min(1, 'Title is required').max(300).optional(),
  content: z.string().optional(),
  slug: z.string().optional(),
  excerpt: z.string().max(500).optional().nullable(),
  targetKeyword: z.string().max(200).optional().nullable(),
  seoScore: z.number().int().min(0).max(100).optional(),
  wordCount: z.number().int().min(0).optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'SCHEDULED']).optional(),
  language: z.string().max(10).optional(),
  intent: z.string().max(50).optional().nullable(),
  tone: z.string().max(50).optional().nullable(),
  length: z.string().max(20).optional().nullable(),
  model: z.string().max(100).optional().nullable(),
  tokensUsed: z.number().int().min(0).optional().nullable(),
  authorName: z.string().max(120).optional().nullable(),
  reviewerName: z.string().max(120).optional().nullable(),
  reviewedAt: z.string().datetime({ offset: true }).optional().nullable(),
  siteId: z.string().max(64).optional().nullable(),
});

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const article = await prisma.article.findFirst({ where: { id, userId } });
    if (!article) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });
    return NextResponse.json({ ok: true, data: { article } });
  } catch (error: any) {
    console.error('Get article error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to load article' }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  const parsed = updateArticleSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const existing = await prisma.article.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });

    const data = parsed.data;
    const updateData: any = { ...data };

    // reviewedAt arrives as ISO string from the client.
    if (typeof data.reviewedAt === 'string') {
      updateData.reviewedAt = new Date(data.reviewedAt);
    }
    if (data.siteId !== undefined) {
      if (data.siteId === null) {
        updateData.siteId = null;
      } else {
        const site = await prisma.connectedSite.findFirst({
          where: { id: data.siteId, userId },
          select: { id: true },
        });
        if (!site) return NextResponse.json({ ok: false, error: 'Linked site not found' }, { status: 404 });
        updateData.siteId = site.id;
      }
    }

    if (data.content !== undefined) {
      updateData.wordCount = data.content ? data.content.trim().split(/\s+/).length : 0;
    }

    // Recompute SEO score server-side whenever scored content changes.
    const contentChanged = data.content !== undefined || data.title !== undefined ||
      data.excerpt !== undefined || data.targetKeyword !== undefined;
    if (contentChanged) {
      const seo = computeSeoScore({
        title: data.title ?? existing.title,
        content: data.content ?? existing.content,
        excerpt: data.excerpt === undefined ? existing.excerpt : data.excerpt,
        targetKeyword: data.targetKeyword === undefined ? existing.targetKeyword : data.targetKeyword,
      });
      updateData.seoScore = seo.score;
    }

    if (data.slug !== undefined) {
      const dup = await prisma.article.findFirst({ where: { userId, slug: data.slug, NOT: { id } } });
      if (dup) return NextResponse.json({ ok: false, error: 'An article with this slug already exists' }, { status: 409 });
    }

    const updated = await prisma.article.update({ where: { id }, data: updateData });
    return NextResponse.json({ ok: true, data: { article: updated } });
  } catch (error: any) {
    console.error('Update article error:', error);
    if (error?.code === 'P2002') {
      return NextResponse.json({ ok: false, error: 'An article with this slug already exists' }, { status: 409 });
    }
    return NextResponse.json({ ok: false, error: 'Unable to update article' }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const existing = await prisma.article.findFirst({ where: { id, userId } });
    if (!existing) return NextResponse.json({ ok: false, error: 'Article not found' }, { status: 404 });

    await prisma.article.delete({ where: { id } });
    return NextResponse.json({ ok: true, data: { deleted: true, id } });
  } catch (error: any) {
    console.error('Delete article error:', error);
    return NextResponse.json({ ok: false, error: 'Unable to delete article' }, { status: 500 });
  }
}
