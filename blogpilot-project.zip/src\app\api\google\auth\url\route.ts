﻿import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { isGoogleConfigured, getGoogleAuthUrl } from '@/lib/google-oauth';
import crypto from 'node:crypto';

function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error('AUTH_SECRET is required');
  return secret;
}

function signState(payload: string): string {
  const hmac = crypto.createHmac('sha256', getAuthSecret());
  hmac.update(payload);
  return hmac.digest('base64url');
}

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  if (!isGoogleConfigured()) {
    return NextResponse.json({ ok: false, error: 'Google OAuth is not configured. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.' }, { status: 501 });
  }

  const payload = JSON.stringify({ userId, ts: Date.now() });
  const sig = signState(payload);
  const state = Buffer.from(payload).toString('base64url') + '.' + sig;
  const url = getGoogleAuthUrl(state);

  return NextResponse.json({ ok: true, url });
}
