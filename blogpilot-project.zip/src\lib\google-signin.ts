import { APP_URL } from '@/lib/env';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

const SIGNIN_SCOPES = [
  'openid',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
].join(' ');

export const GOOGLE_SIGNIN_STATE_COOKIE = 'google_signin_state';

export function isGoogleSignInConfigured(): boolean {
  return !!(GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET);
}

export function getGoogleSignInUrl(state: string): string {
  const params = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID!,
    redirect_uri: `${APP_URL}/api/auth/google/callback`,
    response_type: 'code',
    scope: SIGNIN_SCOPES,
    access_type: 'online',
    include_granted_scopes: 'true',
    prompt: 'select_account',
    state,
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

export interface GoogleSignInProfile {
  email: string;
  emailVerified: boolean;
  name?: string;
  picture?: string;
}

export async function exchangeSignInCode(code: string): Promise<GoogleSignInProfile> {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      client_id: GOOGLE_CLIENT_ID!,
      client_secret: GOOGLE_CLIENT_SECRET!,
      redirect_uri: `${APP_URL}/api/auth/google/callback`,
      grant_type: 'authorization_code',
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error_description || 'Failed to exchange authorization code');
  }

  const tokens = await res.json();

  const userInfo = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
    headers: { Authorization: `Bearer ${tokens.access_token}` },
  });

  if (!userInfo.ok) {
    throw new Error('Failed to fetch Google profile');
  }

  const info = await userInfo.json();
  if (!info.email) {
    throw new Error('No email returned by Google');
  }

  return {
    email: String(info.email).toLowerCase().trim(),
    emailVerified: info.email_verified !== false,
    name: info.name || undefined,
    picture: info.picture || undefined,
  };
}
