﻿import { GoogleGenerativeAI } from '@google/generative-ai';
import { getGeminiApiKey, type GeminiStatus } from '@/lib/secrets';

// Model preference ladder. Aliases like -latest always resolve to the
// current generation; dated models act as concrete fallbacks for when an
// alias lags. Retired models simply 404 and fall through.
const GEMINI_MODELS = ['gemini-flash-latest', 'gemini-3.7-flash', 'gemini-3.6-flash', 'gemini-pro-latest'];
const DEFAULT_MAX_TOKENS = 1024;

// Secondary provider: OpenRouter (OpenAI-compatible gateway) used as an
// automatic failover once the primary Gemini ladder is exhausted. Server-side
// only, subject to the same timeout/retry/quota policies and usage ledger.
const OPENROUTER_MODELS = ['google/gemini-3.6-flash', 'google/gemini-3.7-flash'];
const OPENROUTER_BASE = 'https://openrouter.ai/api/v1';

function getOpenRouterKey(): string | undefined {
  const key = process.env.OPENROUTER_API_KEY;
  return key && key.trim() ? key.trim() : undefined;
}

export function isOpenRouterConfigured(): boolean {
  return !!getOpenRouterKey();
}

// Hard ceiling for automatic budget escalation when a response is cut off by
// the token limit. Prevents runaway costs while eliminating most silent
// truncation.
const MAX_ESCALATION_TOKENS = 8192;

// Per-call timeout and transient-failure retry policy.
const CALL_TIMEOUT_MS = 60_000;
const MAX_RETRIES = 2;
const RETRY_BASE_DELAY_MS = 800;

class GeminiUnavailableError extends Error {
  status: GeminiStatus;
  constructor(status: GeminiStatus, message: string) {
    super(message);
    this.status = status;
  }
}

export { GeminiUnavailableError };

// Client cache is keyed by the resolved API key value so that rotating the
// underlying secret takes effect on the next request without a restart.
let cachedClientKey: string | null = null;
let geminiClient: GoogleGenerativeAI | null = null;

function getClient(): GoogleGenerativeAI | null {
  const key = getGeminiApiKey();
  if (!key) return null;
  if (geminiClient && cachedClientKey === key) return geminiClient;
  geminiClient = new GoogleGenerativeAI(key);
  cachedClientKey = key;
  return geminiClient;
}

export function isGeminiConfigured(): boolean {
  return !!getGeminiApiKey();
}

function extractText(result: any): string | null {
  if (!result) return null;
  if (typeof result === 'string') return result.trim();
  if (result?.response?.text) {
    const text = typeof result.response.text === 'function'
      ? result.response.text()
      : result.response.text;
    return typeof text === 'string' ? text.trim() : null;
  }
  if (result?.text) {
    if (typeof result.text === 'function') return result.text().trim();
    if (typeof result.text === 'string') return result.text.trim();
  }
  const candidate = result?.candidates?.[0]?.content?.parts?.[0]?.text ||
    result?.candidates?.[0]?.content?.text ||
    result?.choices?.[0]?.message?.content ||
    result?.choices?.[0]?.text;
  return candidate ? String(candidate).trim() : null;
}

function extractFinishReason(result: any): string | undefined {
  return result?.response?.candidates?.[0]?.finishReason
    || result?.candidates?.[0]?.finishReason
    || undefined;
}

interface ModelCallResult {
  text: string | null;
  finishReason?: string;
}

/** Transient errors worth retrying with backoff (rate limits, provider hiccups). */
function isTransientError(error: any): boolean {
  const msg = String(error?.message || error || '');
  const status = error?.status ?? error?.code;
  if (status === 429 || status === 500 || status === 503 || status === 504) return true;
  return /429|rate.?limit|quota|timeout|aborted|ECONNRESET|ETIMEDOUT|ENOTFOUND|fetch failed|internal|unavailable|overloaded/i.test(msg);
}

/**
 * Quota/credit exhaustion on either provider — backing off inside the request
 * is pointless; surface fast. Covers Gemini 429s and OpenRouter 402
 * "insufficient credits".
 */
function isQuotaError(error: any): boolean {
  const status = error?.status ?? error?.code;
  if (status === 429 || status === 402) return true;
  return /\[429\s*\]|exceeded your (current )?quota|resource.?exhausted|insufficient credits/i.test(String(error?.message || ''));
}

async function callModelOnce(
  modelName: string,
  prompt: string,
  maxOutputTokens: number,
): Promise<ModelCallResult> {
  const client = getClient();
  if (!client) throw new GeminiUnavailableError('not_configured', 'Gemini API key is not configured');

  const model = client.getGenerativeModel({
    model: modelName,
    generationConfig: {
      temperature: 0.2,
      maxOutputTokens,
    },
  });

  // Overall deadline guard independent of the SDK's own socket handling.
  return Promise.race([
    model.generateContent(prompt).then((result) => ({
      text: extractText(result),
      finishReason: extractFinishReason(result),
    })),
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error(`Gemini request timed out after ${CALL_TIMEOUT_MS}ms`)), CALL_TIMEOUT_MS),
    ),
  ]);
}

/**
 * Calls a single model with timeout + exponential backoff on transient
 * failures (5xx/network). Quota (429) errors propagate immediately — the
 * caller decides whether to try another model.
 */
async function callModel(
  modelName: string,
  prompt: string,
  maxOutputTokens: number,
): Promise<ModelCallResult> {
  let lastError: any;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      return await callModelOnce(modelName, prompt, maxOutputTokens);
    } catch (error: any) {
      lastError = error;
      if (error instanceof GeminiUnavailableError) throw error;
      if (isQuotaError(error)) throw error;
      if (!isTransientError(error) || attempt === MAX_RETRIES) break;
      const delay = RETRY_BASE_DELAY_MS * Math.pow(2, attempt);
      console.warn(`[gemini] ${modelName} transient failure (attempt ${attempt + 1}/${MAX_RETRIES + 1}); retrying in ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  throw lastError;
}

/**
 * OpenRouter failover call. Same timeout/retry/quota semantics as the Gemini
 * ladder; errors are normalized to plain Errors carrying `.status` so the
 * shared classification helpers work unchanged.
 */
async function callOpenRouterOnce(
  modelName: string,
  prompt: string,
  maxOutputTokens: number,
): Promise<ModelCallResult> {
  const key = getOpenRouterKey();
  if (!key) throw new GeminiUnavailableError('not_configured', 'OPENROUTER_API_KEY is not configured');

  const response = await fetch(`${OPENROUTER_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      // Optional attribution headers — no secrets involved.
      'X-Title': 'BlogPilot AI',
    },
    body: JSON.stringify({
      model: modelName,
      max_tokens: maxOutputTokens,
      temperature: 0.2,
      messages: [{ role: 'user', content: prompt }],
    }),
    signal: AbortSignal.timeout(CALL_TIMEOUT_MS),
  });

  if (!response.ok) {
    const bodyText = await response.text().catch(() => '');
    let message = `OpenRouter HTTP ${response.status}`;
    try {
      const parsed = JSON.parse(bodyText);
      message = parsed?.error?.message || message;
    } catch {
      // keep generic message; never log raw body (could echo request data)
    }
    const error: any = new Error(message);
    error.status = response.status;
    throw error;
  }

  const data = await response.json();
  const text = String(data?.choices?.[0]?.message?.content ?? '').trim();
  return { text: text || null, finishReason: data?.choices?.[0]?.finish_reason };
}

async function callOpenRouter(
  modelName: string,
  prompt: string,
  maxOutputTokens: number,
): Promise<ModelCallResult> {
  let lastError: any;
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      return await callOpenRouterOnce(modelName, prompt, maxOutputTokens);
    } catch (error: any) {
      lastError = error;
      if (error instanceof GeminiUnavailableError) throw error;
      if (isQuotaError(error)) throw error;
      if (!isTransientError(error) || attempt === MAX_RETRIES) break;
      const delay = RETRY_BASE_DELAY_MS * Math.pow(2, attempt);
      console.warn(`[openrouter] ${modelName} transient failure (attempt ${attempt + 1}/${MAX_RETRIES + 1}); retrying in ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  throw lastError;
}

// Overall wall-clock budget for one logical AI request across all models,
// retries and escalations. Keeps worst-case latency bounded for callers.
const TOTAL_DEADLINE_MS = 150_000;

/**
 * Runs a prompt against the configured Gemini models.
 *
 * Truncation policy: if a response stops with finishReason === 'MAX_TOKENS',
 * the SAME model is retried with a doubled token budget (up to
 * MAX_ESCALATION_TOKENS) before falling through to the next model. Callers
 * receive `{ text, truncated }` so multi-step flows can detect incomplete
 * output instead of shipping silently truncated content.
 *
 * Quota policy: a 429 skips remaining retries for that model and moves to
 * the next; once ALL models are quota-blocked the error is rethrown as
 * temporarily_unavailable so callers can refund credits and inform the user
 * precisely. A global wall-clock deadline bounds worst-case latency.
 */
async function runWithModels(
  prompt: string,
  maxOutputTokens: number,
): Promise<{ text: string; truncated: boolean; model: string } | null> {
  if (!getClient() && !isOpenRouterConfigured()) return null;

  const deadline = Date.now() + TOTAL_DEADLINE_MS;
  let lastError: any = null;
  let sawQuota = false;
  let sawCredits = false;

  for (const modelName of GEMINI_MODELS) {
    if (Date.now() > deadline) {
      console.warn('[gemini] Total generation deadline exceeded; aborting model ladder.');
      break;
    }
    let budget = maxOutputTokens;
    // Allow up to 2 escalations per model (e.g. 1200 -> 2400 -> 4800).
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const { text, finishReason } = await callModel(modelName, prompt, budget);
        if (!text || text.length === 0) break;
        if (finishReason === 'MAX_TOKENS' && budget < MAX_ESCALATION_TOKENS) {
          console.warn(`[gemini] ${modelName} hit MAX_TOKENS at ${budget}; escalating budget.`);
          budget = Math.min(budget * 2, MAX_ESCALATION_TOKENS);
          continue;
        }
        return { text, truncated: finishReason === 'MAX_TOKENS', model: modelName };
      } catch (error: any) {
        lastError = error;
        if (isQuotaError(error)) {
          // Try the next model once — per-model quota may still exist — but
          // do not burn retries on this one.
          sawQuota = true;
          console.warn(`[gemini] ${modelName} quota exhausted; trying next model.`);
          break;
        }
        break;
      }
    }
  }

  // Secondary provider: OpenRouter failover. Only reached when the primary
  // Gemini ladder produced nothing.
  for (const modelName of OPENROUTER_MODELS) {
    if (!isOpenRouterConfigured()) break;
    if (Date.now() > deadline) {
      console.warn('[openrouter] Total generation deadline exceeded; aborting failover ladder.');
      break;
    }
    let budget = maxOutputTokens;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const { text, finishReason } = await callOpenRouter(modelName, prompt, budget);
        if (!text || text.length === 0) break;
        if ((finishReason === 'length' || finishReason === 'MAX_TOKENS') && budget < MAX_ESCALATION_TOKENS) {
          console.warn(`[openrouter] ${modelName} hit token limit at ${budget}; escalating budget.`);
          budget = Math.min(budget * 2, MAX_ESCALATION_TOKENS);
          continue;
        }
        const truncated = finishReason === 'length' || finishReason === 'MAX_TOKENS';
        return { text, truncated, model: `openrouter/${modelName}` };
      } catch (error: any) {
        lastError = error;
        if (isQuotaError(error)) {
          sawCredits = true;
          console.warn(`[openrouter] ${modelName} credits/quota exhausted; trying next model.`);
          break;
        }
        break;
      }
    }
  }

  if (lastError) {
    // Log only the message — never headers, never the key.
    console.warn('[ai] All providers failed:', lastError?.message || lastError);
    if (sawQuota || sawCredits) {
      throw new GeminiUnavailableError(
        'temporarily_unavailable',
        'AI usage quota is exhausted. Please check your Gemini plan or OpenRouter credits.',
      );
    }
  }
  return null;
}

function unavailableError(): GeminiUnavailableError {
  const anyConfigured = isGeminiConfigured() || isOpenRouterConfigured();
  return new GeminiUnavailableError(
    anyConfigured ? 'temporarily_unavailable' : 'not_configured',
    anyConfigured
      ? 'AI generation failed after trying all configured providers.'
      : 'AI generation is not available. Please configure GEMINI_API_KEY or OPENROUTER_API_KEY in your environment.',
  );
}

export async function generateText(
  prompt: string,
  maxOutputTokens: number = DEFAULT_MAX_TOKENS,
): Promise<string> {
  const out = await runWithModels(prompt, maxOutputTokens);
  if (out) {
    if (out.truncated) {
      console.warn('[gemini] Response still truncated after budget escalation.');
    }
    return out.text;
  }
  throw unavailableError();
}

export async function generateTextChecked(
  prompt: string,
  maxOutputTokens: number = DEFAULT_MAX_TOKENS,
): Promise<{ text: string; truncated: boolean; model: string }> {
  const out = await runWithModels(prompt, maxOutputTokens);
  if (out) return out;
  throw unavailableError();
}

export async function generateTextWithFallback(
  prompt: string,
  maxOutputTokens: number = DEFAULT_MAX_TOKENS,
): Promise<{ text: string; provider: string }> {
  const out = await runWithModels(prompt, maxOutputTokens);
  if (out) return { text: out.text, provider: 'gemini' };
  throw unavailableError();
}
