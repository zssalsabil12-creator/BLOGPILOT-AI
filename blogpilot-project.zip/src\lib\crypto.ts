﻿import crypto from 'node:crypto';

/** Constant-time string comparison (case-insensitive) for signature checks. */
export function timingSafeStringCompare(a: string, b: string): boolean {
  const bufA = Buffer.from(String(a).toLowerCase(), 'utf8');
  const bufB = Buffer.from(String(b).toLowerCase(), 'utf8');
  if (bufA.length !== bufB.length) {
    // Burn comparable time to avoid a length oracle.
    crypto.timingSafeEqual(bufA, bufA);
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}
