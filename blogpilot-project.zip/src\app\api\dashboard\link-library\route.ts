import { NextResponse } from 'next/server';
import { z } from 'zod';
import { addLink, listLinks, LINK_TYPES } from '../../../../lib/linkLibrary';
import { getCurrentUserId } from '../../../../lib/auth';
import { apiError } from '@/lib/utils';

const querySchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
  linkType: z.enum(LINK_TYPES).optional(),
  affiliate: z.enum(['true', 'false']).optional(),
  active: z.enum(['true', 'false']).optional(),
  safetyStatus: z.enum(['UNKNOWN', 'SAFE', 'UNSAFE', 'REVIEW']).optional(),
  limit: z.coerce.number().int().positive().optional(),
  offset: z.coerce.number().int().min(0).optional(),
});

export async function GET(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const url = new URL(req.url);
  const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()));
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'Invalid query parameters' }, { status: 400 });
  }

  try {
    const links = await listLinks(userId, {
      q: parsed.data.q,
      category: parsed.data.category,
      linkType: parsed.data.linkType,
      affiliate: parsed.data.affiliate ? parsed.data.affiliate === 'true' : undefined,
      active: parsed.data.active ? parsed.data.active === 'true' : undefined,
      safetyStatus: parsed.data.safetyStatus,
      limit: parsed.data.limit,
      offset: parsed.data.offset,
    });
    return NextResponse.json({ ok: true, data: { links } });
  } catch (error: any) {
    console.error('List links failed', error);
    return NextResponse.json({ ok: false, error: 'Unable to load links' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch (error) {
    return NextResponse.json({ ok: false, error: 'Invalid JSON body' }, { status: 400 });
  }

  try {
    const link = await addLink(userId, body);
    return NextResponse.json({ ok: true, data: { link } });
  } catch (error: any) {
    return apiError('link-library', error);
  }
}
