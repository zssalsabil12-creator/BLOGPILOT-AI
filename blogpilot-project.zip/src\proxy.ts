import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Next.js 16 proxy convention (formerly middleware.ts). Runs in the same edge
// runtime; this implementation only uses Web-standard APIs (crypto.subtle,
// atob, TextEncoder), so authentication behavior is unchanged from the
// previous middleware-based setup.

const AUTH_COOKIE = 'auth_session';

const STATIC_EXTENSIONS = ['.ico', '.svg', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.woff', '.woff2', '.ttf', '.eot', '.css', '.js', '.map'];

const PUBLIC_API_PATHS = [
  '/api/auth/login',
  '/api/auth/signup',
  '/api/auth/me',
  '/api/auth/logout',
  '/api/auth/google',
  '/api/stripe/webhook',
  '/api/paddle/webhook',
  '/api/paypal/webhook',
  '/api/paypal/capture',
  '/api/health',
  '/api/airtm/webhook',
  '/api/payeer/callback',
  // Free tools are public marketing features; each route enforces its own
  // SSRF validation and per-IP rate limiting.
  '/api/free-tools',
  // Affiliate click tracker must be reachable by anonymous article visitors.
  '/api/aff',
  // OAuth callbacks arrive from Google's servers without a session cookie;
  // both flows validate their own signed state parameters.
  '/api/google/auth/callback',
];

const PUBLIC_PAGE_PATHS = [
  '/',
  '/login',
  '/signup',
  '/free-tools',
  // SEO infrastructure must be crawlable by search engines.
  '/sitemap.xml',
  '/robots.txt',
];

async function verifySessionToken(token: string): Promise<boolean> {
  const secret = process.env.AUTH_SECRET;
  if (!secret) return false;

  try {
    const [encoded, signature] = token.split('.');
    if (!encoded || !signature) return false;

    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['verify'],
    );

    const sigBytes = Uint8Array.from(atob(signature.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    const valid = await crypto.subtle.verify('HMAC', key, sigBytes, encoder.encode(encoded));
    if (!valid) return false;

    const data = JSON.parse(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')));
    if (data.exp && Date.now() > data.exp) return false;
    if (!data.userId) return false;

    return true;
  } catch {
    return false;
  }
}

function hasValidSessionFormat(request: NextRequest): boolean {
  const cookie = request.cookies.get(AUTH_COOKIE);
  if (!cookie?.value) return false;
  const parts = cookie.value.split('.');
  return parts.length === 2 && parts[0].length > 0 && parts[1].length > 0;
}

export default async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const isStaticAsset = pathname.startsWith('/_next') || pathname.startsWith('/favicon') || STATIC_EXTENSIONS.some(ext => pathname.endsWith(ext));
  if (isStaticAsset) {
    return NextResponse.next();
  }

  if (PUBLIC_PAGE_PATHS.some(p => pathname === p || pathname.startsWith(p + '/'))) {
    return NextResponse.next();
  }

  if (pathname.startsWith('/api/')) {
    if (PUBLIC_API_PATHS.some(p => pathname === p || pathname.startsWith(p + '/'))) {
      return NextResponse.next();
    }

    if (!hasValidSessionFormat(request)) {
      return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
    }

    const cookie = request.cookies.get(AUTH_COOKIE);
    const valid = await verifySessionToken(cookie!.value);
    if (!valid) {
      return NextResponse.json({ ok: false, error: 'Invalid or expired session' }, { status: 401 });
    }

    return NextResponse.next();
  }

  if (!hasValidSessionFormat(request)) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  const cookie = request.cookies.get(AUTH_COOKIE);
  const valid = await verifySessionToken(cookie!.value);
  if (!valid) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
};
