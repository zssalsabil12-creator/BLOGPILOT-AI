import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/auth'
import { PLAN_CONFIG, activateSubscription, type PlanTier } from '@/lib/stripe'
import {
  buildAirtmReference,
  buildAirtmCheckoutUrl,
  isAirtmConfigured,
} from '@/lib/airtm'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { parseBody } from '@/lib/validation'
import { airtmCheckoutSchema } from '../_validation'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/airtm/checkout
 *
 * Builds a signed Airtm checkout URL for upgrading to a paid plan.
 *
 * Body:
 *   { tier: 'basic' | 'pro' | 'agency' }
 *
 * The backend reads `process.env.ADMIN_AIRTM_EMAIL` at runtime to
 * determine the payment recipient. No email address is ever hardcoded
 * in the application code — the checkout engine dynamically pulls
 * the email value from the environment variable to generate direct
 * Airtm payment invoices for users.
 *
 * Response (live mode):
 *   200 { url, reference, demo: false }
 *
 * Response (demo mode — no ADMIN_AIRTM_EMAIL configured):
 *   200 { demo: true, url, message }
 *   The demo path activates the subscription locally so the user can
 *   try the upgrade flow end-to-end without a real Airtm account.
 *
 * Funds routing:
 *   When the user pays via Airtm, the money lands in the Airtm
 *   account identified by ADMIN_AIRTM_EMAIL — i.e., the admin's
 *   Airtm wallet. There is no separate payout config; the email
 *   variable is the sole routing mechanism.
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit (10 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(airtmCheckoutSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const tier = body.tier as PlanTier
    if (!tier || !(tier in PLAN_CONFIG) || tier === 'free') {
      return NextResponse.json(
        { error: `Invalid tier. Must be one of: basic, pro, agency`, code: 'validation' },
        { status: 400 }
      )
    }

    const origin =
      request.headers.get('origin') ||
      process.env.NEXT_PUBLIC_APP_URL ||
      'http://localhost:3000'

    // ─── Demo mode ──────────────────────────────────────────────────────
    // ADMIN_AIRTM_EMAIL not configured — activate the subscription locally
    // and return a simulated checkout URL so the front-end can complete
    // the flow.
    if (!isAirtmConfigured()) {
      const result = await activateSubscription({
        userId: user.id,
        tier,
        gateway: 'demo',
        externalId: `demo-airtm-${Date.now()}`,
      })

      return NextResponse.json({
        demo: true,
        url: `/dashboard?demo_checkout=success&tier=${tier}&gateway=airtm`,
        message: `Demo mode: upgraded to ${PLAN_CONFIG[tier].label} via Airtm (simulated). ${
          result.creditsGranted ? `${result.creditsGranted} credits granted.` : ''
        }`,
        reference: `demo-ref-${Date.now()}`,
      })
    }

    // ─── Live mode ──────────────────────────────────────────────────────
    // Build the checkout URL. The admin's Airtm email (ADMIN_AIRTM_EMAIL)
    // is read at runtime inside buildAirtmCheckoutUrl and used as the
    // payment recipient — no email is hardcoded anywhere in this file.
    const reference = buildAirtmReference(user.id, tier)
    const successUrl = `${origin}/dashboard?airtm=success&tier=${tier}&ref=${reference}`
    const cancelUrl = `${origin}/dashboard?airtm=cancelled`
    const statusUrl = `${origin}/api/airtm/webhook`

    const url = buildAirtmCheckoutUrl({
      tier,
      userId: user.id,
      reference,
      successUrl,
      cancelUrl,
      statusUrl,
    })

    if (!url) {
      return NextResponse.json(
        { error: 'Failed to build Airtm checkout URL — ADMIN_AIRTM_EMAIL may be missing', code: 'airtm_error' },
        { status: 500 }
      )
    }

    // Persist a pending subscription row so we can match the webhook later
    await db.subscription.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        plan: tier,
        status: 'incomplete',
        stripeSubscriptionId: reference, // borrowed column — stores Airtm reference
      },
      update: {
        plan: tier,
        status: 'incomplete',
        stripeSubscriptionId: reference,
      },
    })

    return NextResponse.json({
      url,
      reference,
      demo: false,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'airtm/checkout')
  }
}
