import { NextResponse } from 'next/server'
import { requireUser, AuthError } from '@/lib/auth'
import {
  PLAN_CONFIG,
  PAID_PLAN_TIERS,
  isStripeConfigured,
  isDemoMode,
  getConfiguredPriceId,
  tierFromSubscription,
  type PlanTier,
} from '@/lib/stripe'
import { db } from '@/lib/db'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { handleApiError } from '@/lib/api-errors'

/**
 * GET /api/stripe/config
 * Returns the public Stripe config + the current user's subscription state.
 *
 * Used by the Billing page and the Upgrade dialog to render plan options
 * without exposing the secret key.
 *
 * Response:
 *   200 {
 *     publishableKey: string | null,
 *     demoMode: boolean,
 *     currentTier: PlanTier,
 *     subscription: { plan, status, currentPeriodEnd, cancelAtPeriodEnd } | null,
 *     plans: Array<{ tier, label, priceUsd, credits, blurb, accent, priceId }>
 *   }
 */
export async function GET(request: Request) {
  try {
    // ─── Rate limit ───
    const blocked = rateLimit(request, RATE_LIMITS.read)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const subscription = await db.subscription.findUnique({
      where: { userId: user.id },
    })

    const currentTier = tierFromSubscription(subscription)

    const plans = PAID_PLAN_TIERS.map((tier) => {
      const cfg = PLAN_CONFIG[tier]
      return {
        tier,
        label: cfg.label,
        priceUsd: cfg.priceUsdCents / 100,
        credits: cfg.credits,
        blurb: cfg.blurb,
        accent: cfg.accent,
        priceId: getConfiguredPriceId(tier),
      }
    })

    return NextResponse.json({
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || null,
      demoMode: isDemoMode(),
      stripeConfigured: isStripeConfigured(),
      currentTier,
      subscription: subscription
        ? {
            plan: subscription.plan as PlanTier,
            status: subscription.status,
            currentPeriodEnd: subscription.currentPeriodEnd?.toISOString() || null,
            cancelAtPeriodEnd: subscription.cancelAtPeriodEnd,
            stripeCustomerId: subscription.stripeCustomerId ? true : false,
          }
        : null,
      plans,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'stripe/config')
  }
}
