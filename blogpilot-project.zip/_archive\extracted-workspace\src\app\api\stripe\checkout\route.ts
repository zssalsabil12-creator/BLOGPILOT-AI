import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireUser, AuthError } from '@/lib/auth'
import {
  getStripe,
  getConfiguredPriceId,
  isDemoMode,
  PLAN_CONFIG,
  type PlanTier,
} from '@/lib/stripe'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { stripeCheckoutSchema, parseBody } from '@/lib/validation'
import { handleApiError } from '@/lib/api-errors'

/**
 * POST /api/stripe/checkout
 * Creates a Stripe Checkout Session for upgrading to a paid plan.
 *
 * Body:
 *   { tier: 'basic' | 'pro' | 'agency' }
 *
 * In demo mode (no STRIPE_SECRET_KEY), returns a fake checkout URL
 * pointing to /billing?demo_checkout=<tier> so the front-end can simulate
 * the success flow without a real Stripe account.
 *
 * Response:
 *   200 { url: string, sessionId?: string, demo: boolean }
 *   400 if tier is invalid
 *   401 if not authenticated
 */
export async function POST(request: Request) {
  try {
    // ─── Rate limit (10 / minute / user) ───
    const blocked = rateLimit(request, RATE_LIMITS.stripe)
    if (blocked) return blocked

    const { user } = await requireUser(request)

    const raw = await request.json().catch(() => null)
    if (raw === null) {
      return NextResponse.json(
        { error: 'Invalid JSON payload.', code: 'validation' },
        { status: 400 }
      )
    }

    const [body, validationError] = parseBody(stripeCheckoutSchema, raw)
    if (validationError || !body) {
      return NextResponse.json(
        { error: validationError || 'Invalid request', code: 'validation' },
        { status: 400 }
      )
    }

    const tier = body.tier as PlanTier

    if (!tier || !(tier in PLAN_CONFIG) || tier === 'free') {
      return NextResponse.json(
        { error: `Invalid tier. Must be one of: basic, pro, agency`, code: 'validation' },
        { status: 400 }
      )
    }

    const priceId = getConfiguredPriceId(tier)
    const stripe = getStripe()

    // ─── Demo mode ──────────────────────────────────────────────────────
    // No STRIPE_SECRET_KEY configured — return a simulated checkout URL
    // and immediately grant the credits so the user can try the upgrade
    // flow end-to-end without a real Stripe account.
    if (!stripe || isDemoMode()) {
      // In demo mode we proactively grant the plan's credits so the user
      // can immediately see the effect. (Production mode waits for the
      // webhook.)
      const credits = PLAN_CONFIG[tier].credits
      if (credits !== null) {
        await db.user.update({
          where: { id: user.id },
          data: { credits: { increment: credits } },
        })
      } else {
        // Unlimited — set a high balance
        await db.user.update({
          where: { id: user.id },
          data: { credits: 99999 },
        })
      }

      // Upsert subscription row to reflect the new plan
      await db.subscription.upsert({
        where: { userId: user.id },
        create: {
          userId: user.id,
          plan: tier,
          status: 'active',
          stripePriceId: priceId,
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        },
        update: {
          plan: tier,
          status: 'active',
          stripePriceId: priceId,
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          cancelAtPeriodEnd: false,
        },
      })

      // Log a credit transaction for audit
      if (credits !== null && credits > 0) {
        await db.creditTransaction.create({
          data: {
            userId: user.id,
            amount: credits,
            reason: 'topup',
            description: `Demo upgrade to ${PLAN_CONFIG[tier].label} (${credits} credits)`,
            balanceAfter: (user.credits || 0) + credits,
          },
        })
      }

      return NextResponse.json({
        url: `/dashboard?demo_checkout=success&tier=${tier}`,
        demo: true,
        message: `Demo mode: upgraded to ${PLAN_CONFIG[tier].label} and granted ${credits ?? 'unlimited'} credits.`,
      })
    }

    // ─── Live mode ──────────────────────────────────────────────────────
    // Resolve or create a Stripe Customer for this user.
    let customerId: string | undefined
    const existingSub = await db.subscription.findUnique({
      where: { userId: user.id },
    })

    if (existingSub?.stripeCustomerId) {
      customerId = existingSub.stripeCustomerId
    } else {
      const customer = await stripe.customers.create({
        email: user.email ?? undefined,
        name: user.name || undefined,
        metadata: { userId: user.id },
      })
      customerId = customer.id

      // Persist the customer id immediately so we can link webhook events
      await db.subscription.upsert({
        where: { userId: user.id },
        create: {
          userId: user.id,
          plan: 'free',
          status: 'active',
          stripeCustomerId: customerId,
        },
        update: { stripeCustomerId: customerId },
      })
    }

    const origin = request.headers.get('origin') ||
      process.env.NEXT_PUBLIC_APP_URL ||
      'http://localhost:3000'

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${origin}/dashboard?checkout=success&tier=${tier}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/dashboard?checkout=cancelled`,
      allow_promotion_codes: true,
      subscription_data: {
        metadata: { userId: user.id, tier },
      },
      metadata: { userId: user.id, tier },
    })

    return NextResponse.json({
      url: session.url,
      sessionId: session.id,
      demo: false,
    })
  } catch (e) {
    if (e instanceof AuthError) {
      return NextResponse.json({ error: e.message, code: 'auth' }, { status: e.statusCode })
    }
    return handleApiError(e, 'stripe/checkout')
  }
}
