'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  BarChart3,
  PenTool,
  Clock,
  Globe,
  DollarSign,
  CreditCard,
  ChevronsLeft,
  ChevronsRight,
  LogOut,
  Menu,
  Sparkles,
  X,
  FileText,
  Zap,
  Target,
  Layers,
  Megaphone,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAppStore, type DashboardTab } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from '@/components/ui/sheet'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import AnalyticsPage from './analytics-page'
import OpportunitiesPage from './opportunities-page'
import ContentStrategyPage from './content-strategy-page'
import GenerateArticlePage from './generate-article-page'
import HistoryPage from './history-page'
import ConnectedSitesPage from './connected-sites-page'
import AffiliateCredentialsPage from './affiliate-credentials-page'
import AffiliateCampaignsPage from './affiliate-campaigns-page'
import BillingPage from './billing-page'
import EditorPage from './editor-page'

interface NavItem {
  id: DashboardTab
  label: string
  icon: React.ComponentType<{ className?: string }>
}

interface NavGroup {
  label: string
  items: NavItem[]
}

const NAV_GROUPS: NavGroup[] = [
  {
    label: 'Growth',
    items: [
      { id: 'opportunities', label: 'SEO Opportunities', icon: Target },
      { id: 'content-strategy', label: 'Content Strategy', icon: Layers },
    ],
  },
  {
    label: 'Workspace',
    items: [
      { id: 'analytics', label: 'Analytics', icon: BarChart3 },
      { id: 'generate-article', label: 'Generate Article', icon: PenTool },
      { id: 'history', label: 'History', icon: Clock },
    ],
  },
  {
    label: 'Publishing',
    items: [
      { id: 'connected-sites', label: 'Connected Sites', icon: Globe },
    ],
  },
  {
    label: 'Monetization',
    items: [
      { id: 'affiliate-campaigns', label: 'Affiliate Campaigns', icon: Megaphone },
      { id: 'affiliate-credentials', label: 'Payment Credentials', icon: DollarSign },
      { id: 'billing', label: 'Billing', icon: CreditCard },
    ],
  },
]

const ALL_NAV_ITEMS = NAV_GROUPS.flatMap((g) => g.items)

const TAB_TITLES: Record<DashboardTab, string> = {
  opportunities: 'SEO Opportunities',
  'content-strategy': 'Content Strategy',
  analytics: 'Analytics',
  'generate-article': 'Generate Article',
  history: 'History',
  'connected-sites': 'Connected Sites',
  'affiliate-campaigns': 'Affiliate Campaigns',
  'affiliate-credentials': 'Payment Credentials',
  billing: 'Billing',
  editor: 'Editor',
}

const TAB_DESCRIPTIONS: Record<DashboardTab, string> = {
  opportunities: 'What should I do next - from real Search Console data',
  'content-strategy': 'Topical authority, refreshes, and SERP gaps',
  analytics: 'Performance overview across your content',
  'generate-article': 'Create a new SEO-optimized article',
  history: 'Browse and manage your generated articles',
  'connected-sites': 'Manage WordPress and Blogger destinations',
  'affiliate-campaigns': 'Commercial content clusters with real click tracking',
  'affiliate-credentials': 'Store and manage your payment provider keys',
  billing: 'Plans, credits and payment methods',
  editor: 'Edit your article',
}

const PLAN_STYLES: Record<string, string> = {
  free: 'border-slate-500/30 bg-slate-500/10 text-slate-300',
  starter: 'border-cyan-400/30 bg-cyan-400/10 text-cyan-300',
  pro: 'border-violet-400/30 bg-violet-400/10 text-violet-300',
  agency: 'border-fuchsia-400/30 bg-fuchsia-400/10 text-fuchsia-300',
}

function getInitials(name: string | null, email: string): string {
  if (name) {
    return name
      .split(' ')
      .map((w) => w[0])
      .join('')
      .toUpperCase()
      .slice(0, 2)
  }
  return email.slice(0, 2).toUpperCase()
}

function PlanBadge({ plan, className }: { plan?: string; className?: string }) {
  const key = (plan || 'free').toLowerCase()
  const label = key.charAt(0).toUpperCase() + key.slice(1)
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold tracking-wide',
        PLAN_STYLES[key] || PLAN_STYLES.free,
        className,
      )}
    >
      <Sparkles className="size-3" />
      {label}
    </span>
  )
}

function CreditsPill({ compact = false }: { compact?: boolean }) {
  const user = useAppStore((s) => s.user)
  if (!user) return null
  const credits = typeof user.credits === 'number' ? user.credits : 0
  return (
    <div
      className={cn(
        'inline-flex items-center gap-2 rounded-full border border-cyan-400/25 bg-gradient-to-r from-cyan-400/12 to-violet-500/12 text-cyan-200',
        compact ? 'px-3 py-1' : 'w-full px-3 py-2',
      )}
      title={`${credits} generation credits available`}
    >
      <Zap className={cn('shrink-0 text-cyan-300', compact ? 'size-3.5' : 'size-4')} />
      {!compact && (
        <div className="flex min-w-0 flex-1 flex-col">
          <span className="text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
            Credits
          </span>
          <span className="text-sm font-bold tabular-nums">{credits}</span>
        </div>
      )}
      {compact && <span className="text-xs font-bold tabular-nums">{credits}</span>}
    </div>
  )
}

function SidebarContent({
  collapsed,
  onNavigate,
  onMobileClose,
}: {
  collapsed: boolean
  onNavigate: (tab: DashboardTab) => void
  onMobileClose?: () => void
}) {
  const { user, currentDashboardTab, toggleSidebar, logout } = useAppStore()

  const handleLogout = () => {
    fetch('/api/auth/logout', { method: 'POST' }).catch(() => {})
    logout()
    window.location.href = '/'
  }

  const handleNav = (tab: DashboardTab) => {
    onNavigate(tab)
    onMobileClose?.()
  }

  const renderNavItem = (item: NavItem) => {
    const Icon = item.icon
    const isActive = currentDashboardTab === item.id

    const button = (
      <button
        key={item.id}
        onClick={() => handleNav(item.id)}
        className={cn(
          'group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200',
          collapsed && 'justify-center px-2',
          isActive
            ? 'nav-rail bg-gradient-to-r from-cyan-400/15 to-violet-500/15 text-cyan-100'
            : 'text-muted-foreground hover:bg-accent hover:text-foreground',
        )}
      >
        {isActive && (
          <motion.div
            layoutId="sidebar-active"
            className="absolute inset-0 rounded-lg border border-cyan-400/20 bg-gradient-to-r from-cyan-400/15 to-violet-500/15"
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          />
        )}
        <Icon className={cn('relative z-10 size-[18px] shrink-0 transition-transform duration-200 group-hover:scale-110', isActive && 'text-cyan-300')} />
        {!collapsed && (
          <span className="relative z-10 truncate">{item.label}</span>
        )}
        {!collapsed && !isActive && (
          <span className="relative z-10 ml-auto h-1.5 w-1.5 rounded-full bg-transparent transition-colors group-hover:bg-muted-foreground/40" />
        )}
      </button>
    )

    if (collapsed) {
      return (
        <Tooltip key={item.id}>
          <TooltipTrigger asChild>{button}</TooltipTrigger>
          <TooltipContent side="right" sideOffset={8}>
            {item.label}
          </TooltipContent>
        </Tooltip>
      )
    }

    return button
  }

  return (
    <div className="flex h-full flex-col">
      <div className={cn('flex items-center gap-3 px-4 pt-5 pb-4', collapsed && 'justify-center px-2')}>
        <div className="relative flex size-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/30">
          <Sparkles className="size-5 text-white" />
          <span className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/20" />
        </div>
        {!collapsed && (
          <motion.span
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -8 }}
            className="text-lg font-bold tracking-tight"
          >
            BlogPilot <span className="text-gradient">AI</span>
          </motion.span>
        )}
      </div>

      <Separator className="opacity-10" />

      <ScrollArea className="flex-1 py-3">
        <nav className="flex flex-col gap-4 px-3">
          {NAV_GROUPS.map((group) => (
            <div key={group.label}>
              {!collapsed && (
                <p className="mb-1.5 px-3 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">
                  {group.label}
                </p>
              )}
              {collapsed && <div className="mx-auto mb-2 h-px w-6 bg-border/60" />}
              <div className="flex flex-col gap-1">
                {group.items.map(renderNavItem)}
              </div>
            </div>
          ))}
        </nav>
      </ScrollArea>

      <Separator className="opacity-10" />

      <div className={cn('space-y-3 px-3 py-4', collapsed && 'px-2')}>
        {!collapsed && user && (
          <>
            <CreditsPill />
            <div className="flex items-center gap-3 rounded-xl border border-border/70 bg-card/50 px-3 py-2.5">
              <Avatar className="size-9 border border-border">
                <AvatarFallback className="bg-gradient-to-br from-cyan-400/20 to-violet-500/20 text-xs font-semibold text-cyan-300">
                  {getInitials(user.name, user.email)}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-foreground">
                  {user.name || 'User'}
                </p>
                <p className="truncate text-xs text-muted-foreground">{user.email}</p>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleLogout}
                    className="size-8 shrink-0 text-muted-foreground hover:text-destructive"
                  >
                    <LogOut className="size-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="top">Sign out</TooltipContent>
              </Tooltip>
            </div>
            <PlanBadge plan={user.subscription?.plan} className="w-full justify-center" />
          </>
        )}

        {collapsed && (
          <div className="flex flex-col items-center gap-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Avatar
                  className="size-9 cursor-pointer border border-border"
                  onClick={handleLogout}
                >
                  <AvatarFallback className="bg-gradient-to-br from-cyan-400/20 to-violet-500/20 text-xs font-semibold text-cyan-300">
                    {user ? getInitials(user.name, user.email) : '??'}
                  </AvatarFallback>
                </Avatar>
              </TooltipTrigger>
              <TooltipContent side="right" sideOffset={8}>
                {user?.name || 'User'} — Click to logout
              </TooltipContent>
            </Tooltip>
            <PlanBadge plan={user?.subscription?.plan} />
          </div>
        )}

        <Button
          variant="ghost"
          onClick={toggleSidebar}
          className={cn(
            'w-full text-muted-foreground hover:text-foreground',
            collapsed && 'px-2'
          )}
          size={collapsed ? 'icon' : 'sm'}
        >
          {collapsed ? (
            <ChevronsRight className="size-4" />
          ) : (
            <>
              <ChevronsLeft className="size-4" />
              <span className="ml-1">Collapse</span>
            </>
          )}
        </Button>
      </div>
    </div>
  )
}

function MainContent() {
  const { currentDashboardTab, user } = useAppStore()

  const pageTitle = TAB_TITLES[currentDashboardTab] || 'Dashboard'
  const pageDescription = TAB_DESCRIPTIONS[currentDashboardTab] || ''
  const greeting = user?.name ? `Welcome back, ${user.name}` : 'Welcome back'

  const renderTab = () => {
    switch (currentDashboardTab) {
      case 'opportunities':
        return <OpportunitiesPage />
      case 'content-strategy':
        return <ContentStrategyPage />
      case 'analytics':
        return <AnalyticsPage />
      case 'generate-article':
        return <GenerateArticlePage />
      case 'history':
        return <HistoryPage />
      case 'connected-sites':
        return <ConnectedSitesPage />
      case 'affiliate-credentials':
        return <AffiliateCredentialsPage />
      case 'affiliate-campaigns':
        return <AffiliateCampaignsPage />
      case 'billing':
        return <BillingPage />
      case 'editor':
        return <EditorPage />
      default:
        return <AnalyticsPage />
    }
  }

  return (
    <div className="flex flex-1 flex-col overflow-hidden">
      <header className="glass sticky top-0 z-10 border-b border-border">
        <div className="pointer-events-none absolute inset-x-0 -bottom-px h-px bg-gradient-to-r from-transparent via-cyan-400/40 to-transparent" />
        <div className="flex items-center justify-between px-6 py-4">
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-foreground">{pageTitle}</h1>
            <p className="mt-0.5 text-sm text-muted-foreground">
              {currentDashboardTab === 'analytics' ? greeting : pageDescription}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:block">
              <CreditsPill compact />
            </div>
            <div className="hidden md:block">
              <PlanBadge plan={user?.subscription?.plan} />
            </div>
            {user && (
              <Avatar className="size-9 border border-ring/40 shadow-[0_0_16px_-4px_rgba(34,211,238,0.5)]">
                <AvatarFallback className="bg-gradient-to-br from-cyan-400/20 to-violet-500/20 text-xs font-semibold text-cyan-300">
                  {getInitials(user.name, user.email)}
                </AvatarFallback>
              </Avatar>
            )}
          </div>
        </div>
      </header>

      <ScrollArea className="flex-1">
        <div className="mx-auto max-w-6xl p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentDashboardTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2, ease: 'easeInOut' }}
            >
              {renderTab()}
            </motion.div>
          </AnimatePresence>
        </div>
      </ScrollArea>
    </div>
  )
}

export default function Dashboard() {
  const { isSidebarOpen, currentDashboardTab, setDashboardTab, user, login, logout } = useAppStore()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [authChecking, setAuthChecking] = useState(true)

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768)
    check()
    window.addEventListener('resize', check)
    return () => window.removeEventListener('resize', check)
  }, [])

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const tab = params.get('tab')
    if (tab && (['opportunities', 'content-strategy', 'analytics', 'generate-article', 'connected-sites', 'affiliate-campaigns', 'affiliate-credentials', 'history', 'editor', 'billing'] as string[]).includes(tab)) {
      setDashboardTab(tab as DashboardTab)
    }
  }, [setDashboardTab])

  useEffect(() => {
    let cancelled = false
    const restoreSession = async () => {
      try {
        const res = await fetch('/api/auth/me')
        if (!cancelled) {
          if (res.ok) {
            const json = await res.json()
            if (json?.user && !useAppStore.getState().user) {
              login(json.user)
            }
          } else {
            window.location.href = '/login'
          }
        }
      } catch {
        if (!cancelled) window.location.href = '/login'
      } finally {
        if (!cancelled) setAuthChecking(false)
      }
    }
    restoreSession()
    return () => { cancelled = true }
  }, [login])

  if (authChecking) {
    return (
      <div className="relative flex h-screen items-center justify-center overflow-hidden bg-background">
        <div className="aurora" />
        <div className="relative flex flex-col items-center gap-5">
          <div className="relative flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-violet-500 shadow-lg shadow-cyan-500/40">
            <Sparkles className="size-7 animate-pulse text-white" />
            <span className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/25" />
          </div>
          <div className="h-1 w-36 overflow-hidden rounded-full bg-accent/60">
            <motion.div
              className="h-full w-1/3 rounded-full bg-gradient-to-r from-cyan-400 to-violet-500"
              animate={{ x: ['-120%', '320%'] }}
              transition={{ repeat: Infinity, duration: 1.1, ease: 'easeInOut' }}
            />
          </div>
        </div>
      </div>
    )
  }

  const isPro = user?.subscription?.plan === 'pro' || user?.subscription?.plan === 'enterprise'

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {isMobile ? (
        <div className="flex flex-1 flex-col overflow-hidden">
          <header className="glass sticky top-0 z-30 flex items-center gap-3 border-b border-border px-4 py-3">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="shrink-0 md:hidden">
                  <Menu className="size-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 border-border bg-background p-0">
                <SheetTitle className="sr-only">Navigation</SheetTitle>
                <SidebarContent
                  collapsed={false}
                  onNavigate={(tab) => {
                    setDashboardTab(tab)
                    setMobileOpen(false)
                  }}
                  onMobileClose={() => setMobileOpen(false)}
                />
              </SheetContent>
            </Sheet>
            <div className="flex flex-1 items-center justify-between pr-1">
              <div className="flex items-center gap-2">
                <div className="flex size-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-violet-500">
                  <Sparkles className="size-4 text-white" />
                </div>
                <span className="text-base font-bold tracking-tight">
                  BlogPilot <span className="text-gradient">AI</span>
                </span>
              </div>
              <CreditsPill compact />
            </div>
          </header>
          <MainContent />
        </div>
      ) : (
        <>
          <AnimatePresence initial={false}>
            {isSidebarOpen ? (
              <motion.aside
                key="sidebar-open"
                initial={{ width: 64 }}
                animate={{ width: 268 }}
                exit={{ width: 64 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="glass relative z-20 flex h-screen shrink-0 flex-col border-r border-border"
              >
                <div className="pointer-events-none absolute inset-y-0 right-0 w-px bg-gradient-to-b from-transparent via-cyan-400/30 to-transparent" />
                <SidebarContent
                  collapsed={false}
                  onNavigate={(tab) => setDashboardTab(tab)}
                />
              </motion.aside>
            ) : (
              <motion.aside
                key="sidebar-closed"
                initial={{ width: 268 }}
                animate={{ width: 64 }}
                exit={{ width: 268 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="glass relative z-20 flex h-screen shrink-0 flex-col border-r border-border"
              >
                <SidebarContent
                  collapsed={true}
                  onNavigate={(tab) => setDashboardTab(tab)}
                />
              </motion.aside>
            )}
          </AnimatePresence>

          <main className="flex flex-1 flex-col overflow-hidden">
            <MainContent />
          </main>
        </>
      )}

      {!isPro && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.4 }}
          className="fixed bottom-6 right-6 z-50 md:bottom-8 md:right-8"
        >
          <Button
            onClick={() => setDashboardTab('billing')}
            className="group relative gap-2 rounded-full px-6 py-5 text-sm font-semibold text-white shadow-lg shadow-violet-600/30 transition-transform hover:scale-[1.03]"
            style={{
              background: 'linear-gradient(135deg, #22d3ee, #a78bfa, #e879f9)',
            }}
          >
            <span className="absolute inset-0 rounded-full ring-1 ring-inset ring-white/30" />
            <Sparkles className="size-4 transition-transform group-hover:rotate-12" />
            Upgrade to Pro
          </Button>
        </motion.div>
      )}
    </div>
  )
}
