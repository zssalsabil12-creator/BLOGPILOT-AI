/**
 * Content versioning: snapshots before any AI/agent content mutation, with
 * restore. Versions are append-only; version numbers are per-article.
 */

import prisma from '@/lib/prisma';

export async function snapshotVersion(
  userId: string,
  articleId: string,
  label: string,
): Promise<number | null> {
  const article = await prisma.article.findFirst({
    where: { id: articleId, userId },
    select: { title: true, content: true },
  });
  if (!article) return null;

  const last = await prisma.articleVersion.findFirst({
    where: { articleId },
    orderBy: { version: 'desc' },
    select: { version: true },
  });

  const nextVersion = (last?.version ?? 0) + 1;
  await prisma.articleVersion.create({
    data: {
      articleId,
      userId,
      version: nextVersion,
      label: label.slice(0, 120),
      title: article.title,
      content: article.content || '',
    },
  });
  return nextVersion;
}

export async function listVersions(userId: string, articleId: string) {
  // Ownership check via parent article.
  const owns = await prisma.article.findFirst({ where: { id: articleId, userId }, select: { id: true } });
  if (!owns) throw Object.assign(new Error('Article not found'), { statusCode: 404 });

  return prisma.articleVersion.findMany({
    where: { articleId },
    orderBy: { version: 'desc' },
    select: { id: true, version: true, label: true, title: true, createdAt: true },
  });
}

export async function getVersion(userId: string, articleId: string, versionId: string) {
  const owns = await prisma.article.findFirst({ where: { id: articleId, userId }, select: { id: true } });
  if (!owns) throw Object.assign(new Error('Article not found'), { statusCode: 404 });

  return prisma.articleVersion.findFirst({ where: { id: versionId, articleId } });
}

/** Restores a version — snapshots current state first so restore is reversible. */
export async function restoreVersion(userId: string, articleId: string, versionId: string): Promise<{ restoredFrom: number; newSnapshot: number | null }> {
  const version = await getVersion(userId, articleId, versionId);
  if (!version) throw Object.assign(new Error('Version not found'), { statusCode: 404 });

  const snap = await snapshotVersion(userId, articleId, `before-restore-from-v${version.version}`);

  await prisma.article.update({
    where: { id: articleId },
    data: { title: version.title, content: version.content },
  });

  return { restoredFrom: version.version, newSnapshot: snap };
}
