'use client'

import { useState, useCallback, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Sparkles,
  Target,
  Wand2,
  DollarSign,
  FileText,
  CheckCircle2,
  Loader2,
  ArrowRight,
  Copy,
  Save,
  Search,
  Brain,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  TrendingUp,
  ExternalLink,
  Settings,
  ShoppingCart,
  Star,
  ThumbsUp,
  ThumbsDown,
  Image as ImageIcon,
  Package,
  BarChart3,
  Zap,
  AlertTriangle,
  Info,
  Globe,
  Coins,
  Cpu,
} from 'lucide-react'
import { UpgradeDialog } from './upgrade-dialog'

// ─── Types ───

interface Product {
  id: string
  name: string
  brand: string
  price: number
  originalPrice?: number
  currency: string
  rating: number
  reviewCount: number
  imageUrl: string
  affiliateUrl: string
  platform: string
  specs: Record<string, string>
  pros: string[]
  cons: string[]
  badge?: string
  inStock: boolean
}

interface ArticleImage {
  url: string
  alt: string
  width: number
  height: number
  source: 'unsplash' | 'placeholder'
  seoAltText: string
}

interface CompetitorAnalysis {
  searchResults: any[]
  headingStructure: any[]
  commonTopics: string[]
  uniqueTopics: string[]
  informationGaps: string[]
  averageWordCount: number
  pagesAnalyzed: number
}

interface OutlineSection {
  heading: string
  level: number
  purpose: string
  estimatedWords?: number
  subsections: Array<{
    heading: string
    level: number
    keyPoints: string[]
    targetKeywords: string[]
    estimatedWords?: number
  }>
  targetKeywords: string[]
  competitiveAdvantage: string
}

interface ArticleOutline {
  suggestedTitle: string
  metaDescription: string
  informationGainScore: number
  estimatedWordCount: number
  sections: OutlineSection[]
  targetKeywords: string[]
  relatedKeywords?: string[]
  schemaMarkup: string
  recommendedInternalLinks?: string[]
}

interface GeneratedArticle {
  title: string
  content: string
  excerpt: string
  wordCount: number
  seoScore: number
  keywords: string[]
  hasProducts?: boolean
  productCount?: number
  hasComparisonTable?: boolean
  comparisonTable?: string | null
  language?: string
  intent?: string
  model?: string
  provider?: string
  tokensUsed?: number | null
  creditsRemaining?: number
  articleId?: string
}

type WorkflowStep = 'idle' | 'analyzing' | 'products' | 'outline' | 'generating' | 'complete'

// ─── Component ───

export function GenerateArticlePage() {
  // Config state
  const [keyword, setKeyword] = useState('')
  const [topic, setTopic] = useState('')
  const [tone, setTone] = useState('professional')
  const [length, setLength] = useState('medium')
  const [affiliatePlatform, setAffiliatePlatform] = useState('amazon')
  const [enableFactCheck, setEnableFactCheck] = useState(false)
  const [language, setLanguage] = useState('en')
  const [intent, setIntent] = useState<'informational' | 'commercial'>('informational')
  const [creditsRemaining, setCreditsRemaining] = useState<number | null>(null)
  const [providerInfo, setProviderInfo] = useState<{ provider: string; configured: boolean } | null>(null)
  const [upgradeOpen, setUpgradeOpen] = useState(false)
  const [upgradeMessage, setUpgradeMessage] = useState<string | undefined>(undefined)
  const [suggestedTier, setSuggestedTier] = useState<'basic' | 'pro' | 'agency' | null>(null)

  // Gemini settings (admin-only)
  const [showSettings, setShowSettings] = useState(false)
  const [geminiKey, setGeminiKey] = useState('')
  const [serperKey, setSerperKey] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)

  // Workflow state
  const [currentStep, setCurrentStep] = useState<WorkflowStep>('idle')
  const [progress, setProgress] = useState(0)
  const [progressLabel, setProgressLabel] = useState('')

  // Data state
  const [competitorAnalysis, setCompetitorAnalysis] = useState<CompetitorAnalysis | null>(null)
  const [outline, setOutline] = useState<ArticleOutline | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [images, setImages] = useState<ArticleImage[]>([])
  const [generatedArticle, setGeneratedArticle] = useState<GeneratedArticle | null>(null)
  const [factCheckData, setFactCheckData] = useState<any>(null)

  // UI state
  const [expandedSections, setExpandedSections] = useState<Set<number>>(new Set())
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  // ─── Check if current user is admin ───
  useEffect(() => {
    ;(async () => {
      try {
        const res = await fetch('/api/admin/config')
        if (res.ok) {
          setIsAdmin(true)
        }
      } catch {
        // Not admin — API settings panel will be hidden
      }
    })()
  }, [])

  // ─── Settings handlers (admin-only) ───
  const handleSaveKeys = async () => {
    try {
      if (geminiKey) localStorage.setItem('blogpilot_gemini_key', geminiKey)
      if (serperKey) localStorage.setItem('blogpilot_serper_key', serperKey)
      toast.success('API keys saved')
      setShowSettings(false)
    } catch {
      toast.error('Failed to save keys')
    }
  }

  // ─── Fetch credit balance on mount ───
  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const res = await fetch('/api/credits')
        if (res.ok) {
          const data = await res.json()
          if (mounted) setCreditsRemaining(data.balance)
        }
      } catch {
        // Silent — credits are non-blocking
      }
    })()
    return () => {
      mounted = false
    }
  }, [])

  // ─── Step 1: Analyze Competitors ───
  const handleAnalyze = useCallback(async () => {
    if (!keyword.trim()) {
      toast.error('Please enter a target keyword')
      return
    }

    setCurrentStep('analyzing')
    setProgress(0)
    setProgressLabel('Scraping competitor pages...')
    setCompetitorAnalysis(null)
    setOutline(null)
    setProducts(null as any)
    setImages(null as any)
    setGeneratedArticle(null)
    setFactCheckData(null)

    try {
      setProgress(15)
      setProgressLabel('Fetching top 5 ranking URLs...')

      const response = await fetch('/api/generate-outline', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: keyword.trim(),
          topic: topic.trim() || undefined,
          tone,
          length,
          affiliatePlatform,
          enableFactCheck,
        }),
      })

      if (!response.ok) {
        const err = await response.json()
        throw new Error(err.error || 'Analysis failed')
      }

      setProgress(60)
      setProgressLabel('AI analyzing competitor gaps...')

      const data = await response.json()

      setProgress(85)
      setProgressLabel('Generating optimized outline...')

      if (data.competitorAnalysis) setCompetitorAnalysis(data.competitorAnalysis)
      if (data.outline) setOutline(data.outline)
      if (data.factCheck) setFactCheckData(data.factCheck)

      setProgress(100)
      setProgressLabel('Analysis complete!')
      setCurrentStep('products')

      toast.success('Competitor analysis complete!', {
        description: `Found ${data.competitorAnalysis?.pagesAnalyzed || 5} pages, ${data.outline?.sections?.length || 0} outline sections.`,
      })

      if (data.outline?.sections?.length) {
        setExpandedSections(new Set([0]))
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Analysis failed. Please try again.')
      setCurrentStep('idle')
      setProgress(0)
    }
  }, [keyword, topic, tone, length, affiliatePlatform, enableFactCheck])

  // ─── Step 2: Fetch Products ───
  const handleFetchProducts = useCallback(async () => {
    setCurrentStep('products')
    setProgress(0)
    setProgressLabel('Searching for trending products...')
    setProducts(null as any)
    setImages(null as any)
    setGeneratedArticle(null)

    try {
      setProgress(20)
      setProgressLabel('Querying affiliate product database...')

      const prodResponse = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: keyword.trim(),
          platform: affiliatePlatform,
          limit: 5,
        }),
      })

      if (!prodResponse.ok) {
        const err = await prodResponse.json()
        throw new Error(err.error || 'Product fetch failed')
      }

      setProgress(50)
      const prodData = await prodResponse.json()

      if (prodData.commercial && prodData.products?.length > 0) {
        setProducts(prodData.products)
        setProgress(70)
        setProgressLabel('Generating product images...')

        // Fetch images for the products
        const imgResponse = await fetch('/api/images', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            keyword: keyword.trim(),
            products: prodData.products,
            sectionCount: prodData.products.length + 2,
            includeHero: true,
          }),
        })

        if (imgResponse.ok) {
          const imgData = await imgResponse.json()
          if (imgData.images?.length > 0) {
            setImages(imgData.images)
          }
        }

        setProgress(100)
        setProgressLabel(`Found ${prodData.products.length} products`)
        setCurrentStep('outline')

        toast.success(`Found ${prodData.products.length} trending products!`, {
          description: `Average price: $${prodData.averagePrice}. Ready for article generation.`,
        })
      } else {
        // Non-commercial keyword, skip products
        setProducts([])
        setImages([])
        setProgress(100)
        setCurrentStep('outline')
        toast.info('No commercial intent detected', {
          description: 'Product injection will be skipped. Generating standard article.',
        })
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Product fetch failed')
      setCurrentStep('outline')
      setProducts([])
      setImages([])
    }
  }, [keyword, affiliatePlatform])

  // ─── Step 3: Generate Article from Outline + Products ───
  const handleGenerateFromOutline = useCallback(async () => {
    setCurrentStep('generating')
    setProgress(0)
    setProgressLabel('Generating full article with product reviews...')
    setGeneratedArticle(null)

    try {
      setProgress(20)
      setProgressLabel('Writing SEO-optimized product reviews...')

      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          keyword: keyword.trim(),
          topic: topic.trim() || undefined,
          tone,
          length,
          affiliatePlatform,
          products: products && products.length > 0 ? products : undefined,
          language,
          intent,
        }),
      })

      setProgress(60)
      setProgressLabel('Building comparison table...')

      if (!response.ok) {
        const err = await response.json()
        // 403 = subscription / credits issue → trigger Upgrade dialog
        if (response.status === 403 && err.requiresUpgrade) {
          setUpgradeMessage(err.error)
          setSuggestedTier(err.suggestedTier || 'basic')
          setUpgradeOpen(true)
          throw new Error(err.error || 'Upgrade required')
        }
        // 402 = legacy insufficient credits (also open upgrade dialog)
        if (response.status === 402) {
          setUpgradeMessage(err.error)
          setSuggestedTier('basic')
          setUpgradeOpen(true)
          throw new Error(err.error || 'Insufficient credits')
        }
        throw new Error(err.error || 'Generation failed')
      }

      const data = await response.json()

      // Update local credit balance
      if (typeof data.creditsRemaining === 'number') {
        setCreditsRemaining(data.creditsRemaining)
      }

      // Track which AI provider served the request
      if (data.provider) {
        setProviderInfo({ provider: data.provider, configured: data.aiProviderConfigured ?? false })
      }

      setProgress(100)
      setProgressLabel('Article generated!')
      setCurrentStep('complete')

      setGeneratedArticle({
        title: data.title || outline?.suggestedTitle || 'Generated Article',
        content: data.content,
        excerpt: data.excerpt,
        wordCount: data.wordCount,
        seoScore: data.seoScore,
        keywords: data.keywords || outline?.targetKeywords || [],
        hasProducts: data.hasProducts,
        productCount: data.productCount,
        hasComparisonTable: data.hasComparisonTable,
        comparisonTable: data.comparisonTable,
        language: data.language,
        intent: data.intent,
        model: data.model,
        provider: data.provider,
        tokensUsed: data.tokensUsed,
        creditsRemaining: data.creditsRemaining,
        articleId: data.articleId,
      })

      toast.success('Article generated successfully!', {
        description: `${data.wordCount?.toLocaleString() || 0} words, SEO score ${data.seoScore || 'N/A'}${data.hasProducts ? `, ${data.productCount} product reviews` : ''}. Saved to your articles.`,
      })
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Generation failed')
      setCurrentStep('outline')
      setProgress(0)
    }
  }, [keyword, topic, tone, length, affiliatePlatform, products, outline, language, intent])

  // ─── Utility handlers ───
  const toggleSection = (index: number) => {
    setExpandedSections((prev) => {
      const next = new Set(prev)
      if (next.has(index)) next.delete(index)
      else next.add(index)
      return next
    })
  }

  const handleCopyContent = () => {
    if (generatedArticle) {
      navigator.clipboard.writeText(`# ${generatedArticle.title}\n\n${generatedArticle.content}`)
      toast.success('Copied to clipboard!')
    }
  }

  const handleSaveDraft = () => {
    // The article is already saved to the database by /api/generate,
    // so we just inform the user. In a future iteration, this button
    // could update draft status, edit content, etc.
    if (generatedArticle?.articleId) {
      toast.success('Article saved to your library!', {
        description: `Article ID: ${generatedArticle.articleId.slice(0, 8)}… — view it in History.`,
      })
    } else {
      toast.success('Article saved as draft!')
    }
  }

  const resetWorkflow = () => {
    setCurrentStep('idle')
    setProgress(0)
    setProgressLabel('')
    setCompetitorAnalysis(null)
    setOutline(null)
    setProducts(null as any)
    setImages(null as any)
    setGeneratedArticle(null)
    setFactCheckData(null)
    setExpandedSections(new Set())
    setSelectedProduct(null)
  }

  // ─── Markdown renderer with product-aware rendering ───
  const renderMarkdown = (content: string) =>
    content.split('\n').map((line, i) => {
      if (line.startsWith('### ')) return <h3 key={i} className="text-base font-semibold mt-4 mb-1">{line.replace('### ', '')}</h3>
      if (line.startsWith('## ')) return <h2 key={i} className="text-lg font-semibold mt-5 mb-2">{line.replace('## ', '')}</h2>
      if (line.startsWith('# ')) return <h1 key={i} className="text-xl font-bold mt-6 mb-2 first:mt-0">{line.replace('# ', '')}</h1>
      if (line.startsWith('- ')) return <li key={i} className="text-sm text-muted-foreground ml-4 list-disc">{line.replace('- ', '')}</li>
      if (line.startsWith('|') && line.trim().startsWith('|')) {
        // Markdown table row
        const cells = line.split('|').filter(c => c.trim()).map(c => c.trim())
        return (
          <div key={i} className="flex gap-2 text-xs py-1 border-b border-border/30">
            {cells.map((cell, ci) => (
              <span key={ci} className={`flex-1 ${cell.replace(/[*_]/g, '').includes('---') ? 'border-b border-border' : ''}`}>
                {cell.replace(/[*_]/g, '')}
              </span>
            ))}
          </div>
        )
      }
      if (line.includes('[AFFILIATE_LINK:')) {
        const name = line.match(/\[AFFILIATE_LINK:(.*?)\]/)?.[1] || 'product'
        return (
          <div key={i} className="my-3">
            <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors shadow-sm">
              <ShoppingCart className="h-4 w-4" />
              Check Price on {affiliatePlatform.charAt(0).toUpperCase() + affiliatePlatform.slice(1)} →
            </button>
          </div>
        )
      }
      if (line.startsWith('**') && line.endsWith('**')) return <p key={i} className="text-sm font-medium mt-2">{line.replace(/\*\*/g, '')}</p>
      if (line.trim() === '') return <div key={i} className="h-2" />
      return <p key={i} className="text-sm text-muted-foreground leading-relaxed">{line}</p>
    })

  // ─── Render ───
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Wand2 className="h-6 w-6 text-primary" />
            Generate Article
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            4-step AI workflow: Analyze → Products → Outline → Generate
          </p>
        </div>
        <div className="flex items-center gap-2">
          {creditsRemaining !== null && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge
                    variant="outline"
                    className={`text-xs cursor-help ${
                      creditsRemaining > 5
                        ? 'bg-green-500/10 text-green-600 border-green-500/20'
                        : creditsRemaining > 0
                          ? 'bg-amber-500/10 text-amber-600 border-amber-500/20'
                          : 'bg-red-500/10 text-red-600 border-red-500/20'
                    }`}
                  >
                    <Coins className="h-3 w-3 mr-1" />
                    {creditsRemaining} credits
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>Article generation costs 1 credit</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          {providerInfo && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Badge
                    variant="outline"
                    className={`text-xs cursor-help ${
                      providerInfo.provider === 'gemini'
                        ? 'bg-blue-500/10 text-blue-600 border-blue-500/20'
                        : 'bg-purple-500/10 text-purple-600 border-purple-500/20'
                    }`}
                  >
                    <Cpu className="h-3 w-3 mr-1" />
                    {providerInfo.provider === 'gemini' ? 'Gemini Live' : 'Z.AI Fallback'}
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  {providerInfo.configured
                    ? 'Gemini API key is configured'
                    : 'Gemini not configured — using z-ai fallback. Add GEMINI_API_KEY to .env for live mode.'}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
          {/* API Settings button — admin only */}
          {isAdmin && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
                  <Settings className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>API Settings (Admin)</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          )}
          {(currentStep !== 'idle') && (
            <Button variant="ghost" size="sm" onClick={resetWorkflow}>
              Start Over
            </Button>
          )}
        </div>
      </div>

      {/* API Settings Panel — admin only */}
      {showSettings && isAdmin && (
        <Card className="border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2"><Settings className="h-4 w-4" />API Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="gemini-key" className="flex items-center gap-2"><Brain className="h-3.5 w-3.5" />Gemini API Key</Label>
              <Input id="gemini-key" type="password" placeholder="AIzaSy..." value={geminiKey} onChange={(e) => setGeminiKey(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="serper-key" className="flex items-center gap-2"><Search className="h-3.5 w-3.5" />Serper.dev API Key</Label>
              <Input id="serper-key" type="password" placeholder="Optional: for real Google search results" value={serperKey} onChange={(e) => setSerperKey(e.target.value)} />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={handleSaveKeys}>Save Keys</Button>
              <Button size="sm" variant="outline" onClick={() => setShowSettings(false)}>Close</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Workflow Progress */}
      {(currentStep !== 'idle') && (
        <Card className="border-border/50">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground">{progressLabel}</span>
              <span className="text-xs text-muted-foreground">{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
            <div className="flex items-center justify-between mt-3 gap-1">
              {(['analyzing', 'products', 'outline', 'generating', 'complete'] as const).map((step) => {
                const stepIndex = ['analyzing', 'products', 'outline', 'generating', 'complete'].indexOf(step)
                const isActive = currentStep === step
                const isDone = ['analyzing', 'products', 'outline', 'generating', 'complete'].indexOf(currentStep) > stepIndex
                return (
                  <div key={step} className={`flex items-center gap-1 ${isActive ? 'text-primary' : isDone ? 'text-green-500' : 'text-muted-foreground/40'}`}>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${isActive ? 'border-primary bg-primary text-primary-foreground' : isDone ? 'border-green-500 bg-green-500 text-white' : 'border-muted-foreground/30'}`}>
                      {isDone ? <CheckCircle2 className="h-3 w-3" /> : stepIndex + 1}
                    </div>
                    <span className="text-[10px] font-medium hidden sm:inline capitalize">{step}</span>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ─── LEFT: Configuration Panel ─── */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="border-border/50">
            <CardHeader className="pb-4">
              <CardTitle className="text-base flex items-center gap-2"><Target className="h-4 w-4 text-primary" />Article Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="keyword">Target Keyword *</Label>
                <Input id="keyword" placeholder="e.g., best wireless headphones" value={keyword} onChange={(e) => setKeyword(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="topic">Topic / Angle</Label>
                <Input id="topic" placeholder="Optional: specific angle" value={topic} onChange={(e) => setTopic(e.target.value)} />
              </div>

              <Separator />

              <div className="space-y-2">
                <Label className="flex items-center gap-2"><Globe className="h-3.5 w-3.5" />Language</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ar">العربية (Arabic)</SelectItem>
                    <SelectItem value="es">Español (Spanish)</SelectItem>
                    <SelectItem value="fr">Français (French)</SelectItem>
                    <SelectItem value="de">Deutsch (German)</SelectItem>
                    <SelectItem value="it">Italiano (Italian)</SelectItem>
                    <SelectItem value="pt">Português (Portuguese)</SelectItem>
                    <SelectItem value="nl">Nederlands (Dutch)</SelectItem>
                    <SelectItem value="ru">Русский (Russian)</SelectItem>
                    <SelectItem value="zh">中文 (Chinese)</SelectItem>
                    <SelectItem value="ja">日本語 (Japanese)</SelectItem>
                    <SelectItem value="ko">한국어 (Korean)</SelectItem>
                    <SelectItem value="hi">हिन्दी (Hindi)</SelectItem>
                    <SelectItem value="tr">Türkçe (Turkish)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2"><Target className="h-3.5 w-3.5" />Content Intent</Label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setIntent('informational')}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      intent === 'informational'
                        ? 'border-primary bg-primary/5 shadow-sm'
                        : 'border-border hover:border-border/80'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <Info className="h-3.5 w-3.5 text-blue-500" />
                      <span className="text-xs font-medium">Informational</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground leading-tight">How-to, guides, tutorials</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIntent('commercial')}
                    className={`p-2.5 rounded-lg border text-left transition-all ${
                      intent === 'commercial'
                        ? 'border-primary bg-primary/5 shadow-sm'
                        : 'border-border hover:border-border/80'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <DollarSign className="h-3.5 w-3.5 text-green-500" />
                      <span className="text-xs font-medium">Commercial</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground leading-tight">Reviews, comparisons, buying</p>
                  </button>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Tone</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="casual">Casual & Friendly</SelectItem>
                    <SelectItem value="authoritative">Authoritative</SelectItem>
                    <SelectItem value="conversational">Conversational</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Article Length</Label>
                <Select value={length} onValueChange={setLength}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Short (~800 words)</SelectItem>
                    <SelectItem value="medium">Medium (~1,500 words)</SelectItem>
                    <SelectItem value="long">Long (~2,500 words)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label className="flex items-center gap-2"><DollarSign className="h-3.5 w-3.5" />Affiliate Platform</Label>
                <Select value={affiliatePlatform} onValueChange={setAffiliatePlatform}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="amazon">Amazon Associates</SelectItem>
                    <SelectItem value="ebay">eBay Partner Network</SelectItem>
                    <SelectItem value="cj">CJ Affiliate</SelectItem>
                    <SelectItem value="shareasale">ShareASale</SelectItem>
                    <SelectItem value="impact">Impact Radius</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="fact-check" className="flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5" />Live Fact-Check</Label>
                <Switch id="fact-check" checked={enableFactCheck} onCheckedChange={setEnableFactCheck} />
              </div>
              <p className="text-[11px] text-muted-foreground">Uses Gemini Google Search grounding to verify facts in real-time.</p>

              {currentStep === 'idle' && (
                <Button className="w-full" onClick={handleAnalyze} disabled={!keyword.trim()}>
                  <Sparkles className="h-4 w-4 mr-2" />
                  1. Analyze Competitors
                </Button>
              )}
              {currentStep === 'products' && (
                <Button className="w-full" onClick={handleFetchProducts}>
                  <Package className="h-4 w-4 mr-2" />
                  2. Fetch Products & Images
                </Button>
              )}
              {(currentStep === 'outline' || currentStep === 'analyzing') && (
                <Button className="w-full" onClick={handleGenerateFromOutline}>
                  <FileText className="h-4 w-4 mr-2" />
                  {products && products.length > 0 ? '3. Generate with Product Reviews' : '3. Generate Article'}
                </Button>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ─── RIGHT: Results Panel ─── */}
        <div className="lg:col-span-2 space-y-4">
          {/* Step Results: Competitor Analysis */}
          {competitorAnalysis && (
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2"><Search className="h-4 w-4 text-blue-500" />Competitor Analysis</CardTitle>
                <CardDescription className="text-xs">
                  {competitorAnalysis.pagesAnalyzed} pages analyzed • {competitorAnalysis.averageWordCount} avg words • {competitorAnalysis.informationGaps.length} gaps found
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex flex-wrap gap-1.5">
                  {competitorAnalysis.commonTopics.slice(0, 8).map((t, i) => (
                    <Badge key={i} variant="secondary" className="text-[10px]">{t}</Badge>
                  ))}
                </div>
                <div>
                  <p className="text-xs font-medium mb-1.5 flex items-center gap-1"><Lightbulb className="h-3 w-3 text-amber-500" />Information Gaps</p>
                  <div className="flex flex-wrap gap-1.5">
                    {competitorAnalysis.informationGaps.slice(0, 6).map((gap, i) => (
                      <Badge key={i} variant="outline" className="text-[10px] border-amber-500/30 text-amber-600">{gap}</Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step Results: Products */}
          {products && products.length > 0 && (
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2"><Package className="h-4 w-4 text-green-500" />Trending Products ({products.length})</CardTitle>
                <CardDescription className="text-xs">
                  Avg: ${Math.round(products.reduce((s, p) => s + p.price, 0) / products.length)} • Range: ${Math.min(...products.map(p => p.price))} – ${Math.max(...products.map(p => p.price))}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
                  {products.map((product, idx) => (
                    <div
                      key={product.id}
                      className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${selectedProduct?.id === product.id ? 'border-primary bg-primary/5' : 'border-border/50 hover:border-border'}`}
                      onClick={() => setSelectedProduct(selectedProduct?.id === product.id ? null : product)}
                    >
                      {/* Product Image */}
                      <div className="w-12 h-12 rounded-md overflow-hidden bg-muted flex-shrink-0">
                        {images && images[idx + 1] ? (
                          <img src={images[idx + 1].url} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center"><Package className="h-5 w-5 text-muted-foreground" /></div>
                        )}
                      </div>
                      {/* Product Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-medium truncate">{product.name}</p>
                          {product.badge && (
                            <Badge variant="outline" className="text-[9px] px-1 py-0 border-primary/30 text-primary shrink-0">{product.badge}</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-xs font-bold text-primary">${product.price}</span>
                          {product.originalPrice && (
                            <span className="text-[10px] text-muted-foreground line-through">${product.originalPrice}</span>
                          )}
                          <div className="flex items-center gap-0.5">
                            <Star className="h-2.5 w-2.5 fill-amber-400 text-amber-400" />
                            <span className="text-[10px]">{product.rating}</span>
                          </div>
                        </div>
                      </div>
                      <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${selectedProduct?.id === product.id ? 'rotate-180' : ''}`} />
                    </div>
                  ))}
                </div>

                {/* Selected Product Detail */}
                {selectedProduct && (
                  <div className="border-t border-border/50 pt-3 mt-2 space-y-3">
                    <div className="flex items-start gap-3">
                      {images && images[products.indexOf(selectedProduct) + 1] && (
                        <img src={images[products.indexOf(selectedProduct) + 1].url} alt={selectedProduct.name} className="w-24 h-24 rounded-lg object-cover" loading="lazy" />
                      )}
                      <div className="flex-1">
                        <h4 className="text-sm font-semibold">{selectedProduct.name}</h4>
                        <p className="text-xs text-muted-foreground">{selectedProduct.brand} • {selectedProduct.reviewCount.toLocaleString()} reviews</p>
                      </div>
                    </div>
                    {/* Pros & Cons */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <p className="text-[11px] font-medium flex items-center gap-1 text-green-600"><ThumbsUp className="h-3 w-3" />Pros</p>
                        {selectedProduct.pros.map((pro, i) => (
                          <p key={i} className="text-[11px] text-muted-foreground flex items-start gap-1"><CheckCircle2 className="h-3 w-3 text-green-500 mt-0.5 shrink-0" />{pro}</p>
                        ))}
                      </div>
                      <div className="space-y-1">
                        <p className="text-[11px] font-medium flex items-center gap-1 text-red-500"><ThumbsDown className="h-3 w-3" />Cons</p>
                        {selectedProduct.cons.map((con, i) => (
                          <p key={i} className="text-[11px] text-muted-foreground flex items-start gap-1"><AlertTriangle className="h-3 w-3 text-red-400 mt-0.5 shrink-0" />{con}</p>
                        ))}
                      </div>
                    </div>
                    {/* Key Specs */}
                    <div>
                      <p className="text-[11px] font-medium mb-1.5">Key Specifications</p>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                        {Object.entries(selectedProduct.specs).slice(0, 6).map(([key, val]) => (
                          <div key={key} className="flex items-center justify-between text-[10px]">
                            <span className="text-muted-foreground">{key}</span>
                            <span className="font-medium">{val}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Comparison Table */}
                {products.length >= 2 && (
                  <div className="border-t border-border/50 pt-3 mt-2">
                    <p className="text-xs font-medium mb-2 flex items-center gap-1.5"><BarChart3 className="h-3.5 w-3.5" />Quick Comparison</p>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-[10px] h-8">Feature</TableHead>
                            {products.slice(0, 4).map((p) => (
                              <TableHead key={p.id} className="text-[10px] h-8 text-center">{p.brand.split(' ')[0]}</TableHead>
                            ))}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell className="text-[10px] font-medium py-1.5">Price</TableCell>
                            {products.slice(0, 4).map((p) => (
                              <TableCell key={p.id} className="text-[10px] text-center py-1.5 font-bold text-primary">${p.price}</TableCell>
                            ))}
                          </TableRow>
                          <TableRow>
                            <TableCell className="text-[10px] font-medium py-1.5">Rating</TableCell>
                            {products.slice(0, 4).map((p) => (
                              <TableCell key={p.id} className="text-[10px] text-center py-1.5">
                                <div className="flex items-center justify-center gap-0.5">
                                  <Star className="h-2.5 w-2.5 fill-amber-400 text-amber-400" />
                                  {p.rating}
                                </div>
                              </TableCell>
                            ))}
                          </TableRow>
                          {/* Spec rows - pick first 3 spec keys that exist in all products */}
                          {getCommonSpecKeys(products).slice(0, 3).map((specKey) => (
                            <TableRow key={specKey}>
                              <TableCell className="text-[10px] font-medium py-1.5">{specKey}</TableCell>
                              {products.slice(0, 4).map((p) => (
                                <TableCell key={p.id} className="text-[10px] text-center py-1.5">{p.specs[specKey] || '—'}</TableCell>
                              ))}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Non-commercial notice */}
          {products && products.length === 0 && currentStep !== 'idle' && currentStep !== 'analyzing' && (
            <Card className="border-border/50">
              <CardContent className="py-6 flex items-center gap-3 justify-center">
                <Info className="h-4 w-4 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">No commercial products found. Standard article will be generated.</p>
              </CardContent>
            </Card>
          )}

          {/* Step Results: Outline */}
          {outline && outline.sections.length > 0 && currentStep !== 'idle' && currentStep !== 'analyzing' && currentStep !== 'products' && (
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2"><Zap className="h-4 w-4 text-purple-500" />Article Outline</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px]">{outline.sections.length} sections</Badge>
                    <Badge variant="outline" className="text-[10px] border-green-500/30 text-green-600">
                      <TrendingUp className="h-3 w-3 mr-0.5" />Score: {outline.informationGainScore}
                    </Badge>
                  </div>
                </div>
                {outline.suggestedTitle && <p className="text-xs font-medium mt-2">{outline.suggestedTitle}</p>}
              </CardHeader>
              <CardContent className="space-y-1.5">
                {outline.sections.map((section, idx) => (
                  <div key={idx} className="border border-border/40 rounded-lg overflow-hidden">
                    <button
                      className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-muted/50 transition-colors"
                      onClick={() => toggleSection(idx)}
                    >
                      {expandedSections.has(idx) ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                      <span className="text-xs font-medium flex-1">{section.heading}</span>
                      <Badge variant="secondary" className="text-[9px]">{section.subsections?.length || 0} sub</Badge>
                      {section.competitiveAdvantage && (
                        <TooltipProvider><Tooltip><TooltipTrigger asChild><Lightbulb className="h-3 w-3 text-amber-500" /></TooltipTrigger><TooltipContent className="text-xs max-w-60">{section.competitiveAdvantage}</TooltipContent></Tooltip></TooltipProvider>
                      )}
                    </button>
                    {expandedSections.has(idx) && (
                      <div className="px-3 pb-2 space-y-1 border-t border-border/30">
                        <p className="text-[10px] text-muted-foreground mt-1.5 italic">{section.purpose}</p>
                        {section.subsections?.map((sub, si) => (
                          <div key={si} className="ml-3 py-0.5">
                            <p className="text-[11px] font-medium">{sub.heading}</p>
                            {sub.keyPoints?.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-0.5">
                                {sub.keyPoints.slice(0, 3).map((kp, kpi) => (
                                  <Badge key={kpi} variant="outline" className="text-[9px]">{kp}</Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Step Results: Generated Article */}
          {generatedArticle && (
            <Card className="border-border/50">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <FileText className="h-4 w-4 text-primary" />
                    Generated Article
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-[10px]">{generatedArticle.wordCount.toLocaleString()} words</Badge>
                    <Badge variant="outline" className="text-[10px] border-green-500/30 text-green-600">SEO: {generatedArticle.seoScore}</Badge>
                    {generatedArticle.hasProducts && (
                      <Badge variant="outline" className="text-[10px] border-blue-500/30 text-blue-600">
                        <Package className="h-3 w-3 mr-0.5" />{generatedArticle.productCount} products
                      </Badge>
                    )}
                    {generatedArticle.hasComparisonTable && (
                      <Badge variant="outline" className="text-[10px] border-purple-500/30 text-purple-600">
                        <BarChart3 className="h-3 w-3 mr-0.5" />Table
                      </Badge>
                    )}
                    {generatedArticle.language && (
                      <Badge variant="outline" className="text-[10px] border-amber-500/30 text-amber-600">
                        <Globe className="h-3 w-3 mr-0.5" />{generatedArticle.language.toUpperCase()}
                      </Badge>
                    )}
                    {generatedArticle.intent && (
                      <Badge variant="outline" className={`text-[10px] ${generatedArticle.intent === 'commercial' ? 'border-green-500/30 text-green-600' : 'border-blue-500/30 text-blue-600'}`}>
                        {generatedArticle.intent === 'commercial' ? <DollarSign className="h-3 w-3 mr-0.5" /> : <Info className="h-3 w-3 mr-0.5" />}
                        {generatedArticle.intent}
                      </Badge>
                    )}
                    {generatedArticle.provider && (
                      <Badge variant="outline" className={`text-[10px] ${generatedArticle.provider === 'gemini' ? 'border-blue-500/30 text-blue-600' : 'border-purple-500/30 text-purple-600'}`}>
                        <Cpu className="h-3 w-3 mr-0.5" />{generatedArticle.provider === 'gemini' ? 'Gemini' : 'Z.AI'}
                      </Badge>
                    )}
                    {typeof generatedArticle.creditsRemaining === 'number' && (
                      <Badge variant="outline" className="text-[10px] border-amber-500/30 text-amber-600">
                        <Coins className="h-3 w-3 mr-0.5" />{generatedArticle.creditsRemaining} left
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Article Title */}
                <h2 className="text-lg font-bold">{generatedArticle.title}</h2>

                {/* Meta info */}
                <div className="flex flex-wrap gap-1.5">
                  {generatedArticle.keywords.map((kw, i) => (
                    <Badge key={i} variant="secondary" className="text-[10px]">{kw}</Badge>
                  ))}
                </div>

                {/* Hero Image */}
                {images && images.length > 0 && (
                  <div className="rounded-lg overflow-hidden border border-border/30">
                    <img src={images[0].url} alt={images[0].seoAltText} className="w-full h-48 object-cover" loading="lazy" />
                    <p className="text-[10px] text-muted-foreground px-2 py-1 bg-muted/50">{images[0].seoAltText}</p>
                  </div>
                )}

                {/* Article Content */}
                <div className="prose prose-sm max-w-none">
                  {renderMarkdown(generatedArticle.content)}
                </div>

                {/* Inline Product Cards in Article */}
                {products.length > 0 && generatedArticle.hasProducts && (
                  <div className="border-t border-border/50 pt-4 mt-4">
                    <p className="text-xs font-medium mb-3 flex items-center gap-1.5"><Package className="h-3.5 w-3.5" />Products Reviewed in This Article</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {products.map((product, idx) => (
                        <div key={product.id} className="flex items-center gap-2.5 p-2 rounded-lg border border-border/40 bg-muted/30">
                          <div className="w-10 h-10 rounded overflow-hidden bg-muted flex-shrink-0">
                            {images && images[idx + 1] ? (
                              <img src={images[idx + 1].url} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center"><ImageIcon className="h-4 w-4 text-muted-foreground" /></div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] font-medium truncate">{product.name}</p>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold">${product.price}</span>
                              <Star className="h-2.5 w-2.5 fill-amber-400 text-amber-400" />
                              <span className="text-[10px]">{product.rating}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2 border-t border-border/30">
                  <Button size="sm" onClick={handleCopyContent}>
                    <Copy className="h-3.5 w-3.5 mr-1.5" />Copy Content
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleSaveDraft}>
                    <Save className="h-3.5 w-3.5 mr-1.5" />Save Draft
                  </Button>
                  <Button size="sm" variant="outline" className="ml-auto">
                    <ExternalLink className="h-3.5 w-3.5 mr-1.5" />Publish
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Empty State */}
          {currentStep === 'idle' && (
            <Card className="border-border/50">
              <CardContent className="py-16 flex flex-col items-center justify-center text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 mb-4">
                  <Wand2 className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-sm font-semibold mb-1">Ready to Generate</h3>
                <p className="text-xs text-muted-foreground max-w-sm">
                  Enter a target keyword and configure your settings. The AI will analyze competitors, fetch products, and generate a complete article with affiliate links.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Upgrade Plan dialog — triggered on 403 from /api/generate */}
      <UpgradeDialog
        open={upgradeOpen}
        onOpenChange={setUpgradeOpen}
        suggestedTier={suggestedTier}
        reasonMessage={upgradeMessage}
        onUpgraded={async () => {
          // Refetch credit balance after a successful demo upgrade
          try {
            const res = await fetch('/api/credits')
            if (res.ok) {
              const data = await res.json()
              if (typeof data.balance === 'number') setCreditsRemaining(data.balance)
            }
          } catch {}
          setUpgradeMessage(undefined)
          setSuggestedTier(null)
        }}
      />
    </div>
  )
}

// ─── Helper Functions ───

/**
 * Get spec keys that exist in at least 2 products (for comparison table).
 */
function getCommonSpecKeys(products: Product[]): string[] {
  const keyCount = new Map<string, number>()
  for (const p of products) {
    for (const key of Object.keys(p.specs)) {
      keyCount.set(key, (keyCount.get(key) || 0) + 1)
    }
  }
  return Array.from(keyCount.entries())
    .filter(([, count]) => count >= 2)
    .sort((a, b) => b[1] - a[1])
    .map(([key]) => key)
}
