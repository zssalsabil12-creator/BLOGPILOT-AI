/**
 * Rate Limiting Utility
 *
 * Lightweight in-memory rate limiter using a sliding-window-per-key strategy.
 * Designed to protect AI generation and scraping endpoints from API abuse,
 * cost spikes, and accidental infinite loops.
 *
 * Features:
 *   - IP-based keying (falls back to user id when authenticated)
 *   - Sliding window with weighted cost support (1 request = 1 token by default)
 *   - Stale entry eviction on every check (no memory leaks)
 *   - Zero external dependencies (no Redis required for single-instance deploys)
 *
 * Limitations:
 *   - Per-process memory. In a multi-instance deployment, replace the Map
 *     with a Redis-backed store (ioredis + a sliding-window script).
 *   - Not suitable for distributed denial-of-service mitigation — use a
 *     dedicated WAF / Cloudflare-style layer for that.
 *
 * Usage in a Route Handler:
 *
 *   import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
 *
 *   const limited = await rateLimit(request, RATE_LIMITS.generate)
 *   if (limited) return limited  // 429 response is already built
 *
 *   // ... otherwise proceed with the handler
 */

import { NextResponse } from 'next/server'

/* -------------------------------------------------------------------------- */
/*                              Public config                                 */
/* -------------------------------------------------------------------------- */

export interface RateLimitConfig {
  /** Unique name for this limiter (used in error logs + headers). */
  name: string
  /** Max tokens allowed inside the window. */
  limit: number
  /** Window duration in milliseconds. */
  windowMs: number
  /** Optional per-token cost for weighted requests (default 1). */
  cost?: number
}

/**
 * Pre-defined limiters for the BlogPilot AI endpoints.
 * Tuned to balance legitimate use vs. cost-control — every AI call hits
 * a paid upstream (Gemini / z-ai / Serper / Jina), so we err on the
 * conservative side.
 */
export const RATE_LIMITS = {
  /** Article generation — the most expensive operation. */
  generate: {
    name: 'generate',
    limit: 10,
    windowMs: 60 * 1000, // 10 / min
  },
  /** Competitor analysis — scrapes + AI. */
  analyze: {
    name: 'analyze',
    limit: 8,
    windowMs: 60 * 1000, // 8 / min
  },
  /** Outline generation — competitor scrape + AI + optional fact-check. */
  generateOutline: {
    name: 'generate-outline',
    limit: 8,
    windowMs: 60 * 1000,
  },
  /** Standalone fact-check — uses Gemini with Google Search grounding. */
  factCheck: {
    name: 'fact-check',
    limit: 12,
    windowMs: 60 * 1000,
  },
  /** Product fetch — currently mock, but will hit Amazon/eBay APIs in prod. */
  products: {
    name: 'products',
    limit: 20,
    windowMs: 60 * 1000,
  },
  /** Image search — uses Unsplash + placeholders. */
  images: {
    name: 'images',
    limit: 20,
    windowMs: 60 * 1000,
  },
  /** Generic read endpoints (article list, credits, etc.). */
  read: {
    name: 'read',
    limit: 60,
    windowMs: 60 * 1000,
  },
  /** Auth — strict to slow down credential stuffing. */
  auth: {
    name: 'auth',
    limit: 10,
    windowMs: 60 * 1000,
  },
  /** Stripe checkout / portal — strict to prevent abuse. */
  stripe: {
    name: 'stripe',
    limit: 10,
    windowMs: 60 * 1000,
  },
} as const

/* -------------------------------------------------------------------------- */
/*                              In-memory store                               */
/* -------------------------------------------------------------------------- */

interface BucketEntry {
  /** Timestamp of the request (ms since epoch). */
  ts: number
  /** Tokens consumed by this entry. */
  cost: number
}

/**
 * Map of `limiterName:key` → request timestamps.
 * We evict stale entries on every check to keep memory bounded.
 */
const store = new Map<string, BucketEntry[]>()

/** Max entries per limiter (safety cap for memory). */
const MAX_ENTRIES_PER_LIMITER = 10_000

/** Periodic cleanup threshold — once we cross this, run a sweep. */
const CLEANUP_THRESHOLD = 5_000

/* -------------------------------------------------------------------------- */
/*                              Helpers                                       */
/* -------------------------------------------------------------------------- */

/**
 * Resolve the rate-limit key from a request.
 *
 * Strategy:
 *   1. Authenticated user id (from `x-session-token` / `x-user-id` headers)
 *      — when present, we rate-limit per-user rather than per-IP so users
 *      behind a shared corporate NAT aren't unfairly throttled.
 *   2. `x-forwarded-for` (when behind Caddy / a proxy)
 *   3. `request.headers.get('x-real-ip')`
 *   4. Fallback: 'anonymous'
 */
function resolveKey(request: Request): string {
  // Authenticated user takes priority
  const sessionToken = request.headers.get('x-session-token')
  if (sessionToken && sessionToken.length > 0 && sessionToken.length < 200) {
    return `user:${sessionToken}`
  }
  const userId = request.headers.get('x-user-id')
  if (userId && userId.length > 0 && userId.length < 200) {
    return `user:${userId}`
  }
  const bearer = request.headers.get('authorization')
  if (bearer?.startsWith('Bearer ')) {
    const token = bearer.slice('Bearer '.length).trim()
    if (token.length > 0 && token.length < 200) return `user:${token}`
  }

  // IP-based keying
  const xff = request.headers.get('x-forwarded-for')
  if (xff) {
    // Take the first IP in the chain (closest to the client)
    const first = xff.split(',')[0].trim()
    if (first) return `ip:${first}`
  }
  const realIp = request.headers.get('x-real-ip')
  if (realIp) return `ip:${realIp}`

  return 'ip:anonymous'
}

/**
 * Evict stale entries across all limiters. Called opportunistically.
 */
function evictStale(now: number) {
  if (store.size < CLEANUP_THRESHOLD) return
  for (const [key, entries] of store.entries()) {
    // Keep only entries from the last 5 minutes max — any limiter window
    // we use is ≤ 5 min, so older entries are dead weight.
    const cutoff = now - 5 * 60 * 1000
    const fresh = entries.filter((e) => e.ts > cutoff)
    if (fresh.length === 0) {
      store.delete(key)
    } else if (fresh.length !== entries.length) {
      store.set(key, fresh)
    }
  }
}

/* -------------------------------------------------------------------------- */
/*                              Public API                                    */
/* -------------------------------------------------------------------------- */

export interface RateLimitResult {
  allowed: boolean
  /** Tokens remaining in the current window. */
  remaining: number
  /** Unix ms timestamp when the oldest entry expires (Retry-After hint). */
  resetAt: number
  /** Total tokens used in the current window (including this request). */
  used: number
  /** Key used for the limiter (for logging). */
  key: string
}

/**
 * Check whether a request should be allowed under the given limiter.
 * Mutates the bucket in-place when allowed.
 *
 * Pass `cost` to consume more than 1 token (e.g., longer articles).
 */
export function checkRateLimit(
  request: Request,
  config: RateLimitConfig,
  cost: number = 1
): RateLimitResult {
  const now = Date.now()
  const windowStart = now - config.windowMs
  const key = `${config.name}:${resolveKey(request)}`

  evictStale(now)

  const entries = store.get(key) || []
  // Drop entries outside the sliding window
  const fresh = entries.filter((e) => e.ts > windowStart)

  // Sum tokens used in the current window
  const used = fresh.reduce((sum, e) => sum + e.cost, 0)

  if (used + cost > config.limit) {
    // Find when the oldest entry will expire → earliest retry time
    const oldest = fresh.length > 0 ? Math.min(...fresh.map((e) => e.ts)) : now
    const resetAt = oldest + config.windowMs
    return {
      allowed: false,
      remaining: Math.max(0, config.limit - used),
      resetAt,
      used,
      key,
    }
  }

  // Record this request
  fresh.push({ ts: now, cost })
  // Cap memory per limiter key
  if (fresh.length > MAX_ENTRIES_PER_LIMITER) {
    fresh.splice(0, fresh.length - MAX_ENTRIES_PER_LIMITER)
  }
  store.set(key, fresh)

  return {
    allowed: true,
    remaining: Math.max(0, config.limit - used - cost),
    resetAt: now + config.windowMs,
    used: used + cost,
    key,
  }
}

/**
 * Convenience wrapper: returns a NextResponse (429) if rate-limited,
 * or `null` if the request is allowed.
 *
 * Use this in route handlers as:
 *
 *   const blocked = await rateLimit(request, RATE_LIMITS.generate)
 *   if (blocked) return blocked
 */
export function rateLimit(
  request: Request,
  config: RateLimitConfig,
  cost: number = 1
): NextResponse | null {
  const result = checkRateLimit(request, config, cost)

  if (result.allowed) return null

  // Compute retry-after in seconds (at least 1)
  const retryAfterSec = Math.max(
    1,
    Math.ceil((result.resetAt - Date.now()) / 1000)
  )

  // Standard rate-limit response — see RFC drafts for 429 + RateLimit-* headers
  return NextResponse.json(
    {
      error:
        'Too many requests. Please slow down and try again in a moment.',
      code: 'rate_limited',
      retryAfter: retryAfterSec,
      // Don't leak the underlying key (could be a user id) — expose only
      // the limiter name for debugging.
      limiter: config.name,
      limit: config.limit,
    },
    {
      status: 429,
      headers: {
        'Retry-After': String(retryAfterSec),
        'X-RateLimit-Limit': String(config.limit),
        'X-RateLimit-Remaining': String(result.remaining),
        'X-RateLimit-Reset': String(Math.floor(result.resetAt / 1000)),
      },
    }
  )
}

/**
 * Reset rate-limit state for a specific key. Mostly useful in tests.
 */
export function resetRateLimit(config: RateLimitConfig, request: Request) {
  const key = `${config.name}:${resolveKey(request)}`
  store.delete(key)
}

/**
 * Reset all rate-limit state. Mostly useful in tests.
 */
export function resetAllRateLimits() {
  store.clear()
}
