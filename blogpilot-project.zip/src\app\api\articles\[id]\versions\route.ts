import { NextResponse } from 'next/server';
import { getCurrentUserId } from '@/lib/auth';
import { listVersions, restoreVersion } from '@/lib/content-versions';

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const versions = await listVersions(userId, id);
    return NextResponse.json({ ok: true, data: { versions } });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 500;
    return NextResponse.json({ ok: false, error: error?.message || 'Unable to load versions' }, { status });
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = getCurrentUserId(req);
  if (!userId) {
    return NextResponse.json({ ok: false, error: 'Authentication required' }, { status: 401 });
  }

  const { id } = await params;

  let body: unknown = {};
  try {
    body = await req.json();
  } catch {}

  const versionId = (body as any)?.versionId;
  if (typeof versionId !== 'string' || !versionId) {
    return NextResponse.json({ ok: false, error: 'versionId is required' }, { status: 400 });
  }

  try {
    const result = await restoreVersion(userId, id, versionId);

    await import('@/lib/agent-governance').then(g =>
      g.logActivity({
        userId,
        agent: 'system',
        action: 'restore-version',
        targetType: 'article',
        targetId: id,
        reason: `Human restored version v${result.restoredFrom}`,
      }),
    );

    return NextResponse.json({ ok: true, data: result });
  } catch (error: any) {
    const status = typeof error?.statusCode === 'number' ? error.statusCode : 500;
    return NextResponse.json({ ok: false, error: error?.message || 'Restore failed' }, { status });
  }
}
