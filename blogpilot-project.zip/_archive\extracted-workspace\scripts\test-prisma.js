const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()
async function main() {
  console.log('Testing Prisma connection...')
  const users = await prisma.user.findMany({ take: 1 })
  console.log('Found users:', users.length)
  await prisma.$disconnect()
  console.log('Done')
}
main().catch(e => { console.error('PRISMA ERROR:', e.message); process.exit(1) })
